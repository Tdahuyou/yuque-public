
# Chapter 001

- [ ] classroom
- [ ] window
- [ ] blackboard
- [ ] light
- [ ] picture
- [ ] door
- [ ] teacher's desk
- [ ] computer
- [ ] fan
- [ ] wall
- [ ] floor
- [ ] really
- [ ] near
- [ ] TV
- [ ] clean
- [ ] help
- [ ] schoolbag
- [ ] maths book
- [ ] English book
- [ ] Chinese book

# Chapter 002

- [ ] storybook
- [ ] candy
- [ ] notebook
- [ ] toy
- [ ] key
- [ ] wow
- [ ] lost
- [ ] so much
- [ ] cute
- [ ] strong
- [ ] friendly
- [ ] quiet
- [ ] hair
- [ ] shoe
- [ ] glasses
- [ ] his
- [ ] or
- [ ] right
- [ ] hat
- [ ] her

# Chapter 003

- [ ] bedroom
- [ ] living room
- [ ] study
- [ ] kitchen
- [ ] bathroom
- [ ] bed
- [ ] phone
- [ ] table
- [ ] sofa
- [ ] fridge
- [ ] find
- [ ] them
- [ ] beef
- [ ] chicken
- [ ] noodles
- [ ] soup
- [ ] vegetable
- [ ] chopsticks
- [ ] bowl
- [ ] fork

# Chapter 004

- [ ] knife
- [ ] spoon
- [ ] dinner
- [ ] ready
- [ ] help yourself
- [ ] pass
- [ ] try
- [ ] parents
- [ ] cousin
- [ ] uncle
- [ ] aunt
- [ ] baby brother
- [ ] doctor
- [ ] cook
- [ ] driver
- [ ] farmer
- [ ] nurse
- [ ] people
- [ ] but
- [ ] little

# Chapter 005

- [ ] puppy
- [ ] football player
- [ ] job
- [ ] basketball

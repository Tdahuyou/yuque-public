
# Chapter 001

- [ ] characteristic
- [ ] radium
- [ ] painter
- [ ] put forward
- [ ] scientific
- [ ] conclude
- [ ] conclusion
- [ ] draw a conclusion
- [ ] analyse
- [ ] infect
- [ ] infectious
- [ ] cholera
- [ ] defeat
- [ ] expert
- [ ] attend
- [ ] physician
- [ ] expose
- [ ] expose…to
- [ ] deadly
- [ ] cure

# Chapter 002

- [ ] outbreak
- [ ] challenge
- [ ] victim
- [ ] absorb
- [ ] suspect
- [ ] enquiry
- [ ] neighbourhood
- [ ] severe
- [ ] clue
- [ ] pump
- [ ] Cambridge
- [ ] foresee
- [ ] investigate
- [ ] investigation
- [ ] blame
- [ ] pollute
- [ ] handle
- [ ] germ
- [ ] link
- [ ] link…to…

# Chapter 003

- [ ] announce
- [ ] certainty
- [ ] instruct
- [ ] responsible
- [ ] construct
- [ ] construction
- [ ] contribute
- [ ] apart from
- [ ] firework
- [ ] chart
- [ ] creative
- [ ] co-operative
- [ ] positive
- [ ] （be）strict with…
- [ ] Nicolaus Copernicus
- [ ] revolutionary
- [ ] movement
- [ ] make sense
- [ ] backward
- [ ] loop

# Chapter 004

- [ ] privately
- [ ] spin
- [ ] brightness
- [ ] enthusiastic
- [ ] cautious
- [ ] reject
- [ ] universe
- [ ] unite
- [ ] kingdom
- [ ] consist
- [ ] consist of
- [ ] London Heathrow Airport
- [ ] province
- [ ] River Avon
- [ ] River Thames
- [ ] River Severn
- [ ] divide…into
- [ ] Wales
- [ ] Scotland
- [ ] Northern Ireland

# Chapter 005

- [ ] clarify
- [ ] accomplish
- [ ] conflict
- [ ] unwilling
- [ ] break away
- [ ] break away from
- [ ] union
- [ ] the Union Jack
- [ ] credit
- [ ] to one’s credit
- [ ] currency
- [ ] institution
- [ ] educational
- [ ] convenience
- [ ] rough
- [ ] roughly
- [ ] Midlands
- [ ] nationwide
- [ ] attract
- [ ] historical

# Chapter 006

- [ ] architecture
- [ ] Roman
- [ ] collection
- [ ] administration
- [ ] port
- [ ] Anglo-Saxon
- [ ] Norman
- [ ] Viking
- [ ] countryside
- [ ] enjoyable
- [ ] leave out
- [ ] opportunity
- [ ] description
- [ ] fax
- [ ] possibility
- [ ] plus
- [ ] quarrel
- [ ] alike
- [ ] take the place of
- [ ] break down

# Chapter 007

- [ ] arrange
- [ ] wedding
- [ ] fold
- [ ] sightseeing
- [ ] delight
- [ ] royal
- [ ] uniform
- [ ] St Paul’s Cathedral
- [ ] splendid
- [ ] Westminster Abbey
- [ ] statue
- [ ] Buckingham  Palace
- [ ] Greenwich
- [ ] longitude
- [ ] imaginary
- [ ] navigation
- [ ] Highgate Cemetery
- [ ] communism
- [ ] original
- [ ] thrill

# Chapter 008

- [ ] pot
- [ ] error
- [ ] tense
- [ ] consistent
- [ ] aspect
- [ ] impression
- [ ] take up
- [ ] constant
- [ ] constantly
- [ ] jet
- [ ] jet lag
- [ ] flashback
- [ ] previous
- [ ] uncertain
- [ ] guide
- [ ] tablet
- [ ] expertise
- [ ] capsule
- [ ] steward
- [ ] stewardess

# Chapter 009

- [ ] opening
- [ ] sideways
- [ ] surrounding
- [ ] tolerate
- [ ] combination
- [ ] lack
- [ ] adjustment
- [ ] mask
- [ ] be back on one’s feet
- [ ] hover
- [ ] carriage
- [ ] press
- [ ] fasten
- [ ] belt
- [ ] safety belt
- [ ] lose sight of…
- [ ] sweep up
- [ ] flash
- [ ] switch
- [ ] timetable

# Chapter 010

- [ ] exhausted
- [ ] slide into
- [ ] optimistic
- [ ] pessimistic
- [ ] speed up
- [ ] pedal
- [ ] alien
- [ ] mud
- [ ] desert
- [ ] enormous
- [ ] imitate
- [ ] moveable
- [ ] citizen
- [ ] typist
- [ ] typewriter
- [ ] postage
- [ ] postcode
- [ ] button
- [ ] instant
- [ ] receiver

# Chapter 011

- [ ] efficiency
- [ ] efficient
- [ ] ribbon
- [ ] dustbin
- [ ] dispose
- [ ] disposal
- [ ] ecology
- [ ] greedy
- [ ] swallow
- [ ] material
- [ ] recycle
- [ ] manufacture
- [ ] goods
- [ ] etc
- [ ] representative
- [ ] settlement
- [ ] motivation
- [ ] journalist
- [ ] involve
- [ ] editor

# Chapter 012

- [ ] photograph
- [ ] photographer
- [ ] photography
- [ ] unforgettable
- [ ] assignment
- [ ] delighted
- [ ] admirable
- [ ] unusual
- [ ] assist
- [ ] assistant
- [ ] submit
- [ ] profession
- [ ] professional
- [ ] colleague
- [ ] eager
- [ ] concentrate
- [ ] concentrate on
- [ ] amateur
- [ ] update
- [ ] acquire

# Chapter 013

- [ ] assess
- [ ] inform
- [ ] deadline
- [ ] interviewee
- [ ] meanwhile
- [ ] depend on
- [ ] case
- [ ] accuse
- [ ] accuse…of
- [ ] accusation
- [ ] deliberately
- [ ] so as to (do sth)
- [ ] deny
- [ ] sceptical
- [ ] guilty
- [ ] dilemma
- [ ] demand
- [ ] demanding
- [ ] publish
- [ ] scoop

# Chapter 014

- [ ] section
- [ ] concise
- [ ] imaginative
- [ ] technical
- [ ] technically
- [ ] thorough
- [ ] gifted
- [ ] idiomatic
- [ ] housewife
- [ ] crime
- [ ] edition
- [ ] ahead of
- [ ] department
- [ ] accurate
- [ ] senior
- [ ] polish
- [ ] chief
- [ ] approve
- [ ] process
- [ ] negative

# Chapter 015

- [ ] appointment
- [ ] aid
- [ ] first aid
- [ ] temporary
- [ ] fall ill
- [ ] injury
- [ ] bleed
- [ ] nosebleed
- [ ] sprain
- [ ] sprained
- [ ] ankle
- [ ] choke
- [ ] cupboard
- [ ] skin
- [ ] essential
- [ ] organ
- [ ] layer
- [ ] barrier
- [ ] poison
- [ ] ray

# Chapter 016

- [ ] complex
- [ ] variety
- [ ] liquid
- [ ] radiation
- [ ] mild
- [ ] mildly
- [ ] pan
- [ ] stove
- [ ] heal
- [ ] tissue
- [ ] electric shock
- [ ] swell
- [ ] swollen
- [ ] blister
- [ ] watery
- [ ] char
- [ ] nerve
- [ ] scissors
- [ ] unbearable
- [ ] basin

# Chapter 017

- [ ] squeeze
- [ ] squeeze out
- [ ] over and over again
- [ ] bandage
- [ ] in place
- [ ] ointment
- [ ] infection
- [ ] vital
- [ ] symptom
- [ ] label
- [ ] kettle
- [ ] pour
- [ ] wrist
- [ ] damp
- [ ] Casey
- [ ] sleeve
- [ ] blouse
- [ ] tight
- [ ] tightly
- [ ] firm

# Chapter 018

- [ ] firmly
- [ ] throat
- [ ] Janson
- [ ] ceremony
- [ ] bravery
- [ ] Slade
- [ ] stab
- [ ] a number of
- [ ] put one’s hands on
- [ ] treat
- [ ] apply
- [ ] pressure
- [ ] ambulance
- [ ] scheme
- [ ] Southerton
- [ ] make a difference
- [ ] bruise

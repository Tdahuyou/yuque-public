
# Chapter 001

- [ ] good
- [ ] morning
- [ ] Good morning!
- [ ] hi
- [ ] hello
- [ ] afternoon
- [ ] Good afternoon!
- [ ] evening
- [ ] Good evening!
- [ ] how
- [ ] are
- [ ] you
- [ ] How are you?
- [ ] I
- [ ] am
- [ ] fine
- [ ] thanks
- [ ] OK
- [ ] what
- [ ] is

# Chapter 002

- [ ] this
- [ ] in
- [ ] English
- [ ] in English
- [ ] map
- [ ] cup
- [ ] ruler
- [ ] pen
- [ ] orange
- [ ] jacket
- [ ] key
- [ ] quilt
- [ ] it
- [ ] a
- [ ] that
- [ ] spell
- [ ] please
- [ ] color
- [ ] red
- [ ] yellow

# Chapter 003

- [ ] green
- [ ] blue
- [ ] black
- [ ] white
- [ ] purple
- [ ] brown
- [ ] the
- [ ] now
- [ ] see
- [ ] can
- [ ] say
- [ ] my
- [ ] name
- [ ] nice
- [ ] to
- [ ] meet
- [ ] too
- [ ] your
- [ ] Ms.
- [ ] his

# Chapter 004

- [ ] and
- [ ] her
- [ ] yes
- [ ] she
- [ ] he
- [ ] no
- [ ] not
- [ ] zero
- [ ] one
- [ ] two
- [ ] three
- [ ] four
- [ ] five
- [ ] six
- [ ] seven
- [ ] eight
- [ ] nine
- [ ] telephone
- [ ] number
- [ ] phone

# Chapter 005

- [ ] telephone number
- [ ] phone number
- [ ] first
- [ ] first name
- [ ] last
- [ ] last name
- [ ] friend
- [ ] China
- [ ] middle
- [ ] school
- [ ] middle school
- [ ] sister
- [ ] mother
- [ ] father
- [ ] parent
- [ ] brother
- [ ] grandmother
- [ ] grandfather
- [ ] grandparent
- [ ] family

# Chapter 006

- [ ] those
- [ ] who
- [ ] oh
- [ ] these
- [ ] they
- [ ] well
- [ ] have
- [ ] Have a good day!
- [ ] bye
- [ ] son
- [ ] cousin
- [ ] grandpa
- [ ] mom
- [ ] aunt
- [ ] grandma
- [ ] dad
- [ ] uncle
- [ ] daughter
- [ ] here
- [ ] photo

# Chapter 007

- [ ] of
- [ ] next
- [ ] picture
- [ ] girl
- [ ] dog
- [ ] pencil
- [ ] book
- [ ] eraser
- [ ] box
- [ ] pencil box
- [ ] schoolbag
- [ ] dictionary
- [ ] his.
- [ ] mine
- [ ] hers
- [ ] excuse
- [ ] me
- [ ] excuse me
- [ ] thank
- [ ] teacher

# Chapter 008

- [ ] about
- [ ] What about...?
- [ ] yours
- [ ] for
- [ ] thank you for...
- [ ] help
- [ ] welcome
- [ ] You're welcome.
- [ ] baseball
- [ ] watch
- [ ] computer
- [ ] game
- [ ] card
- [ ] ID card
- [ ] notebook
- [ ] ring
- [ ] bag
- [ ] in.
- [ ] library
- [ ] ask

# Chapter 009

- [ ] ask... for...
- [ ] find
- [ ] some
- [ ] classroom
- [ ] e-mail
- [ ] at
- [ ] call
- [ ] lost
- [ ] must
- [ ] set
- [ ] a set of
- [ ] where
- [ ] table
- [ ] bed
- [ ] bookcase
- [ ] sofa
- [ ] chair
- [ ] on
- [ ] under
- [ ] come

# Chapter 010

- [ ] come on
- [ ] desk
- [ ] think
- [ ] room
- [ ] their
- [ ] hat
- [ ] head
- [ ] yeah
- [ ] know
- [ ] radio
- [ ] clock
- [ ] tape
- [ ] player
- [ ] tape player
- [ ] model
- [ ] plane
- [ ] model plane
- [ ] tidy
- [ ] but
- [ ] our

# Chapter 011

- [ ] everywhere
- [ ] always
- [ ] do
- [ ] have.
- [ ] tennis
- [ ] ball
- [ ] ping-pong
- [ ] bat
- [ ] soccer
- [ ] soccer ball
- [ ] volleyball
- [ ] basketball
- [ ] hey
- [ ] let
- [ ] us
- [ ] let's
- [ ] go
- [ ] we
- [ ] late
- [ ] has

# Chapter 012

- [ ] get
- [ ] great
- [ ] play
- [ ] sound
- [ ] interesting
- [ ] boring
- [ ] fun
- [ ] difficult
- [ ] relaxing
- [ ] watch.
- [ ] TV
- [ ] watch TV
- [ ] same
- [ ] love
- [ ] with
- [ ] sport
- [ ] them
- [ ] only
- [ ] like
- [ ] easy

# Chapter 013

- [ ] after
- [ ] class
- [ ] classmate
- [ ] banana
- [ ] hamburger
- [ ] tomato
- [ ] ice-cream
- [ ] salad
- [ ] strawberry
- [ ] pear
- [ ] milk
- [ ] bread
- [ ] birthday
- [ ] dinner
- [ ] week
- [ ] think about
- [ ] food
- [ ] sure
- [ ] How about...?
- [ ] burger

# Chapter 014

- [ ] vegetable
- [ ] fruit
- [ ] right
- [ ] apple
- [ ] then
- [ ] egg
- [ ] carrot
- [ ] rice
- [ ] chicken
- [ ] so
- [ ] breakfast
- [ ] lunch
- [ ] star
- [ ] eat
- [ ] well.
- [ ] habit
- [ ] healthy
- [ ] really
- [ ] question
- [ ] want

# Chapter 015

- [ ] be
- [ ] fat
- [ ] much
- [ ] How much...?
- [ ] sock
- [ ] T-shirt
- [ ] shorts
- [ ] sweater
- [ ] trousers
- [ ] shoe
- [ ] skirt
- [ ] dollar
- [ ] big
- [ ] small
- [ ] short
- [ ] long
- [ ] woman
- [ ] Can I help you?
- [ ] need
- [ ] look

# Chapter 016

- [ ] pair
- [ ] take
- [ ] Here you are.
- [ ] ten
- [ ] eleven
- [ ] twelve
- [ ] thirteen
- [ ] fifteen
- [ ] eighteen
- [ ] twenty
- [ ] thirty
- [ ] Mr.
- [ ] clothes
- [ ] store
- [ ] buy
- [ ] sale
- [ ] sell
- [ ] all
- [ ] very
- [ ] price

# Chapter 017

- [ ] boy
- [ ] a pair of
- [ ] when
- [ ] month
- [ ] January
- [ ] February
- [ ] March
- [ ] April
- [ ] May
- [ ] June
- [ ] July
- [ ] August
- [ ] September
- [ ] October
- [ ] November
- [ ] December
- [ ] happy
- [ ] Happy birthday!
- [ ] old
- [ ] How old...?

# Chapter 018

- [ ] party
- [ ] See you!
- [ ] first.
- [ ] second
- [ ] third
- [ ] fifth
- [ ] eighth
- [ ] ninth
- [ ] twelfth
- [ ] twentieth
- [ ] test
- [ ] trip
- [ ] art
- [ ] festival
- [ ] dear
- [ ] student
- [ ] thing
- [ ] term
- [ ] busy
- [ ] time

# Chapter 019

- [ ] Have a good time!
- [ ] there
- [ ] favorite
- [ ] subject
- [ ] science
- [ ] P.E.
- [ ] music
- [ ] math
- [ ] Chinese
- [ ] geography
- [ ] history
- [ ] why
- [ ] because
- [ ] Monday
- [ ] Friday
- [ ] Saturday
- [ ] for sure
- [ ] free
- [ ] cool
- [ ] Tuesday

# Chapter 020

- [ ] Wednesday
- [ ] Thursday
- [ ] Sunday
- [ ] A.M.
- [ ] P.M.
- [ ] useful
- [ ] from
- [ ] from... to...
- [ ] Mrs.
- [ ] finish
- [ ] lesson
- [ ] hour

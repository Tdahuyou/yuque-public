
# Chapter 001

- [ ] venture
- [ ] web
- [ ] Scottish
- [ ] suffering
- [ ] gall-bladder
- [ ] strengthen
- [ ] Perce Blackborrow
- [ ] Sir Ernest Shackleton
- [ ] endurance
- [ ] hut
- [ ] stove
- [ ] unbearable
- [ ] cosy
- [ ] block out
- [ ] breathless
- [ ] rotten
- [ ] blacken
- [ ] circumstance
- [ ] blast
- [ ] hoarse

# Chapter 002

- [ ] bless
- [ ] selfish
- [ ] Tom Orde-Lees
- [ ] hook
- [ ] aboard
- [ ] seasickness
- [ ] anyhow
- [ ] steward
- [ ] crush
- [ ] mourn
- [ ] urgent
- [ ] bedding
- [ ] Hussey
- [ ] banjo
- [ ] vital
- [ ] cheerful
- [ ] persevere
- [ ] perseverance
- [ ] faith
- [ ] give way to

# Chapter 003

- [ ] framework
- [ ] rank
- [ ] morale
- [ ] select
- [ ] booming
- [ ] swear
- [ ] advocate
- [ ] freezing
- [ ] stool
- [ ] gratitude
- [ ] punishment
- [ ] loyal
- [ ] tactful
- [ ] Frank Worsley
- [ ] odd
- [ ] stout
- [ ] Hubert Hudson
- [ ] optimism
- [ ] delay
- [ ] discourage

# Chapter 004

- [ ] dynamic
- [ ] regular
- [ ] grasp
- [ ] give off
- [ ] Lionel Greenstreet
- [ ] bored
- [ ] liver
- [ ] chef
- [ ] changeable
- [ ] caution
- [ ] sun-blindness
- [ ] admirable
- [ ] commitment
- [ ] proverb
- [ ] King Lear
- [ ] respectful
- [ ] disrespectful
- [ ] disrespectfully
- [ ] emperor
- [ ] shorten

# Chapter 005

- [ ] modernize
- [ ] throne
- [ ] Regan
- [ ] Goneril
- [ ] Cordelia
- [ ] duke
- [ ] Albany
- [ ] Cornwall
- [ ] Kent
- [ ] burden
- [ ] hand over
- [ ] responsibility
- [ ] boundary
- [ ] allocate
- [ ] whichever
- [ ] darling
- [ ] adore
- [ ] pray
- [ ] care for
- [ ] majesty

# Chapter 006

- [ ] lord
- [ ] bridegroom
- [ ] distribute
- [ ] troop
- [ ] contradict
- [ ] hear out
- [ ] on behalf of
- [ ] flattery
- [ ] flatter
- [ ] beyond question
- [ ] speak out
- [ ] friction
- [ ] forecast
- [ ] oppose
- [ ] pack up
- [ ] frontier
- [ ] give away
- [ ] fond
- [ ] be fond of
- [ ] deceitful

# Chapter 007

- [ ] corrupt
- [ ] greedy
- [ ] greed
- [ ] innocent
- [ ] cunning
- [ ] strorage
- [ ] author
- [ ] sacrifice
- [ ] Stratford-on-Avon
- [ ] Latin
- [ ] make a name
- [ ] allergic
- [ ] sneeze
- [ ] armchair
- [ ] confirm
- [ ] rewind
- [ ] cash
- [ ] cheque
- [ ] signature
- [ ] terminal

# Chapter 008

- [ ] vacant
- [ ] dusty
- [ ] Burgundy
- [ ] respond
- [ ] Oswald
- [ ] staff
- [ ] Caius
- [ ] suspect
- [ ] insult
- [ ] scold
- [ ] drunken
- [ ] scratch
- [ ] baggage
- [ ] demand
- [ ] prop
- [ ] civil
- [ ] trolleybus
- [ ] register
- [ ] Maryann Jines
- [ ] Montgommery

# Chapter 009

- [ ] Martin Luther King Jr.
- [ ] boycott
- [ ] prohibit
- [ ] offence
- [ ] unjust
- [ ] separation
- [ ] tradition
- [ ] submit
- [ ] unwilling
- [ ] seize
- [ ] seize on
- [ ] collision
- [ ] collision course
- [ ] hopeful
- [ ] negotiate
- [ ] chaos
- [ ] Serena
- [ ] sandal
- [ ] punctual
- [ ] coincidence

# Chapter 010

- [ ] pedestrian
- [ ] march
- [ ] pavement
- [ ] salute
- [ ] abuse
- [ ] hostility
- [ ] resolve
- [ ] prayer
- [ ] bomb
- [ ] supreme
- [ ] nationwide
- [ ] constitution
- [ ] constitutional
- [ ] fundamental
- [ ] battle
- [ ] happiness
- [ ] liberty
- [ ] skim
- [ ] evident
- [ ] self-evident

# Chapter 011

- [ ] brief
- [ ] discrimination
- [ ] philosophy
- [ ] Scout
- [ ] Atticus
- [ ] Jem
- [ ] Arthur
- [ ] commit
- [ ] Walter Cunningham
- [ ] Caroline
- [ ] live out
- [ ] creed
- [ ] brotherhood
- [ ] oasis
- [ ] Alabama
- [ ] symphony
- [ ] Jew
- [ ] Gentile
- [ ] Protestant
- [ ] Catholic

# Chapter 012

- [ ] Negro
- [ ] almighty
- [ ] quotation
- [ ] metaphor
- [ ] simile
- [ ] Ewell
- [ ] Mayella
- [ ] dominate
- [ ] efficient
- [ ] efficiently
- [ ] centigrade
- [ ] diameter
- [ ] recipe
- [ ] booklet
- [ ] endeavour
- [ ] competent
- [ ] up to
- [ ] caption
- [ ] digest
- [ ] beneath

# Chapter 013

- [ ] adopt
- [ ] preview
- [ ] frequent
- [ ] in detail
- [ ] manual
- [ ] New Zealand
- [ ] assess
- [ ] consult
- [ ] underneath
- [ ] shabby
- [ ] rainbow
- [ ] brewery
- [ ] acute
- [ ] bent
- [ ] cab
- [ ] currency
- [ ] lotus
- [ ] cuisine
- [ ] educator
- [ ] seminar

# Chapter 014

- [ ] acquisition
- [ ] ballet
- [ ] album
- [ ] resemble
- [ ] cassette
- [ ] tend
- [ ] tend to
- [ ] tend to do sth
- [ ] messy
- [ ] tiresome
- [ ] vague
- [ ] bonus
- [ ] auditory
- [ ] tactile
- [ ] oral
- [ ] component
- [ ] concrete
- [ ] literary
- [ ] genre
- [ ] recount

# Chapter 015

- [ ] Agnes Grey
- [ ] Jane Austin
- [ ] Charlotte Bronte
- [ ] Tess of d’Urbevilles
- [ ] prejudice
- [ ] Wuthering Heights
- [ ] Margaret Mitchell
- [ ] Rudyard Kipling
- [ ] consensus
- [ ] equality
- [ ] in force
- [ ] twist
- [ ] contradiction
- [ ] get round
- [ ] George Eliot
- [ ] limitation
- [ ] heroine
- [ ] obstacle
- [ ] ironic
- [ ] hopeless

# Chapter 016

- [ ] under the name of
- [ ] sceptical
- [ ] see through
- [ ] deception
- [ ] approval
- [ ] explicit
- [ ] struggle against
- [ ] outspoken
- [ ] growth
- [ ] childhood
- [ ] hail
- [ ] revelation
- [ ] premier
- [ ] ambiguous
- [ ] concession
- [ ] stand out
- [ ] critic
- [ ] injustice
- [ ] possess
- [ ] sponsor

# Chapter 017

- [ ] eccentric
- [ ] Betsy Trotwood
- [ ] generous
- [ ] merchant
- [ ] staight away
- [ ] warehouse
- [ ] bargain
- [ ] burglar
- [ ] sequence
- [ ] inspect
- [ ] bungalow
- [ ] chain
- [ ] dangle
- [ ] semicircle
- [ ] squeak
- [ ] pull oneself up
- [ ] roof
- [ ] collar
- [ ] bench
- [ ] pine

# Chapter 018

- [ ] claw
- [ ] squirrel
- [ ] romance
- [ ] vain
- [ ] in vain
- [ ] signal
- [ ] discount
- [ ] sensitive
- [ ] decline
- [ ] arrogant
- [ ] at length
- [ ] enquire
- [ ] against one’s will
- [ ] think ill of
- [ ] do everything in one’s power to
- [ ] rejoice
- [ ] initial
- [ ] fault
- [ ] hasty
- [ ] hastily

# Chapter 019

- [ ] sensible

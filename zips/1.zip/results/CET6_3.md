
# Chapter 001

- [ ] cancel
- [ ] numerous
- [ ] surgeon
- [ ] analyse
- [ ] abrupt
- [ ] spacious
- [ ] disapproval
- [ ] spontaneous
- [ ] remote
- [ ] cafeteria
- [ ] rupture
- [ ] wreck
- [ ] virgin
- [ ] afflict
- [ ] reproach
- [ ] fluctuate
- [ ] compartment
- [ ] gloomy
- [ ] kidnap
- [ ] warrant

# Chapter 002

- [ ] calculate
- [ ] persistent
- [ ] authorize
- [ ] sake
- [ ] audience
- [ ] rehearsal
- [ ] sniff
- [ ] narrative
- [ ] possess
- [ ] coincide
- [ ] neutral
- [ ] scratch
- [ ] analysis
- [ ] devise
- [ ] cooperative
- [ ] triple
- [ ] clutch
- [ ] temper
- [ ] grope
- [ ] rejoice

# Chapter 003

- [ ] frantic
- [ ] tickle
- [ ] object
- [ ] humble
- [ ] commodity
- [ ] cliff
- [ ] obedient
- [ ] infinite
- [ ] misery
- [ ] blur
- [ ] suffice
- [ ] concede
- [ ] notable
- [ ] plausible
- [ ] equator
- [ ] commission
- [ ] staircase
- [ ] flip
- [ ] rational
- [ ] barricade

# Chapter 004

- [ ] resume
- [ ] provocative
- [ ] committee
- [ ] posture
- [ ] spiral
- [ ] subtle
- [ ] component
- [ ] overwhelm
- [ ] suite
- [ ] consultant
- [ ] disguise
- [ ] imperial
- [ ] facet
- [ ] liberal
- [ ] surgery
- [ ] harmony
- [ ] violent
- [ ] resolve
- [ ] cozy
- [ ] confront

# Chapter 005

- [ ] dominate
- [ ] imitate
- [ ] deadly
- [ ] compute
- [ ] institution
- [ ] huddle
- [ ] skeleton
- [ ] ambition
- [ ] intersection
- [ ] exceed
- [ ] implement
- [ ] disperse
- [ ] avert
- [ ] fantasy
- [ ] shipment
- [ ] vicious
- [ ] lace
- [ ] enormous
- [ ] external
- [ ] gorgeous

# Chapter 006

- [ ] circumstance
- [ ] authority
- [ ] erosion
- [ ] ascend
- [ ] provided
- [ ] instrument
- [ ] medium
- [ ] indispensable
- [ ] lens
- [ ] embody
- [ ] fatal
- [ ] motive
- [ ] envisage
- [ ] wrestle
- [ ] motivate
- [ ] marginal
- [ ] spoil
- [ ] multiply
- [ ] pasture
- [ ] approval

# Chapter 007

- [ ] mobile
- [ ] multiple
- [ ] evolution
- [ ] peak
- [ ] magnet
- [ ] concentrate
- [ ] expose
- [ ] versatile
- [ ] versus
- [ ] complaint
- [ ] permissible
- [ ] cancer
- [ ] splash
- [ ] inject
- [ ] romance
- [ ] offense
- [ ] atlas
- [ ] invisible
- [ ] focus
- [ ] hamper

# Chapter 008

- [ ] motel
- [ ] approach
- [ ] exaggeration
- [ ] peg
- [ ] myth
- [ ] decisive
- [ ] concise
- [ ] implication
- [ ] thesis
- [ ] bump
- [ ] reservation
- [ ] revive
- [ ] cordial
- [ ] timid
- [ ] loyalty
- [ ] dismiss
- [ ] underlying
- [ ] reform
- [ ] install
- [ ] ensue

# Chapter 009

- [ ] indication
- [ ] bulk
- [ ] bull
- [ ] champion
- [ ] ceramic
- [ ] queer
- [ ] successor
- [ ] enlightenment
- [ ] booklet
- [ ] magnificent
- [ ] stagger
- [ ] irony
- [ ] restrict
- [ ] bandage
- [ ] prevalence
- [ ] scrap
- [ ] syndrome
- [ ] tow
- [ ] imperative
- [ ] meadow

# Chapter 010

- [ ] hitherto
- [ ] energetic
- [ ] haul
- [ ] avail
- [ ] consequence
- [ ] linear
- [ ] robust
- [ ] dominant
- [ ] premier
- [ ] peel
- [ ] intellectual
- [ ] reclaim
- [ ] denounce
- [ ] verge
- [ ] pastry
- [ ] messenger
- [ ] disable
- [ ] irrespective
- [ ] entity
- [ ] prohibit

# Chapter 011

- [ ] bacteria
- [ ] fuel
- [ ] hostile
- [ ] reign
- [ ] tempo
- [ ] descendant
- [ ] foresee
- [ ] bruise
- [ ] associate
- [ ] gown
- [ ] crawl
- [ ] identical
- [ ] plead
- [ ] kidney
- [ ] gleam
- [ ] ambitious
- [ ] academic
- [ ] function
- [ ] stock
- [ ] sneak

# Chapter 012

- [ ] void
- [ ] comparison
- [ ] surge
- [ ] swap
- [ ] ritual
- [ ] liability
- [ ] hatch
- [ ] patriot
- [ ] tick
- [ ] basis
- [ ] tutor
- [ ] senator
- [ ] successive
- [ ] quantify
- [ ] reconcile
- [ ] tempt
- [ ] obligation
- [ ] paperback
- [ ] evil
- [ ] rarely

# Chapter 013

- [ ] hawk
- [ ] twist
- [ ] forthcoming
- [ ] patriotic
- [ ] complication
- [ ] perplex
- [ ] combat
- [ ] despise
- [ ] levy
- [ ] indulge
- [ ] intimidate
- [ ] effective
- [ ] unity
- [ ] pursue
- [ ] vulgar
- [ ] catastrophe
- [ ] convey
- [ ] design
- [ ] generous
- [ ] coincidence

# Chapter 014

- [ ] victim
- [ ] bust
- [ ] skull
- [ ] hysterical
- [ ] lane
- [ ] contaminate
- [ ] ammunition
- [ ] chief
- [ ] accord
- [ ] foremost
- [ ] automatic
- [ ] despite
- [ ] consecutive
- [ ] probe
- [ ] assimilation
- [ ] groan
- [ ] industrial
- [ ] conduct
- [ ] velvet
- [ ] quantitative

# Chapter 015

- [ ] stable
- [ ] reunion
- [ ] fantastic
- [ ] drainage
- [ ] respond
- [ ] incident
- [ ] lame
- [ ] tub
- [ ] cluster
- [ ] prey
- [ ] apparatus
- [ ] lieutenant
- [ ] tug
- [ ] expedition
- [ ] decay
- [ ] grieve
- [ ] absorb
- [ ] concern
- [ ] fracture
- [ ] rectify

# Chapter 016

- [ ] integrity
- [ ] refrain
- [ ] pact
- [ ] notation
- [ ] merge
- [ ] liable
- [ ] recycle
- [ ] dock
- [ ] marsh
- [ ] element
- [ ] confidential
- [ ] abundant
- [ ] exclaim
- [ ] ballet
- [ ] mute
- [ ] courtesy
- [ ] deteriorate
- [ ] warehouse
- [ ] recognize
- [ ] restraint

# Chapter 017

- [ ] pollutant
- [ ] bamboo
- [ ] input
- [ ] induce
- [ ] abnormal
- [ ] shrewd
- [ ] stereotype
- [ ] molecule
- [ ] enroll
- [ ] resign
- [ ] safeguard
- [ ] diligent
- [ ] sophisticated
- [ ] entertainment
- [ ] reside
- [ ] indicative
- [ ] ward
- [ ] dread
- [ ] scrutiny
- [ ] chase

# Chapter 018

- [ ] accident
- [ ] promote
- [ ] routine
- [ ] attack
- [ ] divorce
- [ ] tariff
- [ ] attach
- [ ] graphic
- [ ] convict
- [ ] retention
- [ ] creation
- [ ] legislation
- [ ] dodge
- [ ] ingredient
- [ ] surplus
- [ ] consolidate
- [ ] correspondence
- [ ] inhibit
- [ ] refresh
- [ ] intimate

# Chapter 019

- [ ] shove
- [ ] theft
- [ ] disclose
- [ ] religion
- [ ] yacht
- [ ] mistress
- [ ] oxide
- [ ] miniature
- [ ] clan
- [ ] economical
- [ ] prosperous
- [ ] polish
- [ ] reassess
- [ ] cabinet
- [ ] optical
- [ ] evoke
- [ ] insurance
- [ ] dazzle
- [ ] principle
- [ ] thigh

# Chapter 020

- [ ] tedious
- [ ] tilt
- [ ] inferiority
- [ ] participant
- [ ] initiate
- [ ] domestic
- [ ] glare
- [ ] irrigation
- [ ] compile
- [ ] vitality
- [ ] locomotive
- [ ] tile
- [ ] donation
- [ ] immense
- [ ] inherent
- [ ] stability
- [ ] budget
- [ ] radiate
- [ ] given
- [ ] perish

# Chapter 021

- [ ] pastime
- [ ] ultimate
- [ ] adapt
- [ ] prosecute
- [ ] batch
- [ ] merit
- [ ] verbal
- [ ] solicitor
- [ ] intrinsic
- [ ] proximity
- [ ] luminous
- [ ] lash
- [ ] receipt
- [ ] assume
- [ ] predestine
- [ ] chant
- [ ] destiny
- [ ] capsule
- [ ] concept
- [ ] resistant

# Chapter 022

- [ ] ozone
- [ ] indefinite
- [ ] disaster
- [ ] ecology
- [ ] minimal
- [ ] cocktail
- [ ] enhance
- [ ] convention
- [ ] disease
- [ ] calcium
- [ ] notwithstanding
- [ ] suspicion
- [ ] purchase
- [ ] refusal
- [ ] disposable
- [ ] bypass
- [ ] silicon
- [ ] clarity
- [ ] fund
- [ ] typical

# Chapter 023

- [ ] recipient
- [ ] commonwealth
- [ ] watt
- [ ] buzz
- [ ] finance
- [ ] incur
- [ ] notorious
- [ ] assassination
- [ ] infant
- [ ] gland
- [ ] premise
- [ ] circus
- [ ] controversial
- [ ] attain
- [ ] deprive
- [ ] tenant
- [ ] resultant
- [ ] pest
- [ ] pedal
- [ ] batter

# Chapter 024

- [ ] heritage
- [ ] supreme
- [ ] hostage
- [ ] priority
- [ ] slope
- [ ] inlet
- [ ] metallic
- [ ] shuttle
- [ ] regenerate
- [ ] allocate
- [ ] latent
- [ ] terrific
- [ ] standpoint
- [ ] primary
- [ ] pirate
- [ ] stubborn
- [ ] formulate
- [ ] consume
- [ ] dome
- [ ] layer

# Chapter 025

- [ ] alien
- [ ] competence
- [ ] fuse
- [ ] elite
- [ ] premium
- [ ] ornament
- [ ] assure
- [ ] pretext
- [ ] ivory
- [ ] theme
- [ ] consult
- [ ] solidarity
- [ ] tumble
- [ ] gracious
- [ ] smash
- [ ] merely
- [ ] appropriation
- [ ] contradiction
- [ ] wealth
- [ ] henceforth

# Chapter 026

- [ ] wallet
- [ ] survive
- [ ] desire
- [ ] initial
- [ ] efficient
- [ ] murmur
- [ ] fury
- [ ] unify
- [ ] muddy
- [ ] hound
- [ ] consistent
- [ ] dole
- [ ] reverse
- [ ] barren
- [ ] eternal
- [ ] permanent
- [ ] foster
- [ ] barely
- [ ] prevalent
- [ ] cling

# Chapter 027

- [ ] incidence
- [ ] clip
- [ ] beam
- [ ] compact
- [ ] alliance
- [ ] invaluable
- [ ] fiction
- [ ] doom
- [ ] cucumber
- [ ] aviation
- [ ] pessimistic
- [ ] denote
- [ ] emphasis
- [ ] interrupt
- [ ] propagate
- [ ] feasible
- [ ] majesty
- [ ] flatter
- [ ] potential
- [ ] necessitate

# Chapter 028

- [ ] orthodox
- [ ] accustomed
- [ ] combination
- [ ] obtain
- [ ] statesman
- [ ] tack
- [ ] gross
- [ ] lounge
- [ ] porch
- [ ] workshop
- [ ] format
- [ ] sacrifice
- [ ] illegal
- [ ] corps
- [ ] eclipse
- [ ] formal
- [ ] correlate
- [ ] soar
- [ ] commute
- [ ] sustain

# Chapter 029

- [ ] critical
- [ ] shepherd
- [ ] outcry
- [ ] radiant
- [ ] principal
- [ ] exceedingly
- [ ] uphold
- [ ] exotic
- [ ] relief
- [ ] boycott
- [ ] dimension
- [ ] deserve
- [ ] process
- [ ] revenge
- [ ] restore
- [ ] subscribe
- [ ] distill
- [ ] alternative
- [ ] concentration
- [ ] velocity

# Chapter 030

- [ ] encounter
- [ ] fellowship
- [ ] colleague
- [ ] approve
- [ ] interaction
- [ ] pedestrian
- [ ] interfere
- [ ] apartment
- [ ] account
- [ ] fitting
- [ ] stack
- [ ] radioactive
- [ ] resent
- [ ] stride
- [ ] ambiguous
- [ ] impulsive
- [ ] qualitative
- [ ] diverse
- [ ] crisp
- [ ] prime

# Chapter 031

- [ ] intellect
- [ ] preference
- [ ] mild
- [ ] loyal
- [ ] impact
- [ ] paralysis
- [ ] court
- [ ] chapel
- [ ] distort
- [ ] subsidiary
- [ ] venture
- [ ] discern
- [ ] enthusiasm
- [ ] flexible
- [ ] domain
- [ ] census
- [ ] corpse
- [ ] willful
- [ ] attitude
- [ ] relative

# Chapter 032

- [ ] compare
- [ ] depict
- [ ] hop
- [ ] characteristic
- [ ] involvement
- [ ] pave
- [ ] integral
- [ ] lubricate
- [ ] comet
- [ ] deadline
- [ ] bully
- [ ] chip
- [ ] medieval
- [ ] tanker
- [ ] involve
- [ ] pistol
- [ ] assemble
- [ ] watertight
- [ ] transition
- [ ] repel

# Chapter 033

- [ ] mutter
- [ ] series
- [ ] complicated
- [ ] junk
- [ ] maximum
- [ ] thrive
- [ ] imaginative
- [ ] penguin
- [ ] represent
- [ ] masterpiece
- [ ] compete
- [ ] tolerant
- [ ] dispatch
- [ ] emergency
- [ ] dim
- [ ] paralyze
- [ ] interpersonal
- [ ] exemplary
- [ ] faculty
- [ ] layoff

# Chapter 034

- [ ] wretched
- [ ] absurd
- [ ] modesty
- [ ] considerate
- [ ] glamor
- [ ] clue
- [ ] bracket
- [ ] legal
- [ ] midst
- [ ] trait
- [ ] radius
- [ ] disintegration
- [ ] signal
- [ ] impair
- [ ] dolphin
- [ ] sightseeing
- [ ] stray
- [ ] planet
- [ ] exhaust
- [ ] thereafter

# Chapter 035

- [ ] soluble
- [ ] feast
- [ ] vision
- [ ] accompany
- [ ] armor
- [ ] acceptance
- [ ] beneficial
- [ ] paradise
- [ ] tackle
- [ ] reckon
- [ ] confusion
- [ ] distract
- [ ] hinge
- [ ] virtual
- [ ] squeeze
- [ ] blank
- [ ] additional
- [ ] worthy
- [ ] primarily
- [ ] telecommunications

# Chapter 036

- [ ] ferry
- [ ] ignore
- [ ] hemisphere
- [ ] reception
- [ ] applaud
- [ ] outward
- [ ] lunar
- [ ] poetry
- [ ] jury
- [ ] arrogant
- [ ] idiot
- [ ] relay
- [ ] priest
- [ ] monitor
- [ ] solo
- [ ] tuition
- [ ] permeate
- [ ] utopian
- [ ] schedule
- [ ] tame

# Chapter 037

- [ ] adjoin
- [ ] universe
- [ ] inherit
- [ ] overwhelming
- [ ] interpret
- [ ] peculiar
- [ ] idiom
- [ ] diplomat
- [ ] hug
- [ ] grant
- [ ] muscular
- [ ] sparkle
- [ ] hum
- [ ] staple
- [ ] discount
- [ ] construct
- [ ] royalty
- [ ] convert
- [ ] attempt
- [ ] rivalry

# Chapter 038

- [ ] relish
- [ ] fluorescent
- [ ] division
- [ ] superficial
- [ ] executive
- [ ] navigation
- [ ] melt
- [ ] stalk
- [ ] whereas
- [ ] pitch
- [ ] casualty
- [ ] gauge
- [ ] oriental
- [ ] electrical
- [ ] stall
- [ ] protest
- [ ] sensitive
- [ ] classification
- [ ] brew
- [ ] vacant

# Chapter 039

- [ ] menace
- [ ] afford
- [ ] invalid
- [ ] curse
- [ ] legitimate
- [ ] appease
- [ ] sieve
- [ ] whereby
- [ ] evaluate
- [ ] status
- [ ] machinery
- [ ] shield
- [ ] skip
- [ ] instantaneous
- [ ] phenomenon
- [ ] quarterly
- [ ] notify
- [ ] bibliography
- [ ] stream
- [ ] recur

# Chapter 040

- [ ] coalition
- [ ] generalize
- [ ] accumulate
- [ ] crime
- [ ] dwarf
- [ ] heave
- [ ] leisure
- [ ] nourish
- [ ] grease
- [ ] allege
- [ ] pilgrim
- [ ] trigger
- [ ] assimilate
- [ ] positive
- [ ] segregate
- [ ] addict
- [ ] prospect
- [ ] withhold
- [ ] comparable
- [ ] discreet

# Chapter 041

- [ ] specialize
- [ ] instance
- [ ] presumably
- [ ] bonus
- [ ] recognition
- [ ] banquet
- [ ] thrill
- [ ] aisle
- [ ] convene
- [ ] arrangement
- [ ] revenue
- [ ] solution
- [ ] monopoly
- [ ] opponent
- [ ] accelerate
- [ ] supplementary
- [ ] grain
- [ ] credit
- [ ] oxygen
- [ ] intensive

# Chapter 042

- [ ] alter
- [ ] combine
- [ ] ideal
- [ ] occur
- [ ] illustrate
- [ ] hose
- [ ] definitive
- [ ] streak
- [ ] pressure
- [ ] dentist
- [ ] brood
- [ ] literacy
- [ ] originate
- [ ] specialist
- [ ] background
- [ ] millionaire
- [ ] transit
- [ ] adolescent
- [ ] nonetheless
- [ ] dispose

# Chapter 043

- [ ] petty
- [ ] glow
- [ ] sentiment
- [ ] differentiation
- [ ] constitution
- [ ] patent
- [ ] cocaine
- [ ] groove
- [ ] abundance
- [ ] racket
- [ ] conceive
- [ ] sour
- [ ] transform
- [ ] napkin
- [ ] reckless
- [ ] paradox
- [ ] magnitude
- [ ] justification
- [ ] genuine
- [ ] execution

# Chapter 044

- [ ] immune
- [ ] brochure
- [ ] stern
- [ ] rotary
- [ ] compound
- [ ] dub
- [ ] masculine
- [ ] extraordinary
- [ ] witness
- [ ] conventional
- [ ] regulation
- [ ] conform
- [ ] circulation
- [ ] authentic
- [ ] mere
- [ ] accommodation
- [ ] evident
- [ ] suburb
- [ ] pumpkin
- [ ] annoy

# Chapter 045

- [ ] profess
- [ ] psychological
- [ ] credible
- [ ] empirical
- [ ] commit
- [ ] curb
- [ ] crash
- [ ] character
- [ ] reflect
- [ ] outfit
- [ ] contribution
- [ ] ongoing
- [ ] massacre
- [ ] reassure
- [ ] bang
- [ ] magnetic
- [ ] cholesterol
- [ ] orbit
- [ ] band
- [ ] negligible

# Chapter 046

- [ ] setback
- [ ] resident
- [ ] symbolic
- [ ] distinguish
- [ ] mall
- [ ] module
- [ ] howl
- [ ] execute
- [ ] substantial
- [ ] benefit
- [ ] booth
- [ ] enthusiastic
- [ ] disastrous
- [ ] unique
- [ ] processing
- [ ] boost
- [ ] impulse
- [ ] sober
- [ ] crystallize
- [ ] religious

# Chapter 047

- [ ] infectious
- [ ] shelter
- [ ] prominent
- [ ] expel
- [ ] superiority
- [ ] outset
- [ ] latitude
- [ ] scan
- [ ] association
- [ ] fundamental
- [ ] eliminate
- [ ] cute
- [ ] entitle
- [ ] outline
- [ ] partition
- [ ] nominal
- [ ] excess
- [ ] glance
- [ ] perspective
- [ ] galaxy

# Chapter 048

- [ ] equality
- [ ] destruction
- [ ] rebellion
- [ ] expression
- [ ] reaction
- [ ] accordance
- [ ] weary
- [ ] appeal
- [ ] swamp
- [ ] entrepreneur
- [ ] dedicate
- [ ] peninsula
- [ ] extensive
- [ ] residential
- [ ] definitely
- [ ] stab
- [ ] abandon
- [ ] collaboration
- [ ] inspire
- [ ] impart

# Chapter 049

- [ ] bureaucracy
- [ ] household
- [ ] glide
- [ ] adverse
- [ ] bulletin
- [ ] devote
- [ ] junction
- [ ] crumble
- [ ] agent
- [ ] abortion
- [ ] salvation
- [ ] instinct
- [ ] cannon
- [ ] invest
- [ ] reputation
- [ ] project
- [ ] shrug
- [ ] arena
- [ ] independence
- [ ] shrub

# Chapter 050

- [ ] presentation
- [ ] nominate
- [ ] loom
- [ ] stationary
- [ ] restrain
- [ ] awkward
- [ ] ruin
- [ ] beforehand
- [ ] formidable
- [ ] impatient
- [ ] invert
- [ ] cradle
- [ ] discrete
- [ ] assurance
- [ ] psychiatrist
- [ ] squad
- [ ] disrupt
- [ ] scar
- [ ] sergeant
- [ ] vital

# Chapter 051

- [ ] eccentric
- [ ] conflict
- [ ] appliance
- [ ] alloy
- [ ] delusion
- [ ] mass
- [ ] detect
- [ ] update
- [ ] renaissance
- [ ] poisonous
- [ ] condemn
- [ ] assistance
- [ ] auction
- [ ] propel
- [ ] admit
- [ ] uneven
- [ ] definition
- [ ] mansion
- [ ] mask
- [ ] patrol

# Chapter 052

- [ ] nickel
- [ ] patron
- [ ] entail
- [ ] inferior
- [ ] apply
- [ ] propaganda
- [ ] overlook
- [ ] refuge
- [ ] dramatic
- [ ] incredible
- [ ] certainty
- [ ] corrode
- [ ] spine
- [ ] commend
- [ ] parasite
- [ ] artificial
- [ ] deficiency
- [ ] imaginary
- [ ] formula
- [ ] disgust

# Chapter 053

- [ ] transcend
- [ ] tribute
- [ ] mob
- [ ] subordinate
- [ ] trend
- [ ] achievement
- [ ] sturdy
- [ ] desirable
- [ ] consist
- [ ] reliable
- [ ] compatible
- [ ] incentive
- [ ] critic
- [ ] preliminary
- [ ] obstacle
- [ ] profession
- [ ] van
- [ ] dizzy
- [ ] resemblance
- [ ] exceptional

# Chapter 054

- [ ] constitute
- [ ] cherish
- [ ] discrepancy
- [ ] spectrum
- [ ] convince
- [ ] prolong
- [ ] missionary
- [ ] terminate
- [ ] valve
- [ ] refund
- [ ] remnant
- [ ] internal
- [ ] literary
- [ ] classical
- [ ] privilege
- [ ] substitute
- [ ] mortgage
- [ ] blaze
- [ ] moreover
- [ ] scatter

# Chapter 055

- [ ] violate
- [ ] federal
- [ ] verify
- [ ] excursion
- [ ] inaugurate
- [ ] undergo
- [ ] reward
- [ ] graze
- [ ] coupon
- [ ] multitude
- [ ] inhabit
- [ ] siege
- [ ] abstract
- [ ] agenda
- [ ] degenerate
- [ ] nurture
- [ ] destructive
- [ ] appearance
- [ ] culture
- [ ] paternity

# Chapter 056

- [ ] hasty
- [ ] anonymous
- [ ] fake
- [ ] span
- [ ] escort
- [ ] bizarre
- [ ] existence
- [ ] ascribe
- [ ] threshold
- [ ] float
- [ ] minority
- [ ] axis
- [ ] pole
- [ ] preferable
- [ ] reference
- [ ] spite
- [ ] defendant
- [ ] arrange
- [ ] olive
- [ ] coarse

# Chapter 057

- [ ] exaggerate
- [ ] streamline
- [ ] imply
- [ ] offset
- [ ] commitment
- [ ] cavity
- [ ] coward
- [ ] fossil
- [ ] poke
- [ ] rejection
- [ ] fixture
- [ ] manufacture
- [ ] collision
- [ ] sequence
- [ ] recruit
- [ ] provision
- [ ] calorie
- [ ] slogan
- [ ] invariably
- [ ] commence

# Chapter 058

- [ ] tract
- [ ] configuration
- [ ] mercury
- [ ] frequent
- [ ] chunk
- [ ] interact
- [ ] commonplace
- [ ] aggregate
- [ ] seemingly
- [ ] attendant
- [ ] array
- [ ] parameter
- [ ] extinct
- [ ] discriminate
- [ ] degrade
- [ ] opaque
- [ ] repay
- [ ] monetary
- [ ] grave
- [ ] advantage

# Chapter 059

- [ ] controversy
- [ ] command
- [ ] compulsory
- [ ] performance
- [ ] serial
- [ ] anticipate
- [ ] detach
- [ ] slash
- [ ] fabricate
- [ ] comic
- [ ] perfection
- [ ] vague
- [ ] pope
- [ ] exception
- [ ] ego
- [ ] urge
- [ ] spouse
- [ ] score
- [ ] isle
- [ ] enclosure

# Chapter 060

- [ ] graduate
- [ ] famine
- [ ] quota
- [ ] unanimous
- [ ] scorn
- [ ] thermal
- [ ] sulfur
- [ ] visual
- [ ] terrain
- [ ] grief
- [ ] rap
- [ ] upgrade
- [ ] instruct
- [ ] appendix
- [ ] virtually
- [ ] agreeable
- [ ] economy
- [ ] community
- [ ] version
- [ ] sprinkle

# Chapter 061

- [ ] bronze
- [ ] conception
- [ ] municipal
- [ ] detain
- [ ] institute
- [ ] endure
- [ ] detail
- [ ] subculture
- [ ] appropriate
- [ ] criterion
- [ ] essence
- [ ] pore
- [ ] utility
- [ ] manual
- [ ] maneuver
- [ ] symphony
- [ ] eloquent
- [ ] optimistic
- [ ] dual
- [ ] submarine

# Chapter 062

- [ ] aspect
- [ ] aggressive
- [ ] stump
- [ ] behavior
- [ ] federation
- [ ] minimize
- [ ] descend
- [ ] signify
- [ ] logical
- [ ] reconciliation
- [ ] weird
- [ ] characterize
- [ ] descent
- [ ] ridiculous
- [ ] turbulent
- [ ] overt
- [ ] refute
- [ ] precedent
- [ ] severe
- [ ] emerge

# Chapter 063

- [ ] exemplify
- [ ] lease
- [ ] exploit
- [ ] slap
- [ ] anniversary
- [ ] register
- [ ] communicate
- [ ] evidence
- [ ] jerk
- [ ] fling
- [ ] stun
- [ ] acid
- [ ] autonomy
- [ ] transmission
- [ ] blush
- [ ] dubious
- [ ] intuition
- [ ] artillery
- [ ] educational
- [ ] pose

# Chapter 064

- [ ] finite
- [ ] amend
- [ ] erupt
- [ ] exquisite
- [ ] collide
- [ ] remedy
- [ ] cardinal
- [ ] consent
- [ ] insist
- [ ] fusion
- [ ] volume
- [ ] mutual
- [ ] therefore
- [ ] exchange
- [ ] indignant
- [ ] hesitate
- [ ] decimal
- [ ] cynical
- [ ] ventilate
- [ ] scoop

# Chapter 065

- [ ] companion
- [ ] culminate
- [ ] breakdown
- [ ] directory
- [ ] behave
- [ ] accomplish
- [ ] strand
- [ ] constituent
- [ ] engine
- [ ] irritate
- [ ] scope
- [ ] responsible
- [ ] linen
- [ ] expectancy
- [ ] illuminate
- [ ] liner
- [ ] identify
- [ ] citizenship
- [ ] label
- [ ] slippery

# Chapter 066

- [ ] forum
- [ ] contempt
- [ ] modify
- [ ] environment
- [ ] clone
- [ ] betray
- [ ] progressive
- [ ] pledge
- [ ] exempt
- [ ] deliberate
- [ ] physiological
- [ ] shaft
- [ ] aesthetic
- [ ] atmosphere
- [ ] decorate
- [ ] electrician
- [ ] occupation
- [ ] tendency
- [ ] release
- [ ] caption

# Chapter 067

- [ ] hardy
- [ ] purify
- [ ] toll
- [ ] variation
- [ ] moral
- [ ] rig
- [ ] eject
- [ ] defect
- [ ] reinforce
- [ ] casual
- [ ] slack
- [ ] rim
- [ ] property
- [ ] rip
- [ ] outbreak
- [ ] manipulate
- [ ] similar
- [ ] contradict
- [ ] melody
- [ ] likelihood

# Chapter 068

- [ ] converge
- [ ] compose
- [ ] catholic
- [ ] partial
- [ ] aid
- [ ] supersonic
- [ ] optimism
- [ ] confident
- [ ] retain
- [ ] drastic
- [ ] epoch
- [ ] saleable
- [ ] crew
- [ ] manufacturer
- [ ] defeat
- [ ] valid
- [ ] inertia
- [ ] encourage
- [ ] vacuum
- [ ] extravagant

# Chapter 069

- [ ] accommodate
- [ ] bubble
- [ ] morality
- [ ] yield
- [ ] electronic
- [ ] transplant
- [ ] terrace
- [ ] deficit
- [ ] sacred
- [ ] cathedral
- [ ] elegant
- [ ] synthesis
- [ ] incidentally
- [ ] polar
- [ ] shark
- [ ] linger
- [ ] historian
- [ ] cumulative
- [ ] prototype
- [ ] overpass

# Chapter 070

- [ ] species
- [ ] slip
- [ ] temperament
- [ ] cite
- [ ] acquaintance
- [ ] moan
- [ ] quench
- [ ] shed
- [ ] spice
- [ ] rating
- [ ] assertive
- [ ] autonomous
- [ ] referee
- [ ] aerial
- [ ] trial
- [ ] perception
- [ ] elapse
- [ ] symmetry
- [ ] visualize
- [ ] reap

# Chapter 071

- [ ] insect
- [ ] presume
- [ ] complement
- [ ] cable
- [ ] nasty
- [ ] intense
- [ ] border
- [ ] estate
- [ ] articulate
- [ ] adhere
- [ ] expense
- [ ] traverse
- [ ] rigorous
- [ ] yell
- [ ] contemporary
- [ ] tribe
- [ ] activate
- [ ] mobilize
- [ ] mock
- [ ] minibus

# Chapter 072

- [ ] repetitive
- [ ] gear
- [ ] facilitate
- [ ] precipitate
- [ ] endow
- [ ] financial
- [ ] respective
- [ ] quiver
- [ ] slot
- [ ] harden
- [ ] rot
- [ ] define
- [ ] predict
- [ ] dictate
- [ ] memorize
- [ ] render
- [ ] undermine
- [ ] subjective
- [ ] blossom
- [ ] radical

# Chapter 073

- [ ] manifest
- [ ] blunt
- [ ] endeavor
- [ ] relieve
- [ ] quartz
- [ ] air-conditioning
- [ ] adjacent
- [ ] employment
- [ ] transport
- [ ] specific
- [ ] analogy
- [ ] application
- [ ] productive
- [ ] prune
- [ ] engage
- [ ] chord
- [ ] semester
- [ ] strategy
- [ ] remainder
- [ ] hypothesis

# Chapter 074

- [ ] revolve
- [ ] collapse
- [ ] territory
- [ ] summon
- [ ] flare
- [ ] accurate
- [ ] legend
- [ ] maintain
- [ ] expertise
- [ ] bargain
- [ ] erect
- [ ] professional
- [ ] nil
- [ ] identification
- [ ] migrant
- [ ] protein
- [ ] annual
- [ ] exclusive
- [ ] repertoire
- [ ] poverty

# Chapter 075

- [ ] resort
- [ ] testify
- [ ] pearl
- [ ] conclusive
- [ ] margin
- [ ] apt
- [ ] remain
- [ ] pregnancy
- [ ] shabby
- [ ] toss
- [ ] demand
- [ ] reel
- [ ] pathetic
- [ ] dissipate
- [ ] flask
- [ ] accuse
- [ ] disturbance
- [ ] visceral
- [ ] simultaneous
- [ ] instructional

# Chapter 076

- [ ] guarantee
- [ ] odor
- [ ] predecessor
- [ ] acquire
- [ ] literal
- [ ] notion
- [ ] default
- [ ] arc
- [ ] beverage
- [ ] captive
- [ ] insane
- [ ] attribute
- [ ] cemetery
- [ ] genetic
- [ ] stitch
- [ ] triumph
- [ ] vice
- [ ] detection
- [ ] bowel
- [ ] arouse

# Chapter 077

- [ ] optimum
- [ ] suppress
- [ ] pudding
- [ ] wrinkle
- [ ] consensus
- [ ] boring
- [ ] classic
- [ ] supervise
- [ ] gossip
- [ ] describe
- [ ] dilemma
- [ ] engagement
- [ ] wealthy
- [ ] slum
- [ ] foam
- [ ] disregard
- [ ] administration
- [ ] occasional
- [ ] dwell
- [ ] incorporate

# Chapter 078

- [ ] debate
- [ ] extinguish
- [ ] vulnerable
- [ ] furniture
- [ ] segment
- [ ] counterpart
- [ ] preach
- [ ] flank
- [ ] donate
- [ ] pendulum
- [ ] defiance
- [ ] sovereign
- [ ] cater
- [ ] attractive
- [ ] significant
- [ ] duplicate
- [ ] bleed
- [ ] rein
- [ ] decrease
- [ ] flutter

# Chapter 079

- [ ] volunteer
- [ ] overlap
- [ ] materialism
- [ ] installment
- [ ] mourn
- [ ] cane
- [ ] trifle
- [ ] migrate
- [ ] Easter
- [ ] submit
- [ ] novelty
- [ ] occupy
- [ ] string
- [ ] boom
- [ ] absence
- [ ] abolish
- [ ] attract
- [ ] cautious
- [ ] snatch
- [ ] blink

# Chapter 080

- [ ] summit
- [ ] perfume
- [ ] magnify
- [ ] redundant
- [ ] situated
- [ ] recession
- [ ] doubtless
- [ ] negative
- [ ] impose
- [ ] statement
- [ ] trademark
- [ ] factor
- [ ] analogous
- [ ] substance
- [ ] complexion
- [ ] continuity
- [ ] sculpture
- [ ] target
- [ ] momentum
- [ ] wax

# Chapter 081

- [ ] sensation
- [ ] urban
- [ ] furthermore
- [ ] timely
- [ ] cape
- [ ] discard
- [ ] delicate
- [ ] rebel
- [ ] subsidy
- [ ] bounce
- [ ] obscene
- [ ] tissue
- [ ] Thanksgiving
- [ ] proficiency
- [ ] modest
- [ ] cast
- [ ] vocational
- [ ] crush
- [ ] hatred
- [ ] slice

# Chapter 082

- [ ] electron
- [ ] embed
- [ ] incline
- [ ] elevate
- [ ] designate
- [ ] promising
- [ ] slick
- [ ] practicable
- [ ] item
- [ ] counsel
- [ ] canvas
- [ ] superintendent
- [ ] probability
- [ ] contention
- [ ] lofty
- [ ] explicit
- [ ] rely
- [ ] slide
- [ ] utilize
- [ ] sticky

# Chapter 083

- [ ] prevail
- [ ] excessive
- [ ] denial
- [ ] assault
- [ ] implicit
- [ ] intensify
- [ ] feminine
- [ ] purity
- [ ] pattern
- [ ] settle
- [ ] heighten
- [ ] vehicle
- [ ] scrape
- [ ] web
- [ ] femininity
- [ ] plateau
- [ ] tragic
- [ ] grin
- [ ] grip
- [ ] reliance

# Chapter 084

- [ ] explore
- [ ] display
- [ ] electricity
- [ ] climate
- [ ] tentative
- [ ] disorder
- [ ] aggravate
- [ ] criticize
- [ ] preside
- [ ] economic
- [ ] transistor
- [ ] statistics
- [ ] grim
- [ ] giggle
- [ ] offspring
- [ ] arrest
- [ ] mature
- [ ] alleviate
- [ ] notification
- [ ] overflow

# Chapter 085

- [ ] provoke
- [ ] threaten
- [ ] enrich
- [ ] foil
- [ ] strain
- [ ] negotiate
- [ ] cellar
- [ ] tangle
- [ ] package
- [ ] intrigue
- [ ] orient
- [ ] crisis
- [ ] handicap
- [ ] survival
- [ ] shatter
- [ ] plea
- [ ] persuasion
- [ ] keen
- [ ] nutrition
- [ ] detective

# Chapter 086

- [ ] transfer
- [ ] veteran
- [ ] cereal
- [ ] esthetic
- [ ] indifferent
- [ ] affection
- [ ] diversion
- [ ] elementary
- [ ] eagle
- [ ] solemn
- [ ] embarrass
- [ ] erroneous
- [ ] option
- [ ] acute
- [ ] limitation
- [ ] jog
- [ ] terrify
- [ ] handbook
- [ ] ascertain
- [ ] crucial

# Chapter 087

- [ ] contribute
- [ ] insert
- [ ] faith
- [ ] inspiration
- [ ] endurance
- [ ] highlight
- [ ] candidate
- [ ] strive
- [ ] database
- [ ] intelligible
- [ ] parallel
- [ ] reject
- [ ] hospitality
- [ ] sheer
- [ ] imitation
- [ ] compliment
- [ ] blunder
- [ ] breach
- [ ] original
- [ ] comply

# Chapter 088

- [ ] deviate
- [ ] assignment
- [ ] album
- [ ] stimulus
- [ ] electric
- [ ] bewilder
- [ ] regiment
- [ ] diminish
- [ ] surpass
- [ ] various
- [ ] depression
- [ ] affiliate
- [ ] unfold
- [ ] extent
- [ ] equivalent
- [ ] sensational
- [ ] wedge
- [ ] alienate
- [ ] brink
- [ ] plague

# Chapter 089

- [ ] perpetual
- [ ] retrospect
- [ ] fascinate
- [ ] colonial
- [ ] warfare
- [ ] draft
- [ ] complex
- [ ] assumption
- [ ] humidity
- [ ] rank
- [ ] pamphlet
- [ ] preparatory
- [ ] neglect
- [ ] addition
- [ ] vein
- [ ] carve
- [ ] veil
- [ ] shrink
- [ ] hierarchy
- [ ] ancestor

# Chapter 090

- [ ] hazardous
- [ ] locality
- [ ] proceeding
- [ ] artery
- [ ] panic
- [ ] underestimate
- [ ] fold
- [ ] transient
- [ ] hurl
- [ ] competitive
- [ ] dean
- [ ] sponge
- [ ] abuse
- [ ] scheme
- [ ] insulate
- [ ] consequently
- [ ] drain
- [ ] reluctance
- [ ] rape
- [ ] isolate

# Chapter 091

- [ ] popularity
- [ ] nickname
- [ ] subsequent
- [ ] metabolic
- [ ] humanity
- [ ] innovation
- [ ] litter
- [ ] charge
- [ ] shutter
- [ ] alternate
- [ ] biography
- [ ] procedure
- [ ] sample
- [ ] plunge
- [ ] skeptical
- [ ] ultraviolet
- [ ] planetary
- [ ] visa
- [ ] diagnose
- [ ] petition

# Chapter 092

- [ ] vicinity
- [ ] naive
- [ ] essential
- [ ] expenditure
- [ ] vent
- [ ] haunt
- [ ] precede
- [ ] gasp
- [ ] stroll
- [ ] furnish
- [ ] differentiate
- [ ] contact
- [ ] garment
- [ ] discharge
- [ ] exclude
- [ ] scary
- [ ] criticism
- [ ] enlighten
- [ ] utmost
- [ ] prospective

# Chapter 093

- [ ] deduct
- [ ] plaster
- [ ] consultancy
- [ ] metropolitan
- [ ] portray
- [ ] garbage
- [ ] suspicious
- [ ] scrub
- [ ] complain
- [ ] homogeneous
- [ ] affirm
- [ ] profound
- [ ] marble
- [ ] anxiety
- [ ] adjust
- [ ] aspiration
- [ ] vigorous
- [ ] vocal
- [ ] deem
- [ ] origin

# Chapter 094

- [ ] clash
- [ ] overturn
- [ ] compel
- [ ] depress
- [ ] capable
- [ ] burden
- [ ] salute
- [ ] clasp
- [ ] symposium
- [ ] hover
- [ ] random
- [ ] dine
- [ ] personality
- [ ] sanction
- [ ] alert
- [ ] deduce
- [ ] oak
- [ ] client
- [ ] sip
- [ ] dutiful

# Chapter 095

- [ ] contend
- [ ] conversion
- [ ] brilliant
- [ ] gamble
- [ ] bound
- [ ] specification
- [ ] deport
- [ ] counter
- [ ] rhythm
- [ ] layman
- [ ] conserve
- [ ] stroke
- [ ] breed
- [ ] tease
- [ ] rash
- [ ] fragrance
- [ ] management
- [ ] cylinder
- [ ] fort
- [ ] avoid

# Chapter 096

- [ ] comprehensive
- [ ] tunnel
- [ ] assign
- [ ] withdraw
- [ ] straightforward
- [ ] elaborate
- [ ] expert
- [ ] decade
- [ ] fulfill
- [ ] crowd
- [ ] congress
- [ ] mechanical
- [ ] divine
- [ ] slaughter
- [ ] foul
- [ ] output
- [ ] intricate
- [ ] fatigue
- [ ] agony
- [ ] contemplate

# Chapter 097

- [ ] majority
- [ ] drag
- [ ] zinc
- [ ] costume
- [ ] clamp
- [ ] issue
- [ ] maturity
- [ ] vain
- [ ] decree
- [ ] conservation
- [ ] supplement
- [ ] contrast
- [ ] verdict
- [ ] stereo
- [ ] defy
- [ ] doctrine
- [ ] paragraph
- [ ] mediate
- [ ] pursuit
- [ ] prophet

# Chapter 098

- [ ] cycle
- [ ] amplify
- [ ] lure
- [ ] disposal
- [ ] settlement
- [ ] whirl
- [ ] recede
- [ ] literature
- [ ] digest
- [ ] slump
- [ ] prejudice
- [ ] clearance
- [ ] customary
- [ ] immigrant
- [ ] guardian
- [ ] veto
- [ ] thorn
- [ ] disposition
- [ ] corporate
- [ ] stabilize

# Chapter 099

- [ ] compensate
- [ ] conscious
- [ ] transaction
- [ ] constant
- [ ] bribe
- [ ] certify
- [ ] intermittent
- [ ] outrage
- [ ] solitary
- [ ] diffuse
- [ ] scramble
- [ ] orchestra
- [ ] immerse
- [ ] sufficient
- [ ] marshal
- [ ] champagne
- [ ] claim
- [ ] widespread
- [ ] antique
- [ ] communication

# Chapter 100

- [ ] chronic
- [ ] toxic
- [ ] contest
- [ ] author
- [ ] lever
- [ ] preserve
- [ ] establish
- [ ] expansion
- [ ] wrench
- [ ] relevant
- [ ] expand
- [ ] gaze
- [ ] proclaim
- [ ] magistrate
- [ ] retrieve
- [ ] survey
- [ ] jeopardize
- [ ] spy
- [ ] displace
- [ ] predominant

# Chapter 101

- [ ] recipe
- [ ] ideology
- [ ] mental
- [ ] decent
- [ ] seam
- [ ] investigate
- [ ] racial
- [ ] illusion
- [ ] considerable
- [ ] productivity
- [ ] proposition
- [ ] reserve
- [ ] savage
- [ ] heap
- [ ] sympathy
- [ ] consumer
- [ ] cripple
- [ ] brief
- [ ] console
- [ ] initiative

# Chapter 102

- [ ] recover
- [ ] clockwise
- [ ] embark
- [ ] medication
- [ ] drill
- [ ] friction
- [ ] confer
- [ ] intelligent
- [ ] clerk
- [ ] acknowledge
- [ ] equip
- [ ] deferential
- [ ] manuscript
- [ ] luxury
- [ ] overthrow
- [ ] knit
- [ ] inflict
- [ ] worthwhile
- [ ] inland
- [ ] stumble

# Chapter 103

- [ ] specialty
- [ ] vary
- [ ] readily
- [ ] coherent
- [ ] intercourse
- [ ] convenience
- [ ] decency
- [ ] falsehood
- [ ] discipline
- [ ] ponder
- [ ] objective
- [ ] exert
- [ ] scandal
- [ ] composite
- [ ] hinder
- [ ] scent
- [ ] estimate
- [ ] diploma
- [ ] exhibit
- [ ] brand

# Chapter 104

- [ ] suspension
- [ ] alcohol
- [ ] inevitable
- [ ] deny
- [ ] trench
- [ ] subtract
- [ ] recreation
- [ ] frustration
- [ ] allowance
- [ ] hurricane
- [ ] hike
- [ ] ancient
- [ ] mission
- [ ] cognitive
- [ ] adopt
- [ ] expire
- [ ] smuggle
- [ ] hustle
- [ ] oppose
- [ ] device

# Chapter 105

- [ ] commentary
- [ ] sue
- [ ] conservative
- [ ] belly
- [ ] access
- [ ] conference
- [ ] primitive
- [ ] knob
- [ ] advisable
- [ ] overcome
- [ ] cabin
- [ ] recite
- [ ] oppress
- [ ] current
- [ ] heel
- [ ] gloom
- [ ] adore
- [ ] persist
- [ ] caution
- [ ] offensive

# Chapter 106

- [ ] texture
- [ ] closet
- [ ] speculate
- [ ] dismantle
- [ ] monster
- [ ] bud
- [ ] confirm
- [ ] bug
- [ ] prescient
- [ ] acquaint
- [ ] elastic
- [ ] consequent
- [ ] vast
- [ ] intervene
- [ ] symbol
- [ ] ignite
- [ ] commercial
- [ ] revelation
- [ ] available
- [ ] innumerable

# Chapter 107

- [ ] advocate
- [ ] confine
- [ ] quest
- [ ] frequency
- [ ] elicit
- [ ] relegate
- [ ] trivial
- [ ] burial
- [ ] luggage
- [ ] drawback
- [ ] longevity
- [ ] military
- [ ] dynamic
- [ ] wardrobe
- [ ] reluctant
- [ ] conscientious
- [ ] passion
- [ ] generate
- [ ] extreme
- [ ] tuck

# Chapter 108

- [ ] authoritative
- [ ] athlete
- [ ] upright
- [ ] extract
- [ ] obscure
- [ ] dismay
- [ ] expend
- [ ] forge
- [ ] demonstrate
- [ ] region
- [ ] deceive
- [ ] preview
- [ ] ingenious
- [ ] questionnaire
- [ ] breakthrough
- [ ] snack
- [ ] yoke
- [ ] destination
- [ ] throne
- [ ] privacy

# Chapter 109

- [ ] reciprocal
- [ ] vertical
- [ ] inventory
- [ ] vivid
- [ ] flush
- [ ] heir
- [ ] screw
- [ ] kit
- [ ] virtue
- [ ] emphasize
- [ ] turnover
- [ ] mortal
- [ ] coverage
- [ ] figure
- [ ] brutal
- [ ] slight
- [ ] ore
- [ ] corrupt
- [ ] preclude
- [ ] previous

# Chapter 110

- [ ] regime
- [ ] transmit
- [ ] commemorate
- [ ] argue
- [ ] consumption
- [ ] premature
- [ ] superior
- [ ] drought
- [ ] periodical
- [ ] leaflet
- [ ] accessory
- [ ] compromise
- [ ] retort
- [ ] electrify
- [ ] seminar
- [ ] fringe
- [ ] competition
- [ ] beyond
- [ ] hazard
- [ ] justify

# Chapter 111

- [ ] dreadful
- [ ] voluntary
- [ ] connection
- [ ] proof
- [ ] militant
- [ ] simulate
- [ ] intricacy
- [ ] phase
- [ ] dilute
- [ ] inclusive
- [ ] efficiency
- [ ] ethnic
- [ ] spectacle
- [ ] overhead
- [ ] contract
- [ ] conclude
- [ ] profitable
- [ ] misfortune
- [ ] comprehension
- [ ] susceptible

# Chapter 112

- [ ] leather
- [ ] insight
- [ ] intact
- [ ] instrumental
- [ ] fabric
- [ ] revolutionary
- [ ] unemployment
- [ ] juvenile
- [ ] force
- [ ] sympathetic
- [ ] periodic
- [ ] distribution
- [ ] derive
- [ ] capacity
- [ ] cope
- [ ] overhear
- [ ] dart
- [ ] flaw
- [ ] saturate
- [ ] feature

# Chapter 113

- [ ] flat
- [ ] assert
- [ ] climax
- [ ] recall
- [ ] rectangular
- [ ] flap
- [ ] precise
- [ ] sensible
- [ ] objection
- [ ] precious
- [ ] contrive
- [ ] inhabitant
- [ ] fraction
- [ ] token
- [ ] emotion
- [ ] massive
- [ ] assess
- [ ] mingle
- [ ] prescription
- [ ] spectator

# Chapter 114

- [ ] edible
- [ ] prone
- [ ] chorus
- [ ] owe
- [ ] asset
- [ ] exposition
- [ ] minimum
- [ ] apology
- [ ] reveal
- [ ] adequate
- [ ] owl
- [ ] cork
- [ ] tremendous
- [ ] norm
- [ ] condense
- [ ] impetus
- [ ] indignation
- [ ] barrier
- [ ] realistic
- [ ] divert

# Chapter 115

- [ ] conspicuous
- [ ] verse
- [ ] criminal
- [ ] furious
- [ ] obesity
- [ ] tan
- [ ] individual
- [ ] briefcase
- [ ] nuisance
- [ ] brace
- [ ] constrain
- [ ] brisk
- [ ] prestige
- [ ] insulation
- [ ] cord
- [ ] startle
- [ ] interim
- [ ] fraud
- [ ] testimony
- [ ] council

# Chapter 116

- [ ] reaffirm
- [ ] enforce
- [ ] glitter
- [ ] destined
- [ ] repression
- [ ] fragile
- [ ] penalty
- [ ] sociology
- [ ] exile
- [ ] scale
- [ ] gigantic
- [ ] distinct
- [ ] vegetation
- [ ] recovery
- [ ] geology
- [ ] hoist
- [ ] aware
- [ ] quart
- [ ] numerical
- [ ] limp

# Chapter 117

- [ ] security
- [ ] award
- [ ] buck
- [ ] eligible
- [ ] alarm
- [ ] feeble
- [ ] appraisal
- [ ] continual
- [ ] herb
- [ ] prose
- [ ] limb
- [ ] orientation
- [ ] refreshment
- [ ] confidence
- [ ] arbitrary
- [ ] intent
- [ ] passive
- [ ] fertilizer
- [ ] corresponding
- [ ] oath

# Chapter 118

- [ ] response
- [ ] treaty
- [ ] dignity
- [ ] challenge
- [ ] rival

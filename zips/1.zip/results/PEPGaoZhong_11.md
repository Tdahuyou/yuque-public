
# Chapter 001

- [ ] Auckland
- [ ] Maori
- [ ] kiwi
- [ ] Stewart Island
- [ ] tectonic
- [ ] geological
- [ ] geology
- [ ] plateau
- [ ] Alps
- [ ] backbone
- [ ] graze
- [ ] strip
- [ ] Christchurch
- [ ] carve
- [ ] paddle
- [ ] uninhabited
- [ ] extinction
- [ ] fern
- [ ] scarce
- [ ] warlike

# Chapter 002

- [ ] tribe
- [ ] wipe out
- [ ] take over
- [ ] fence
- [ ] immunity
- [ ] immune
- [ ] Christianity
- [ ] treaty
- [ ] representative
- [ ] owenrship
- [ ] unrest
- [ ] civilian
- [ ] bungee jumping
- [ ] fasten
- [ ] elastic
- [ ] suspension
- [ ] appetite
- [ ] buffet
- [ ] pasta
- [ ] porter

# Chapter 003

- [ ] suite
- [ ] lounge
- [ ] laundry
- [ ] helicopter
- [ ] brunch
- [ ] Napier
- [ ] Burma
- [ ] Lake Taupo
- [ ] dairy
- [ ] statistics
- [ ] eco-friendly
- [ ] subtropical
- [ ] fiord
- [ ] not to mention
- [ ] recreation
- [ ] raft
- [ ] abseil
- [ ] get around
- [ ] hemisphere
- [ ] schedule

# Chapter 004

- [ ] extensive
- [ ] flexible
- [ ] pace
- [ ] insurance
- [ ] insure
- [ ] theft
- [ ] handy
- [ ] consultant
- [ ] guidance
- [ ] database
- [ ] cater
- [ ] cater for sb
- [ ] cater for sth
- [ ] enquiry
- [ ] extension
- [ ] vertical
- [ ] axis
- [ ] detect
- [ ] Bahmad
- [ ] jogger

# Chapter 005

- [ ] forensic
- [ ] spray
- [ ] fingerprint
- [ ] stain
- [ ] wrap
- [ ] bind
- [ ] torso
- [ ] Dempsey
- [ ] surgeon
- [ ] X-ray
- [ ] abnormal
- [ ] Shipley
- [ ] emergency
- [ ] by law
- [ ] jury
- [ ] imprisonment
- [ ] assessment
- [ ] widow
- [ ] compensate
- [ ] maximum

# Chapter 006

- [ ] motive
- [ ] savagely
- [ ] ward
- [ ] lame
- [ ] thriller
- [ ] confidential
- [ ] ministry
- [ ] funeral
- [ ] memorial
- [ ] trend
- [ ] unemployment
- [ ] taxpayer
- [ ] import
- [ ] aluminium
- [ ] surplus
- [ ] Arthur Conan Doyle
- [ ] Jaez Wilson
- [ ] Sherlock Holmes
- [ ] flame
- [ ] greengrocer

# Chapter 007

- [ ] greengrocer’s
- [ ] alley
- [ ] remark
- [ ] make of sth
- [ ] make of sb
- [ ] candidate
- [ ] furnish
- [ ] expel
- [ ] allowance
- [ ] every so often
- [ ] peculiar
- [ ] strategy
- [ ] myth
- [ ] harmony
- [ ] depressed
- [ ] well-balanced
- [ ] prescription
- [ ] cope
- [ ] cope with
- [ ] let down

# Chapter 008

- [ ] proportion
- [ ] fulfil
- [ ] effective
- [ ] agenda
- [ ] interval
- [ ] session
- [ ] contradictory
- [ ] revise
- [ ] curriculum
- [ ] informal
- [ ] deadline
- [ ] rigid
- [ ] subscribe
- [ ] post-graduate
- [ ] academy
- [ ] stead
- [ ] stand sb in good stead
- [ ] employer
- [ ] diploma
- [ ] format

# Chapter 009

- [ ] glory
- [ ] glory in
- [ ] forgetful
- [ ] administration
- [ ] choir
- [ ] postcode
- [ ] withdraw
- [ ] sake
- [ ] for one’s own sake
- [ ] pursuit
- [ ] pursue
- [ ] pedicab
- [ ] sleep rough
- [ ] feed on
- [ ] philosophical
- [ ] socialism
- [ ] receipt
- [ ] outweigh
- [ ] ensure
- [ ] reproach

# Chapter 010

- [ ] jealousy
- [ ] cease
- [ ] cease to be
- [ ] count up
- [ ] reinforce
- [ ] Odysseus
- [ ] Trojan
- [ ] Ithaca
- [ ] Telemachus
- [ ] split
- [ ] violate
- [ ] temporary
- [ ] Penelope
- [ ] statesman
- [ ] statesmanlike
- [ ] unconditional
- [ ] Cyclops
- [ ] scar
- [ ] howl
- [ ] merciful

# Chapter 011

- [ ] at the crack of dawn
- [ ] quick as a flash
- [ ] hatch
- [ ] whistle
- [ ] heel
- [ ] a wolf in sheep’s clothing
- [ ] pint
- [ ] dead to the world
- [ ] socket
- [ ] stagger
- [ ] agony
- [ ] belly
- [ ] wrestle
- [ ] Circe
- [ ] marble
- [ ] arch
- [ ] coarse
- [ ] pillow
- [ ] quilt
- [ ] trough

# Chapter 012

- [ ] slice
- [ ] wear off
- [ ] saucer
- [ ] circus
- [ ] freeway
- [ ] plug
- [ ] hydrogen
- [ ] clay
- [ ] moustache
- [ ] mustard
- [ ] Theseus
- [ ] enlarge
- [ ] tournament
- [ ] fist
- [ ] combat
- [ ] walnut
- [ ] transparent
- [ ] transparently
- [ ] tug
- [ ] dismay

# Chapter 013

- [ ] pulse
- [ ] zoom
- [ ] zoom in on
- [ ] insignificant
- [ ] Sinis
- [ ] Procrustes
- [ ] Crete
- [ ] fleece
- [ ] Perseus
- [ ] vice versa
- [ ] (be) faced with
- [ ] scholarship
- [ ] in disbelief
- [ ] drop into
- [ ] unsettling
- [ ] dozens of
- [ ] now and again
- [ ] expectantly
- [ ] suck
- [ ] co-operate

# Chapter 014

- [ ] hand out
- [ ] preference
- [ ] pleasureable
- [ ] anticipation
- [ ] intellectual
- [ ] arithmetic
- [ ] algebra
- [ ] interpersonal
- [ ] complex
- [ ] agro-scientifc
- [ ] core
- [ ] drop in
- [ ] recommendation
- [ ] call on
- [ ] composer
- [ ] mathematician
- [ ] stewardess
- [ ] diplomat
- [ ] embassy
- [ ] referee

# Chapter 015

- [ ] brake
- [ ] swerve
- [ ] missile
- [ ] bishop
- [ ] circuit
- [ ] go on circuit
- [ ] razor
- [ ] shaver
- [ ] oval
- [ ] orbit
- [ ] substance
- [ ] curriculum vitae
- [ ] nickname
- [ ] presentational
- [ ] fabulous
- [ ] IELTS
- [ ] accountancy
- [ ] function
- [ ] bureaucratic
- [ ] ethos

# Chapter 016

- [ ] minefield
- [ ] unwary
- [ ] autobiography
- [ ] build on
- [ ] prosperous
- [ ] to tell you the truth
- [ ] tempt
- [ ] appendix
- [ ] roundabout


# Chapter 001

- [ ] globalisation
- [ ] race
- [ ] brand
- [ ] import
- [ ] ethnic
- [ ] non-native
- [ ] multinational
- [ ] investor
- [ ] multi-ethnic
- [ ] emigration
- [ ] immigration
- [ ] clash
- [ ] Americanisation
- [ ] deprive
- [ ] come to the fore
- [ ] subcontinent
- [ ] uniqueness
- [ ] opposing
- [ ] pursue
- [ ] likewise

# Chapter 002

- [ ] infectious
- [ ] billboard
- [ ] youngster
- [ ] headset
- [ ] sip
- [ ] multi-storey
- [ ] lane
- [ ] stroke
- [ ] episode
- [ ] high-rise
- [ ] unimaginable
- [ ] commonplace
- [ ] spare
- [ ] out of date
- [ ] simplify
- [ ] controller
- [ ] command
- [ ] Applied Linguistics
- [ ] subsequent
- [ ] implication

# Chapter 003

- [ ] intelligible
- [ ] conform
- [ ] Arabic
- [ ] legitimate
- [ ] patronise
- [ ] drawback
- [ ] consideration
- [ ] devise
- [ ] syllabus
- [ ] monolingual
- [ ] mathematical
- [ ] spatial
- [ ] geometry
- [ ] score
- [ ] fund
- [ ] monetary
- [ ] annual
- [ ] disperse
- [ ] marcher
- [ ] cut off

# Chapter 004

- [ ] Hindu
- [ ] Maha Kumbh Mela
- [ ] commemorate
- [ ] mythological
- [ ] confer
- [ ] immortality
- [ ] sadhu
- [ ] simplicity
- [ ] chariot
- [ ] pilgrim
- [ ] wipe away
- [ ] sin
- [ ] downpour
- [ ] douse
- [ ] bushfire
- [ ] fortnight
- [ ] evacuation
- [ ] welfare
- [ ] telecom
- [ ] geographical

# Chapter 005

- [ ] boundary
- [ ] highly
- [ ] the World Wireless Forum
- [ ] mobility
- [ ] freelancer
- [ ] migrant
- [ ] ownership
- [ ] vague
- [ ] countless
- [ ] indispensable
- [ ] long for
- [ ] relieved
- [ ] cross
- [ ] furious
- [ ] insecure
- [ ] shattered
- [ ] disillusioned
- [ ] let down
- [ ] satisfaction
- [ ] dread

# Chapter 006

- [ ] sprain
- [ ] disallow
- [ ] out of the blue
- [ ] intend
- [ ] punchline
- [ ] grizzly
- [ ] passion
- [ ] caveman
- [ ] playwright
- [ ] statesman
- [ ] habit-forming
- [ ] juggle
- [ ] packed
- [ ] blazing
- [ ] hesitant
- [ ] squint
- [ ] wildly
- [ ] bounce
- [ ] hop
- [ ] limp

# Chapter 007

- [ ] mystified
- [ ] ashamed
- [ ] amusement
- [ ] desperation
- [ ] onwards
- [ ] beg for
- [ ] messy
- [ ] retire
- [ ] wit
- [ ] purse
- [ ] heartbroken
- [ ] belongings
- [ ] chop
- [ ] majesty
- [ ] sob
- [ ] count
- [ ] sideboard
- [ ] jester
- [ ] astonishment
- [ ] carefree

# Chapter 008

- [ ] camouflage
- [ ] shield
- [ ] for sure
- [ ] unforgettable
- [ ] cunning
- [ ] undo
- [ ] collar
- [ ] unbutton
- [ ] thread
- [ ] mutter
- [ ] undisturbed
- [ ] stride
- [ ] presently
- [ ] shabby
- [ ] promptly
- [ ] tumble
- [ ] punch
- [ ] astride
- [ ] pound
- [ ] rage

# Chapter 009

- [ ] relive
- [ ] good manners
- [ ] disrespectful
- [ ] revolting
- [ ] gentlemanly
- [ ] unhygienic
- [ ] unprofessional
- [ ] misinterpreted
- [ ] drop in
- [ ] sneeze
- [ ] curse
- [ ] context
- [ ] infuriate
- [ ] dispenser
- [ ] device
- [ ] disapprove
- [ ] uneasy
- [ ] aural
- [ ] confusion
- [ ] standardisation

# Chapter 010

- [ ] be supposed to
- [ ] awkwardness
- [ ] overdue
- [ ] liar
- [ ] dialect
- [ ] spinach
- [ ] excessive
- [ ] undivided
- [ ] go into details
- [ ] display
- [ ] put sb. down
- [ ] make light of
- [ ] dumbness
- [ ] get one's mind off
- [ ] tactful
- [ ] straightforward
- [ ] opinionated
- [ ] obligation
- [ ] necessity
- [ ] inappropriate

# Chapter 011

- [ ] voice mail
- [ ] funeral
- [ ] punctual
- [ ] the other night
- [ ] calm down
- [ ] socialise
- [ ] stumble
- [ ] dry up
- [ ] be unsure of
- [ ] status
- [ ] interrogation
- [ ] tempt
- [ ] unclear
- [ ] summarise
- [ ] restate
- [ ] look sb.in the eye
- [ ] distract
- [ ] over-emotional
- [ ] charm
- [ ] unconsciously

# Chapter 012

- [ ] come across
- [ ] get across
- [ ] resent
- [ ] defensive
- [ ] washed
- [ ] flatmate
- [ ] protective
- [ ] hint
- [ ] spoil
- [ ] drop out
- [ ] sack
- [ ] fly off the handle
- [ ] explosive
- [ ] conversational
- [ ] concise
- [ ] courteous
- [ ] overuse
- [ ] cliché
- [ ] punctuation
- [ ] courtesy

# Chapter 013

- [ ] sign-off
- [ ] neglect
- [ ] for the sake of
- [ ] recipient
- [ ] annoyance
- [ ] abbreviation
- [ ] as far as
- [ ] overdo
- [ ] oblivious
- [ ] dispatch
- [ ] in accordance with
- [ ] herewith
- [ ] sum
- [ ] print
- [ ] dinosaur
- [ ] endeavour
- [ ] retail
- [ ] outlet
- [ ] uncooperative
- [ ] reluctant

# Chapter 014

- [ ] nuisance
- [ ] aisle
- [ ] choke
- [ ] ineffective
- [ ] oasis
- [ ] numerous
- [ ] tailor made
- [ ] place an order
- [ ] mar
- [ ] litterbug
- [ ] efficiency
- [ ] pothole
- [ ] install
- [ ] payoff
- [ ] jail
- [ ] civil
- [ ] tag
- [ ] auction
- [ ] plaster
- [ ] outnumber

# Chapter 015

- [ ] slingshot
- [ ] violation
- [ ] chime
- [ ] back up
- [ ] publicity
- [ ] slogan
- [ ] antispit
- [ ] distribution
- [ ] pamphlet
- [ ] poster
- [ ] strip
- [ ] contest
- [ ] liveable
- [ ] flush
- [ ] enact
- [ ] inspector
- [ ] intrude
- [ ] consciousness
- [ ] norm


# Chapter 001

- [ ] hurdling
- [ ] boxing
- [ ] hula hooping
- [ ] pogo stick jumping
- [ ] jumping jack
- [ ] somersaulting
- [ ] lunge
- [ ] Ashrita Furman
- [ ] Guinness
- [ ] Guiness Book of World Records
- [ ] approximate
- [ ] approximately
- [ ] conventional
- [ ] laughter
- [ ] reality
- [ ] in reality
- [ ] ajustment
- [ ] tough
- [ ] extreme
- [ ] vomit

# Chapter 002

- [ ] gymnastics
- [ ] gymnastically
- [ ] unfit
- [ ] fascinate
- [ ] meditation
- [ ] Sri chinmoy
- [ ] spiritual
- [ ] marathon
- [ ] urge
- [ ] accomplish
- [ ] motivation
- [ ] devotion
- [ ] soul
- [ ] sacred
- [ ] deed
- [ ] conception
- [ ] tact
- [ ] regret
- [ ] repentance
- [ ] wisdom

# Chapter 003

- [ ] virtue
- [ ] noble
- [ ] doom
- [ ] bid
- [ ] juggle
- [ ] triathlon
- [ ] triathlete
- [ ] amateur
- [ ] champion
- [ ] therefore
- [ ] Barcelona
- [ ] springboard
- [ ] economics
- [ ] Slovenia
- [ ] entire
- [ ] the Danube River
- [ ] attain
- [ ] the Parana River
- [ ] profile
- [ ] courageous

# Chapter 004

- [ ] appreciate
- [ ] appreciation
- [ ] accountant
- [ ] receptionist
- [ ] lawyer
- [ ] politician
- [ ] scarf
- [ ] zip
- [ ] underwear
- [ ] overcoat
- [ ] salary
- [ ] wage
- [ ] Marco Polo
- [ ] latitude
- [ ] voyage
- [ ] mercy
- [ ] at the mercy of
- [ ] encyclopedia
- [ ] alongside
- [ ] exploration

# Chapter 005

- [ ] minimum
- [ ] celestial
- [ ] pole
- [ ] equator
- [ ] horizon
- [ ] overhead
- [ ] seaweed
- [ ] nowhere
- [ ] offshore
- [ ] outward
- [ ] tide
- [ ] secure
- [ ] knot
- [ ] log
- [ ] nautical
- [ ] nautical mile
- [ ] magnetic
- [ ] bearing
- [ ] random
- [ ] astrolabe

# Chapter 006

- [ ] awkward
- [ ] reference
- [ ] quadrant
- [ ] precise
- [ ] simplify
- [ ] portable
- [ ] shortcoming
- [ ] sextant
- [ ] update
- [ ] tendency
- [ ] reliable
- [ ] Samuel
- [ ] swoop
- [ ] parcel
- [ ] peck
- [ ] cliff
- [ ] expedition
- [ ] compulsory
- [ ] reform
- [ ] survival

# Chapter 007

- [ ] Captain Bligh
- [ ] Tahiti
- [ ] incident
- [ ] departure
- [ ] crew
- [ ] deposit
- [ ] dilemma
- [ ] drawback
- [ ] dusk
- [ ] routine
- [ ] reckon
- [ ] reckoning
- [ ] starvation
- [ ] psychology
- [ ] tension
- [ ] gradual
- [ ] foresee
- [ ] thirst
- [ ] Timor
- [ ] set loose

# Chapter 008

- [ ] tear
- [ ] hardship
- [ ] jaw
- [ ] jaws of death
- [ ] Greenland
- [ ] Shetland Islands
- [ ] the Faroe Islands
- [ ] roar
- [ ] background
- [ ] associate
- [ ] associate with
- [ ] Perth
- [ ] Kakadu
- [ ] Canberra
- [ ] Uluru
- [ ] barrier
- [ ] Great Barrier Reef
- [ ] brochure
- [ ] Commonwealth
- [ ] Kosciuszko

# Chapter 009

- [ ] Oceania
- [ ] adequate
- [ ] Melbourne
- [ ] ecology
- [ ] autonomous
- [ ] federal
- [ ] defence
- [ ] policy
- [ ] tax
- [ ] taxation
- [ ] nation
- [ ] citizen
- [ ] citizenship
- [ ] celebration
- [ ] birthplace
- [ ] tolerate
- [ ] tolerance
- [ ] migrant
- [ ] homeland
- [ ] via

# Chapter 010

- [ ] Adelaide
- [ ] superb
- [ ] Nullarbor
- [ ] rust
- [ ] rusty
- [ ] tropical
- [ ] splendour
- [ ] timetable
- [ ] heritage
- [ ] aboriginal
- [ ] out of respect
- [ ] fortnight
- [ ] reservation
- [ ] Hobart
- [ ] highway
- [ ] cradle
- [ ] rainfall
- [ ] agriculture
- [ ] sow
- [ ] bachelor

# Chapter 011

- [ ] correspond
- [ ] correspond with
- [ ] owe
- [ ] owe to
- [ ] enclosure
- [ ] authority
- [ ] desperate
- [ ] shrink
- [ ] barbecue
- [ ] talk… into…
- [ ] wind
- [ ] limb
- [ ] venom
- [ ] venomous
- [ ] anti-venom
- [ ] paralyze
- [ ] sickness
- [ ] recover
- [ ] funnel
- [ ] funnelweb spider

# Chapter 012

- [ ] snatch
- [ ] amongst
- [ ] vinegar
- [ ] unconscious
- [ ] pollinate
- [ ] pollinator
- [ ] courtyard
- [ ] balcony
- [ ] exotic
- [ ] date back to
- [ ] distant
- [ ] Egypt
- [ ] goods
- [ ] scale
- [ ] conflict
- [ ] missionary
- [ ] d’Incaville
- [ ] Joseph
- [ ] endeavour
- [ ] anchor

# Chapter 013

- [ ] Nathaniel Ward
- [ ] tight
- [ ] seal
- [ ] container
- [ ] Wardian case
- [ ] restriction
- [ ] fluency
- [ ] shave
- [ ] thunderstorm
- [ ] pirate
- [ ] Father Farges
- [ ] appeal
- [ ] appeal to
- [ ] dove
- [ ] botanist
- [ ] chrysanthemum
- [ ] red date
- [ ] lower
- [ ] beard
- [ ] ripe

# Chapter 014

- [ ] irrigation
- [ ] weed
- [ ] spear
- [ ] string
- [ ] spade
- [ ] postpone
- [ ] pyramid
- [ ] monument
- [ ] pitcher plant
- [ ] Raffesia arnoldii
- [ ] rot
- [ ] evolve
- [ ] evolution
- [ ] nectar
- [ ] attach
- [ ] wasp
- [ ] beetle
- [ ] bat
- [ ] moth
- [ ] humming-bird

# Chapter 015

- [ ] typical
- [ ] petal
- [ ] tube
- [ ] delicate
- [ ] fragrant
- [ ] daisy
- [ ] odour
- [ ] odourless
- [ ] give out
- [ ] dull
- [ ] musty
- [ ] fruity
- [ ] billboard
- [ ] casual
- [ ] garment
- [ ] turn… into
- [ ] advertiser
- [ ] advert
- [ ] inform
- [ ] association

# Chapter 016

- [ ] target
- [ ] fit into
- [ ] basis
- [ ] technique
- [ ] lane
- [ ] feature
- [ ] conscience
- [ ] worthy
- [ ] corporation
- [ ] budget
- [ ] expense
- [ ] broadcast
- [ ] rely
- [ ] rely on
- [ ] visual
- [ ] generate
- [ ] response
- [ ] stereo
- [ ] have no use for
- [ ] refresh

# Chapter 017

- [ ] partly
- [ ] murder
- [ ] suitcase
- [ ] sheet
- [ ] actress
- [ ] typist
- [ ] spokesman
- [ ] fluent
- [ ] hostess
- [ ] invitation
- [ ] appoint
- [ ] chairman
- [ ] raise
- [ ] dial
- [ ] operator
- [ ] litre
- [ ] mature
- [ ] fashion
- [ ] misleading
- [ ] disonest

# Chapter 018

- [ ] alcoholic
- [ ] tobacco
- [ ] ban
- [ ] promote
- [ ] immoral
- [ ] decent
- [ ] ethics
- [ ] ethical
- [ ] offending
- [ ] beware
- [ ] consumer
- [ ] trustworthy

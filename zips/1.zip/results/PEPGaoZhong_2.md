
# Chapter 001

- [ ] cultural
- [ ] relic
- [ ] rare
- [ ] valuable
- [ ] survive
- [ ] vase
- [ ] dynasty
- [ ] Taj Mahal
- [ ] ivory
- [ ] dragon
- [ ] amber
- [ ] in search of
- [ ] Frederick William I
- [ ] Prussia
- [ ] amaze
- [ ] amazing
- [ ] select
- [ ] honey
- [ ] design
- [ ] fancy

# Chapter 002

- [ ] style
- [ ] decorate
- [ ] jewel
- [ ] artist
- [ ] belong
- [ ] belong to
- [ ] Peter the Great
- [ ] in return
- [ ] Czar
- [ ] troop
- [ ] St Petersburg
- [ ] reception
- [ ] CatherineⅡ
- [ ] at war
- [ ] remove
- [ ] less than
- [ ] wooden
- [ ] doubt
- [ ] Konigsberg
- [ ] the Baltic Sea

# Chapter 003

- [ ] mystery
- [ ] former
- [ ] worth
- [ ] rebuild
- [ ] local
- [ ] apart
- [ ] take apart
- [ ] Leningrad
- [ ] painting
- [ ] castle
- [ ] Windsor Castle
- [ ] trial
- [ ] eyewitness
- [ ] evidence
- [ ] Jan Hasek
- [ ] Czech Republic
- [ ] explode
- [ ] entrance
- [ ] Hans Braun
- [ ] sailor

# Chapter 004

- [ ] sink
- [ ] Anna Petrov
- [ ] maid
- [ ] Berlin
- [ ] think highly of
- [ ] Johann Webber
- [ ] informal
- [ ] debate
- [ ] ancient
- [ ] compete
- [ ] competitor
- [ ] take part in
- [ ] medal
- [ ] stand for
- [ ] mascot
- [ ] Pausanias
- [ ] Greece
- [ ] Greek
- [ ] magical
- [ ] volunteer

# Chapter 005

- [ ] homeland
- [ ] regular
- [ ] basis
- [ ] athlete
- [ ] admit
- [ ] slave
- [ ] nowadays
- [ ] gymnastics
- [ ] athletics
- [ ] Stadium
- [ ] gymnasium
- [ ] gym
- [ ] as well
- [ ] host
- [ ] responsibility
- [ ] olive
- [ ] wreath
- [ ] replace
- [ ] motto
- [ ] swift

# Chapter 006

- [ ] similarity
- [ ] Athens
- [ ] charge
- [ ] in charge
- [ ] physical
- [ ] fine
- [ ] poster
- [ ] advertise
- [ ] Atlanta
- [ ] princess
- [ ] glory
- [ ] bargain
- [ ] prince
- [ ] hopeless
- [ ] Hippomenes
- [ ] foolish
- [ ] goddess
- [ ] pain
- [ ] one after another
- [ ] deserve

# Chapter 007

- [ ] striker
- [ ] abacus
- [ ] calculator
- [ ] PC
- [ ] laptop
- [ ] PDA
- [ ] analytical
- [ ] calculate
- [ ] universal
- [ ] simplify
- [ ] sum
- [ ] Charles Babbage
- [ ] operator
- [ ] logical
- [ ] logically
- [ ] technology
- [ ] technological
- [ ] revolution
- [ ] artificial
- [ ] intelligence

# Chapter 008

- [ ] intelligent
- [ ] Alan Turing
- [ ] solve
- [ ] mathematical
- [ ] from…on
- [ ] reality
- [ ] designer
- [ ] personal
- [ ] personally
- [ ] tube
- [ ] transistor
- [ ] chip
- [ ] as a result
- [ ] total
- [ ] totally
- [ ] so…that…
- [ ] network
- [ ] web
- [ ] application
- [ ] finance

# Chapter 009

- [ ] mobile
- [ ] rocket
- [ ] explore
- [ ] Mars
- [ ] anyhow
- [ ] goal
- [ ] happiness
- [ ] human race
- [ ] supporting
- [ ] download
- [ ] programmer
- [ ] virus
- [ ] android
- [ ] signal
- [ ] teammate
- [ ] Nagoya
- [ ] Seattle
- [ ] type
- [ ] in a way
- [ ] coach

# Chapter 010

- [ ] arise
- [ ] with the help of
- [ ] electronic
- [ ] appearance
- [ ] character
- [ ] mop
- [ ] deal with
- [ ] watch over
- [ ] naughty
- [ ] niece
- [ ] spoil
- [ ] wildlife
- [ ] protection
- [ ] wild
- [ ] habitat
- [ ] threaten
- [ ] decrease
- [ ] endanger
- [ ] die out
- [ ] loss

# Chapter 011

- [ ] reserve
- [ ] hunt
- [ ] zone
- [ ] in peace
- [ ] in danger
- [ ] Daisy
- [ ] species
- [ ] carpet
- [ ] respond
- [ ] distant
- [ ] fur
- [ ] antelope
- [ ] Zimbabwe
- [ ] relief
- [ ] in relief
- [ ] laughter
- [ ] burst into laughter
- [ ] mercy
- [ ] certain
- [ ] importance

# Chapter 012

- [ ] WWF
- [ ] rub
- [ ] protect…from
- [ ] mosquito
- [ ] millipede
- [ ] insect
- [ ] contain
- [ ] powerful
- [ ] affect
- [ ] attention
- [ ] pay attention to
- [ ] appreciate
- [ ] succeed
- [ ] Indonesia
- [ ] rhino
- [ ] secure
- [ ] income
- [ ] employ
- [ ] harm
- [ ] Milu deer

# Chapter 013

- [ ] bite
- [ ] extinction
- [ ] dinosaur
- [ ] come into being
- [ ] county
- [ ] inspect
- [ ] unexpected
- [ ] incident
- [ ] dust
- [ ] according to
- [ ] Mauritius
- [ ] disappearance
- [ ] fierce
- [ ] so that
- [ ] ending
- [ ] faithfully
- [ ] Colobus monkey
- [ ] classical
- [ ] roll
- [ ] rock’n’roll

# Chapter 014

- [ ] orchestra
- [ ] rap
- [ ] folk
- [ ] jazz
- [ ] choral
- [ ] the Monkees
- [ ] musician
- [ ] dream of
- [ ] karaoke
- [ ] pretend
- [ ] to be honest
- [ ] attach
- [ ] attach…to
- [ ] form
- [ ] fame
- [ ] passer-by
- [ ] earn
- [ ] extra
- [ ] instrument
- [ ] perform

# Chapter 015

- [ ] performance
- [ ] pub
- [ ] cash
- [ ] in cash
- [ ] studio
- [ ] millionaire
- [ ] play jokes on
- [ ] actor
- [ ] rely
- [ ] rely on
- [ ] broadcast
- [ ] humorous
- [ ] familiar
- [ ] be familiar with
- [ ] get familiar with
- [ ] or so
- [ ] break up
- [ ] reunite
- [ ] attractive
- [ ] addition

# Chapter 016

- [ ] in addition
- [ ] sort out
- [ ] excitement
- [ ] ballad
- [ ] overnignt
- [ ] dip
- [ ] tadpole
- [ ] lily
- [ ] confident
- [ ] Freddy
- [ ] brief
- [ ] briefly
- [ ] devotion
- [ ] afterwards
- [ ] invitation
- [ ] beard
- [ ] sensitive
- [ ] painful
- [ ] above all


# Chapter 001

- [ ] participate
- [ ] fill out
- [ ] evaluate
- [ ] arrange
- [ ] chimpanzee
- [ ] dolphin
- [ ] sign
- [ ] hunt
- [ ] actor
- [ ] actress
- [ ] writer
- [ ] collection
- [ ] boxing
- [ ] ski
- [ ] water skiing
- [ ] windsurfing
- [ ] frightening
- [ ] underwater
- [ ] spirit
- [ ] explorer

# Chapter 002

- [ ] sailor
- [ ] Viking
- [ ] voyage
- [ ] ancestor
- [ ] set sail
- [ ] AD
- [ ] further
- [ ] according to
- [ ] get into trouble
- [ ] persuade
- [ ] make it to
- [ ] in search of
- [ ] unknown
- [ ] eventually
- [ ] present-day
- [ ] deed
- [ ] journey
- [ ] lecture
- [ ] brake
- [ ] apologise

# Chapter 003

- [ ] the Antarctic
- [ ] pollute
- [ ] pollution
- [ ] over-fishing
- [ ] industrial
- [ ] agricultural
- [ ] chemical
- [ ] ban
- [ ] altogether
- [ ] handle
- [ ] department
- [ ] make a living
- [ ] solution
- [ ] port
- [ ] present
- [ ] intelligence
- [ ] intelligent
- [ ] Iceberg
- [ ] seal
- [ ] energetic

# Chapter 004

- [ ] penguin
- [ ] coral
- [ ] discovery
- [ ] crab
- [ ] educate
- [ ] up-to-date
- [ ] attraction
- [ ] attract
- [ ] watch out
- [ ] shark
- [ ] discount
- [ ] trick
- [ ] melt
- [ ] measure
- [ ] length
- [ ] schoolboy
- [ ] centimetre
- [ ] barrel
- [ ] whirlpool
- [ ] horrible

# Chapter 005

- [ ] float
- [ ] terrify
- [ ] escape
- [ ] terror
- [ ] soul
- [ ] survive
- [ ] all at once
- [ ] recover
- [ ] scream
- [ ] sink
- [ ] pick up
- [ ] unable
- [ ] recognise
- [ ] Oceania
- [ ] opposite
- [ ] net
- [ ] leak
- [ ] stadium
- [ ] debate
- [ ] local

# Chapter 006

- [ ] shopkeeper
- [ ] bay
- [ ] wildlife
- [ ] disagree
- [ ] adventure
- [ ] desert
- [ ] canoe
- [ ] safari
- [ ] hike
- [ ] take off
- [ ] presenter
- [ ] major
- [ ] wild
- [ ] tiring
- [ ] raft
- [ ] extra
- [ ] optional
- [ ] horizon
- [ ] organization
- [ ] uncomfortable

# Chapter 007

- [ ] route
- [ ] porter
- [ ] luggage
- [ ] accommodation
- [ ] hostel
- [ ] maximum
- [ ] altitude
- [ ] right now
- [ ] differ
- [ ] footprint
- [ ] anxious
- [ ] extreme
- [ ] bungee jumping
- [ ] snowboarding
- [ ] snow rafting
- [ ] in order to do something
- [ ] gymnastics
- [ ] similarity
- [ ] upside down
- [ ] exactly

# Chapter 008

- [ ] risk
- [ ] excitement
- [ ] various
- [ ] flow
- [ ] equipment
- [ ] dull
- [ ] preference
- [ ] turn up
- [ ] back out
- [ ] get across
- [ ] jog
- [ ] traveller
- [ ] emperor
- [ ] court
- [ ] in turn
- [ ] amaze
- [ ] goods
- [ ] confuse
- [ ] fuel
- [ ] wealthy

# Chapter 009

- [ ] break out
- [ ] put...into prison
- [ ] author
- [ ] dictation
- [ ] stand by
- [ ] statement
- [ ] quantity
- [ ] professor
- [ ] hunter
- [ ] skin
- [ ] the Antarctic.
- [ ] on one's way
- [ ] Norwegian
- [ ] preparation
- [ ] sledge
- [ ] break down
- [ ] shock
- [ ] goal
- [ ] ambition
- [ ] exhausted

# Chapter 010

- [ ] run out of
- [ ] hopeless
- [ ] cheerful
- [ ] distant
- [ ] carry on
- [ ] within
- [ ] sadness
- [ ] function
- [ ] patience
- [ ] nationality
- [ ] aim
- [ ] Arctic
- [ ] transport
- [ ] observe
- [ ] disadvantage
- [ ] staff
- [ ] survival
- [ ] shelter
- [ ] philosophy
- [ ] limit

# Chapter 011

- [ ] ferry
- [ ] minibus
- [ ] cyclist
- [ ] motorist
- [ ] pedestrian
- [ ] jam
- [ ] traffic jam
- [ ] actually
- [ ] benefit
- [ ] flat
- [ ] therefore
- [ ] convenient
- [ ] parking
- [ ] convenience
- [ ] hopeful
- [ ] neighbourhood
- [ ] wherever
- [ ] thief
- [ ] chip
- [ ] insert

# Chapter 012

- [ ] indeed
- [ ] fed up
- [ ] consequence
- [ ] arrest
- [ ] bone
- [ ] work out
- [ ] argue
- [ ] baggage
- [ ] platform
- [ ] belt
- [ ] ambassador
- [ ] sensitive
- [ ] grey
- [ ] gentle
- [ ] fierce
- [ ] vocabulary
- [ ] interpreter
- [ ] schedule
- [ ] timetable
- [ ] foolish

# Chapter 013

- [ ] responsibility
- [ ] rely on
- [ ] hostess
- [ ] air hostess
- [ ] non-smoking
- [ ] case
- [ ] suitcase
- [ ] pull up
- [ ] pull out
- [ ] content
- [ ] petrol
- [ ] gas
- [ ] solar
- [ ] racer
- [ ] sunlight
- [ ] kindergarten
- [ ] so far
- [ ] take place
- [ ] northwest
- [ ] southeast

# Chapter 014

- [ ] chapter
- [ ] impression
- [ ] reliable
- [ ] golf
- [ ] operator
- [ ] appreciate
- [ ] essay
- [ ] shopping
- [ ] carbon monoxide
- [ ] highway
- [ ] construction
- [ ] pavement
- [ ] crossroads
- [ ] amount
- [ ] physical
- [ ] motor
- [ ] figure
- [ ] go up
- [ ] engine
- [ ] per

# Chapter 015

- [ ] centigrade
- [ ] admit
- [ ] addicted
- [ ] on average
- [ ] occupy
- [ ] somehow
- [ ] whichever
- [ ] suit
- [ ] damage
- [ ] nowhere
- [ ] crossing
- [ ] tunnel
- [ ] plus
- [ ] frequent
- [ ] fare

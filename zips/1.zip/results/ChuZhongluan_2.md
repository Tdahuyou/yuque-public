
# Chapter 001

- [ ] boat
- [ ] group
- [ ] nineteen
- [ ] party
- [ ] marriage
- [ ] clean
- [ ] bottle
- [ ] tail
- [ ] very
- [ ] bag
- [ ] Tuesday
- [ ] cancel
- [ ] map
- [ ] grandparent
- [ ] moon
- [ ] be
- [ ] America
- [ ] need
- [ ] new
- [ ] stamp

# Chapter 002

- [ ] without
- [ ] quick
- [ ] joke
- [ ] table
- [ ] its
- [ ] check
- [ ] giraffe
- [ ] picture
- [ ] kiss
- [ ] several
- [ ] monitor
- [ ] culture
- [ ] taxi
- [ ] health
- [ ] dialogue
- [ ] recent
- [ ] ten
- [ ] blue
- [ ] dark
- [ ] order

# Chapter 003

- [ ] egg
- [ ] feeling
- [ ] at
- [ ] if
- [ ] piece
- [ ] he
- [ ] direct
- [ ] rat
- [ ] brother
- [ ] geography
- [ ] advise
- [ ] print
- [ ] festival
- [ ] along
- [ ] forest
- [ ] apple
- [ ] salad
- [ ] rabbit
- [ ] we
- [ ] yours

# Chapter 004

- [ ] shop
- [ ] theirs
- [ ] wet
- [ ] shout
- [ ] purse
- [ ] modern
- [ ] express
- [ ] blackboard
- [ ] servant
- [ ] hobby
- [ ] winter
- [ ] plant
- [ ] huge
- [ ] tall
- [ ] rich
- [ ] please
- [ ] paint
- [ ] business
- [ ] already
- [ ] brave

# Chapter 005

- [ ] continue
- [ ] cat
- [ ] discover
- [ ] coke
- [ ] turn
- [ ] steam
- [ ] video
- [ ] stupid
- [ ] anything
- [ ] conversation
- [ ] part
- [ ] door
- [ ] asleep
- [ ] peace
- [ ] single
- [ ] prove
- [ ] walk
- [ ] search
- [ ] cotton
- [ ] stomach

# Chapter 006

- [ ] common
- [ ] cry
- [ ] sometimes
- [ ] hometown
- [ ] standard
- [ ] snowy
- [ ] seat
- [ ] drum
- [ ] capital
- [ ] officer
- [ ] skirt
- [ ] ship
- [ ] song
- [ ] special
- [ ] rope
- [ ] collect
- [ ] concert
- [ ] fox
- [ ] centre
- [ ] cow

# Chapter 007

- [ ] pupil
- [ ] hardly
- [ ] cake
- [ ] popular
- [ ] cheat
- [ ] driver
- [ ] manage
- [ ] butter
- [ ] fan
- [ ] height
- [ ] retell
- [ ] Europe
- [ ] holiday
- [ ] Rusia
- [ ] kid
- [ ] nearly
- [ ] where
- [ ] slow
- [ ] any
- [ ] front

# Chapter 008

- [ ] above
- [ ] smooth
- [ ] airplane
- [ ] choice
- [ ] live
- [ ] death
- [ ] June
- [ ] seventeen
- [ ] natural
- [ ] Wednesday
- [ ] edge
- [ ] her
- [ ] police
- [ ] wheat
- [ ] they
- [ ] forty
- [ ] week
- [ ] parent
- [ ] cough
- [ ] gate

# Chapter 009

- [ ] mother
- [ ] voice
- [ ] important
- [ ] thick
- [ ] tourist
- [ ] rubbish
- [ ] prepare
- [ ] house
- [ ] through
- [ ] mad
- [ ] queen
- [ ] lake
- [ ] math
- [ ] home
- [ ] often
- [ ] box
- [ ] talk
- [ ] kitchen
- [ ] call
- [ ] bee

# Chapter 010

- [ ] kilo
- [ ] period
- [ ] vegetable
- [ ] pull
- [ ] glove
- [ ] you
- [ ] March
- [ ] examine
- [ ] result
- [ ] pleasure
- [ ] four
- [ ] pioneer
- [ ] information
- [ ] society
- [ ] compare
- [ ] provide
- [ ] owner
- [ ] sun
- [ ] always
- [ ] way

# Chapter 011

- [ ] rather
- [ ] accept
- [ ] cover
- [ ] Friday
- [ ] cause
- [ ] visitor
- [ ] August
- [ ] report
- [ ] borrow
- [ ] sorry
- [ ] town
- [ ] connect
- [ ] sweet
- [ ] stone
- [ ] anyone
- [ ] here
- [ ] back
- [ ] sugar
- [ ] paper
- [ ] country

# Chapter 012

- [ ] fruit
- [ ] aunt
- [ ] pair
- [ ] busy
- [ ] time
- [ ] foreign
- [ ] prisoner
- [ ] uncle
- [ ] laugh
- [ ] English
- [ ] countryside
- [ ] great
- [ ] VCD
- [ ] cool
- [ ] sandwich
- [ ] appear
- [ ] relax
- [ ] size
- [ ] chair
- [ ] England

# Chapter 013

- [ ] postcard
- [ ] end
- [ ] lie
- [ ] eighth
- [ ] windy
- [ ] attention
- [ ] believe
- [ ] mail
- [ ] letter
- [ ] overcoat
- [ ] fun
- [ ] sudden
- [ ] gold
- [ ] engineer
- [ ] keyboard
- [ ] too
- [ ] doubt
- [ ] outside
- [ ] basic
- [ ] breath

# Chapter 014

- [ ] drawer
- [ ] until
- [ ] passenger
- [ ] key
- [ ] remember
- [ ] coast
- [ ] tongue
- [ ] basketball
- [ ] camel
- [ ] Chinese
- [ ] speed
- [ ] schoolbag
- [ ] step
- [ ] umbrella
- [ ] college
- [ ] show
- [ ] clock
- [ ] volleyball
- [ ] invention
- [ ] although

# Chapter 015

- [ ] coffee
- [ ] cent
- [ ] purple
- [ ] film
- [ ] school
- [ ] useful
- [ ] dish
- [ ] everywhere
- [ ] glad
- [ ] ninety
- [ ] composition
- [ ] wing
- [ ] number
- [ ] polite
- [ ] dismiss
- [ ] doctor
- [ ] tired
- [ ] crayon
- [ ] interest
- [ ] wonderful

# Chapter 016

- [ ] mine
- [ ] wind
- [ ] one
- [ ] arm
- [ ] except
- [ ] trust
- [ ] long
- [ ] other
- [ ] dozen
- [ ] fear
- [ ] as
- [ ] before
- [ ] stream
- [ ] after
- [ ] fix
- [ ] behaviour
- [ ] room
- [ ] disturb
- [ ] Russian
- [ ] smile

# Chapter 017

- [ ] strict
- [ ] king
- [ ] communication
- [ ] toothpaste
- [ ] his
- [ ] value
- [ ] succeed
- [ ] restaurant
- [ ] ability
- [ ] spoon
- [ ] face
- [ ] shoe
- [ ] big
- [ ] produce
- [ ] island
- [ ] heavy
- [ ] electric
- [ ] planet
- [ ] weather
- [ ] guest

# Chapter 018

- [ ] whom
- [ ] hard
- [ ] clap
- [ ] fetch
- [ ] each
- [ ] wish
- [ ] environment
- [ ] shy
- [ ] murder
- [ ] afford
- [ ] not
- [ ] must
- [ ] enemy
- [ ] pride
- [ ] smoke
- [ ] act
- [ ] underground
- [ ] camp
- [ ] total
- [ ] jacket

# Chapter 019

- [ ] address
- [ ] north
- [ ] watch
- [ ] book
- [ ] used
- [ ] news
- [ ] pond
- [ ] friend
- [ ] vehicle
- [ ] weight
- [ ] sausage
- [ ] hall
- [ ] with
- [ ] flag
- [ ] interesting
- [ ] president
- [ ] February
- [ ] future
- [ ] clothes
- [ ] regard

# Chapter 020

- [ ] active
- [ ] miss
- [ ] southern
- [ ] tonight
- [ ] join
- [ ] however
- [ ] floor
- [ ] quarter
- [ ] cup
- [ ] machine
- [ ] rainy
- [ ] candle
- [ ] complete
- [ ] chicken
- [ ] carry
- [ ] sand
- [ ] tree
- [ ] meal
- [ ] lion
- [ ] record

# Chapter 021

- [ ] fork
- [ ] finish
- [ ] start
- [ ] license
- [ ] pen
- [ ] low
- [ ] whose
- [ ] classmate
- [ ] zoo
- [ ] post
- [ ] team
- [ ] same
- [ ] could
- [ ] secretary
- [ ] place
- [ ] supermarket
- [ ] noise
- [ ] stairs
- [ ] northern
- [ ] field

# Chapter 022

- [ ] classroom
- [ ] grade
- [ ] cook
- [ ] him
- [ ] move
- [ ] wash
- [ ] sunny
- [ ] rose
- [ ] seventh
- [ ] ground
- [ ] hundred
- [ ] leader
- [ ] story
- [ ] nose
- [ ] church
- [ ] also
- [ ] fill
- [ ] sofa
- [ ] ninth
- [ ] bus

# Chapter 023

- [ ] inch
- [ ] hot
- [ ] play
- [ ] postman
- [ ] touch
- [ ] white
- [ ] breakfast
- [ ] object
- [ ] silk
- [ ] should
- [ ] cheap
- [ ] public
- [ ] beside
- [ ] main
- [ ] angry
- [ ] method
- [ ] accident
- [ ] night
- [ ] over
- [ ] football

# Chapter 024

- [ ] yet
- [ ] snake
- [ ] fresh
- [ ] imagine
- [ ] everyday
- [ ] either
- [ ] past
- [ ] subject
- [ ] Miss
- [ ] personal
- [ ] knee
- [ ] note
- [ ] ourselves
- [ ] building
- [ ] memory
- [ ] introduction
- [ ] dentist
- [ ] loud
- [ ] unit
- [ ] return

# Chapter 025

- [ ] left
- [ ] once
- [ ] dead
- [ ] example
- [ ] technology
- [ ] butterfly
- [ ] illness
- [ ] article
- [ ] swimming
- [ ] dance
- [ ] tent
- [ ] my
- [ ] lucky
- [ ] but
- [ ] hour
- [ ] noon
- [ ] funny
- [ ] movie
- [ ] newspaper
- [ ] out

# Chapter 026

- [ ] against
- [ ] discovery
- [ ] student
- [ ] November
- [ ] Japanese
- [ ] ink
- [ ] instruction
- [ ] supper
- [ ] fisherman
- [ ] flower
- [ ] lot
- [ ] or
- [ ] maybe
- [ ] duty
- [ ] count
- [ ] thirty
- [ ] goal
- [ ] dictionary
- [ ] shirt
- [ ] meeting

# Chapter 027

- [ ] half
- [ ] short
- [ ] tie
- [ ] hope
- [ ] eighty
- [ ] private
- [ ] prize
- [ ] wife
- [ ] twelfth
- [ ] shorts
- [ ] write
- [ ] energy
- [ ] sir
- [ ] store
- [ ] grass
- [ ] soup
- [ ] street
- [ ] fact
- [ ] help
- [ ] till

# Chapter 028

- [ ] tale
- [ ] alive
- [ ] oil
- [ ] lovely
- [ ] role
- [ ] quiet
- [ ] test
- [ ] include
- [ ] plain
- [ ] somewhere
- [ ] spirit
- [ ] office
- [ ] healthy
- [ ] twentieth
- [ ] pear
- [ ] smart
- [ ] panda
- [ ] train
- [ ] park
- [ ] born

# Chapter 029

- [ ] progress
- [ ] zebra
- [ ] nurse
- [ ] promise
- [ ] girl
- [ ] traffic
- [ ] translate
- [ ] risk
- [ ] top
- [ ] candy
- [ ] west
- [ ] shoulder
- [ ] successful
- [ ] dinner
- [ ] stranger
- [ ] education
- [ ] war
- [ ] deep
- [ ] watermelon
- [ ] duck

# Chapter 030

- [ ] forward
- [ ] climb
- [ ] immediately
- [ ] chess
- [ ] discussion
- [ ] lamb
- [ ] plenty
- [ ] car
- [ ] tidy
- [ ] pink
- [ ] certain
- [ ] necessary
- [ ] bridge
- [ ] level
- [ ] son
- [ ] available
- [ ] pie
- [ ] population
- [ ] care
- [ ] ugly

# Chapter 031

- [ ] luck
- [ ] close
- [ ] university
- [ ] pretty
- [ ] die
- [ ] round
- [ ] thirsty
- [ ] free
- [ ] Atlantic
- [ ] ham
- [ ] comfortable
- [ ] silence
- [ ] deaf
- [ ] father
- [ ] circle
- [ ] wealth
- [ ] then
- [ ] bank
- [ ] dog
- [ ] difficulty

# Chapter 032

- [ ] ear
- [ ] kick
- [ ] alone
- [ ] proper
- [ ] fast
- [ ] litter
- [ ] water
- [ ] station
- [ ] strawberry
- [ ] afraid
- [ ] brain
- [ ] coat
- [ ] none
- [ ] require
- [ ] dumpling
- [ ] drop
- [ ] almost
- [ ] second
- [ ] friendship
- [ ] traditional

# Chapter 033

- [ ] copy
- [ ] seem
- [ ] history
- [ ] list
- [ ] beyond
- [ ] Monday
- [ ] season
- [ ] pronounce
- [ ] few
- [ ] among
- [ ] again
- [ ] reach
- [ ] research
- [ ] text
- [ ] autumn
- [ ] fit
- [ ] quite
- [ ] high
- [ ] army
- [ ] silly

# Chapter 034

- [ ] airline
- [ ] bright
- [ ] than
- [ ] Japan
- [ ] captain
- [ ] whenever
- [ ] road
- [ ] fourteen
- [ ] trip
- [ ] bike
- [ ] robot
- [ ] sale
- [ ] symbol
- [ ] weekend
- [ ] warm
- [ ] dollar
- [ ] useless
- [ ] cancer
- [ ] there
- [ ] blood

# Chapter 035

- [ ] separate
- [ ] situation
- [ ] yourselves
- [ ] nobody
- [ ] horse
- [ ] pleasant
- [ ] lock
- [ ] eraser
- [ ] shower
- [ ] reply
- [ ] raincoat
- [ ] sixth
- [ ] regret
- [ ] dress
- [ ] crazy
- [ ] learn
- [ ] ice
- [ ] treasure
- [ ] page
- [ ] plastic

# Chapter 036

- [ ] rain
- [ ] hotel
- [ ] noodle
- [ ] riddle
- [ ] thirteen
- [ ] least
- [ ] guard
- [ ] couple
- [ ] describe
- [ ] air
- [ ] hate
- [ ] small
- [ ] sight
- [ ] avoid
- [ ] science
- [ ] hungry
- [ ] present
- [ ] madam
- [ ] bathroom
- [ ] goat

# Chapter 037

- [ ] pass
- [ ] boy
- [ ] young
- [ ] jeans
- [ ] model
- [ ] like
- [ ] push
- [ ] happy
- [ ] pronunciation
- [ ] twice
- [ ] toilet
- [ ] husband
- [ ] herself
- [ ] earth
- [ ] elder
- [ ] flu
- [ ] card
- [ ] encourage
- [ ] wine
- [ ] afternoon

# Chapter 038

- [ ] force
- [ ] east
- [ ] daily
- [ ] gun
- [ ] remain
- [ ] language
- [ ] anywhere
- [ ] lesson
- [ ] save
- [ ] cousin
- [ ] granddaughter
- [ ] class
- [ ] violin
- [ ] me
- [ ] sound
- [ ] beef
- [ ] market
- [ ] airport
- [ ] marry
- [ ] pencil

# Chapter 039

- [ ] first
- [ ] thousand
- [ ] next
- [ ] strange
- [ ] them
- [ ] twelve
- [ ] zero
- [ ] ill
- [ ] surface
- [ ] chemistry
- [ ] twenty
- [ ] suggestion
- [ ] sail
- [ ] whether
- [ ] final
- [ ] stay
- [ ] because
- [ ] interview
- [ ] state
- [ ] Wheel

# Chapter 040

- [ ] which
- [ ] still
- [ ] create
- [ ] in
- [ ] worker
- [ ] these
- [ ] solid
- [ ] shape
- [ ] homework
- [ ] chant
- [ ] relation
- [ ] date
- [ ] drug
- [ ] plate
- [ ] policy
- [ ] sea
- [ ] right
- [ ] percent
- [ ] corner
- [ ] form

# Chapter 041

- [ ] pity
- [ ] lunch
- [ ] towel
- [ ] even
- [ ] Christmas
- [ ] weekday
- [ ] so
- [ ] sad
- [ ] dry
- [ ] garden
- [ ] tiny
- [ ] can
- [ ] mile
- [ ] Canada
- [ ] off
- [ ] allow
- [ ] invite
- [ ] thought
- [ ] handsome
- [ ] housework

# Chapter 042

- [ ] myself
- [ ] April
- [ ] balloon
- [ ] sky
- [ ] storm
- [ ] biscuit
- [ ] down
- [ ] Asian
- [ ] bill
- [ ] enjoy
- [ ] heart
- [ ] south
- [ ] lively
- [ ] rapid
- [ ] frog
- [ ] control
- [ ] toothache
- [ ] clever
- [ ] raise
- [ ] lead

# Chapter 043

- [ ] deal
- [ ] package
- [ ] what
- [ ] pig
- [ ] head
- [ ] experience
- [ ] punish
- [ ] develop
- [ ] birthday
- [ ] scientist
- [ ] fail
- [ ] swing
- [ ] everyone
- [ ] this
- [ ] milk
- [ ] waste
- [ ] absent
- [ ] tomorrow
- [ ] Internet
- [ ] toothbrush

# Chapter 044

- [ ] near
- [ ] body
- [ ] baby
- [ ] ceiling
- [ ] honest
- [ ] middle
- [ ] away
- [ ] meaning
- [ ] evening
- [ ] beautiful
- [ ] gift
- [ ] pork
- [ ] try
- [ ] monkey
- [ ] famous
- [ ] green
- [ ] line
- [ ] factory
- [ ] Saturday
- [ ] trouble

# Chapter 045

- [ ] careful
- [ ] cabbage
- [ ] winner
- [ ] protect
- [ ] correct
- [ ] want
- [ ] rest
- [ ] difficult
- [ ] accent
- [ ] oneself
- [ ] coal
- [ ] coin
- [ ] real
- [ ] though
- [ ] divide
- [ ] leaf
- [ ] fourth
- [ ] treatment
- [ ] skill
- [ ] their

# Chapter 046

- [ ] danger
- [ ] cross
- [ ] point
- [ ] now
- [ ] magic
- [ ] would
- [ ] cinema
- [ ] downstairs
- [ ] neither
- [ ] dirty
- [ ] breathe
- [ ] neck
- [ ] influence
- [ ] poor
- [ ] Sunday
- [ ] bit
- [ ] bird
- [ ] happen
- [ ] delicious
- [ ] operation

# Chapter 047

- [ ] pool
- [ ] skate
- [ ] wrong
- [ ] day
- [ ] golden
- [ ] excuse
- [ ] lonely
- [ ] silent
- [ ] poem
- [ ] late
- [ ] disease
- [ ] bell
- [ ] lab
- [ ] grandson
- [ ] welcome
- [ ] daughter
- [ ] meat
- [ ] path
- [ ] both
- [ ] up

# Chapter 048

- [ ] possible
- [ ] thing
- [ ] India
- [ ] pick
- [ ] area
- [ ] explain
- [ ] social
- [ ] weigh
- [ ] nine
- [ ] nothing
- [ ] job
- [ ] museum
- [ ] inside
- [ ] patient
- [ ] tomato
- [ ] different
- [ ] word
- [ ] lady
- [ ] kite
- [ ] foreigner

# Chapter 049

- [ ] never
- [ ] refuse
- [ ] heat
- [ ] fire
- [ ] perhaps
- [ ] boss
- [ ] supply
- [ ] socks
- [ ] yesterday
- [ ] those
- [ ] success
- [ ] website
- [ ] similar
- [ ] steel
- [ ] besides
- [ ] all
- [ ] advice
- [ ] music
- [ ] practice
- [ ] eight

# Chapter 050

- [ ] seventy
- [ ] worry
- [ ] wonder
- [ ] every
- [ ] screen
- [ ] hen
- [ ] bread
- [ ] person
- [ ] themselves
- [ ] chalk
- [ ] cheese
- [ ] sleepy
- [ ] sixteen
- [ ] pancake
- [ ] ton
- [ ] hair
- [ ] granny
- [ ] cloud
- [ ] seldom
- [ ] telephone

# Chapter 051

- [ ] race
- [ ] computer
- [ ] listen
- [ ] trade
- [ ] may
- [ ] everything
- [ ] instead
- [ ] ours
- [ ] grammar
- [ ] how
- [ ] she
- [ ] basket
- [ ] and
- [ ] match
- [ ] perfect
- [ ] fever
- [ ] especially
- [ ] problem
- [ ] bye
- [ ] physics

# Chapter 052

- [ ] between
- [ ] lamp
- [ ] juice
- [ ] animal
- [ ] member
- [ ] tape
- [ ] shame
- [ ] black
- [ ] heaven
- [ ] under
- [ ] our
- [ ] national
- [ ] metal
- [ ] ready
- [ ] celebrate
- [ ] fifteen
- [ ] coach
- [ ] sour
- [ ] blind
- [ ] bedroom

# Chapter 053

- [ ] chocolate
- [ ] toy
- [ ] pound
- [ ] double
- [ ] tiger
- [ ] strong
- [ ] easy
- [ ] television
- [ ] idea
- [ ] together
- [ ] the
- [ ] love
- [ ] brush
- [ ] truck
- [ ] mouth
- [ ] sick
- [ ] only
- [ ] soon
- [ ] friendly
- [ ] wall

# Chapter 054

- [ ] weak
- [ ] money
- [ ] railway
- [ ] tool
- [ ] careless
- [ ] helpful
- [ ] five
- [ ] European
- [ ] term
- [ ] yellow
- [ ] mirror
- [ ] condition
- [ ] position
- [ ] fish
- [ ] rule
- [ ] why
- [ ] visit
- [ ] courage
- [ ] doll
- [ ] May

# Chapter 055

- [ ] spring
- [ ] no
- [ ] joy
- [ ] wait
- [ ] elephant
- [ ] dare
- [ ] general
- [ ] moment
- [ ] wise
- [ ] glass
- [ ] menu
- [ ] wide
- [ ] course
- [ ] gentleman
- [ ] open
- [ ] morning
- [ ] soft
- [ ] upstairs
- [ ] vacation
- [ ] fifty

# Chapter 056

- [ ] to
- [ ] kill
- [ ] seven
- [ ] space
- [ ] fridge
- [ ] ball
- [ ] fly
- [ ] ask
- [ ] hand
- [ ] scarf
- [ ] development
- [ ] flat
- [ ] below
- [ ] fantastic
- [ ] world
- [ ] since
- [ ] itself
- [ ] whole
- [ ] terrible
- [ ] such

# Chapter 057

- [ ] farm
- [ ] magazine
- [ ] lazy
- [ ] repair
- [ ] activity
- [ ] effort
- [ ] everybody
- [ ] victory
- [ ] brown
- [ ] bowl
- [ ] nice
- [ ] competition
- [ ] pocket
- [ ] September
- [ ] minute
- [ ] finger
- [ ] surprise
- [ ] share
- [ ] bottom
- [ ] fair

# Chapter 058

- [ ] nod
- [ ] thank
- [ ] on
- [ ] usual
- [ ] improve
- [ ] rice
- [ ] god
- [ ] sort
- [ ] international
- [ ] empty
- [ ] sense
- [ ] expensive
- [ ] lift
- [ ] lay
- [ ] guess
- [ ] just
- [ ] ever
- [ ] able
- [ ] hers
- [ ] today

# Chapter 059

- [ ] chairman
- [ ] government
- [ ] camera
- [ ] of
- [ ] bamboo
- [ ] work
- [ ] about
- [ ] family
- [ ] cheer
- [ ] December
- [ ] ago
- [ ] potato
- [ ] OK
- [ ] own
- [ ] achieve
- [ ] full
- [ ] cooker
- [ ] discuss
- [ ] enough
- [ ] hill

# Chapter 060

- [ ] banana
- [ ] people
- [ ] notebook
- [ ] agreement
- [ ] review
- [ ] China
- [ ] it
- [ ] tea
- [ ] prevent
- [ ] clear
- [ ] rush
- [ ] ancient
- [ ] handbag
- [ ] suggest
- [ ] worth
- [ ] plane
- [ ] three
- [ ] greeting
- [ ] whatever
- [ ] repeat

# Chapter 061

- [ ] January
- [ ] orange
- [ ] October
- [ ] during
- [ ] hamburger
- [ ] answer
- [ ] something
- [ ] notice
- [ ] proud
- [ ] introduce
- [ ] fat
- [ ] beach
- [ ] ruler
- [ ] study
- [ ] sure
- [ ] pardon
- [ ] decide
- [ ] diary
- [ ] grandchild
- [ ] excite

# Chapter 062

- [ ] square
- [ ] CD
- [ ] century
- [ ] suppose
- [ ] mention
- [ ] motorcycle
- [ ] radio
- [ ] service
- [ ] look
- [ ] chance
- [ ] by
- [ ] rubber
- [ ] us
- [ ] early
- [ ] someone
- [ ] primary
- [ ] difference
- [ ] whale
- [ ] true
- [ ] grape

# Chapter 063

- [ ] Indian
- [ ] communicate
- [ ] yard
- [ ] secret
- [ ] jump
- [ ] I
- [ ] ant
- [ ] industry
- [ ] into
- [ ] while
- [ ] wood
- [ ] behind
- [ ] teacher
- [ ] American
- [ ] that
- [ ] advertisement
- [ ] task
- [ ] board
- [ ] lemonade
- [ ] pet

# Chapter 064

- [ ] some
- [ ] somebody
- [ ] stop
- [ ] follow
- [ ] across
- [ ] experiment
- [ ] taste
- [ ] arrive
- [ ] tower
- [ ] change
- [ ] passage
- [ ] company
- [ ] city
- [ ] ticket
- [ ] ache
- [ ] knowledge
- [ ] hat
- [ ] who
- [ ] decision
- [ ] around

# Chapter 065

- [ ] mark
- [ ] row
- [ ] fifth
- [ ] manager
- [ ] leg
- [ ] old
- [ ] bed
- [ ] safety
- [ ] library
- [ ] yourself
- [ ] palace
- [ ] month
- [ ] land
- [ ] last
- [ ] dear
- [ ] western
- [ ] speech
- [ ] birth
- [ ] thin
- [ ] excellent

# Chapter 066

- [ ] bitter
- [ ] himself
- [ ] expect
- [ ] club
- [ ] snow
- [ ] receive
- [ ] mountain
- [ ] serious
- [ ] two
- [ ] normal
- [ ] unless
- [ ] third
- [ ] cap
- [ ] law
- [ ] playground
- [ ] cold
- [ ] thread
- [ ] iron
- [ ] six
- [ ] knock

# Chapter 067

- [ ] art
- [ ] hurry
- [ ] human
- [ ] rock
- [ ] another
- [ ] recorder
- [ ] eighteen
- [ ] recite
- [ ] kind
- [ ] cloudy
- [ ] background
- [ ] age
- [ ] name
- [ ] add
- [ ] year
- [ ] prison
- [ ] sentence
- [ ] trousers
- [ ] anyway
- [ ] light

# Chapter 068

- [ ] offer
- [ ] dangerous
- [ ] red
- [ ] kilometer
- [ ] Asia
- [ ] window
- [ ] temperature
- [ ] medical
- [ ] nature
- [ ] chopsticks
- [ ] increase
- [ ] conference
- [ ] praise
- [ ] abroad
- [ ] nor
- [ ] gym
- [ ] wound
- [ ] your
- [ ] agree
- [ ] question

# Chapter 069

- [ ] pilot
- [ ] aloud
- [ ] eleven
- [ ] boring
- [ ] cruel
- [ ] nervous
- [ ] yes
- [ ] river
- [ ] Australia
- [ ] hospital
- [ ] training
- [ ] clone
- [ ] message
- [ ] sixty
- [ ] exercise
- [ ] village
- [ ] safe
- [ ] bear
- [ ] sweater
- [ ] game

# Chapter 070

- [ ] price
- [ ] Thursday
- [ ] soap
- [ ] intention
- [ ] action
- [ ] mind
- [ ] food
- [ ] insist
- [ ] plan
- [ ] farmer
- [ ] mend
- [ ] chest
- [ ] warn
- [ ] eye
- [ ] speaker
- [ ] piano
- [ ] medicine
- [ ] soldier
- [ ] picnic
- [ ] master

# Chapter 071

- [ ] salt
- [ ] Australian
- [ ] score
- [ ] tenth
- [ ] invent
- [ ] else
- [ ] simple
- [ ] depend
- [ ] truth
- [ ] enter
- [ ] when
- [ ] pacific
- [ ] side
- [ ] sister
- [ ] passport
- [ ] London
- [ ] for
- [ ] large
- [ ] use
- [ ] fine

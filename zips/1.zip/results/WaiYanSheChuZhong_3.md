
# Chapter 001

- [ ] pair
- [ ] correct
- [ ] spelling
- [ ] word
- [ ] practise
- [ ] match
- [ ] meaning
- [ ] complete
- [ ] sentence
- [ ] dictionary
- [ ] grammar
- [ ] letter
- [ ] look up
- [ ] mistake
- [ ] make a mistake
- [ ] understand
- [ ] advice
- [ ] should
- [ ] possible
- [ ] write down

# Chapter 002

- [ ] notebook
- [ ] forget
- [ ] pronounce
- [ ] aloud
- [ ] radio
- [ ] pronunciation
- [ ] key
- [ ] main
- [ ] excellent
- [ ] agree
- [ ] agree with sb.
- [ ] vocabulary
- [ ] ask for
- [ ] improve
- [ ] basic
- [ ] time
- [ ] advise
- [ ] shy
- [ ] conversation
- [ ] quickly

# Chapter 003

- [ ] natural
- [ ] suggest
- [ ] place
- [ ] hill
- [ ] population
- [ ] wide
- [ ] million
- [ ] pretty
- [ ] pretty good
- [ ] than
- [ ] get
- [ ] north
- [ ] south
- [ ] west
- [ ] home town
- [ ] especially
- [ ] be famous for
- [ ] university
- [ ] island
- [ ] area

# Chapter 004

- [ ] low
- [ ] mountain
- [ ] countryside
- [ ] umbrella
- [ ] baseball
- [ ] volleyball
- [ ] boring
- [ ] exciting
- [ ] relaxing
- [ ] score
- [ ] already
- [ ] matter
- [ ] What's the matter?
- [ ] hurt
- [ ] enjoyable
- [ ] Olympics
- [ ] stadium
- [ ] miss
- [ ] mind
- [ ] plenty

# Chapter 005

- [ ] plenty of
- [ ] beat
- [ ] careless
- [ ] cheer ⋯ on
- [ ] coach
- [ ] fan club
- [ ] against
- [ ] train
- [ ] practice
- [ ] warm
- [ ] warm up
- [ ] usual
- [ ] better
- [ ] after-school
- [ ] pleased
- [ ] pass
- [ ] pity
- [ ] chance
- [ ] loudly
- [ ] confident

# Chapter 006

- [ ] road
- [ ] accident
- [ ] except
- [ ] choice
- [ ] classmate
- [ ] far
- [ ] far from
- [ ] close
- [ ] crowded
- [ ] all the time
- [ ] journey
- [ ] book
- [ ] park
- [ ] outside
- [ ] however
- [ ] cost
- [ ] actress
- [ ] teahouse
- [ ] offer
- [ ] end

# Chapter 007

- [ ] in the end
- [ ] no idea
- [ ] act
- [ ] show
- [ ] common
- [ ] twentieth
- [ ] describe
- [ ] society
- [ ] head teacher
- [ ] college
- [ ] novel
- [ ] name
- [ ] if
- [ ] magic
- [ ] snake
- [ ] neck
- [ ] thin
- [ ] danger
- [ ] in danger
- [ ] at last

# Chapter 008

- [ ] interested
- [ ] allow
- [ ] think of
- [ ] protect
- [ ] wild
- [ ] grow
- [ ] take away
- [ ] enough
- [ ] peace
- [ ] in peace
- [ ] notice
- [ ] look after
- [ ] raise
- [ ] research
- [ ] baby
- [ ] situation
- [ ] scientist
- [ ] produce
- [ ] southwest
- [ ] in order to

# Chapter 009

- [ ] government
- [ ] set
- [ ] set up
- [ ] nature
- [ ] nature park
- [ ] develop
- [ ] feed
- [ ] symbol
- [ ] fall
- [ ] follow
- [ ] hole
- [ ] rabbit
- [ ] ssh
- [ ] ground
- [ ] tea party
- [ ] twice
- [ ] once or twice
- [ ] suddenly
- [ ] pink
- [ ] pocket

# Chapter 010

- [ ] field
- [ ] think about
- [ ] deep
- [ ] while
- [ ] land
- [ ] dry
- [ ] pale
- [ ] appear
- [ ] round
- [ ] corner
- [ ] hit
- [ ] glad
- [ ] in time
- [ ] fall off
- [ ] risk
- [ ] attention
- [ ] pay attention
- [ ] side
- [ ] side by side
- [ ] bite

# Chapter 011

- [ ] climb
- [ ] hide
- [ ] throw
- [ ] fridge
- [ ] pain
- [ ] worse
- [ ] medicine
- [ ] noise
- [ ] prepare
- [ ] notes
- [ ] report
- [ ] Grow
- [ ] huge
- [ ] cause
- [ ] problem
- [ ] increase
- [ ] birth
- [ ] billion
- [ ] fifth
- [ ] hang on

# Chapter 012

- [ ] flat
- [ ] rubbish
- [ ] quiet
- [ ] local
- [ ] close down
- [ ] pupil
- [ ] pollution
- [ ] public
- [ ] service
- [ ] solve
- [ ] cloud
- [ ] shower
- [ ] snow
- [ ] storm
- [ ] cloudy
- [ ] rainy
- [ ] snowy
- [ ] sunny
- [ ] windy
- [ ] skate

# Chapter 013

- [ ] thick
- [ ] ice
- [ ] joke
- [ ] might
- [ ] temperature
- [ ] minus
- [ ] degree
- [ ] although
- [ ] wet
- [ ] neither
- [ ] terrible
- [ ] wish
- [ ] probably
- [ ] come on
- [ ] mile
- [ ] Round
- [ ] northwest
- [ ] southeast
- [ ] from time to time
- [ ] cap

# Chapter 014

- [ ] chess
- [ ] Set
- [ ] a chess set
- [ ] chopstick
- [ ] toy
- [ ] video
- [ ] video game
- [ ] gift
- [ ] surprise
- [ ] immediately
- [ ] difference
- [ ] accept
- [ ] tradition
- [ ] example
- [ ] for example
- [ ] must
- [ ] month
- [ ] serious
- [ ] taste
- [ ] experience

# Chapter 015

- [ ] stay
- [ ] someone
- [ ] for the first time
- [ ] sandwich
- [ ] chip
- [ ] fish and chips
- [ ] onto
- [ ] gentleman
- [ ] shoulder
- [ ] broken
- [ ] glass
- [ ] stairs
- [ ] aid
- [ ] first aid
- [ ] medical
- [ ] imagine
- [ ] bottom
- [ ] at the bottom of
- [ ] wrong
- [ ] What's wrong with ⋯?

# Chapter 016

- [ ] trouble
- [ ] lift
- [ ] lift up
- [ ] harmful
- [ ] drop
- [ ] training
- [ ] make sure
- [ ] cover
- [ ] earthquake
- [ ] warn
- [ ] inside
- [ ] under
- [ ] window
- [ ] keep
- [ ] clear
- [ ] keep clear of ⋯
- [ ] calm
- [ ] brave
- [ ] helpful
- [ ] power

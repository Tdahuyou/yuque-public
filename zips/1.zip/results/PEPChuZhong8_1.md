
# Chapter 001

- [ ] anyone
- [ ] anywhere
- [ ] wonderful
- [ ] few
- [ ] quite a few
- [ ] most
- [ ] something
- [ ] nothing
- [ ] everyone
- [ ] of course
- [ ] myself
- [ ] yourself
- [ ] hen
- [ ] pig
- [ ] seem
- [ ] bored
- [ ] someone
- [ ] diary
- [ ] activity
- [ ] decide

# Chapter 002

- [ ] try
- [ ] paragliding
- [ ] feel like(doing sth.)
- [ ] bird
- [ ] bicycle
- [ ] building
- [ ] trader
- [ ] wonder
- [ ] difference
- [ ] top
- [ ] wait
- [ ] umbrella
- [ ] wet
- [ ] because of
- [ ] below
- [ ] enough
- [ ] hungry
- [ ] as
- [ ] hill
- [ ] duck

# Chapter 003

- [ ] dislike
- [ ] have a good time
- [ ] Central Park
- [ ] Huangguoshu waterfall
- [ ] Hong Kong
- [ ] Malaysia
- [ ] Georgetown
- [ ] Weld Quay
- [ ] Penang Hill
- [ ] tian'anmen square
- [ ] the Palace Museum
- [ ] housework
- [ ] hardly
- [ ] ever
- [ ] hardly ever
- [ ] once
- [ ] twice
- [ ] Internet
- [ ] program
- [ ] full

# Chapter 004

- [ ] swing
- [ ] swing dance
- [ ] maybe
- [ ] least
- [ ] at least
- [ ] junk
- [ ] junk food
- [ ] coffee
- [ ] health
- [ ] result
- [ ] percent
- [ ] online
- [ ] television
- [ ] although
- [ ] through
- [ ] mind
- [ ] body
- [ ] such
- [ ] such as
- [ ] together

# Chapter 005

- [ ] die
- [ ] writer
- [ ] dentist
- [ ] magazine
- [ ] however
- [ ] than
- [ ] more than
- [ ] almost
- [ ] none
- [ ] less
- [ ] less than
- [ ] point
- [ ] outgoing
- [ ] better
- [ ] loudly
- [ ] quietly
- [ ] hard-working
- [ ] competition
- [ ] fantastic
- [ ] which

# Chapter 006

- [ ] clearly
- [ ] win
- [ ] though
- [ ] talented
- [ ] truly
- [ ] care
- [ ] care about
- [ ] serious
- [ ] mirror
- [ ] kid
- [ ] as long as
- [ ] necessary
- [ ] be different from
- [ ] both
- [ ] bring out
- [ ] grade
- [ ] should
- [ ] the same as
- [ ] saying
- [ ] reach

# Chapter 007

- [ ] hand
- [ ] touch
- [ ] heart
- [ ] fact
- [ ] in fact
- [ ] break
- [ ] arm
- [ ] laugh
- [ ] share
- [ ] loud
- [ ] similar
- [ ] be similar to
- [ ] primary
- [ ] primary school
- [ ] information
- [ ] theater
- [ ] comfortable
- [ ] seat
- [ ] screen
- [ ] close

# Chapter 008

- [ ] ticket
- [ ] worst
- [ ] cheaply
- [ ] song
- [ ] choose
- [ ] carefully
- [ ] reporter
- [ ] so far
- [ ] fresh
- [ ] comfortably
- [ ] worse
- [ ] service
- [ ] pretty
- [ ] menu
- [ ] act
- [ ] meal
- [ ] creative
- [ ] performer
- [ ] talent
- [ ] common

# Chapter 009

- [ ] have…in common
- [ ] magician
- [ ] all kinds of
- [ ] beautifully
- [ ] be up to
- [ ] role
- [ ] play a role
- [ ] winner
- [ ] prize
- [ ] everybody
- [ ] make up
- [ ] example
- [ ] for example
- [ ] poor
- [ ] seriously
- [ ] take…seriously
- [ ] give
- [ ] crowded
- [ ] sitcom
- [ ] situation comedy

# Chapter 010

- [ ] news
- [ ] soap
- [ ] soap opera
- [ ] educational
- [ ] plan
- [ ] hope
- [ ] find out
- [ ] discussion
- [ ] stand
- [ ] happen
- [ ] may
- [ ] expect
- [ ] joke
- [ ] comedy
- [ ] meaningless
- [ ] action
- [ ] action movie
- [ ] cartoon
- [ ] culture
- [ ] famous

# Chapter 011

- [ ] appear
- [ ] become
- [ ] rich
- [ ] successful
- [ ] might
- [ ] main
- [ ] reason
- [ ] comedy.
- [ ] film
- [ ] unlucky
- [ ] lose
- [ ] girlfriend
- [ ] ready
- [ ] be ready to
- [ ] character
- [ ] simple
- [ ] dress up
- [ ] take sb.’s place
- [ ] army
- [ ] do a good job

# Chapter 012

- [ ] grow up
- [ ] computer programmer
- [ ] cook
- [ ] doctor
- [ ] engineer
- [ ] violinist
- [ ] driver
- [ ] pilot
- [ ] pianist
- [ ] scientist
- [ ] be sure about
- [ ] make sure
- [ ] college
- [ ] education
- [ ] medicine
- [ ] university
- [ ] London
- [ ] article
- [ ] send
- [ ] resolution

# Chapter 013

- [ ] team
- [ ] foreign
- [ ] able
- [ ] be able to
- [ ] question
- [ ] meaning
- [ ] discuss
- [ ] promise
- [ ] beginning
- [ ] at the beginning of
- [ ] improve
- [ ] write down
- [ ] physical
- [ ] themselves
- [ ] have to do with
- [ ] self-improvement
- [ ] take up
- [ ] hobby
- [ ] weekly
- [ ] school work

# Chapter 014

- [ ] agree
- [ ] agree with
- [ ] own
- [ ] personal
- [ ] relationship
- [ ] paper
- [ ] pollution
- [ ] prediction
- [ ] future
- [ ] pollute
- [ ] environment
- [ ] planet
- [ ] earth
- [ ] plant
- [ ] part
- [ ] play a part
- [ ] peace
- [ ] sea
- [ ] sky
- [ ] astronaut

# Chapter 015

- [ ] apartment
- [ ] rocket
- [ ] space
- [ ] space station
- [ ] human
- [ ] servant
- [ ] dangerous
- [ ] already
- [ ] factory
- [ ] over and over again
- [ ] believe
- [ ] disagree
- [ ] even
- [ ] hundreds of
- [ ] shape
- [ ] fall
- [ ] fall down
- [ ] inside
- [ ] look for
- [ ] possible

# Chapter 016

- [ ] impossible
- [ ] side
- [ ] probably
- [ ] during
- [ ] holiday
- [ ] word
- [ ] shake
- [ ] milk shake
- [ ] blender
- [ ] turn on
- [ ] peel
- [ ] pour
- [ ] yogurt
- [ ] honey
- [ ] watermelon
- [ ] spoon
- [ ] pot
- [ ] add
- [ ] finally
- [ ] salt

# Chapter 017

- [ ] sugar
- [ ] cheese
- [ ] popcorn
- [ ] corn
- [ ] machine
- [ ] dig
- [ ] hole
- [ ] sandwich
- [ ] butter
- [ ] turkey
- [ ] lettuce
- [ ] piece
- [ ] Thanksgiving
- [ ] traditional
- [ ] autumn
- [ ] traveler
- [ ] England
- [ ] celebrate
- [ ] mix
- [ ] pepper

# Chapter 018

- [ ] fill
- [ ] oven
- [ ] plate
- [ ] cover
- [ ] gravy
- [ ] serve
- [ ] temperature
- [ ] prepare
- [ ] prepare for
- [ ] exam
- [ ] flu
- [ ] available
- [ ] another time
- [ ] until
- [ ] hang
- [ ] hang out
- [ ] catch
- [ ] invite
- [ ] accept
- [ ] refuse

# Chapter 019

- [ ] the day before yesterday
- [ ] the day after tomorrow
- [ ] weekday
- [ ] look after
- [ ] invitation
- [ ] turn down
- [ ] reply
- [ ] forward
- [ ] delete
- [ ] print
- [ ] sad
- [ ] goodbye
- [ ] take a trip
- [ ] glad
- [ ] preparation
- [ ] glue
- [ ] without
- [ ] surprised
- [ ] look forward to
- [ ] hear from

# Chapter 020

- [ ] housewarming
- [ ] opening
- [ ] concert
- [ ] headmaster
- [ ] event
- [ ] guest
- [ ] calendar
- [ ] daytime
- [ ] meeting
- [ ] video
- [ ] potato chips
- [ ] chocolate
- [ ] upset
- [ ] taxi
- [ ] advice
- [ ] travel
- [ ] agent
- [ ] expert
- [ ] keep…to oneself
- [ ] teenager

# Chapter 021

- [ ] normal
- [ ] unless
- [ ] certainly
- [ ] wallet
- [ ] mile
- [ ] angry
- [ ] understanding
- [ ] careless
- [ ] mistake
- [ ] himself
- [ ] careful
- [ ] advise
- [ ] solve
- [ ] step
- [ ] trust
- [ ] experience
- [ ] in half
- [ ] halfway
- [ ] else

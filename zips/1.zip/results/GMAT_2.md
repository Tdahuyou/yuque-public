
# Chapter 001

- [ ] abdicate
- [ ] abnormal
- [ ] abolish
- [ ] absenteeism
- [ ] absorb
- [ ] abstract
- [ ] absurd
- [ ] abundant
- [ ] academic
- [ ] accelerate
- [ ] access
- [ ] accessible
- [ ] acclaim
- [ ] accommodate
- [ ] accompaniment
- [ ] accomplish
- [ ] accord
- [ ] accordingly
- [ ] accountant
- [ ] accounting

# Chapter 002

- [ ] accretion
- [ ] accrue
- [ ] accumulate
- [ ] accuracy
- [ ] accurate
- [ ] accustomed
- [ ] acidity
- [ ] acknowledge
- [ ] acoustic
- [ ] acoustical
- [ ] acquiesce
- [ ] acquire
- [ ] acquisition
- [ ] acreage
- [ ] activate
- [ ] activism
- [ ] activist
- [ ] acute
- [ ] adapt
- [ ] adaptation

# Chapter 003

- [ ] adapter
- [ ] addict
- [ ] addictive
- [ ] addition
- [ ] additive
- [ ] adept
- [ ] adhere
- [ ] adherence
- [ ] adjacent
- [ ] adjust
- [ ] administer
- [ ] admit
- [ ] adolescent
- [ ] adoption
- [ ] advent
- [ ] adverse
- [ ] advertising
- [ ] advocacy
- [ ] aerodynamic
- [ ] affiliation

# Chapter 004

- [ ] affirmative
- [ ] afflict
- [ ] affluent
- [ ] affordable
- [ ] aftermath
- [ ] aggravate
- [ ] aggregate
- [ ] aggression
- [ ] aggressive
- [ ] agrarian
- [ ] ailment
- [ ] airliner
- [ ] ale
- [ ] alga
- [ ] alien
- [ ] alignment
- [ ] allay
- [ ] allege
- [ ] allegiance
- [ ] allergic

# Chapter 005

- [ ] allergy
- [ ] alleviate
- [ ] alliance
- [ ] alligator
- [ ] allocate
- [ ] allotment
- [ ] allowance
- [ ] allude
- [ ] alluvial
- [ ] ally
- [ ] alpha
- [ ] alter
- [ ] alternate
- [ ] alternative
- [ ] altitude
- [ ] altruism
- [ ] aluminum
- [ ] alumna
- [ ] alumnus
- [ ] amalgam

# Chapter 006

- [ ] amass
- [ ] amateur
- [ ] amber
- [ ] ambiguity
- [ ] ambiguous
- [ ] ambitious
- [ ] ambivalent
- [ ] amenable
- [ ] amend
- [ ] amenity
- [ ] amphitheater
- [ ] ample
- [ ] amplifier
- [ ] amplify
- [ ] amplitude
- [ ] anaerobic
- [ ] analogy
- [ ] anatomical
- [ ] anatomy
- [ ] ancestor

# Chapter 007

- [ ] ancestry
- [ ] anecdotal
- [ ] anemia
- [ ] anesthesia
- [ ] animate
- [ ] animosity
- [ ] announce
- [ ] announcement
- [ ] anole
- [ ] anomaly
- [ ] anonymous
- [ ] answerable
- [ ] antagonism
- [ ] antedate
- [ ] anterior
- [ ] anthropologist
- [ ] antibiotic
- [ ] antibiotics
- [ ] antibody
- [ ] anticipate

# Chapter 008

- [ ] antifreeze
- [ ] antiquated
- [ ] antique
- [ ] antiquity
- [ ] antitrust
- [ ] aperiodic
- [ ] apex
- [ ] apiece
- [ ] apparatus
- [ ] apparel
- [ ] apparent
- [ ] appeal
- [ ] appendicitis
- [ ] appetite
- [ ] appliance
- [ ] applicable
- [ ] appoint
- [ ] apportion
- [ ] apprentice
- [ ] apprenticeship

# Chapter 009

- [ ] approbation
- [ ] appropriate
- [ ] appropriation
- [ ] approval
- [ ] approve
- [ ] aquarium
- [ ] aquatic
- [ ] arable
- [ ] arbitrary
- [ ] arboreal
- [ ] arch
- [ ] archaeological
- [ ] archaeologist
- [ ] archaeology
- [ ] archenemy
- [ ] architect
- [ ] ardent
- [ ] arid
- [ ] aristocracy
- [ ] arithmetic

# Chapter 010

- [ ] array
- [ ] arrest
- [ ] artery
- [ ] arthritis
- [ ] artifact
- [ ] artificial
- [ ] artisan
- [ ] ascending
- [ ] ascribe
- [ ] aspect
- [ ] aspen
- [ ] aspersion
- [ ] aspiration
- [ ] assemble
- [ ] assembler
- [ ] assert
- [ ] assertion
- [ ] assess
- [ ] asset
- [ ] assign

# Chapter 011

- [ ] assist
- [ ] associate
- [ ] association
- [ ] assume
- [ ] assumption
- [ ] asteroid
- [ ] asthma
- [ ] astronomical
- [ ] astronomy
- [ ] atmosphere
- [ ] attain
- [ ] attempt
- [ ] attendance
- [ ] attendee
- [ ] attorney
- [ ] attraction
- [ ] attributable
- [ ] attrition
- [ ] auction
- [ ] audiophile

# Chapter 012

- [ ] audit
- [ ] auditorium
- [ ] aura
- [ ] aurora
- [ ] austere
- [ ] authentic
- [ ] authenticate
- [ ] authoritative
- [ ] authority
- [ ] authorize
- [ ] autobiography
- [ ] automate
- [ ] automatic
- [ ] automation
- [ ] automobile
- [ ] autonomy
- [ ] availability
- [ ] avalanche
- [ ] aversion
- [ ] avian

# Chapter 013

- [ ] aviation
- [ ] avidly
- [ ] avoid
- [ ] backwater
- [ ] bacterium
- [ ] balcony
- [ ] ballistic
- [ ] bankruptcy
- [ ] bar
- [ ] barb
- [ ] bark
- [ ] barracks
- [ ] barrel
- [ ] barren
- [ ] barrier
- [ ] batch
- [ ] battalion
- [ ] bead
- [ ] beam
- [ ] bearer

# Chapter 014

- [ ] beckon
- [ ] beehive
- [ ] behavioral
- [ ] bellows
- [ ] benchmark
- [ ] benefactor
- [ ] beneficiary
- [ ] benefit
- [ ] benevolence
- [ ] bestow
- [ ] betrayal
- [ ] off
- [ ] beverage
- [ ] bias
- [ ] bicker
- [ ] bid
- [ ] bifurcation
- [ ] bilateral
- [ ] billing
- [ ] bind

# Chapter 015

- [ ] biodegradable
- [ ] bioengineer
- [ ] biography
- [ ] biomedical
- [ ] biophysicist
- [ ] biosphere
- [ ] bisect
- [ ] bizarre
- [ ] blackout
- [ ] bland
- [ ] blast
- [ ] bloc
- [ ] block
- [ ] blot
- [ ] bluegrass
- [ ] bluntly
- [ ] boarder
- [ ] boardinghouse
- [ ] bold
- [ ] bolster

# Chapter 016

- [ ] bolt
- [ ] bombard
- [ ] bond
- [ ] bonus
- [ ] boom
- [ ] boomerang
- [ ] boost
- [ ] booth
- [ ] boreal
- [ ] bounce
- [ ] bound
- [ ] bounty
- [ ] bourgeois
- [ ] bower
- [ ] boycott
- [ ] brace
- [ ] brass
- [ ] brew
- [ ] brochure
- [ ] broker

# Chapter 017

- [ ] brokerage
- [ ] bronze
- [ ] brutal
- [ ] bucket
- [ ] budget
- [ ] budworm
- [ ] buffalo
- [ ] buffer
- [ ] bulge
- [ ] bulk
- [ ] buoyant
- [ ] burden
- [ ] bureau
- [ ] burglarize
- [ ] burrow
- [ ] butterfly
- [ ] buttress
- [ ] bygone
- [ ] bylaw
- [ ] cabin

# Chapter 018

- [ ] cabinet
- [ ] caffeine
- [ ] calamitous
- [ ] calcium
- [ ] calculate
- [ ] calculus
- [ ] calefaction
- [ ] calendar
- [ ] calf
- [ ] caller
- [ ] calligraphic
- [ ] camcorder
- [ ] campaign
- [ ] campsite
- [ ] canary
- [ ] candidate
- [ ] cannon
- [ ] canopy
- [ ] canyon
- [ ] capacity

# Chapter 019

- [ ] capitalize
- [ ] capsule
- [ ] captivate
- [ ] captive
- [ ] capture
- [ ] carbohydrate
- [ ] carbonate
- [ ] carcass
- [ ] carcinogen
- [ ] carcinogenic
- [ ] cardiac
- [ ] cardiopulmonary
- [ ] cardiovascular
- [ ] cargo
- [ ] caribou
- [ ] carnivore
- [ ] carpenter
- [ ] carpentry
- [ ] carpet
- [ ] carpeting

# Chapter 020

- [ ] cartel
- [ ] cascade
- [ ] caseload
- [ ] cashew
- [ ] caste
- [ ] casualty
- [ ] cataclysm
- [ ] cataclysmic
- [ ] catalyst
- [ ] catalytic
- [ ] catastrophe
- [ ] categorical
- [ ] category
- [ ] cater
- [ ] caterpillar
- [ ] cathedral
- [ ] Catholic
- [ ] causative
- [ ] cease
- [ ] celestial

# Chapter 021

- [ ] cellular
- [ ] censure
- [ ] census
- [ ] centrality
- [ ] ceramic
- [ ] cereal
- [ ] certificate
- [ ] certify
- [ ] certitude
- [ ] cessation
- [ ] chaise
- [ ] chalice
- [ ] chamber
- [ ] character
- [ ] characterization
- [ ] charity
- [ ] chart
- [ ] charter
- [ ] chatter
- [ ] chatty

# Chapter 022

- [ ] chauvinism
- [ ] chip
- [ ] cholesterol
- [ ] chord
- [ ] chore
- [ ] choreographer
- [ ] chronicle
- [ ] chronology
- [ ] circuit
- [ ] circular
- [ ] circulate
- [ ] circulation
- [ ] circulatory
- [ ] circumference
- [ ] circumspect
- [ ] circumstance
- [ ] circumvent
- [ ] citywide
- [ ] civic
- [ ] civilization

# Chapter 023

- [ ] claim
- [ ] clan
- [ ] clandestine
- [ ] clarify
- [ ] clarity
- [ ] classify
- [ ] clergy
- [ ] client
- [ ] cliff
- [ ] clinging
- [ ] clockwise
- [ ] clog
- [ ] clot
- [ ] clump
- [ ] cluster
- [ ] coalition
- [ ] coaster
- [ ] cocaine
- [ ] codify
- [ ] cognitive

# Chapter 024

- [ ] coherent
- [ ] coinage
- [ ] coincide
- [ ] collaborate
- [ ] collapse
- [ ] collateral
- [ ] collective
- [ ] collide
- [ ] collinear
- [ ] colonize
- [ ] coloration
- [ ] colossal
- [ ] combat
- [ ] combine
- [ ] combustion
- [ ] comedian
- [ ] comet
- [ ] commend
- [ ] commensurate
- [ ] comment

# Chapter 025

- [ ] commerce
- [ ] commercial
- [ ] commission
- [ ] commit
- [ ] commitment
- [ ] commodity
- [ ] commoner
- [ ] commonplace
- [ ] communal
- [ ] communist
- [ ] community
- [ ] commute
- [ ] compact
- [ ] companionate
- [ ] comparable
- [ ] comparison
- [ ] compassion
- [ ] compatible
- [ ] compel
- [ ] compelling

# Chapter 026

- [ ] compensate
- [ ] compensation
- [ ] competence
- [ ] competitive
- [ ] compile
- [ ] complacency
- [ ] complainant
- [ ] complaint
- [ ] complex
- [ ] complication
- [ ] comply
- [ ] component
- [ ] compose
- [ ] composition
- [ ] compound
- [ ] comprehend
- [ ] comprehension
- [ ] compress
- [ ] comprise
- [ ] compromise

# Chapter 027

- [ ] compulsory
- [ ] computation
- [ ] compute
- [ ] conceal
- [ ] concede
- [ ] conceive
- [ ] concentrate
- [ ] concentration
- [ ] conceptual
- [ ] concern
- [ ] concerning
- [ ] concert
- [ ] concession
- [ ] conclude
- [ ] concrete
- [ ] concurrent
- [ ] condemn
- [ ] condense
- [ ] condescending
- [ ] condition

# Chapter 028

- [ ] condominium
- [ ] confederation
- [ ] confer
- [ ] confess
- [ ] confidential
- [ ] configuration
- [ ] confine
- [ ] confirm
- [ ] conflict
- [ ] conform
- [ ] confront
- [ ] Confucian
- [ ] congenial
- [ ] congested
- [ ] congestion
- [ ] conglomerate
- [ ] congregation
- [ ] congress
- [ ] congressional
- [ ] conjunction

# Chapter 029

- [ ] connotation
- [ ] conscience
- [ ] conscription
- [ ] consecutive
- [ ] consensus
- [ ] consent
- [ ] consequence
- [ ] conservatism
- [ ] conservative
- [ ] conservatively
- [ ] conserve
- [ ] considerable
- [ ] consideration
- [ ] consistency
- [ ] consistent
- [ ] consolidate
- [ ] consortium
- [ ] conspire
- [ ] constant
- [ ] constellation

# Chapter 030

- [ ] constituent
- [ ] constitute
- [ ] constraint
- [ ] constrict
- [ ] construct
- [ ] construction
- [ ] constructivism
- [ ] constructivist
- [ ] consult
- [ ] consultant
- [ ] consumption
- [ ] contaminate
- [ ] contamination
- [ ] contemplate
- [ ] contemporary
- [ ] contemptuous
- [ ] contend
- [ ] contiguous
- [ ] contingent
- [ ] contraband

# Chapter 031

- [ ] contraction
- [ ] contractor
- [ ] contradict
- [ ] contradiction
- [ ] contrast
- [ ] contribute
- [ ] contributor
- [ ] control
- [ ] controversial
- [ ] controversy
- [ ] convection
- [ ] convenience
- [ ] conventional
- [ ] conversion
- [ ] convert
- [ ] convey
- [ ] conviction
- [ ] convince
- [ ] convoluted
- [ ] cooperate

# Chapter 032

- [ ] coordinate
- [ ] copper
- [ ] coral
- [ ] cord
- [ ] cork
- [ ] coronary
- [ ] corporate
- [ ] corporation
- [ ] corps
- [ ] corral
- [ ] correlate
- [ ] correspond
- [ ] corresponding
- [ ] corroborate
- [ ] corrosion
- [ ] corrosive
- [ ] corruption
- [ ] cortex
- [ ] cosmetic
- [ ] cosmic

# Chapter 033

- [ ] council
- [ ] counteract
- [ ] counterattack
- [ ] counterevidence
- [ ] counterfeit
- [ ] countermeasure
- [ ] counterpart
- [ ] counterproductive
- [ ] countervail
- [ ] coupon
- [ ] courier
- [ ] courtesy
- [ ] cowhide
- [ ] crack
- [ ] cramped
- [ ] crass
- [ ] crate
- [ ] creative
- [ ] creativity
- [ ] credence

# Chapter 034

- [ ] credit
- [ ] creditworthiness
- [ ] crest
- [ ] criminology
- [ ] cripple
- [ ] criteria
- [ ] criterion
- [ ] critic
- [ ] critical
- [ ] criticism
- [ ] critique
- [ ] crossbred
- [ ] crucial
- [ ] crude
- [ ] crusade
- [ ] crush
- [ ] crust
- [ ] crustal
- [ ] cryptic
- [ ] crystallize

# Chapter 035

- [ ] cube
- [ ] cue
- [ ] cuisine
- [ ] culminate
- [ ] culpability
- [ ] cult
- [ ] cultivate
- [ ] cultivated
- [ ] cultivation
- [ ] cumbersome
- [ ] cupidity
- [ ] curb
- [ ] curiosity
- [ ] currency
- [ ] curriculum
- [ ] cursorial
- [ ] curtail
- [ ] customize
- [ ] customs
- [ ] cutback

# Chapter 036

- [ ] cyclic
- [ ] cylinder
- [ ] cylindrical
- [ ] cynical
- [ ] dealership
- [ ] debase
- [ ] debate
- [ ] debilitate
- [ ] debris
- [ ] debunk
- [ ] decade
- [ ] decay
- [ ] decimal
- [ ] decimate
- [ ] decipher
- [ ] declension
- [ ] decorate
- [ ] decoration
- [ ] decorous
- [ ] dedicated

# Chapter 037

- [ ] deduce
- [ ] deduct
- [ ] deduction
- [ ] deem
- [ ] default
- [ ] defendant
- [ ] deferential
- [ ] defiant
- [ ] deficiency
- [ ] deficit
- [ ] definition
- [ ] definitive
- [ ] deflect
- [ ] deform
- [ ] defrost
- [ ] degradation
- [ ] degrade
- [ ] dehydrate
- [ ] deleterious
- [ ] deliberate

# Chapter 038

- [ ] delicacy
- [ ] delicate
- [ ] delineate
- [ ] delinquent
- [ ] deliver
- [ ] delta
- [ ] deluxe
- [ ] delve
- [ ] demobilization
- [ ] democracy
- [ ] democrat
- [ ] demographer
- [ ] demographic
- [ ] demonstrably
- [ ] demonstrate
- [ ] denote
- [ ] denounce
- [ ] dense
- [ ] density
- [ ] denunciatory

# Chapter 039

- [ ] depart
- [ ] departure
- [ ] dependence
- [ ] depict
- [ ] depiction
- [ ] deplete
- [ ] depletion
- [ ] deposit
- [ ] deprecate
- [ ] depreciation
- [ ] depress
- [ ] depression
- [ ] deprivation
- [ ] deregulation
- [ ] derivative
- [ ] derive
- [ ] descend
- [ ] description
- [ ] desegregation
- [ ] deserve

# Chapter 040

- [ ] designate
- [ ] desire
- [ ] despise
- [ ] detach
- [ ] detached
- [ ] detection
- [ ] deter
- [ ] deteriorate
- [ ] deterioration
- [ ] determination
- [ ] determinism
- [ ] detrimental
- [ ] devastate
- [ ] deviate
- [ ] deviation
- [ ] devise
- [ ] devoid
- [ ] dexterity
- [ ] diagnose
- [ ] diagnostic

# Chapter 041

- [ ] diagonal
- [ ] dialect
- [ ] diameter
- [ ] diaper
- [ ] dichotomy
- [ ] dictate
- [ ] diesel
- [ ] dietary
- [ ] differentiate
- [ ] differentiation
- [ ] digest
- [ ] digit
- [ ] digitize
- [ ] dilemma
- [ ] dilute
- [ ] dimension
- [ ] diminish
- [ ] diminution
- [ ] dinosaur
- [ ] dioxide

# Chapter 042

- [ ] diploma
- [ ] diplomatic
- [ ] dire
- [ ] disability
- [ ] disaster
- [ ] discard
- [ ] discern
- [ ] discharge
- [ ] disciple
- [ ] discipline
- [ ] disclosure
- [ ] discord
- [ ] discrepancy
- [ ] discrete
- [ ] discretion
- [ ] discretionary
- [ ] discriminate
- [ ] disdainful
- [ ] disenchanted
- [ ] disenfranchise

# Chapter 043

- [ ] disinclined
- [ ] disintegration
- [ ] dislocation
- [ ] dislodge
- [ ] dismal
- [ ] dismantle
- [ ] dismay
- [ ] dismiss
- [ ] disorient
- [ ] disparaging
- [ ] disparate
- [ ] dispel
- [ ] dispense
- [ ] disperse
- [ ] displace
- [ ] dispose
- [ ] disproportionate
- [ ] dispute
- [ ] disrupt
- [ ] disseminate

# Chapter 044

- [ ] dissent
- [ ] dissimilar
- [ ] dissipate
- [ ] dissociate
- [ ] distill
- [ ] distinct
- [ ] distinctive
- [ ] distinguish
- [ ] distort
- [ ] distribute
- [ ] distribution
- [ ] distributor
- [ ] district
- [ ] disturb
- [ ] diverge
- [ ] diverse
- [ ] diversification
- [ ] diversify
- [ ] diversion
- [ ] divest

# Chapter 045

- [ ] dividend
- [ ] divisible
- [ ] division
- [ ] divisive
- [ ] divulge
- [ ] doctorate
- [ ] doctrine
- [ ] documentation
- [ ] dogma
- [ ] domain
- [ ] domestic
- [ ] domesticate
- [ ] domestication
- [ ] domesticity
- [ ] dominate
- [ ] donate
- [ ] dormant
- [ ] dosage
- [ ] dose
- [ ] dough

# Chapter 046

- [ ] downplay
- [ ] downstream
- [ ] drab
- [ ] draft
- [ ] drainage
- [ ] dramatize
- [ ] drastic
- [ ] drift
- [ ] drilling
- [ ] drizzle
- [ ] droplet
- [ ] dropout
- [ ] drought
- [ ] dubious
- [ ] ductile
- [ ] dump
- [ ] dumpster
- [ ] duplicate
- [ ] duplication
- [ ] durability

# Chapter 047

- [ ] duration
- [ ] dwarf
- [ ] dwelling
- [ ] dwindle
- [ ] dye
- [ ] dynamic
- [ ] ease
- [ ] echolocation
- [ ] eclipse
- [ ] ecology
- [ ] economy
- [ ] ecosystem
- [ ] edge
- [ ] edible
- [ ] editorial
- [ ] educator
- [ ] effect
- [ ] efficacy
- [ ] efficiency
- [ ] efficient

# Chapter 048

- [ ] effigy
- [ ] effluent
- [ ] egalitarianism
- [ ] egoistic
- [ ] eject
- [ ] elective
- [ ] electorate
- [ ] electricity
- [ ] electro
- [ ] electromagnetic
- [ ] electron
- [ ] element
- [ ] elevate
- [ ] elevation
- [ ] elicit
- [ ] eligible
- [ ] eliminate
- [ ] elite
- [ ] elliptical
- [ ] elongate

# Chapter 049

- [ ] eloquent
- [ ] elude
- [ ] emancipation
- [ ] embalm
- [ ] embargo
- [ ] embark
- [ ] embarrass
- [ ] embarrassed
- [ ] embed
- [ ] embellish
- [ ] embrace
- [ ] embryo
- [ ] embryonic
- [ ] emerge
- [ ] emergence
- [ ] emergency
- [ ] emigrate
- [ ] eminent
- [ ] emission
- [ ] emit

# Chapter 050

- [ ] emphasis
- [ ] emphasize
- [ ] empirical
- [ ] emulate
- [ ] enact
- [ ] enamel
- [ ] encephalitis
- [ ] enclose
- [ ] encode
- [ ] encompass
- [ ] encounter
- [ ] encroach
- [ ] encyclopedia
- [ ] endanger
- [ ] endeavor
- [ ] endemic
- [ ] endorphin
- [ ] endorse
- [ ] endothermic
- [ ] enforce

# Chapter 051

- [ ] enfranchisement
- [ ] engage
- [ ] engender
- [ ] engulf
- [ ] enhance
- [ ] enhanced
- [ ] enlightened
- [ ] enlist
- [ ] enormous
- [ ] enrich
- [ ] enroll
- [ ] ensemble
- [ ] enshrine
- [ ] entail
- [ ] enterprise
- [ ] entertainment
- [ ] enthusiastically
- [ ] entice
- [ ] entitle
- [ ] entity

# Chapter 052

- [ ] entrant
- [ ] entrapment
- [ ] entrepreneur
- [ ] entrepreneurship
- [ ] entry
- [ ] enumerate
- [ ] envelop
- [ ] envelope
- [ ] envision
- [ ] enzyme
- [ ] epic
- [ ] epicenter
- [ ] epidemic
- [ ] episode
- [ ] episodic
- [ ] epochal
- [ ] equalize
- [ ] equilibrium
- [ ] equip
- [ ] equity

# Chapter 053

- [ ] equivalent
- [ ] era
- [ ] eradicate
- [ ] eradication
- [ ] erase
- [ ] ergonomic
- [ ] erode
- [ ] errand
- [ ] erratic
- [ ] eruption
- [ ] escalate
- [ ] eschew
- [ ] essence
- [ ] estate
- [ ] esteem
- [ ] estimate
- [ ] etched
- [ ] eternal
- [ ] ethanol
- [ ] ethic

# Chapter 054

- [ ] ethnic
- [ ] ethnographic
- [ ] ethnomusicology
- [ ] euphoria
- [ ] eusocial
- [ ] evacuation
- [ ] evade
- [ ] evaluate
- [ ] evaporate
- [ ] eventual
- [ ] evident
- [ ] evil
- [ ] evolve
- [ ] exacerbate
- [ ] exaggerate
- [ ] excavate
- [ ] excavation
- [ ] exceedingly
- [ ] exceptional
- [ ] excerpt

# Chapter 055

- [ ] excessive
- [ ] exclude
- [ ] excluder
- [ ] exclusion
- [ ] exclusively
- [ ] excrete
- [ ] excursion
- [ ] execute
- [ ] executive
- [ ] exemplary
- [ ] exemplify
- [ ] exempt
- [ ] exert
- [ ] exhale
- [ ] exhaust
- [ ] exhaustive
- [ ] exile
- [ ] exodus
- [ ] exonerate
- [ ] exotic

# Chapter 056

- [ ] expatriate
- [ ] expedient
- [ ] expedition
- [ ] expenditure
- [ ] experience
- [ ] expertise
- [ ] expire
- [ ] explicit
- [ ] explode
- [ ] exploit
- [ ] exploration
- [ ] explore
- [ ] explosion
- [ ] export
- [ ] expound
- [ ] expulsion
- [ ] exquisite
- [ ] extend
- [ ] extensive
- [ ] exterminate

# Chapter 057

- [ ] external
- [ ] extinct
- [ ] extinction
- [ ] extinguish
- [ ] extract
- [ ] extraction
- [ ] extracurricular
- [ ] extraneous
- [ ] extraordinary
- [ ] extrapolation
- [ ] extraterrestrial
- [ ] extreme
- [ ] fabric
- [ ] facial
- [ ] facilitate
- [ ] facility
- [ ] faction
- [ ] factor
- [ ] faculty
- [ ] faith

# Chapter 058

- [ ] fallow
- [ ] falsify
- [ ] fatal
- [ ] fatality
- [ ] fault
- [ ] feasible
- [ ] fecundity
- [ ] federal
- [ ] feign
- [ ] feminist
- [ ] ferrous
- [ ] fertility
- [ ] fertilized
- [ ] fertilizer
- [ ] fervent
- [ ] fetal
- [ ] fetch
- [ ] feudal
- [ ] fiber
- [ ] fibrosis

# Chapter 059

- [ ] fickle
- [ ] fierce
- [ ] figurine
- [ ] filament
- [ ] file
- [ ] filibuster
- [ ] filter
- [ ] financier
- [ ] finite
- [ ] fiscal
- [ ] fivefold
- [ ] fixture
- [ ] fjord
- [ ] flat
- [ ] flatten
- [ ] flaunt
- [ ] flavor
- [ ] fledgling
- [ ] flexible
- [ ] flip

# Chapter 060

- [ ] flippant
- [ ] flock
- [ ] flourish
- [ ] fluctuate
- [ ] fluctuation
- [ ] fluid
- [ ] fluorescent
- [ ] focus
- [ ] fodder
- [ ] folklore
- [ ] folkway
- [ ] follicle
- [ ] forage
- [ ] forager
- [ ] foraging
- [ ] forecast
- [ ] foreclosure
- [ ] foresee
- [ ] foreseeable
- [ ] foreshadow

# Chapter 061

- [ ] foresight
- [ ] forestall
- [ ] forfeit
- [ ] forge
- [ ] format
- [ ] formation
- [ ] formidable
- [ ] formula
- [ ] forthcoming
- [ ] fortify
- [ ] fossil
- [ ] fossilize
- [ ] foster
- [ ] fraction
- [ ] fracture
- [ ] fragile
- [ ] fragment
- [ ] frame
- [ ] framework
- [ ] franchise

# Chapter 062

- [ ] fraternal
- [ ] frequency
- [ ] friction
- [ ] frontier
- [ ] frugal
- [ ] frustrate
- [ ] fuel
- [ ] function
- [ ] fundraise
- [ ] fungi
- [ ] fungus
- [ ] funnel
- [ ] furnace
- [ ] fuse
- [ ] fusion
- [ ] futile
- [ ] gadgeteering
- [ ] galactic
- [ ] galaxy
- [ ] garment

# Chapter 063

- [ ] gauge
- [ ] gear
- [ ] generalization
- [ ] generate
- [ ] generational
- [ ] generic
- [ ] genetic
- [ ] genial
- [ ] gentry
- [ ] genuine
- [ ] geographic
- [ ] geological
- [ ] geologist
- [ ] geometric
- [ ] geophysical
- [ ] gimmick
- [ ] glacier
- [ ] gland
- [ ] glean
- [ ] gloomy

# Chapter 064

- [ ] glucose
- [ ] gorilla
- [ ] gourmet
- [ ] gradient
- [ ] granite
- [ ] grant
- [ ] graph
- [ ] graphite
- [ ] gravel
- [ ] gravitational
- [ ] gregarious
- [ ] grill
- [ ] grind
- [ ] groove
- [ ] grove
- [ ] guarantee
- [ ] gut
- [ ] gymnast
- [ ] gyroscope
- [ ] habitat

# Chapter 065

- [ ] hail
- [ ] halo
- [ ] halt
- [ ] hamper
- [ ] handicap
- [ ] handlebar
- [ ] harbor
- [ ] hardcover
- [ ] harden
- [ ] hardy
- [ ] harmonize
- [ ] harness
- [ ] harsh
- [ ] hatch
- [ ] haunt
- [ ] haven
- [ ] havoc
- [ ] hazard
- [ ] hazardous
- [ ] haze

# Chapter 066

- [ ] headquarters
- [ ] hedge
- [ ] hedgehog
- [ ] heed
- [ ] heist
- [ ] helicopter
- [ ] helium
- [ ] hemoglobin
- [ ] herbicide
- [ ] herbivore
- [ ] herd
- [ ] hereditary
- [ ] heretical
- [ ] heritage
- [ ] hexagonal
- [ ] hide
- [ ] hierarchical
- [ ] hierarchy
- [ ] hieroglyphic
- [ ] highlight

# Chapter 067

- [ ] hike
- [ ] hinder
- [ ] hint
- [ ] hinterland
- [ ] Hispanic
- [ ] historical
- [ ] hitherto
- [ ] hoary
- [ ] homeostasis
- [ ] homestead
- [ ] homing
- [ ] hominid
- [ ] homogeneity
- [ ] hone
- [ ] hoof
- [ ] hormone
- [ ] horseshoe
- [ ] horticultural
- [ ] hospitable
- [ ] hostility

# Chapter 068

- [ ] household
- [ ] hover
- [ ] howl
- [ ] hue
- [ ] hum
- [ ] humane
- [ ] humble
- [ ] humid
- [ ] humidity
- [ ] hurricane
- [ ] husk
- [ ] hybrid
- [ ] hydrogen
- [ ] hydroponic
- [ ] hypertension
- [ ] hypnotize
- [ ] hypothesis
- [ ] hypothesize
- [ ] iconography
- [ ] identical

# Chapter 069

- [ ] identifiable
- [ ] identification
- [ ] identify
- [ ] identity
- [ ] ideographic
- [ ] ideology
- [ ] idiosyncrasy
- [ ] idle
- [ ] ignite
- [ ] illegal
- [ ] illicit
- [ ] illiterate
- [ ] illuminate
- [ ] illustrate
- [ ] illustration
- [ ] imbalance
- [ ] imitate
- [ ] imitative
- [ ] immigration
- [ ] immobilize

# Chapter 070

- [ ] immune
- [ ] impact
- [ ] impartial
- [ ] impeachment
- [ ] impede
- [ ] imperative
- [ ] implausible
- [ ] implementation
- [ ] implication
- [ ] implicit
- [ ] imply
- [ ] impose
- [ ] imposition
- [ ] impoverished
- [ ] impulse
- [ ] inability
- [ ] inaccessible
- [ ] inaccurate
- [ ] inadequate
- [ ] inalienable

# Chapter 071

- [ ] incandescent
- [ ] incentive
- [ ] incinerate
- [ ] incineration
- [ ] incipient
- [ ] incline
- [ ] inclusion
- [ ] incompatible
- [ ] inconclusive
- [ ] inconsistent
- [ ] incorporate
- [ ] increment
- [ ] incubate
- [ ] incur
- [ ] incursion
- [ ] indenture
- [ ] independence
- [ ] independent
- [ ] index
- [ ] indicate

# Chapter 072

- [ ] indication
- [ ] indicative
- [ ] indicator
- [ ] indifference
- [ ] indigenous
- [ ] indigent
- [ ] indirect
- [ ] indiscriminate
- [ ] indispensable
- [ ] indistinct
- [ ] indistinguishable
- [ ] individual
- [ ] individualism
- [ ] induce
- [ ] indulge
- [ ] industrialization
- [ ] industrialize
- [ ] ineffective
- [ ] inefficient
- [ ] inequality

# Chapter 073

- [ ] inertia
- [ ] inescapable
- [ ] inevitable
- [ ] inextricably
- [ ] infancy
- [ ] infect
- [ ] infectious
- [ ] infer
- [ ] inferior
- [ ] infest
- [ ] infirmary
- [ ] inflammation
- [ ] inflammatory
- [ ] inflate
- [ ] inflation
- [ ] inflationary
- [ ] inflict
- [ ] influenza
- [ ] influx
- [ ] infrared

# Chapter 074

- [ ] infrastructure
- [ ] infringement
- [ ] infringer
- [ ] infuse
- [ ] ingenious
- [ ] ingenuity
- [ ] ingest
- [ ] ingrained
- [ ] ingredient
- [ ] inhabit
- [ ] inhalation
- [ ] inherent
- [ ] inherit
- [ ] inhibit
- [ ] initial
- [ ] initiate
- [ ] injection
- [ ] inland
- [ ] inlet
- [ ] inmate

# Chapter 075

- [ ] innate
- [ ] innovation
- [ ] innovative
- [ ] inoculate
- [ ] inquisitive
- [ ] inscribe
- [ ] inscription
- [ ] insecticide
- [ ] insert
- [ ] insight
- [ ] insignificant
- [ ] insomnia
- [ ] inspection
- [ ] inspector
- [ ] inspiration
- [ ] install
- [ ] installation
- [ ] instantaneous
- [ ] instill
- [ ] institute

# Chapter 076

- [ ] institution
- [ ] instruct
- [ ] instrument
- [ ] insulate
- [ ] insulin
- [ ] insuperable
- [ ] intact
- [ ] intake
- [ ] intangible
- [ ] integer
- [ ] integrate
- [ ] integrated
- [ ] integration
- [ ] intelligence
- [ ] intense
- [ ] intensify
- [ ] intensity
- [ ] intensive
- [ ] intent
- [ ] interact

# Chapter 077

- [ ] intercept
- [ ] interdependence
- [ ] interfere
- [ ] interior
- [ ] interloper
- [ ] interlude
- [ ] intermediary
- [ ] intermediate
- [ ] interpolation
- [ ] interpretation
- [ ] intersect
- [ ] intersection
- [ ] interservice
- [ ] intersperse
- [ ] interstate
- [ ] interstellar
- [ ] interval
- [ ] intervention
- [ ] intestinal
- [ ] intricate

# Chapter 078

- [ ] intrigue
- [ ] intrinsic
- [ ] introductory
- [ ] intuition
- [ ] intuitive
- [ ] invade
- [ ] invariant
- [ ] inventory
- [ ] invertebrate
- [ ] inverted
- [ ] investigate
- [ ] invoke
- [ ] involvement
- [ ] irate
- [ ] iridescence
- [ ] ironic
- [ ] irradiate
- [ ] irradiation
- [ ] irreconcilable
- [ ] irregularity

# Chapter 079

- [ ] irreversible
- [ ] irrigation
- [ ] irritant
- [ ] irritating
- [ ] islet
- [ ] isolate
- [ ] isotope
- [ ] jeopardize
- [ ] judicial
- [ ] jumbo
- [ ] jurisdiction
- [ ] juror
- [ ] justify
- [ ] juvenile
- [ ] juxtapose
- [ ] kernel
- [ ] kidney
- [ ] kin
- [ ] kinetic
- [ ] lactation

# Chapter 080

- [ ] lactic
- [ ] lag
- [ ] lamellar
- [ ] landfill
- [ ] landlocked
- [ ] landownership
- [ ] landscape
- [ ] lane
- [ ] lapse
- [ ] larva
- [ ] latch
- [ ] lateral
- [ ] latitude
- [ ] launch
- [ ] laurel
- [ ] laxity
- [ ] leach
- [ ] lease
- [ ] leaven
- [ ] leery

# Chapter 081

- [ ] legislation
- [ ] legislature
- [ ] legitimate
- [ ] legitimation
- [ ] leopard
- [ ] lessen
- [ ] lethal
- [ ] letup
- [ ] levy
- [ ] liable
- [ ] liberalize
- [ ] limestone
- [ ] linear
- [ ] linkage
- [ ] lipoprotein
- [ ] liquidation
- [ ] listlessness
- [ ] literacy
- [ ] literally
- [ ] litigant

# Chapter 082

- [ ] litter
- [ ] liver
- [ ] lizard
- [ ] loaf
- [ ] lobby
- [ ] lobe
- [ ] lobster
- [ ] localize
- [ ] loch
- [ ] locomotion
- [ ] locomotive
- [ ] lodge
- [ ] logotype
- [ ] longevity
- [ ] longitudinal
- [ ] loom
- [ ] loosen
- [ ] lore
- [ ] lounge
- [ ] lucrative

# Chapter 083

- [ ] lumber
- [ ] luminosity
- [ ] luminous
- [ ] lump
- [ ] lunar
- [ ] lure
- [ ] lymph
- [ ] lysis
- [ ] magmatic
- [ ] magnesium
- [ ] magnet
- [ ] magnitude
- [ ] mainstream
- [ ] maintenance
- [ ] malaria
- [ ] malarial
- [ ] maldistribution
- [ ] malfunction
- [ ] malice
- [ ] malleable

# Chapter 084

- [ ] malpractice
- [ ] mammalian
- [ ] managerial
- [ ] mandate
- [ ] mandatory
- [ ] maneuver
- [ ] manic
- [ ] manipulate
- [ ] mannerism
- [ ] mantle
- [ ] manual
- [ ] manufacture
- [ ] manufacturing
- [ ] manumission
- [ ] manuscript
- [ ] margin
- [ ] marital
- [ ] maritime
- [ ] marketplace
- [ ] marrow

# Chapter 085

- [ ] marshy
- [ ] martial
- [ ] masculine
- [ ] mass
- [ ] transit
- [ ] materialistic
- [ ] maternal
- [ ] maternity
- [ ] matriarch
- [ ] matrix
- [ ] maturation
- [ ] mature
- [ ] maturity
- [ ] maxim
- [ ] maximize
- [ ] measles
- [ ] mechanical
- [ ] mechanism
- [ ] mechanization
- [ ] median

# Chapter 086

- [ ] mediate
- [ ] medication
- [ ] medieval
- [ ] medium
- [ ] megacity
- [ ] megalithic
- [ ] melancholy
- [ ] meld
- [ ] membrane
- [ ] memoir
- [ ] memorandum
- [ ] merchandise
- [ ] merchant
- [ ] merge
- [ ] merger
- [ ] metabolic
- [ ] metabolism
- [ ] metabolize
- [ ] metallic
- [ ] metamorphic

# Chapter 087

- [ ] metaphor
- [ ] meteor
- [ ] meteorite
- [ ] meteorological
- [ ] methane
- [ ] metric
- [ ] microbe
- [ ] microcomputer
- [ ] microorganism
- [ ] microscopic
- [ ] migraine
- [ ] migrate
- [ ] mileage
- [ ] milieu
- [ ] militancy
- [ ] millennium
- [ ] millipede
- [ ] mimic
- [ ] mineralize
- [ ] miniature

# Chapter 088

- [ ] minimum
- [ ] minivan
- [ ] minority
- [ ] mint
- [ ] minus
- [ ] minute
- [ ] miraculous
- [ ] mishap
- [ ] misinterpret
- [ ] misrepresent
- [ ] missile
- [ ] mitigate
- [ ] modem
- [ ] modest
- [ ] modification
- [ ] modify
- [ ] moisture
- [ ] mold
- [ ] mole
- [ ] molecule

# Chapter 089

- [ ] molten
- [ ] monarch
- [ ] monitor
- [ ] mononucleosis
- [ ] monopolistic
- [ ] monopoly
- [ ] monsoon
- [ ] monumental
- [ ] mooring
- [ ] moral
- [ ] morale
- [ ] morphine
- [ ] mortality
- [ ] mortar
- [ ] mortgage
- [ ] mosaics
- [ ] mosque
- [ ] mosquito
- [ ] moth
- [ ] motion

# Chapter 090

- [ ] motivate
- [ ] mound
- [ ] mount
- [ ] mow
- [ ] multicellular
- [ ] multiple
- [ ] multinational
- [ ] multiply
- [ ] multitude
- [ ] municipal
- [ ] municipality
- [ ] mural
- [ ] mutation
- [ ] mutual
- [ ] mystic
- [ ] mythic
- [ ] mythology
- [ ] narrative
- [ ] naturalize
- [ ] navigation

# Chapter 091

- [ ] navy
- [ ] nebula
- [ ] necessitate
- [ ] needy
- [ ] negative
- [ ] negligence
- [ ] negligible
- [ ] negotiate
- [ ] negotiation
- [ ] nematode
- [ ] neural
- [ ] neuron
- [ ] neutral
- [ ] neutron
- [ ] newlywed
- [ ] nexus
- [ ] niche
- [ ] nihilism
- [ ] nitrogen
- [ ] nocturnal

# Chapter 092

- [ ] nomad
- [ ] nomadic
- [ ] nominate
- [ ] nonbiodegradable
- [ ] noncommercial
- [ ] noncommittal
- [ ] nonessential
- [ ] nonstarter
- [ ] note
- [ ] notify
- [ ] notorious
- [ ] novel
- [ ] novice
- [ ] noxious
- [ ] nuclear
- [ ] nucleon
- [ ] nucleotide
- [ ] nucleus
- [ ] nuisance
- [ ] numerator

# Chapter 093

- [ ] nutrient
- [ ] nutrition
- [ ] nutritious
- [ ] oats
- [ ] obese
- [ ] objection
- [ ] objective
- [ ] oblique
- [ ] obscure
- [ ] observation
- [ ] observatory
- [ ] obsess
- [ ] obsolescence
- [ ] obstacle
- [ ] occupation
- [ ] occupational
- [ ] occurrence
- [ ] odd
- [ ] odometer
- [ ] odor

# Chapter 094

- [ ] offender
- [ ] season
- [ ] offset
- [ ] offshoot
- [ ] offspring
- [ ] olfactory
- [ ] omen
- [ ] omission
- [ ] ongoing
- [ ] onset
- [ ] opaque
- [ ] operagoer
- [ ] optical
- [ ] optimal
- [ ] optimism
- [ ] optimum
- [ ] optometrist
- [ ] orator
- [ ] ordinance
- [ ] ore

# Chapter 095

- [ ] organization
- [ ] orientation
- [ ] oriented
- [ ] originality
- [ ] originate
- [ ] originator
- [ ] ornamentation
- [ ] orthodox
- [ ] osmotic
- [ ] ostentation
- [ ] oust
- [ ] outcome
- [ ] outfit
- [ ] outlaw
- [ ] outlay
- [ ] outlet
- [ ] outline
- [ ] outlying
- [ ] outmoded
- [ ] outnumber

# Chapter 096

- [ ] outpatient
- [ ] outpost
- [ ] outrage
- [ ] outright
- [ ] outsource
- [ ] outstrip
- [ ] oval
- [ ] overall
- [ ] overcapitalize
- [ ] overcharge
- [ ] overextend
- [ ] overfish
- [ ] overflow
- [ ] overlap
- [ ] overlay
- [ ] overlie
- [ ] overlook
- [ ] overlord
- [ ] overpayment
- [ ] overrun

# Chapter 097

- [ ] overstock
- [ ] oversupply
- [ ] overt
- [ ] overview
- [ ] overwhelm
- [ ] overwhelming
- [ ] ovulate
- [ ] oxidize
- [ ] ozone
- [ ] pacemaker
- [ ] pact
- [ ] pad
- [ ] pagination
- [ ] painstaking
- [ ] palatable
- [ ] paleoclimatologist
- [ ] paleolithic
- [ ] paleontologist
- [ ] pall
- [ ] pallid

# Chapter 098

- [ ] palm
- [ ] paltry
- [ ] pamphlet
- [ ] panacea
- [ ] panel
- [ ] pang
- [ ] pant
- [ ] pantheon
- [ ] par
- [ ] paradigm
- [ ] paradox
- [ ] parallel
- [ ] paralysis
- [ ] paramount
- [ ] parasite
- [ ] parasitic
- [ ] parish
- [ ] parity
- [ ] parliament
- [ ] parlor

# Chapter 099

- [ ] parole
- [ ] partial
- [ ] participate
- [ ] participation
- [ ] participatory
- [ ] particle
- [ ] particular
- [ ] particulate
- [ ] partisan
- [ ] partridge
- [ ] passbook
- [ ] passive
- [ ] pastoral
- [ ] pasture
- [ ] patch
- [ ] patent
- [ ] paternalism
- [ ] paternity
- [ ] pathogenic
- [ ] patriarchal

# Chapter 100

- [ ] patriotic
- [ ] patriotism
- [ ] patrol
- [ ] patron
- [ ] payroll
- [ ] peak
- [ ] peat
- [ ] peculiar
- [ ] pecuniary
- [ ] pedal
- [ ] peddle
- [ ] pedestrian
- [ ] peel
- [ ] peer
- [ ] pelvis
- [ ] penalty
- [ ] penetrate
- [ ] peninsula
- [ ] pension
- [ ] perceive

# Chapter 101

- [ ] perceptibly
- [ ] perception
- [ ] perennial
- [ ] performance
- [ ] perfunctory
- [ ] perimeter
- [ ] periodic
- [ ] periodical
- [ ] periphery
- [ ] perishable
- [ ] permanent
- [ ] permeate
- [ ] permissive
- [ ] pernicious
- [ ] perpendicular
- [ ] perpetrator
- [ ] perpetuate
- [ ] perplex
- [ ] persecute
- [ ] persist

# Chapter 102

- [ ] personality
- [ ] personhood
- [ ] personnel
- [ ] perspective
- [ ] persuade
- [ ] pertinent
- [ ] perturb
- [ ] pervasive
- [ ] perversion
- [ ] pesticide
- [ ] petition
- [ ] petroleum
- [ ] pharmaceutical
- [ ] pharmacy
- [ ] phase
- [ ] phenomenon
- [ ] philanthropic
- [ ] philosophy
- [ ] photon
- [ ] photosynthesis

# Chapter 103

- [ ] physiological
- [ ] physiology
- [ ] pigment
- [ ] pinpoint
- [ ] pirate
- [ ] pivotal
- [ ] placate
- [ ] plague
- [ ] plaintiff
- [ ] planetary
- [ ] plankton
- [ ] plantation
- [ ] plateau
- [ ] platform
- [ ] plausible
- [ ] plead
- [ ] pledge
- [ ] plot
- [ ] plough
- [ ] plume

# Chapter 104

- [ ] plummet
- [ ] plunge
- [ ] plywood
- [ ] pneumonia
- [ ] pneumonic
- [ ] poach
- [ ] poacher
- [ ] polar
- [ ] poll
- [ ] pollen
- [ ] pollinate
- [ ] pollutant
- [ ] polygraph
- [ ] population
- [ ] porcelain
- [ ] porpoise
- [ ] portfolio
- [ ] portrait
- [ ] portray
- [ ] posit

# Chapter 105

- [ ] positive
- [ ] possess
- [ ] possibility
- [ ] postage
- [ ] postal
- [ ] posterity
- [ ] potent
- [ ] potential
- [ ] potter
- [ ] poultry
- [ ] practical
- [ ] practitioner
- [ ] pragmatic
- [ ] prairie
- [ ] prank
- [ ] precaution
- [ ] precede
- [ ] precedence
- [ ] preceding
- [ ] precipitation

# Chapter 106

- [ ] precise
- [ ] precursor
- [ ] predate
- [ ] predation
- [ ] predator
- [ ] predatory
- [ ] predecessor
- [ ] predicament
- [ ] predicate
- [ ] predict
- [ ] prediction
- [ ] predisposition
- [ ] predominant
- [ ] predominantly
- [ ] predominate
- [ ] preeminent
- [ ] preference
- [ ] preferential
- [ ] prefigure
- [ ] preflight

# Chapter 107

- [ ] pregnancy
- [ ] preindustrial
- [ ] prejudice
- [ ] preliminary
- [ ] premature
- [ ] premise
- [ ] premium
- [ ] preoccupation
- [ ] prepay
- [ ] preponderance
- [ ] prerequisite
- [ ] prescribe
- [ ] prescription
- [ ] presentation
- [ ] preservation
- [ ] preservative
- [ ] preserve
- [ ] preside
- [ ] pressboard
- [ ] prestige

# Chapter 108

- [ ] prestigious
- [ ] presume
- [ ] presuppose
- [ ] pretax
- [ ] prevail
- [ ] prevalence
- [ ] prevalent
- [ ] preventive
- [ ] previous
- [ ] prey
- [ ] priest
- [ ] primary
- [ ] primate
- [ ] primer
- [ ] primitive
- [ ] primordial
- [ ] princely
- [ ] principal
- [ ] principle
- [ ] priority

# Chapter 109

- [ ] pristine
- [ ] privilege
- [ ] privy
- [ ] probability
- [ ] probe
- [ ] procedure
- [ ] proceed
- [ ] proceeds
- [ ] process
- [ ] proclaim
- [ ] procreative
- [ ] procure
- [ ] prodigy
- [ ] professional
- [ ] proficient
- [ ] profile
- [ ] profitability
- [ ] profitable
- [ ] profound
- [ ] prognosis

# Chapter 110

- [ ] progression
- [ ] progressive
- [ ] prohibit
- [ ] projection
- [ ] prokaryote
- [ ] proliferate
- [ ] proliferation
- [ ] prolonged
- [ ] prominence
- [ ] prominent
- [ ] promising
- [ ] promote
- [ ] promotional
- [ ] prompt
- [ ] pronounced
- [ ] propagandistic
- [ ] propagate
- [ ] propeller
- [ ] property
- [ ] prophet

# Chapter 111

- [ ] propitious
- [ ] proponent
- [ ] proportion
- [ ] proportional
- [ ] proprietary
- [ ] prorate
- [ ] prose
- [ ] prosecute
- [ ] prosecutor
- [ ] prospect
- [ ] prospective
- [ ] prosper
- [ ] prosperity
- [ ] protein
- [ ] protestant
- [ ] protocol
- [ ] proton
- [ ] prototype
- [ ] provenance
- [ ] provided

# Chapter 112

- [ ] providing
- [ ] provision
- [ ] provisional
- [ ] proviso
- [ ] provoke
- [ ] proximity
- [ ] prudent
- [ ] prudery
- [ ] pseudonym
- [ ] psyche
- [ ] psychological
- [ ] psychopath
- [ ] pugnacious
- [ ] pulp
- [ ] punishable
- [ ] pup
- [ ] purchase
- [ ] purchaser
- [ ] purification
- [ ] Puritan

# Chapter 113

- [ ] purport
- [ ] pursue
- [ ] purview
- [ ] putty
- [ ] pyramid
- [ ] quadrant
- [ ] quadruple
- [ ] quail
- [ ] qualify
- [ ] qualitative
- [ ] quantitative
- [ ] quantum
- [ ] quarantine
- [ ] quarry
- [ ] quasar
- [ ] quest
- [ ] questionnaire
- [ ] quiescent
- [ ] quiz
- [ ] quota

# Chapter 114

- [ ] quote
- [ ] quotient
- [ ] raccoon
- [ ] racism
- [ ] radiant
- [ ] radiate
- [ ] radical
- [ ] radioactive
- [ ] radiocarbon
- [ ] radius
- [ ] raffle
- [ ] ragtime
- [ ] raid
- [ ] railroad
- [ ] ranch
- [ ] rangeland
- [ ] ransom
- [ ] ratification
- [ ] rating
- [ ] ratio

# Chapter 115

- [ ] ration
- [ ] rational
- [ ] rationale
- [ ] reactor
- [ ] readily
- [ ] realm
- [ ] rear
- [ ] reasoning
- [ ] rebut
- [ ] recall
- [ ] receipt
- [ ] reception
- [ ] receptive
- [ ] receptor
- [ ] recession
- [ ] recipe
- [ ] recipient
- [ ] reciprocal
- [ ] reclaim
- [ ] recluse

# Chapter 116

- [ ] recommend
- [ ] recommendation
- [ ] reconcile
- [ ] reconvene
- [ ] recoup
- [ ] recourse
- [ ] recover
- [ ] recreation
- [ ] recreational
- [ ] recruit
- [ ] rectangle
- [ ] recur
- [ ] redirect
- [ ] redress
- [ ] reef
- [ ] referendum
- [ ] referral
- [ ] refine
- [ ] refiner
- [ ] refinery

# Chapter 117

- [ ] reflective
- [ ] reflex
- [ ] refraction
- [ ] refrain
- [ ] refuel
- [ ] refugee
- [ ] refund
- [ ] refutation
- [ ] refute
- [ ] regenerate
- [ ] regime
- [ ] regiment
- [ ] regionalization
- [ ] register
- [ ] regressive
- [ ] reign
- [ ] reimburse
- [ ] reinforce
- [ ] reinvest
- [ ] reject

# Chapter 118

- [ ] rejection
- [ ] rekindle
- [ ] relative
- [ ] relativity
- [ ] relay
- [ ] release
- [ ] relentless
- [ ] reliable
- [ ] reliance
- [ ] relic
- [ ] relieve
- [ ] religious
- [ ] relinquish
- [ ] reluctant
- [ ] remainder
- [ ] remedy
- [ ] reminiscent
- [ ] remnant
- [ ] renaissance
- [ ] renal

# Chapter 119

- [ ] render
- [ ] renegade
- [ ] renounce
- [ ] renovation
- [ ] renown
- [ ] rental
- [ ] reorganization
- [ ] repeal
- [ ] repertory
- [ ] replacement
- [ ] replete
- [ ] replicate
- [ ] repousse
- [ ] representation
- [ ] representative
- [ ] reproduce
- [ ] reproduction
- [ ] reptile
- [ ] republican
- [ ] repudiate

# Chapter 120

- [ ] rescind
- [ ] resemble
- [ ] resent
- [ ] reservation
- [ ] reserve
- [ ] reservoir
- [ ] reside
- [ ] residency
- [ ] residential
- [ ] residual
- [ ] residue
- [ ] resign
- [ ] resist
- [ ] resistance
- [ ] resolve
- [ ] resonance
- [ ] resort
- [ ] respective
- [ ] respiratory
- [ ] respire

# Chapter 121

- [ ] resplendent
- [ ] responsible
- [ ] responsive
- [ ] restitution
- [ ] restore
- [ ] restrain
- [ ] restrict
- [ ] restructure
- [ ] resume
- [ ] resurgence
- [ ] resuscitation
- [ ] retail
- [ ] retain
- [ ] retaliation
- [ ] retard
- [ ] retarded
- [ ] retention
- [ ] reticent
- [ ] retrieve
- [ ] revamp

# Chapter 122

- [ ] reveal
- [ ] revenue
- [ ] reverence
- [ ] reversal
- [ ] reverse
- [ ] reversion
- [ ] revert
- [ ] revise
- [ ] revitalize
- [ ] revive
- [ ] revolution
- [ ] revolutionary
- [ ] rewind
- [ ] rhetoric
- [ ] rheumatic
- [ ] rhinoceros
- [ ] rib
- [ ] ridge
- [ ] ridicule
- [ ] rigid

# Chapter 123

- [ ] rigor
- [ ] rigorous
- [ ] rim
- [ ] rinse
- [ ] ripple
- [ ] ritual
- [ ] rival
- [ ] rivalry
- [ ] robust
- [ ] rodent
- [ ] roost
- [ ] rotate
- [ ] rotational
- [ ] roughly
- [ ] round
- [ ] royalty
- [ ] rudder
- [ ] rudimentary
- [ ] rug
- [ ] rugby

# Chapter 124

- [ ] rugged
- [ ] ruin
- [ ] rumor
- [ ] runner
- [ ] rupture
- [ ] sacralization
- [ ] sacred
- [ ] sacrifice
- [ ] salable
- [ ] salient
- [ ] saline
- [ ] salinity
- [ ] salvage
- [ ] sample
- [ ] samurai
- [ ] sanction
- [ ] sanctuary
- [ ] sandbar
- [ ] sane
- [ ] sanitary

# Chapter 125

- [ ] saturated
- [ ] scale
- [ ] scandalize
- [ ] scapegoat
- [ ] scarce
- [ ] scarcity
- [ ] scatter
- [ ] scavenge
- [ ] scent
- [ ] scheme
- [ ] scorn
- [ ] scorpion
- [ ] scour
- [ ] scout
- [ ] scramble
- [ ] scrap
- [ ] scrape
- [ ] scrawny
- [ ] screen
- [ ] scribe

# Chapter 126

- [ ] scrub
- [ ] scrubber
- [ ] scrupulous
- [ ] scrutinize
- [ ] scrutiny
- [ ] scuba
- [ ] sculpture
- [ ] scurrilous
- [ ] seasonal
- [ ] secluded
- [ ] secrete
- [ ] secretion
- [ ] secular
- [ ] secure
- [ ] sedentary
- [ ] sediment
- [ ] sedimentary
- [ ] seedling
- [ ] seesaw
- [ ] segment

# Chapter 127

- [ ] segregate
- [ ] segregation
- [ ] seismic
- [ ] select
- [ ] semicircle
- [ ] semiconductor
- [ ] seminal
- [ ] seminar
- [ ] senate
- [ ] sensation
- [ ] sensational
- [ ] sensible
- [ ] sensitive
- [ ] sensitize
- [ ] sentence
- [ ] sentient
- [ ] sentiment
- [ ] sentinel
- [ ] sequence
- [ ] sequester

# Chapter 128

- [ ] session
- [ ] severe
- [ ] sewage
- [ ] shareholder
- [ ] shatter
- [ ] sheath
- [ ] shed
- [ ] sheer
- [ ] shellfish
- [ ] shelter
- [ ] shield
- [ ] shimmer
- [ ] shortfall
- [ ] shrill
- [ ] shrink
- [ ] shroud
- [ ] shrub
- [ ] shuttle
- [ ] sibling
- [ ] sidestep

# Chapter 129

- [ ] siege
- [ ] signature
- [ ] significance
- [ ] significant
- [ ] signify
- [ ] silkworm
- [ ] similarity
- [ ] simulate
- [ ] simultaneous
- [ ] sinew
- [ ] singularly
- [ ] sinus
- [ ] sip
- [ ] skeleton
- [ ] skeptic
- [ ] skeptical
- [ ] sketch
- [ ] skull
- [ ] slam
- [ ] slice

# Chapter 130

- [ ] slick
- [ ] slight
- [ ] slip
- [ ] slope
- [ ] slot
- [ ] sloth
- [ ] sluggish
- [ ] slump
- [ ] smear
- [ ] smelt
- [ ] smog
- [ ] smokestack
- [ ] smuggler
- [ ] snap
- [ ] sniper
- [ ] snout
- [ ] snuff
- [ ] soar
- [ ] sodium
- [ ] solar

# Chapter 131

- [ ] solidarity
- [ ] solitary
- [ ] solvency
- [ ] songbird
- [ ] sophisticated
- [ ] sovereign
- [ ] span
- [ ] sparse
- [ ] spate
- [ ] spatial
- [ ] spawn
- [ ] specialist
- [ ] specialization
- [ ] specialize
- [ ] species
- [ ] specific
- [ ] specify
- [ ] specimen
- [ ] specious
- [ ] spectacular

# Chapter 132

- [ ] spectator
- [ ] specter
- [ ] spectrum
- [ ] speculate
- [ ] speculation
- [ ] speculator
- [ ] sphere
- [ ] spherical
- [ ] spiced
- [ ] spin
- [ ] spinach
- [ ] spine
- [ ] spiral
- [ ] spiteful
- [ ] splinter
- [ ] split
- [ ] splotchy
- [ ] spoilage
- [ ] sponsor
- [ ] sporadically

# Chapter 133

- [ ] spot
- [ ] spouse
- [ ] spray
- [ ] spring
- [ ] sprinkler
- [ ] spruce
- [ ] spur
- [ ] spurious
- [ ] squash
- [ ] squeak
- [ ] squirrel
- [ ] stabilize
- [ ] staggering
- [ ] stake
- [ ] stamina
- [ ] stance
- [ ] standardize
- [ ] staple
- [ ] startlingly
- [ ] static

# Chapter 134

- [ ] stationary
- [ ] stationery
- [ ] statistic
- [ ] statistical
- [ ] stature
- [ ] status
- [ ] statute
- [ ] staunch
- [ ] stave
- [ ] steep
- [ ] steer
- [ ] stem
- [ ] steppe
- [ ] stereotype
- [ ] sterile
- [ ] stew
- [ ] stiffness
- [ ] stimulant
- [ ] stimulate
- [ ] stimuli

# Chapter 135

- [ ] sting
- [ ] stinger
- [ ] stipend
- [ ] stipulate
- [ ] stitch
- [ ] stock
- [ ] storefront
- [ ] strain
- [ ] strait
- [ ] strand
- [ ] strategic
- [ ] strategy
- [ ] stratosphere
- [ ] stray
- [ ] strenuous
- [ ] strife
- [ ] string
- [ ] stringent
- [ ] strip
- [ ] strive

# Chapter 136

- [ ] stroke
- [ ] stroll
- [ ] strut
- [ ] studious
- [ ] stumble
- [ ] stun
- [ ] stunning
- [ ] stunt
- [ ] sturdy
- [ ] subgroup
- [ ] subject
- [ ] sublanguage
- [ ] submarine
- [ ] submit
- [ ] subordinate
- [ ] subscribe
- [ ] subscription
- [ ] subsequent
- [ ] subsidiary
- [ ] subsidize

# Chapter 137

- [ ] subsidy
- [ ] subsistence
- [ ] substance
- [ ] substantial
- [ ] substantiate
- [ ] substitute
- [ ] substitution
- [ ] substrate
- [ ] subtle
- [ ] subtract
- [ ] subtraction
- [ ] succession
- [ ] sue
- [ ] sufficiency
- [ ] sufficient
- [ ] suffrage
- [ ] sugarcane
- [ ] sulfuric
- [ ] summit
- [ ] superb

# Chapter 138

- [ ] superficial
- [ ] superior
- [ ] superiority
- [ ] supernova
- [ ] supersede
- [ ] supersonic
- [ ] suppress
- [ ] supreme
- [ ] surcharge
- [ ] surge
- [ ] surgeon
- [ ] surpass
- [ ] surplus
- [ ] susceptible
- [ ] suspicion
- [ ] sustain
- [ ] sustenance
- [ ] swiftly
- [ ] symbiotic
- [ ] symmetry

# Chapter 139

- [ ] sympathetic
- [ ] symptom
- [ ] synchronize
- [ ] syndrome
- [ ] synthesis
- [ ] synthesize
- [ ] synthetic
- [ ] taboo
- [ ] tactic
- [ ] tactile
- [ ] takeover
- [ ] tangible
- [ ] tap
- [ ] tariff
- [ ] taxable
- [ ] taxpayer
- [ ] tectonics
- [ ] teem
- [ ] telecommunication
- [ ] telephoto

# Chapter 140

- [ ] temblor
- [ ] temperance
- [ ] temperate
- [ ] temporary
- [ ] tempt
- [ ] tenant
- [ ] tenet
- [ ] tentative
- [ ] tenure
- [ ] terminate
- [ ] terminology
- [ ] termite
- [ ] terrain
- [ ] terrestrial
- [ ] territory
- [ ] testify
- [ ] testimony
- [ ] theme
- [ ] theophylline
- [ ] theoretical

# Chapter 141

- [ ] therapeutic
- [ ] therapy
- [ ] thereafter
- [ ] thermal
- [ ] thermostat
- [ ] threaten
- [ ] threshold
- [ ] thrive
- [ ] throne
- [ ] tile
- [ ] timber
- [ ] tissue
- [ ] toll
- [ ] tortoise
- [ ] toxic
- [ ] toxin
- [ ] tract
- [ ] tragedy
- [ ] trait
- [ ] tranquilizer

# Chapter 142

- [ ] transaction
- [ ] transatlantic
- [ ] transform
- [ ] transition
- [ ] transmission
- [ ] transnational
- [ ] transplant
- [ ] transport
- [ ] transportation
- [ ] treasury
- [ ] treaty
- [ ] tremendous
- [ ] trench
- [ ] triangle
- [ ] tribal
- [ ] tribute
- [ ] trigger
- [ ] triple
- [ ] state
- [ ] triumph

# Chapter 143

- [ ] trivial
- [ ] tropical
- [ ] trout
- [ ] truce
- [ ] trunk
- [ ] tuition
- [ ] turbulence
- [ ] turbulent
- [ ] typhoid
- [ ] ultimate
- [ ] ultrasound
- [ ] unaccompanied
- [ ] unaffected
- [ ] unanticipated
- [ ] unavailable
- [ ] unbridled
- [ ] unconfined
- [ ] unconscious
- [ ] unconstitutional
- [ ] underbelly

# Chapter 144

- [ ] undercapitalize
- [ ] undergo
- [ ] underlie
- [ ] underline
- [ ] underlying
- [ ] undermine
- [ ] underscore
- [ ] undertake
- [ ] underwrite
- [ ] underwriter
- [ ] undesirable
- [ ] undeterred
- [ ] undue
- [ ] unearth
- [ ] unequalled
- [ ] unequivocally
- [ ] uneven
- [ ] unilateral
- [ ] uninitiated
- [ ] unionist

# Chapter 145

- [ ] unionization
- [ ] unique
- [ ] university
- [ ] unleavened
- [ ] unobtrusive
- [ ] unparalleled
- [ ] unprecedented
- [ ] unpredictable
- [ ] unprocessed
- [ ] unpromising
- [ ] unravel
- [ ] unrealistic
- [ ] unrefined
- [ ] unscrupulous
- [ ] unsubstantiated
- [ ] untainted
- [ ] untenable
- [ ] unwarranted
- [ ] unwieldy
- [ ] updraft

# Chapter 146

- [ ] upheaval
- [ ] upholstered
- [ ] upstate
- [ ] upstream
- [ ] upsurge
- [ ] urbanization
- [ ] urbanize
- [ ] urchin
- [ ] urine
- [ ] utensil
- [ ] utilize
- [ ] vacant
- [ ] vaccinate
- [ ] vaccination
- [ ] vaccine
- [ ] vacuum
- [ ] vague
- [ ] validity
- [ ] vanish
- [ ] variable

# Chapter 147

- [ ] variation
- [ ] varsity
- [ ] vegetarian
- [ ] vegetation
- [ ] vegetative
- [ ] vein
- [ ] velocity
- [ ] velvet
- [ ] venom
- [ ] venture
- [ ] verge
- [ ] verify
- [ ] veritable
- [ ] versatile
- [ ] versatility
- [ ] version
- [ ] vertebrate
- [ ] vertical
- [ ] vertice
- [ ] vessel

# Chapter 148

- [ ] vestige
- [ ] veteran
- [ ] viability
- [ ] viable
- [ ] vicinity
- [ ] vicious
- [ ] victimize
- [ ] vigorous
- [ ] vine
- [ ] violate
- [ ] virgin
- [ ] virtue
- [ ] virtuoso
- [ ] virtuous
- [ ] viscosity
- [ ] visual
- [ ] vocal
- [ ] volatile
- [ ] volunteer
- [ ] voracious

# Chapter 149

- [ ] vortices
- [ ] vulnerable
- [ ] wage
- [ ] wanton
- [ ] warbler
- [ ] warrior
- [ ] wary
- [ ] waterfront
- [ ] welfare
- [ ] being
- [ ] whim
- [ ] whiplash
- [ ] whirl
- [ ] whisker
- [ ] wholesale
- [ ] wield
- [ ] wig
- [ ] wilderness
- [ ] withdraw
- [ ] withdrawal

# Chapter 150

- [ ] withstand
- [ ] womb
- [ ] woven
- [ ] wrap
- [ ] wreak
- [ ] wreath
- [ ] wreck
- [ ] wrestle
- [ ] axis
- [ ] yeast
- [ ] yen
- [ ] yield
- [ ] adulatory
- [ ] annoyance
- [ ] appreciation
- [ ] apprehensive
- [ ] anger
- [ ] acceptance
- [ ] apprehension
- [ ] analytical

# Chapter 151

- [ ] annoyed
- [ ] cautious
- [ ] concerned
- [ ] defensive
- [ ] disappointed
- [ ] disapproval
- [ ] disapproving
- [ ] disinterested
- [ ] dismissal
- [ ] distrustful
- [ ] endorsement
- [ ] enthusiastic
- [ ] frustrated
- [ ] hesitance
- [ ] idealistic
- [ ] indifferent
- [ ] interest
- [ ] interested
- [ ] naive
- [ ] neutrality

# Chapter 152

- [ ] prejudiced
- [ ] realistic
- [ ] regard
- [ ] regret
- [ ] relief
- [ ] resigned
- [ ] respect
- [ ] respectful
- [ ] scornful
- [ ] shocked
- [ ] skepticism
- [ ] supportive
- [ ] sympathy
- [ ] uncertain
- [ ] understanding
- [ ] unpatriotic
- [ ] backward
- [ ] bargaining
- [ ] cost
- [ ] discount

# Chapter 153

- [ ] downsizing
- [ ] investment
- [ ] nominal
- [ ] real
- [ ] argon
- [ ] asphalt
- [ ] atom
- [ ] baryonic
- [ ] carton
- [ ] charge
- [ ] formaldehyde
- [ ] ilmenite
- [ ] ion
- [ ] Kelvin
- [ ] morphogenetic
- [ ] muon
- [ ] neutrino
- [ ] nucleons
- [ ] phosphodiesterase
- [ ] plutonium

# Chapter 154

- [ ] potassium
- [ ] protons
- [ ] radiometric
- [ ] ramjet
- [ ] scramjet
- [ ] obsidian
- [ ] photoperiod
- [ ] Pleistocene
- [ ] protogalaxy
- [ ] pulsar
- [ ] aerobic
- [ ] aflatoxin
- [ ] anaerobe
- [ ] cytoplasm
- [ ] eukaryote
- [ ] histidine
- [ ] intracellular
- [ ] macrophage
- [ ] organelle
- [ ] ribosome

# Chapter 155

- [ ] tryptophan
- [ ] tyrosine
- [ ] archaeopteryx
- [ ] boll
- [ ] bowerbird
- [ ] cheetah
- [ ] cornstalk
- [ ] coyote
- [ ] cranberry
- [ ] diatom
- [ ] gecko
- [ ] haddock
- [ ] lepidopter
- [ ] lepidoptera
- [ ] mastodon
- [ ] milkweed
- [ ] myrmecophagous
- [ ] opossum
- [ ] pterosaur
- [ ] reindeer

# Chapter 156

- [ ] sandpiper
- [ ] tyrannosaurus
- [ ] angioplasty
- [ ] bubonic
- [ ] carotenoid
- [ ] cartilage
- [ ] clavicle
- [ ] dengue
- [ ] hemolytic
- [ ] hypertherm
- [ ] hypothalamus
- [ ] ibuprofen
- [ ] indomethacin
- [ ] keratitis
- [ ] leukemia
- [ ] lymphocyte
- [ ] melatonin
- [ ] mesothelioma
- [ ] neurotransmitter
- [ ] novocaine

# Chapter 157

- [ ] osteoarthritis
- [ ] pelvic
- [ ] poliomyelitis
- [ ] prostaglandin
- [ ] rhinovirus
- [ ] saffron
- [ ] serotonin
- [ ] sinusitis
- [ ] coleslaw
- [ ] get
- [ ] billion
- [ ] even
- [ ] denominator
- [ ] percentage
- [ ] inverse
- [ ] infinitesimal
- [ ] infinity
- [ ] nonnegative
- [ ] nonzero
- [ ] tens

# Chapter 158

- [ ] tenths
- [ ] units
- [ ] percent
- [ ] base
- [ ] power
- [ ] cardinal
- [ ] logarithm
- [ ] product
- [ ] root
- [ ] ordinal
- [ ] set
- [ ] subset
- [ ] average
- [ ] equidistant
- [ ] maximum
- [ ] mode
- [ ] random
- [ ] range
- [ ] variance
- [ ] approximate

# Chapter 159

- [ ] approximation
- [ ] combination
- [ ] permutations
- [ ] add
- [ ] plus
- [ ] aliquant
- [ ] aliquot
- [ ] decrease
- [ ] difference
- [ ] divide
- [ ] factorial
- [ ] factorization
- [ ] increase
- [ ] minuend
- [ ] multiplicand
- [ ] multiplication
- [ ] multiplier
- [ ] times
- [ ] sum
- [ ] centigrade

# Chapter 160

- [ ] Fahrenheit
- [ ] foot
- [ ] inch
- [ ] meter
- [ ] micron
- [ ] milliliter
- [ ] nickel
- [ ] pint
- [ ] quart
- [ ] score
- [ ] yard
- [ ] binomial
- [ ] coefficient
- [ ] expression
- [ ] monomial
- [ ] polynomial
- [ ] quadratic
- [ ] solution
- [ ] term
- [ ] trinomial

# Chapter 161

- [ ] bisector
- [ ] endpoint
- [ ] midpoint
- [ ] transversal
- [ ] angle
- [ ] decagon
- [ ] equilateral
- [ ] heptagon
- [ ] hexagon
- [ ] multilateral
- [ ] nonagon
- [ ] octagon
- [ ] parallelogram
- [ ] pentagon
- [ ] polygon
- [ ] quadrilateral
- [ ] rhombus
- [ ] side
- [ ] square
- [ ] trapezoid

# Chapter 162

- [ ] arm
- [ ] congruent
- [ ] hypotenuse
- [ ] leg
- [ ] opposite
- [ ] Pythagorean
- [ ] triangular
- [ ] trigonometry
- [ ] vertex
- [ ] arc
- [ ] circle
- [ ] curvature
- [ ] oblateness
- [ ] radian
- [ ] semicircular
- [ ] tangency
- [ ] tangent
- [ ] cone
- [ ] depth
- [ ] length

# Chapter 163

- [ ] plane
- [ ] volume
- [ ] width
- [ ] abscissa
- [ ] counterclockwise
- [ ] hyperbola
- [ ] ordinate
- [ ] origin
- [ ] parabola
- [ ] symmetric
- [ ] define
- [ ] markup
- [ ] markdown
- [ ] tie


# Chapter 001

- [ ] trade
- [ ] deal
- [ ] hike
- [ ] action
- [ ] resultant
- [ ] consequent
- [ ] composer
- [ ] slave
- [ ] grunt
- [ ] abide
- [ ] value
- [ ] dignity
- [ ] outermost
- [ ] optimum
- [ ] initially
- [ ] makeup
- [ ] integral
- [ ] composition
- [ ] block
- [ ] damn

# Chapter 002

- [ ] ample
- [ ] suffice
- [ ] lease
- [ ] charter
- [ ] headquarters
- [ ] executive
- [ ] main
- [ ] overall
- [ ] conceit
- [ ] ultraviolet
- [ ] descendant
- [ ] endow
- [ ] datum
- [ ] qualification
- [ ] bourgeois
- [ ] woodpecker
- [ ] bump
- [ ] crash
- [ ] way
- [ ] superb

# Chapter 003

- [ ] ornament
- [ ] decorative
- [ ] ornamental
- [ ] mount
- [ ] shipment
- [ ] can
- [ ] array
- [ ] diversion
- [ ] convert
- [ ] transition
- [ ] torque
- [ ] box
- [ ] workshop
- [ ] patent
- [ ] clutch
- [ ] nest
- [ ] coin
- [ ] noted
- [ ] watchful
- [ ] inject

# Chapter 004

- [ ] storage
- [ ] position
- [ ] metropolitan
- [ ] principally
- [ ] stalk
- [ ] preside
- [ ] eject
- [ ] bamboo
- [ ] jewellery
- [ ] wrinkle
- [ ] axial
- [ ] axis
- [ ] ambient
- [ ] periodic
- [ ] anniversary
- [ ] peripheral
- [ ] perimeter
- [ ] anybody
- [ ] responsible
- [ ] consequence

# Chapter 005

- [ ] category
- [ ] species
- [ ] hearty
- [ ] neutron
- [ ] intermediate
- [ ] proton
- [ ] qualitative
- [ ] fabricate
- [ ] fabrication
- [ ] volunteer
- [ ] rebuke
- [ ] indicative
- [ ] denote
- [ ] instructor
- [ ] designate
- [ ] colonial
- [ ] vocation
- [ ] notable
- [ ] merit
- [ ] weaver

# Chapter 006

- [ ] brace
- [ ] check
- [ ] second
- [ ] bearing
- [ ] symptom
- [ ] regime
- [ ] politics
- [ ] platform
- [ ] confirmation
- [ ] testify
- [ ] audience
- [ ] correctly
- [ ] positive
- [ ] normalization
- [ ] sign
- [ ] conqueror
- [ ] controversy
- [ ] suppress
- [ ] gust
- [ ] clinic

# Chapter 007

- [ ] diagnose
- [ ] sincerity
- [ ] cherish
- [ ] detective
- [ ] underline
- [ ] grind
- [ ] discount
- [ ] literally
- [ ] illuminate
- [ ] summon
- [ ] marsh
- [ ] entertainment
- [ ] hindrance
- [ ] hose
- [ ] sofa
- [ ] tensile
- [ ] warfare
- [ ] battle
- [ ] predominant
- [ ] unfold

# Chapter 008

- [ ] cling
- [ ] viscous
- [ ] coherent
- [ ] album
- [ ] glue
- [ ] cement
- [ ] adhere
- [ ] strip
- [ ] grasshopper
- [ ] wink
- [ ] further
- [ ] multiplication
- [ ] liability
- [ ] shipbuilding
- [ ] mint
- [ ] hollow
- [ ] hymn
- [ ] glorify
- [ ] fore
- [ ] therein

# Chapter 009

- [ ] overseas
- [ ] ashore
- [ ] outside
- [ ] brand
- [ ] alongside
- [ ] roam
- [ ] over
- [ ] reproduction
- [ ] specification
- [ ] disastrous
- [ ] operation
- [ ] freight
- [ ] locomotive
- [ ] lunar
- [ ] undertake
- [ ] primitive
- [ ] dome
- [ ] cylinder
- [ ] satisfactorily
- [ ] nucleus

# Chapter 010

- [ ] prototype
- [ ] vowel
- [ ] marshal
- [ ] subscription
- [ ] prophet
- [ ] prophecy
- [ ] prediction
- [ ] preset
- [ ] beforehand
- [ ] budget
- [ ] foresee
- [ ] prevention
- [ ] tulip
- [ ] intonation
- [ ] cosmic
- [ ] cosmos
- [ ] overlap
- [ ] excuse
- [ ] senseless
- [ ] amusement

# Chapter 011

- [ ] torpedo
- [ ] margin
- [ ] roundabout
- [ ] kidnap
- [ ] guilt
- [ ] shadowy
- [ ] avail
- [ ] ambitious
- [ ] significant
- [ ] validity
- [ ] availability
- [ ] finite
- [ ] magnet
- [ ] profitable
- [ ] advantageous
- [ ] courteous
- [ ] bead
- [ ] commonsense
- [ ] conservative
- [ ] liable

# Chapter 012

- [ ] yacht
- [ ] uranium
- [ ] tanker
- [ ] postal
- [ ] superiority
- [ ] elbow
- [ ] paper
- [ ] cutter
- [ ] net
- [ ] head
- [ ] tug
- [ ] hook
- [ ] formulate
- [ ] sniff
- [ ] courageous
- [ ] emigrate
- [ ] perpetual
- [ ] everlasting
- [ ] eternal
- [ ] stiffness

# Chapter 013

- [ ] comply
- [ ] bound
- [ ] salute
- [ ] cater
- [ ] press
- [ ] printer
- [ ] harbour
- [ ] diet
- [ ] tempt
- [ ] cite
- [ ] ignite
- [ ] derivation
- [ ] banker
- [ ] obscure
- [ ] inasmuch
- [ ] through
- [ ] consciousness
- [ ] observation
- [ ] cross
- [ ] refrain

# Chapter 014

- [ ] restrain
- [ ] singular
- [ ] house
- [ ] obligation
- [ ] formerly
- [ ] veil
- [ ] desert
- [ ] forsake
- [ ] transmission
- [ ] displace
- [ ] displacement
- [ ] colonist
- [ ] instrumental
- [ ] wardrobe
- [ ] garment
- [ ] Islam
- [ ] evenly
- [ ] compatible
- [ ] stitch
- [ ] troop

# Chapter 015

- [ ] concert
- [ ] chop
- [ ] baby
- [ ] episode
- [ ] cluster
- [ ] generalization
- [ ] burglar
- [ ] amateur
- [ ] metallurgy
- [ ] Jesus
- [ ] fort
- [ ] postulate
- [ ] prescription
- [ ] cradle
- [ ] waver
- [ ] wag
- [ ] oxide
- [ ] oxidize
- [ ] domestic
- [ ] foster

# Chapter 016

- [ ] balcony
- [ ] anode
- [ ] proverb
- [ ] banquet
- [ ] scope
- [ ] cloak
- [ ] sharply
- [ ] prolong
- [ ] retard
- [ ] pickle
- [ ] dentist
- [ ] opium
- [ ] deposit
- [ ] squeeze
- [ ] compression
- [ ] squash
- [ ] overwhelming
- [ ] overwhelm
- [ ] velocity
- [ ] circulation

# Chapter 017

- [ ] patrol
- [ ] cruise
- [ ] quest
- [ ] cigar
- [ ] scholarship
- [ ] radiant
- [ ] gorgeous
- [ ] option
- [ ] cock
- [ ] melody
- [ ] overhang
- [ ] console
- [ ] propaganda
- [ ] declaration
- [ ] narration
- [ ] sequence
- [ ] warrant
- [ ] requisite
- [ ] embroidery
- [ ] nun

# Chapter 018

- [ ] eloquence
- [ ] wind
- [ ] directory
- [ ] pacific
- [ ] survival
- [ ] flush
- [ ] formal
- [ ] constituent
- [ ] scarlet
- [ ] religion
- [ ] novelty
- [ ] regenerative
- [ ] bridegroom
- [ ] novel
- [ ] zinc
- [ ] appreciation
- [ ] psychology
- [ ] crab
- [ ] subscript
- [ ] sideways

# Chapter 019

- [ ] jean
- [ ] gradient
- [ ] vicious
- [ ] evil
- [ ] collaborate
- [ ] team
- [ ] coefficient
- [ ] wedge
- [ ] calibration
- [ ] paragraph
- [ ] cautious
- [ ] caution
- [ ] suitcase
- [ ] decimal
- [ ] footpath
- [ ] puppy
- [ ] closet
- [ ] pamphlet
- [ ] slack
- [ ] disappearance

# Chapter 020

- [ ] recreation
- [ ] consumer
- [ ] consumption
- [ ] depression
- [ ] token
- [ ] ivory
- [ ] forward
- [ ] southwards
- [ ] orientation
- [ ] defy
- [ ] hail
- [ ] yearn
- [ ] spice
- [ ] pilgrim
- [ ] fragrant
- [ ] incense
- [ ] uniformly
- [ ] resemblance
- [ ] analogy
- [ ] interact

# Chapter 021

- [ ] correlation
- [ ] reciprocal
- [ ] coincide
- [ ] inversely
- [ ] devotion
- [ ] linear
- [ ] qualify
- [ ] realistic
- [ ] striking
- [ ] microscopic
- [ ] apparent
- [ ] distinctly
- [ ] bacon
- [ ] gossip
- [ ] ramble
- [ ] precede
- [ ] priority
- [ ] shower
- [ ] decline
- [ ] descent

# Chapter 022

- [ ] subordinate
- [ ] inferior
- [ ] slim
- [ ] taper
- [ ] petty
- [ ] nice
- [ ] filament
- [ ] bacterium
- [ ] germ
- [ ] systematically
- [ ] spectrum
- [ ] lace
- [ ] tape
- [ ] drama
- [ ] theatre
- [ ] comedy
- [ ] assault
- [ ] usage
- [ ] quench
- [ ] extinguish

# Chapter 023

- [ ] absorption
- [ ] intake
- [ ] physically
- [ ] substantial
- [ ] body
- [ ] luncheon
- [ ] ignorance
- [ ] insignificant
- [ ] doubtless
- [ ] indefinite
- [ ] infinitely
- [ ] unlimited
- [ ] infinite
- [ ] fearless
- [ ] innumerable
- [ ] inorganic
- [ ] ruthless
- [ ] incapable
- [ ] unique
- [ ] faultless

# Chapter 024

- [ ] foreign
- [ ] nought
- [ ] filth
- [ ] snail
- [ ] hum
- [ ] compliment
- [ ] question
- [ ] literal
- [ ] illiterate
- [ ] stationery
- [ ] plague
- [ ] softness
- [ ] graze
- [ ] locality
- [ ] situated
- [ ] bachelor
- [ ] unpaid
- [ ] stern
- [ ] commission
- [ ] latitude

# Chapter 025

- [ ] vitamin
- [ ] Venus
- [ ] idealism
- [ ] mast
- [ ] enclosure
- [ ] violation
- [ ] violate
- [ ] towards
- [ ] plead
- [ ] catalogue
- [ ] microprocessor
- [ ] subtle
- [ ] atom
- [ ] calculus
- [ ] gleam
- [ ] negligible
- [ ] microwave
- [ ] awful
- [ ] majesty
- [ ] prestige

# Chapter 026

- [ ] endanger
- [ ] crisis
- [ ] peril
- [ ] dismiss
- [ ] fro
- [ ] mesh
- [ ] network
- [ ] web
- [ ] stubborn
- [ ] trifle
- [ ] completion
- [ ] crooked
- [ ] hull
- [ ] diplomatic
- [ ] alien
- [ ] strange
- [ ] distort
- [ ] twist
- [ ] tile
- [ ] watt

# Chapter 027

- [ ] elliptical
- [ ] haul
- [ ] hip
- [ ] devour
- [ ] retirement
- [ ] drawback
- [ ] inference
- [ ] rational
- [ ] propulsion
- [ ] propel
- [ ] recommendation
- [ ] overthrow
- [ ] impulse
- [ ] presumably
- [ ] gather
- [ ] shove
- [ ] solidarity
- [ ] regiment
- [ ] bandit
- [ ] lever

# Chapter 028

- [ ] overtake
- [ ] nose
- [ ] bald
- [ ] projector
- [ ] poll
- [ ] dizzy
- [ ] steal
- [ ] misery
- [ ] torment
- [ ] thrash
- [ ] dominant
- [ ] dominate
- [ ] statistics
- [ ] even
- [ ] identical
- [ ] likeness
- [ ] simultaneous
- [ ] accessory
- [ ] homogeneous
- [ ] coordinate

# Chapter 029

- [ ] whilst
- [ ] notify
- [ ] advertise
- [ ] correspondence
- [ ] popularity
- [ ] inflation
- [ ] currency
- [ ] entry
- [ ] customary
- [ ] ordinarily
- [ ] hydrocarbon
- [ ] resignation
- [ ] blacksmith
- [ ] ferrous
- [ ] adjoin
- [ ] hop
- [ ] skip
- [ ] overlook
- [ ] regulate
- [ ] modulate

# Chapter 030

- [ ] settlement
- [ ] mischief
- [ ] accord
- [ ] questionnaire
- [ ] sweetness
- [ ] dessert
- [ ] Catholic
- [ ] astronomy
- [ ] embody
- [ ] theme
- [ ] nominate
- [ ] finance
- [ ] nourish
- [ ] enhance
- [ ] elevate
- [ ] purify
- [ ] raise
- [ ] introduce
- [ ] peculiarity
- [ ] individual

# Chapter 031

- [ ] essential
- [ ] bore
- [ ] earthenware
- [ ] flee
- [ ] outlaw
- [ ] wade
- [ ] probe
- [ ] expedition
- [ ] charcoal
- [ ] plain
- [ ] negotiate
- [ ] greed
- [ ] moss
- [ ] pedal
- [ ] thereof
- [ ] trivial
- [ ] detail
- [ ] concern
- [ ] what
- [ ] miniature

# Chapter 032

- [ ] hurt
- [ ] deform
- [ ] deformation
- [ ] fringe
- [ ] scrap
- [ ] random
- [ ] garlic
- [ ] plastic
- [ ] shorthand
- [ ] scout
- [ ] laundry
- [ ] replace
- [ ] loosely
- [ ] rear
- [ ] perish
- [ ] hiss
- [ ] rip
- [ ] speculate
- [ ] smuggle
- [ ] confidence

# Chapter 033

- [ ] velvet
- [ ] treasurer
- [ ] exposition
- [ ] preach
- [ ] observe
- [ ] momentary
- [ ] instantaneous
- [ ] couch
- [ ] slumber
- [ ] buffalo
- [ ] hydraulic
- [ ] watery
- [ ] rinse
- [ ] wrestle
- [ ] numerical
- [ ] reckon
- [ ] harp
- [ ] erect
- [ ] terminology
- [ ] proficient

# Chapter 034

- [ ] proficiency
- [ ] input
- [ ] grant
- [ ] dependant
- [ ] miser
- [ ] trolley
- [ ] manuscript
- [ ] handbook
- [ ] adoption
- [ ] revenue
- [ ] oath
- [ ] vow
- [ ] pledge
- [ ] indoor
- [ ] wholesome
- [ ] moderately
- [ ] fitting
- [ ] fitness
- [ ] vision
- [ ] attendant

# Chapter 035

- [ ] occurrence
- [ ] snob
- [ ] snobbish
- [ ] influence
- [ ] municipal
- [ ] conform
- [ ] automate
- [ ] divert
- [ ] specialize
- [ ] hazard
- [ ] standardize
- [ ] lengthen
- [ ] shame
- [ ] freshen
- [ ] distinguish
- [ ] evaporate
- [ ] ventilate
- [ ] moor
- [ ] resign
- [ ] perfect

# Chapter 036

- [ ] infect
- [ ] lubricate
- [ ] soften
- [ ] facilitate
- [ ] acquaint
- [ ] tiresome
- [ ] sorrowful
- [ ] blaze
- [ ] subdue
- [ ] bend
- [ ] suit
- [ ] confront
- [ ] paralyse
- [ ] deafen
- [ ] subject
- [ ] terrify
- [ ] insulate
- [ ] integrate
- [ ] alternate
- [ ] degrade

# Chapter 037

- [ ] minimize
- [ ] mingle
- [ ] interconnect
- [ ] reconcile
- [ ] oblige
- [ ] enrich
- [ ] embarrass
- [ ] decay
- [ ] contrast
- [ ] baffle
- [ ] mature
- [ ] ice
- [ ] overload
- [ ] tangle
- [ ] sweeten
- [ ] thicken
- [ ] establish
- [ ] develop
- [ ] jog
- [ ] engage

# Chapter 038

- [ ] vector
- [ ] nourishment
- [ ] pantry
- [ ] experimentally
- [ ] experimentation
- [ ] virtual
- [ ] execution
- [ ] quartz
- [ ] graphite
- [ ] whitewash
- [ ] limestone
- [ ] humidity
- [ ] handout
- [ ] verse
- [ ] unemployment
- [ ] disgrace
- [ ] residual
- [ ] remainder
- [ ] excel
- [ ] stiff

# Chapter 039

- [ ] ecology
- [ ] hide
- [ ] vital
- [ ] producer
- [ ] productivity
- [ ] productive
- [ ] hoist
- [ ] kidney
- [ ] deliberately
- [ ] censor
- [ ] mystery
- [ ] shrine
- [ ] divine
- [ ] deliberate
- [ ] profound
- [ ] trench
- [ ] photography
- [ ] editorial
- [ ] sociology
- [ ] conceive

# Chapter 040

- [ ] reject
- [ ] serpent
- [ ] extravagant
- [ ] maid
- [ ] maiden
- [ ] scorch
- [ ] context
- [ ] Heaven
- [ ] counsel
- [ ] tradesman
- [ ] trader
- [ ] dealer
- [ ] ware
- [ ] merchandise
- [ ] blue
- [ ] goodness
- [ ] underwear
- [ ] cancel
- [ ] gap
- [ ] sift

# Chapter 041

- [ ] shark
- [ ] gravel
- [ ] sardine
- [ ] tone
- [ ] scan
- [ ] uproar
- [ ] prose
- [ ] emission
- [ ] stroll
- [ ] triangular
- [ ] mute
- [ ] choice
- [ ] tolerant
- [ ] commodity
- [ ] routine
- [ ] undertaking
- [ ] deem
- [ ] awake
- [ ] recognition
- [ ] identification

# Chapter 042

- [ ] merciful
- [ ] hostage
- [ ] pitch
- [ ] personnel
- [ ] humanity
- [ ] personality
- [ ] thermal
- [ ] tropic
- [ ] tropical
- [ ] concession
- [ ] combustion
- [ ] whisker
- [ ] flock
- [ ] conviction
- [ ] certainty
- [ ] positively
- [ ] quantify
- [ ] deficient
- [ ] deficiency
- [ ] scarcity

# Chapter 043

- [ ] flaw
- [ ] induce
- [ ] persuasion
- [ ] claim
- [ ] late
- [ ] extract
- [ ] crank
- [ ] expel
- [ ] dissipate
- [ ] spherical
- [ ] global
- [ ] Jupiter
- [ ] plea
- [ ] petition
- [ ] sight
- [ ] mistress
- [ ] mosque
- [ ] cleanliness
- [ ] inclination
- [ ] rap

# Chapter 044

- [ ] rash
- [ ] bronze
- [ ] industrious
- [ ] admiration
- [ ] agreeable
- [ ] section
- [ ] segment
- [ ] slit
- [ ] hardy
- [ ] compulsory
- [ ] constraint
- [ ] mighty
- [ ] thoughtless
- [ ] denounce
- [ ] pious
- [ ] lobby
- [ ] consistent
- [ ] predecessor
- [ ] visa
- [ ] modesty

# Chapter 045

- [ ] gracious
- [ ] migrate
- [ ] kilowatt
- [ ] pertinent
- [ ] apt
- [ ] utensil
- [ ] maple
- [ ] follower
- [ ] siren
- [ ] motel
- [ ] garage
- [ ] motorway
- [ ] hitherto
- [ ] barometer
- [ ] pant
- [ ] jack
- [ ] scratch
- [ ] count
- [ ] message
- [ ] enlighten

# Chapter 046

- [ ] implore
- [ ] knight
- [ ] marvel
- [ ] subsequently
- [ ] cheat
- [ ] periodical
- [ ] currently
- [ ] universally
- [ ] bushel
- [ ] raisin
- [ ] fracture
- [ ] destructive
- [ ] bankrupt
- [ ] persecute
- [ ] incline
- [ ] flask
- [ ] tack
- [ ] terrace
- [ ] civilian
- [ ] tranquil

# Chapter 047

- [ ] equation
- [ ] equilibrium
- [ ] commonplace
- [ ] frequency
- [ ] barren
- [ ] float
- [ ] bleach
- [ ] flake
- [ ] deflection
- [ ] prejudice
- [ ] adjacent
- [ ] cape
- [ ] clash
- [ ] collide
- [ ] ingredient
- [ ] shell
- [ ] battery
- [ ] foam
- [ ] bypass
- [ ] limp

# Chapter 048

- [ ] stagger
- [ ] ascend
- [ ] dispatch
- [ ] faction
- [ ] hover
- [ ] drainage
- [ ] range
- [ ] clap
- [ ] reptile
- [ ] overhear
- [ ] ohm
- [ ] hostess
- [ ] feminine
- [ ] waitress
- [ ] goddess
- [ ] blouse
- [ ] coward
- [ ] radiator
- [ ] strive
- [ ] mess

# Chapter 049

- [ ] distortion
- [ ] shorten
- [ ] Saturn
- [ ] milky
- [ ] wrench
- [ ] wring
- [ ] peer
- [ ] nickel
- [ ] junior
- [ ] annually
- [ ] practicable
- [ ] capability
- [ ] basin
- [ ] interior
- [ ] tickle
- [ ] incredible
- [ ] difficult
- [ ] refugee
- [ ] pumpkin
- [ ] polar

# Chapter 050

- [ ] masculine
- [ ] baron
- [ ] endurance
- [ ] sodium
- [ ] pasture
- [ ] intent
- [ ] end
- [ ] oyster
- [ ] magician
- [ ] skyscraper
- [ ] module
- [ ] ambiguous
- [ ] feel
- [ ] destiny
- [ ] doom
- [ ] proposition
- [ ] bid
- [ ] destine
- [ ] sensible
- [ ] explicit

# Chapter 051

- [ ] decidedly
- [ ] formulation
- [ ] brightness
- [ ] classic
- [ ] promptly
- [ ] sensitivity
- [ ] representation
- [ ] nursery
- [ ] deposition
- [ ] confidential
- [ ] enchant
- [ ] fascinate
- [ ] superstition
- [ ] stray
- [ ] perplex
- [ ] bewilder
- [ ] snap
- [ ] hurl
- [ ] jerk
- [ ] ally

# Chapter 052

- [ ] threshold
- [ ] charm
- [ ] fair
- [ ] offensive
- [ ] pore
- [ ] fuss
- [ ] cartoon
- [ ] vine
- [ ] expire
- [ ] bull
- [ ] wharf
- [ ] circus
- [ ] filter
- [ ] ass
- [ ] propeller
- [ ] spiral
- [ ] nut
- [ ] Roman
- [ ] thesis
- [ ] forum

# Chapter 053

- [ ] oval
- [ ] video
- [ ] reed
- [ ] leakage
- [ ] hug
- [ ] stairway
- [ ] monopoly
- [ ] bridle
- [ ] willow
- [ ] streamline
- [ ] rascal
- [ ] prevalent
- [ ] exile
- [ ] flux
- [ ] track
- [ ] gramophone
- [ ] otherwise
- [ ] province
- [ ] consul
- [ ] retail

# Chapter 054

- [ ] flexible
- [ ] inspiration
- [ ] grove
- [ ] neighbouring
- [ ] vicinity
- [ ] fission
- [ ] prey
- [ ] martyr
- [ ] grin
- [ ] expect
- [ ] quantitative
- [ ] blush
- [ ] allied
- [ ] ripple
- [ ] mitten
- [ ] attachment
- [ ] junction
- [ ] chestnut
- [ ] exceptional
- [ ] solar

# Chapter 055

- [ ] impose
- [ ] utilization
- [ ] stereo
- [ ] cubic
- [ ] legislation
- [ ] historian
- [ ] historic
- [ ] mechanics
- [ ] intellect
- [ ] ideally
- [ ] abstract
- [ ] slang
- [ ] courtesy
- [ ] twilight
- [ ] ion
- [ ] excursion
- [ ] grim
- [ ] prism
- [ ] troublesome
- [ ] analogue

# Chapter 056

- [ ] similarity
- [ ] flank
- [ ] comprehend
- [ ] optimism
- [ ] sophisticated
- [ ] straightforward
- [ ] wasteful
- [ ] idleness
- [ ] shabby
- [ ] dust
- [ ] flight
- [ ] rapture
- [ ] fury
- [ ] violent
- [ ] furious
- [ ] satisfaction
- [ ] snack
- [ ] rapidity
- [ ] parade
- [ ] pants

# Chapter 057

- [ ] bitterness
- [ ] wither
- [ ] clasp
- [ ] fastener
- [ ] stammer
- [ ] panic
- [ ] terrorist
- [ ] peacock
- [ ] fantastic
- [ ] pneumatic
- [ ] aerial
- [ ] spatial
- [ ] void
- [ ] gnaw
- [ ] longing
- [ ] suspicious
- [ ] shady
- [ ] questionable
- [ ] portable
- [ ] grateful

# Chapter 058

- [ ] adjustable
- [ ] frightful
- [ ] formidable
- [ ] dreadful
- [ ] monstrous
- [ ] possibility
- [ ] likelihood
- [ ] respectable
- [ ] appreciable
- [ ] shameful
- [ ] comparable
- [ ] particular
- [ ] whereby
- [ ] ponder
- [ ] exploration
- [ ] generosity
- [ ] discern
- [ ] fell
- [ ] carry
- [ ] inaugurate

# Chapter 059

- [ ] initiate
- [ ] commence
- [ ] reclaim
- [ ] evolution
- [ ] start
- [ ] unlock
- [ ] sheriff
- [ ] monarch
- [ ] sovereign
- [ ] bugle
- [ ] extinct
- [ ] decisive
- [ ] govern
- [ ] winding
- [ ] curly
- [ ] reel
- [ ] mob
- [ ] polymer
- [ ] hurricane
- [ ] sting

# Chapter 060

- [ ] repel
- [ ] gigantic
- [ ] uphold
- [ ] exemplify
- [ ] rectangle
- [ ] administration
- [ ] reside
- [ ] dwell
- [ ] induction
- [ ] Christ
- [ ] symposium
- [ ] whoever
- [ ] rectify
- [ ] vein
- [ ] competitor
- [ ] competitive
- [ ] contend
- [ ] alert
- [ ] warning
- [ ] whale

# Chapter 061

- [ ] selection
- [ ] thorough
- [ ] finely
- [ ] literary
- [ ] refinery
- [ ] vigorous
- [ ] fright
- [ ] astonishment
- [ ] dismay
- [ ] empirical
- [ ] longitude
- [ ] support
- [ ] economics
- [ ] prohibition
- [ ] shortcut
- [ ] inlet
- [ ] perfection
- [ ] notwithstanding
- [ ] prudent
- [ ] compact

# Chapter 062

- [ ] tightly
- [ ] barely
- [ ] metallic
- [ ] tuna
- [ ] henceforth
- [ ] mustard
- [ ] presentation
- [ ] interpret
- [ ] version
- [ ] untie
- [ ] tackle
- [ ] dissolve
- [ ] tuberculosis
- [ ] incorporate
- [ ] construction
- [ ] economically
- [ ] abbreviation
- [ ] thrifty
- [ ] interview
- [ ] receiver

# Chapter 063

- [ ] yeast
- [ ] doctrine
- [ ] tutor
- [ ] disillusion
- [ ] horn
- [ ] reef
- [ ] coke
- [ ] symphony
- [ ] intercourse
- [ ] soy
- [ ] parachute
- [ ] degradation
- [ ] oar
- [ ] discourse
- [ ] ginger
- [ ] splash
- [ ] architect
- [ ] theory
- [ ] clip
- [ ] diminish

# Chapter 064

- [ ] lessen
- [ ] inspector
- [ ] reserve
- [ ] challenge
- [ ] enterprise
- [ ] resolute
- [ ] firmness
- [ ] sturdy
- [ ] steady
- [ ] stability
- [ ] insistent
- [ ] persistence
- [ ] persevere
- [ ] shrill
- [ ] bridge
- [ ] rate
- [ ] hypothesis
- [ ] sham
- [ ] fake
- [ ] presume

# Chapter 065

- [ ] beetle
- [ ] clamp
- [ ] sandwich
- [ ] homely
- [ ] fowl
- [ ] poultry
- [ ] heater
- [ ] deepen
- [ ] heighten
- [ ] line
- [ ] stillness
- [ ] lodging
- [ ] successor
- [ ] succession
- [ ] quarterly
- [ ] craft
- [ ] souvenir
- [ ] documentary
- [ ] marginal
- [ ] terminal

# Chapter 066

- [ ] scheme
- [ ] geometrical
- [ ] bazaar
- [ ] gathering
- [ ] set
- [ ] disorder
- [ ] complaint
- [ ] forthcoming
- [ ] polarity
- [ ] extreme
- [ ] guitar
- [ ] timely
- [ ] irritate
- [ ] drastic
- [ ] severe
- [ ] Christian
- [ ] elemental
- [ ] radical
- [ ] ultimate
- [ ] energetic

# Chapter 067

- [ ] muscular
- [ ] witty
- [ ] mechanism
- [ ] tact
- [ ] ingenious
- [ ] ingenuity
- [ ] framework
- [ ] fence
- [ ] stall
- [ ] fellowship
- [ ] Mars
- [ ] ham
- [ ] piston
- [ ] vigour
- [ ] cloudy
- [ ] mixer
- [ ] engagement
- [ ] bribe
- [ ] corrupt
- [ ] response

# Chapter 068

- [ ] badge
- [ ] wield
- [ ] locust
- [ ] wasp
- [ ] royalty
- [ ] desolate
- [ ] illusion
- [ ] modification
- [ ] environmental
- [ ] pregnant
- [ ] fossil
- [ ] glider
- [ ] pulley
- [ ] slide
- [ ] granite
- [ ] correlate
- [ ] walnut
- [ ] arc
- [ ] exclamation
- [ ] outcome

# Chapter 069

- [ ] ruby
- [ ] hit
- [ ] traverse
- [ ] transverse
- [ ] bed
- [ ] harmonious
- [ ] monk
- [ ] cooperative
- [ ] hinge
- [ ] proper
- [ ] composite
- [ ] synthesis
- [ ] applause
- [ ] applaud
- [ ] hurrah
- [ ] pal
- [ ] hospitality
- [ ] romantic
- [ ] howl
- [ ] aerospace

# Chapter 070

- [ ] log
- [ ] pedestrian
- [ ] move
- [ ] hesitate
- [ ] pest
- [ ] strait
- [ ] turtle
- [ ] custom
- [ ] seaport
- [ ] cable
- [ ] pirate
- [ ] seaside
- [ ] surplus
- [ ] overestimate
- [ ] excessively
- [ ] excess
- [ ] orchard
- [ ] peel
- [ ] stone
- [ ] slap

# Chapter 071

- [ ] inland
- [ ] boiler
- [ ] roller
- [ ] valuable
- [ ] salmon
- [ ] silicon
- [ ] regulation
- [ ] regularity
- [ ] define
- [ ] provision
- [ ] replacement
- [ ] spacious
- [ ] amplitude
- [ ] radial
- [ ] photoelectric
- [ ] optical
- [ ] shrub
- [ ] irrigation
- [ ] inertia
- [ ] orchestra

# Chapter 072

- [ ] blast
- [ ] pipe
- [ ] coffin
- [ ] bureaucracy
- [ ] monster
- [ ] client
- [ ] obstinate
- [ ] inherent
- [ ] fixture
- [ ] pluck
- [ ] agitation
- [ ] skeleton
- [ ] thigh
- [ ] cereal
- [ ] antique
- [ ] assessment
- [ ] constitute
- [ ] hound
- [ ] gutter
- [ ] tribute

# Chapter 073

- [ ] number
- [ ] commonwealth
- [ ] arch
- [ ] vault
- [ ] mercury
- [ ] consolidate
- [ ] impartial
- [ ] convention
- [ ] duke
- [ ] rooster
- [ ] studio
- [ ] earnings
- [ ] implement
- [ ] workpiece
- [ ] combat
- [ ] impart
- [ ] energize
- [ ] vaccinate
- [ ] flavour
- [ ] insulator

# Chapter 074

- [ ] lattice
- [ ] dove
- [ ] reveal
- [ ] plateau
- [ ] lofty
- [ ] tower
- [ ] elevation
- [ ] intervene
- [ ] dry
- [ ] olive
- [ ] sentiment
- [ ] perception
- [ ] sensation
- [ ] Thanksgiving
- [ ] chill
- [ ] outline
- [ ] notion
- [ ] conception
- [ ] summary
- [ ] generalize

# Chapter 075

- [ ] impress
- [ ] mend
- [ ] duplicate
- [ ] complication
- [ ] complexity
- [ ] satellite
- [ ] appendix
- [ ] extra
- [ ] incidentally
- [ ] charge
- [ ] negative
- [ ] corrosion
- [ ] erosion
- [ ] subsidiary
- [ ] coach
- [ ] answer
- [ ] emerge
- [ ] obedient
- [ ] obedience
- [ ] maintenance

# Chapter 076

- [ ] veto
- [ ] denial
- [ ] Buddhism
- [ ] dedicate
- [ ] flatter
- [ ] pineapple
- [ ] seam
- [ ] landscape
- [ ] windmill
- [ ] plump
- [ ] abundance
- [ ] indignation
- [ ] shatter
- [ ] molecular
- [ ] limb
- [ ] offset
- [ ] fraction
- [ ] distract
- [ ] installment
- [ ] split

# Chapter 077

- [ ] detach
- [ ] partition
- [ ] interface
- [ ] relay
- [ ] diverge
- [ ] litter
- [ ] abolish
- [ ] gangster
- [ ] extraordinarily
- [ ] fly
- [ ] aviation
- [ ] indulge
- [ ] herd
- [ ] magnify
- [ ] imitation
- [ ] pattern
- [ ] reproduce
- [ ] estate
- [ ] hamper
- [ ] handicap

# Chapter 078

- [ ] handy
- [ ] offence
- [ ] blunder
- [ ] mirror
- [ ] reactor
- [ ] echo
- [ ] contrary
- [ ] contradict
- [ ] propagation
- [ ] propagate
- [ ] toss
- [ ] decree
- [ ] flannel
- [ ] valve
- [ ] originate
- [ ] spokesman
- [ ] outlet
- [ ] incidence
- [ ] generate
- [ ] invoice

# Chapter 079

- [ ] detector
- [ ] flame
- [ ] exert
- [ ] luminous
- [ ] beam
- [ ] motive
- [ ] dynamo
- [ ] rattle
- [ ] dioxide
- [ ] bait
- [ ] subsequent
- [ ] whereas
- [ ] youngster
- [ ] offspring
- [ ] malice
- [ ] spite
- [ ] nightmare
- [ ] yoke
- [ ] deprive
- [ ] mountainous

# Chapter 080

- [ ] windy
- [ ] versatile
- [ ] stew
- [ ] mop
- [ ] halve
- [ ] symmetrical
- [ ] symmetry
- [ ] provoke
- [ ] resent
- [ ] alignment
- [ ] assert
- [ ] affirm
- [ ] shortage
- [ ] ferry
- [ ] jealousy
- [ ] cuckoo
- [ ] gamble
- [ ] jam
- [ ] distinct
- [ ] solo

# Chapter 081

- [ ] dictator
- [ ] linger
- [ ] tease
- [ ] fighter
- [ ] champion
- [ ] insight
- [ ] cavity
- [ ] jelly
- [ ] mobilize
- [ ] grease
- [ ] disturbance
- [ ] kinetic
- [ ] orient
- [ ] location
- [ ] theorem
- [ ] subscribe
- [ ] summit
- [ ] sculpture
- [ ] electronics
- [ ] pressure

# Chapter 082

- [ ] capacitor
- [ ] capacitance
- [ ] electrode
- [ ] electrician
- [ ] telex
- [ ] kindle
- [ ] geology
- [ ] basement
- [ ] geographical
- [ ] magistrate
- [ ] mortgage
- [ ] hostile
- [ ] whisper
- [ ] underestimate
- [ ] murmur
- [ ] equivalent
- [ ] enroll
- [ ] burner
- [ ] triumphant
- [ ] clatter

# Chapter 083

- [ ] morality
- [ ] theft
- [ ] attendance
- [ ] between
- [ ] yolk
- [ ] cartridge
- [ ] detain
- [ ] simple
- [ ] simplicity
- [ ] fill
- [ ] jug
- [ ] algebra
- [ ] attorney
- [ ] deputy
- [ ] representative
- [ ] delegate
- [ ] gorilla
- [ ] magnitude
- [ ] massacre
- [ ] stride

# Chapter 084

- [ ] embassy
- [ ] ambassador
- [ ] mansion
- [ ] multitude
- [ ] barley
- [ ] continental
- [ ] infinity
- [ ] steak
- [ ] butt
- [ ] largely
- [ ] widely
- [ ] prairie
- [ ] smash
- [ ] sneeze
- [ ] lighter
- [ ] snore
- [ ] thresh
- [ ] forge
- [ ] passport
- [ ] inaccessible

# Chapter 085

- [ ] frustrate
- [ ] latent
- [ ] frail
- [ ] fragile
- [ ] crisp
- [ ] catalyst
- [ ] promotion
- [ ] reckless
- [ ] vulgar
- [ ] massive
- [ ] harsh
- [ ] jungle
- [ ] follow
- [ ] overflow
- [ ] smart
- [ ] prick
- [ ] thereafter
- [ ] magnetism
- [ ] porcelain
- [ ] initial

# Chapter 086

- [ ] glossary
- [ ] vocabulary
- [ ] stem
- [ ] poke
- [ ] lipstick
- [ ] stainless
- [ ] sheer
- [ ] perpendicular
- [ ] author
- [ ] innovation
- [ ] initiative
- [ ] puff
- [ ] shipwreck
- [ ] report
- [ ] infectious
- [ ] romance
- [ ] herald
- [ ] missionary
- [ ] sensor
- [ ] circular

# Chapter 087

- [ ] leaflet
- [ ] convey
- [ ] pierce
- [ ] penetration
- [ ] antenna
- [ ] virgin
- [ ] transaction
- [ ] penalty
- [ ] exclusive
- [ ] notorious
- [ ] scandal
- [ ] specimen
- [ ] extraction
- [ ] adore
- [ ] worship
- [ ] bug
- [ ] punch
- [ ] strife
- [ ] equator
- [ ] gear

# Chapter 088

- [ ] persist
- [ ] breakfast
- [ ] dine
- [ ] proceeding
- [ ] length
- [ ] acknowledge
- [ ] shoulder
- [ ] integrity
- [ ] offer
- [ ] membership
- [ ] systematic
- [ ] kit
- [ ] commend
- [ ] brood
- [ ] muse
- [ ] meditate
- [ ] hush
- [ ] immerse
- [ ] repeal
- [ ] lathe

# Chapter 089

- [ ] row
- [ ] mock
- [ ] reign
- [ ] supersonic
- [ ] ultrasonic
- [ ] surpass
- [ ] nickname
- [ ] waggon
- [ ] spectacle
- [ ] resident
- [ ] haunt
- [ ] visit
- [ ] frequent
- [ ] shovel
- [ ] toad
- [ ] diesel
- [ ] errand
- [ ] ascertain
- [ ] horizon
- [ ] tactics

# Chapter 090

- [ ] grassy
- [ ] herb
- [ ] groove
- [ ] manipulate
- [ ] hatch
- [ ] warehouse
- [ ] cruelty
- [ ] napkin
- [ ] participate
- [ ] senator
- [ ] reference
- [ ] participant
- [ ] spectator
- [ ] parameter
- [ ] recipe
- [ ] assumption
- [ ] rule
- [ ] substance
- [ ] friction
- [ ] sermon

# Chapter 091

- [ ] absent
- [ ] disagreement
- [ ] awkward
- [ ] immortal
- [ ] wretched
- [ ] misfortune
- [ ] incompatible
- [ ] instability
- [ ] incomplete
- [ ] stuffy
- [ ] opaque
- [ ] improper
- [ ] dissatisfaction
- [ ] watertight
- [ ] inevitably
- [ ] irrespective
- [ ] inaccurate
- [ ] unreasonable
- [ ] undesirable
- [ ] unfit

# Chapter 092

- [ ] absurd
- [ ] irregularity
- [ ] disregard
- [ ] uncertain
- [ ] impurity
- [ ] inadequate
- [ ] invariably
- [ ] uneasy
- [ ] mammal
- [ ] supplement
- [ ] complement
- [ ] compensation
- [ ] humanitarian
- [ ] barge
- [ ] fluctuation
- [ ] fluctuate
- [ ] invalid
- [ ] ward
- [ ] strength
- [ ] icy

# Chapter 093

- [ ] objective
- [ ] villa
- [ ] characterize
- [ ] signify
- [ ] manifest
- [ ] seemingly
- [ ] superficial
- [ ] criterion
- [ ] norm
- [ ] heading
- [ ] reason
- [ ] advocate
- [ ] discrimination
- [ ] transform
- [ ] loosen
- [ ] alteration
- [ ] fall
- [ ] program
- [ ] edit
- [ ] verge

# Chapter 094

- [ ] rim
- [ ] hearth
- [ ] fireplace
- [ ] patron
- [ ] diploma
- [ ] indispensable
- [ ] sullen
- [ ] bandage
- [ ] breakdown
- [ ] essence
- [ ] captive
- [ ] reverse
- [ ] deviation
- [ ] arctic
- [ ] tragic
- [ ] woe
- [ ] grief
- [ ] firework
- [ ] storm
- [ ] tyranny

# Chapter 095

- [ ] wrath
- [ ] tyrant
- [ ] panther
- [ ] leopard
- [ ] grumble
- [ ] announce
- [ ] vengeance
- [ ] fortress
- [ ] assurance
- [ ] fuse
- [ ] reservation
- [ ] safeguard
- [ ] preservation
- [ ] saturation
- [ ] mist
- [ ] chip
- [ ] inclusive
- [ ] siege
- [ ] embrace
- [ ] baseball

# Chapter 096

- [ ] hemisphere
- [ ] radius
- [ ] scar
- [ ] liner
- [ ] trigger
- [ ] tar
- [ ] blind
- [ ] shutter
- [ ] lily
- [ ] millionaire
- [ ] white
- [ ] blond
- [ ] idiot
- [ ] bank
- [ ] tabulate
- [ ] bestow
- [ ] subdivide
- [ ] dock
- [ ] straighten
- [ ] flatten

# Chapter 097

- [ ] ascribe
- [ ] except
- [ ] entitle
- [ ] ballet
- [ ] haughty
- [ ] foul
- [ ] assassinate
- [ ] burial
- [ ] luxurious
- [ ] patriot
- [ ] patriotic
- [ ] dwarf
- [ ] stout
- [ ] alas
- [ ] Egyptian
- [ ] pathetic
- [ ] should
- [ ] ought
- [ ] scripture
- [ ] referee

# Chapter 098

- [ ] pendulum
- [ ] shuttle
- [ ] outbreak
- [ ] market
- [ ] gross
- [ ] heave
- [ ] pop
- [ ] lining
- [ ] mild
- [ ] panel
- [ ] rigorous
- [ ] climax
- [ ] epoch
- [ ] shrimp
- [ ] peak
- [ ] cane
- [ ] drain
- [ ] switch
- [ ] board
- [ ] immigrate

# Chapter 099

- [ ] disperse
- [ ] lump
- [ ] deviate
- [ ] pose
- [ ] expenditure
- [ ] elapse
- [ ] hoarse
- [ ] clearing
- [ ] shade
- [ ] eclipse
- [ ] constitution
- [ ] spill
- [ ] unanimous
- [ ] quiver
- [ ] perch
- [ ] span
- [ ] pier
- [ ] frock
- [ ] flutter
- [ ] resume

# Chapter 100

- [ ] clown
- [ ] pace
- [ ] lounge
- [ ] pope
- [ ] axle
- [ ] measurement
- [ ] realization
- [ ] chord
- [ ] pyjamas
- [ ] elegant
- [ ] hard
- [ ] refreshment
- [ ] ticket
- [ ] gesture
- [ ] situation
- [ ] software
- [ ] bishop
- [ ] insert
- [ ] kernel
- [ ] wisdom

# Chapter 101

- [ ] growl
- [ ] shaft
- [ ] buzz
- [ ] breed
- [ ] ear
- [ ] dean
- [ ] fertile
- [ ] sink
- [ ] versus
- [ ] ranch
- [ ] grope
- [ ] pedlar
- [ ] rally
- [ ] squat
- [ ] fling
- [ ] scrub
- [ ] tread
- [ ] crack
- [ ] slander
- [ ] escort

# Chapter 102

- [ ] swell
- [ ] menace
- [ ] tramp
- [ ] trample
- [ ] suicide
- [ ] tighten
- [ ] jingle
- [ ] fret
- [ ] thrill
- [ ] deflect
- [ ] tilt
- [ ] revolve
- [ ] rotate
- [ ] compensate
- [ ] default
- [ ] infer
- [ ] repay
- [ ] scoff
- [ ] hoe
- [ ] retort

# Chapter 103

- [ ] broaden
- [ ] decompose
- [ ] chorus
- [ ] supervise
- [ ] beware
- [ ] grab
- [ ] entreat
- [ ] concentrate
- [ ] urge
- [ ] riot
- [ ] shrug
- [ ] revive
- [ ] terminate
- [ ] solidify
- [ ] dazzle
- [ ] transplant
- [ ] xerox
- [ ] peck
- [ ] trot
- [ ] ridicule

# Chapter 104

- [ ] chatter
- [ ] sneer
- [ ] boycott
- [ ] plunder
- [ ] endeavor
- [ ] scramble
- [ ] flap
- [ ] slaughter
- [ ] tow
- [ ] credit
- [ ] clockwise
- [ ] headlong
- [ ] counter
- [ ] eastward
- [ ] Moslem
- [ ] melancholy
- [ ] bulletin
- [ ] allowance


# Chapter 001

- [ ] smell
- [ ] soft
- [ ] sour
- [ ] cookie
- [ ] mm
- [ ] pizza
- [ ] lovely
- [ ] done
- [ ] try
- [ ] have a try
- [ ] pie
- [ ] sound
- [ ] sweet tooth
- [ ] salt
- [ ] jam
- [ ] for
- [ ] favourite
- [ ] ear
- [ ] glasses
- [ ] jeans

# Chapter 002

- [ ] nervous
- [ ] fair
- [ ] pretty
- [ ] proud
- [ ] be proud of …
- [ ] stranger
- [ ] message
- [ ] sb. can't wait
- [ ] hobby
- [ ] at school
- [ ] in
- [ ] mark
- [ ] love
- [ ] ever
- [ ] enter
- [ ] competition
- [ ] prize
- [ ] first prize
- [ ] dream
- [ ] afford

# Chapter 003

- [ ] write about
- [ ] make up
- [ ] invite
- [ ] move
- [ ] send
- [ ] Germany
- [ ] France
- [ ] tower
- [ ] ancient
- [ ] king
- [ ] queen
- [ ] Arabic
- [ ] way
- [ ] mix
- [ ] miss
- [ ] count
- [ ] count down
- [ ] earth
- [ ] moon
- [ ] news

# Chapter 004

- [ ] planet
- [ ] reach
- [ ] yet
- [ ] just
- [ ] model
- [ ] spaceship
- [ ] project
- [ ] no problem
- [ ] latest
- [ ] on
- [ ] discover
- [ ] astronaut
- [ ] space travel
- [ ] none
- [ ] environment
- [ ] that
- [ ] solar
- [ ] system
- [ ] solar system
- [ ] group

# Chapter 005

- [ ] galaxy
- [ ] universe
- [ ] light
- [ ] impossible
- [ ] out
- [ ] communicate
- [ ] cough
- [ ] fever
- [ ] headache
- [ ] stomach
- [ ] ache
- [ ] stomach ache
- [ ] toothache
- [ ] ill
- [ ] this
- [ ] since
- [ ] cold
- [ ] catch a cold
- [ ] take
- [ ] take sb.'s temperature

# Chapter 006

- [ ] fast food
- [ ] health
- [ ] well
- [ ] heart
- [ ] active
- [ ] pet
- [ ] member
- [ ] take part (in sth.)
- [ ] condition
- [ ] in excellent condition
- [ ] sleepy
- [ ] then
- [ ] daily
- [ ] weak
- [ ] illness
- [ ] exercise
- [ ] awful
- [ ] feel awful
- [ ] all over
- [ ] perhaps

# Chapter 007

- [ ] cartoon
- [ ] handsome
- [ ] smart
- [ ] sky
- [ ] fight
- [ ] cool
- [ ] hero
- [ ] humorous
- [ ] can't help doing sth.
- [ ] laugh
- [ ] lesson
- [ ] orange-and-white
- [ ] ugly
- [ ] win the heart of sb.
- [ ] schoolbag
- [ ] lead
- [ ] clever
- [ ] as
- [ ] mess
- [ ] heaven

# Chapter 008

- [ ] expect
- [ ] artist
- [ ] invent
- [ ] copy
- [ ] black-and-white
- [ ] own
- [ ] private
- [ ] create
- [ ] satisfy
- [ ] fan
- [ ] stamp
- [ ] tidy up
- [ ] shelf
- [ ] have a look
- [ ] As
- [ ] coin
- [ ] note
- [ ] pound
- [ ] dollar
- [ ] must

# Chapter 009

- [ ] valuable
- [ ] with
- [ ] value
- [ ] Just
- [ ] person
- [ ] interest
- [ ] skill
- [ ] activity
- [ ] sailing
- [ ] come out
- [ ] result
- [ ] as a result
- [ ] pleasure
- [ ] success
- [ ] list
- [ ] make a list
- [ ] crazy
- [ ] at the end of
- [ ] shorts
- [ ] trousers

# Chapter 010

- [ ] sunglasses
- [ ] homestay
- [ ] weigh
- [ ] total
- [ ] weight
- [ ] passport
- [ ] culture
- [ ] at the same time
- [ ] last
- [ ] depend
- [ ] depend on
- [ ] provide
- [ ] test
- [ ] progress
- [ ] guest
- [ ] daily life
- [ ] form
- [ ] friendship
- [ ] stay in touch (with sb.)
- [ ] prefer

# Chapter 011

- [ ] certain
- [ ] fill
- [ ] fill out
- [ ] hardly
- [ ] take up
- [ ] point out
- [ ] sights
- [ ] thirsty
- [ ] at the top of
- [ ] waste
- [ ] square
- [ ] kilometre
- [ ] shape
- [ ] human
- [ ] wake
- [ ] wake sb. up
- [ ] somebody
- [ ] about
- [ ] path
- [ ] pull

# Chapter 012

- [ ] freshwater
- [ ] helpline
- [ ] separate
- [ ] explain
- [ ] mention
- [ ] refuse
- [ ] treat
- [ ] herself
- [ ] whether
- [ ] lonely
- [ ] regret
- [ ] patient
- [ ] introduce
- [ ] encourage
- [ ] join in
- [ ] No problem
- [ ] silence
- [ ] in silence
- [ ] pass
- [ ] bright

# Chapter 013

- [ ] treasure
- [ ] day by day
- [ ] trust
- [ ] include
- [ ] circle
- [ ] stick
- [ ] glue
- [ ] suggestion
- [ ] director
- [ ] show
- [ ] around
- [ ] show sb. around
- [ ] on air
- [ ] avoid
- [ ] background
- [ ] national
- [ ] international
- [ ] presenter
- [ ] interview
- [ ] seem

# Chapter 014

- [ ] listener
- [ ] in person
- [ ] part-time
- [ ] article
- [ ] studio
- [ ] purpose

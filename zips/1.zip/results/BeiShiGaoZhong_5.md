
# Chapter 001

- [ ] assessment
- [ ] self-assessment
- [ ] strength
- [ ] weakness
- [ ] gain
- [ ] appropriately
- [ ] passive
- [ ] phrase
- [ ] concentrate
- [ ] previous
- [ ] positive
- [ ] associate
- [ ] mental
- [ ] lawyer
- [ ] senior
- [ ] physicist
- [ ] beard
- [ ] blond
- [ ] sunglasses
- [ ] uniform

# Chapter 002

- [ ] moustache
- [ ] heel
- [ ] sleeve
- [ ] facial
- [ ] expression
- [ ] connection
- [ ] chain
- [ ] aircraft
- [ ] emergency
- [ ] pray
- [ ] gifted
- [ ] accurately
- [ ] draw up
- [ ] description
- [ ] academic
- [ ] predict
- [ ] deserve
- [ ] failure
- [ ] mistaken
- [ ] association

# Chapter 003

- [ ] thus
- [ ] possibility
- [ ] disability
- [ ] entirely
- [ ] Easter
- [ ] embassy
- [ ] accuse
- [ ] lightning
- [ ] personality
- [ ] clerk
- [ ] conductor
- [ ] butcher
- [ ] athletic
- [ ] independent
- [ ] neat
- [ ] selfish
- [ ] sharp
- [ ] characteristic
- [ ] desire
- [ ] satisfaction

# Chapter 004

- [ ] harvest
- [ ] biology
- [ ] pineapple
- [ ] peach
- [ ] kindness
- [ ] requirement
- [ ] airline
- [ ] aboard
- [ ] assistant
- [ ] independence
- [ ] poet
- [ ] translator
- [ ] tutor
- [ ] tear
- [ ] cheek
- [ ] hug
- [ ] upset
- [ ] fault
- [ ] thunder
- [ ] wool

# Chapter 005

- [ ] pine
- [ ] seed
- [ ] squirrel
- [ ] sparrow
- [ ] bleed
- [ ] broken
- [ ] relief
- [ ] shelter
- [ ] scholar
- [ ] bench
- [ ] housewife
- [ ] postcode
- [ ] astronomy
- [ ] allergic
- [ ] anxiety
- [ ] revision
- [ ] oral
- [ ] straw
- [ ] glare
- [ ] section

# Chapter 006

- [ ] literary
- [ ] glance
- [ ] steam
- [ ] confirm
- [ ] librarian
- [ ] file
- [ ] sigh
- [ ] grateful
- [ ] guilty
- [ ] can't help doing sth.
- [ ] alike
- [ ] shortcoming
- [ ] account
- [ ] button
- [ ] parrot
- [ ] cage
- [ ] judge
- [ ] part-time
- [ ] claw
- [ ] yoghurt

# Chapter 007

- [ ] honey
- [ ] chew
- [ ] satellite
- [ ] wrinkle
- [ ] forehead
- [ ] block
- [ ] lap
- [ ] devote
- [ ] salty
- [ ] carrot
- [ ] pea
- [ ] companion
- [ ] devotion
- [ ] forever
- [ ] carpenter
- [ ] chemist
- [ ] receptionist
- [ ] shop assistant
- [ ] typist
- [ ] insurance

# Chapter 008

- [ ] bonus
- [ ] fee
- [ ] income
- [ ] reward
- [ ] wage
- [ ] charge
- [ ] summary
- [ ] guidance
- [ ] paragraph
- [ ] institute
- [ ] aid
- [ ] pump
- [ ] data
- [ ] deer
- [ ] take charge of
- [ ] topic
- [ ] receipt
- [ ] error
- [ ] liquid
- [ ] comprehension

# Chapter 009

- [ ] consult
- [ ] chart
- [ ] casual
- [ ] quarrel
- [ ] make up
- [ ] make out
- [ ] go into detail(s)
- [ ] speak up
- [ ] sit up
- [ ] nursery
- [ ] collar
- [ ] appointment
- [ ] childhood
- [ ] typewriter
- [ ] instant
- [ ] battle
- [ ] civil
- [ ] moral
- [ ] basis
- [ ] corn

# Chapter 010

- [ ] cattle
- [ ] frost
- [ ] surrounding
- [ ] steep
- [ ] grain
- [ ] lip
- [ ] mud
- [ ] wisdom
- [ ] idiom
- [ ] junior
- [ ] universe
- [ ] believe in
- [ ] mankind
- [ ] nest
- [ ] feather
- [ ] turn over
- [ ] overcome
- [ ] grasp
- [ ] inspect
- [ ] illegal

# Chapter 011

- [ ] pay off
- [ ] commit
- [ ] committed
- [ ] existence
- [ ] glory
- [ ] constantly
- [ ] beneath
- [ ] bend
- [ ] stage
- [ ] hesitate
- [ ] wrist
- [ ] twist
- [ ] judgement
- [ ] keep up with
- [ ] decrease
- [ ] multiply
- [ ] division
- [ ] branch
- [ ] operate
- [ ] dynamic

# Chapter 012

- [ ] respond
- [ ] flexible
- [ ] envy
- [ ] bother
- [ ] continent
- [ ] in case
- [ ] comfort
- [ ] slave
- [ ] boom
- [ ] panic
- [ ] arithmetic
- [ ] enclose
- [ ] curriculum vitae
- [ ] due to
- [ ] in addition
- [ ] arrow
- [ ] oxygen
- [ ] tick
- [ ] ox
- [ ] spelling

# Chapter 013

- [ ] backwards
- [ ] correction
- [ ] simplify
- [ ] jar
- [ ] secure
- [ ] frankly
- [ ] lay off
- [ ] blank
- [ ] swell
- [ ] suspect
- [ ] lump
- [ ] throat
- [ ] status
- [ ] chief
- [ ] saying
- [ ] postage
- [ ] airmail
- [ ] user
- [ ] instruct
- [ ] aside

# Chapter 014

- [ ] bury
- [ ] alphabet
- [ ] distinguish
- [ ] drill
- [ ] motto
- [ ] conservative
- [ ] assignment
- [ ] alternative
- [ ] punishment
- [ ] reputation
- [ ] slight
- [ ] loose
- [ ] obey
- [ ] mild
- [ ] receiver
- [ ] pace
- [ ] outstanding
- [ ] reflect
- [ ] select
- [ ] to a certain extent

# Chapter 015

- [ ] misunderstand
- [ ] angle
- [ ] triangle
- [ ] atom
- [ ] pour
- [ ] powder
- [ ] flame
- [ ] set off
- [ ] lack
- [ ] spit
- [ ] drag
- [ ] acid
- [ ] onion
- [ ] access
- [ ] worthwhile
- [ ] spy
- [ ] glue
- [ ] fellow
- [ ] acquire
- [ ] be accustomed to

# Chapter 016

- [ ] thinking
- [ ] rank
- [ ] bureaucratic
- [ ] worthy
- [ ] religion
- [ ] defence
- [ ] tend to
- [ ] ignore
- [ ] unwilling
- [ ] assumption
- [ ] approve
- [ ] urge
- [ ] inspire
- [ ] shadow
- [ ] conventional
- [ ] kingdom
- [ ] civilisation
- [ ] vital
- [ ] beneficial
- [ ] image

# Chapter 017

- [ ] assume
- [ ] adapt
- [ ] as a whole
- [ ] facility
- [ ] appreciation
- [ ] biochemistry
- [ ] choir

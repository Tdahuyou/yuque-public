
# Chapter 001

- [ ] hello
- [ ] class
- [ ] my
- [ ] name
- [ ] is
- [ ] Miss
- [ ] good
- [ ] morning
- [ ] good morning
- [ ] afternoon
- [ ] good afternoon
- [ ] goodbye
- [ ] I
- [ ] am
- [ ] I'm = I am
- [ ] Mr
- [ ] what
- [ ] your
- [ ] please
- [ ] sorry

# Chapter 002

- [ ] can
- [ ] you
- [ ] spell
- [ ] it
- [ ] yes
- [ ] thank
- [ ] how
- [ ] are
- [ ] fine
- [ ] thanks
- [ ] Mrs
- [ ] too
- [ ] this
- [ ] she
- [ ] teacher
- [ ] friend
- [ ] her
- [ ] his
- [ ] nice
- [ ] to

# Chapter 003

- [ ] meet
- [ ] time
- [ ] go
- [ ] now
- [ ] bye
- [ ] see
- [ ] tomorrow
- [ ] sit
- [ ] down
- [ ] sit down
- [ ] open
- [ ] book
- [ ] listen
- [ ] draw
- [ ] put
- [ ] up
- [ ] hand
- [ ] stand
- [ ] stand up
- [ ] close

# Chapter 004

- [ ] new
- [ ] student
- [ ] here
- [ ] in
- [ ] one
- [ ] two
- [ ] three
- [ ] four
- [ ] five
- [ ] six
- [ ] seven
- [ ] eight
- [ ] nine
- [ ] ten
- [ ] telephone
- [ ] number
- [ ] old
- [ ] how old
- [ ] twelve
- [ ] eleven

# Chapter 005

- [ ] thirteen
- [ ] fourteen
- [ ] fifteen
- [ ] sixteen
- [ ] seventeen
- [ ] eighteen
- [ ] nineteen
- [ ] twenty
- [ ] boy
- [ ] girl
- [ ] desk
- [ ] chair
- [ ] bag
- [ ] In
- [ ] English
- [ ] in English
- [ ] a
- [ ] write
- [ ] on
- [ ] the

# Chapter 006

- [ ] blackboard
- [ ] OK
- [ ] pen
- [ ] no
- [ ] pencil
- [ ] do
- [ ] bird
- [ ] cat
- [ ] dog
- [ ] flower
- [ ] help
- [ ] me
- [ ] of
- [ ] course
- [ ] of course
- [ ] classroom
- [ ] know
- [ ] say
- [ ] that
- [ ] again

# Chapter 007

- [ ] welcome
- [ ] You're welcome.
- [ ] black
- [ ] white
- [ ] blue
- [ ] green
- [ ] yellow
- [ ] red
- [ ] brown
- [ ] orange
- [ ] colour (AmE color)
- [ ] and
- [ ] day
- [ ] today
- [ ] Monday
- [ ] Tuesday
- [ ] Wednesday
- [ ] Thursday
- [ ] Friday
- [ ] Saturday

# Chapter 008

- [ ] Sunday
- [ ] birthday
- [ ] favourite (AmE favorite)
- [ ] spring
- [ ] summer
- [ ] autumn
- [ ] winter
- [ ] warm
- [ ] hot
- [ ] cool
- [ ] cold
- [ ] weather
- [ ] like
- [ ] London
- [ ] basketball
- [ ] football
- [ ] swimming
- [ ] table tennis
- [ ] sport
- [ ] let

# Chapter 009

- [ ] us
- [ ] let's = let us
- [ ] play
- [ ] after
- [ ] school
- [ ] idea
- [ ] Chinese
- [ ] from
- [ ] where
- [ ] year
- [ ] about
- [ ] What about ⋯?
- [ ] Ms
- [ ] America
- [ ] not
- [ ] England
- [ ] hi
- [ ] American
- [ ] adj.
- [ ] our

# Chapter 010

- [ ] grade
- [ ] he
- [ ] China
- [ ] everyone
- [ ] capital
- [ ] but
- [ ] very
- [ ] big
- [ ] city
- [ ] small
- [ ] first
- [ ] first name
- [ ] last
- [ ] last name
- [ ] all
- [ ] aunt
- [ ] brother
- [ ] cousin
- [ ] daughter
- [ ] family

# Chapter 011

- [ ] father
- [ ] grandfather
- [ ] grandmother
- [ ] grandparent
- [ ] mother
- [ ] parent
- [ ] sister
- [ ] son
- [ ] uncle
- [ ] photo (= photograph)
- [ ] these
- [ ] they
- [ ] mum
- [ ] left
- [ ] on the left
- [ ] dad
- [ ] right
- [ ] on the right
- [ ] who
- [ ] woman

# Chapter 012

- [ ] next
- [ ] next to
- [ ] husband
- [ ] front
- [ ] in front of
- [ ] those
- [ ] bus
- [ ] station
- [ ] hospital
- [ ] hotel
- [ ] police
- [ ] theatre (AmE theater)
- [ ] actor
- [ ] driver
- [ ] manager
- [ ] nurse
- [ ] policeman
- [ ] we
- [ ] an
- [ ] job

# Chapter 013

- [ ] at
- [ ] same
- [ ] doctor
- [ ] farm
- [ ] worker
- [ ] man
- [ ] shop
- [ ] its
- [ ] their
- [ ] computer
- [ ] furniture
- [ ] map
- [ ] picture
- [ ] television (= TV)
- [ ] wall
- [ ] thirty
- [ ] forty
- [ ] fifty
- [ ] sixty
- [ ] seventy

# Chapter 014

- [ ] eighty
- [ ] ninety
- [ ] really
- [ ] many
- [ ] how many
- [ ] there
- [ ] lot
- [ ] a lot of
- [ ] oh
- [ ] any
- [ ] world
- [ ] tree
- [ ] building
- [ ] hall
- [ ] dining hall
- [ ] gate
- [ ] library
- [ ] office
- [ ] playground
- [ ] science

# Chapter 015

- [ ] lab (= laboratory)
- [ ] behind
- [ ] between
- [ ] middle
- [ ] near
- [ ] with
- [ ] for
- [ ] room
- [ ] food
- [ ] drink
- [ ] candy
- [ ] fruit
- [ ] meat
- [ ] vegetable
- [ ] apple
- [ ] bean
- [ ] beef
- [ ] carrot
- [ ] chicken
- [ ] chocolate

# Chapter 016

- [ ] coffee
- [ ] cola
- [ ] juice
- [ ] milk
- [ ] potato
- [ ] tea
- [ ] tomato
- [ ] water
- [ ] Shop
- [ ] go shopping
- [ ] have
- [ ] get
- [ ] have got
- [ ] some
- [ ] much
- [ ] too much
- [ ] kind
- [ ] lots of
- [ ] so
- [ ] How about ⋯?

# Chapter 017

- [ ] has
- [ ] bad
- [ ] healthy
- [ ] delicious
- [ ] bread
- [ ] fish
- [ ] hamburger
- [ ] ice cream
- [ ] noodle
- [ ] rice
- [ ] sugar
- [ ] eat
- [ ] child
- [ ] be good for
- [ ] sweet
- [ ] be bad for
- [ ] Right
- [ ] egg
- [ ] eye
- [ ] cheese

# Chapter 018

- [ ] tooth
- [ ] bit
- [ ] a bit
- [ ] tired
- [ ] soup
- [ ] important
- [ ] remember
- [ ] well
- [ ] stay
- [ ] fat
- [ ] get fat
- [ ] or
- [ ] breakfast
- [ ] every
- [ ] lunch
- [ ] home
- [ ] dinner
- [ ] banana
- [ ] buy
- [ ] half

# Chapter 019

- [ ] past
- [ ] o'clock
- [ ] To
- [ ] art
- [ ] geography
- [ ] history
- [ ] IT
- [ ] maths (AmE math)
- [ ] PE (= physical education)
- [ ] lesson
- [ ] then
- [ ] Like
- [ ] difficult
- [ ] love
- [ ] subject
- [ ] because
- [ ] interesting
- [ ] talk
- [ ] begin
- [ ] when

# Chapter 020

- [ ] go to school
- [ ] weekday
- [ ] get up
- [ ] have breakfast
- [ ] house
- [ ] start
- [ ] work
- [ ] break
- [ ] have lunch
- [ ] go home
- [ ] evening
- [ ] watch
- [ ] have dinner
- [ ] Do
- [ ] homework
- [ ] bed
- [ ] go to bed
- [ ] sleep
- [ ] go to sleep
- [ ] park

# Chapter 021

- [ ] busy
- [ ] wash
- [ ] face
- [ ] minute
- [ ] grandma
- [ ] grandpa
- [ ] him
- [ ] want
- [ ] make
- [ ] kitchen
- [ ] farmer
- [ ] week
- [ ] read
- [ ] story
- [ ] live
- [ ] bear
- [ ] elephant
- [ ] giraffe
- [ ] lion
- [ ] monkey

# Chapter 022

- [ ] panda
- [ ] tiger
- [ ] zebra
- [ ] zoo
- [ ] guide
- [ ] animal
- [ ] such
- [ ] as
- [ ] such as
- [ ] come
- [ ] come from
- [ ] different
- [ ] country
- [ ] other
- [ ] dangerous
- [ ] ugh
- [ ] also
- [ ] plant
- [ ] look
- [ ] look at

# Chapter 023

- [ ] tall
- [ ] sure
- [ ] bamboo
- [ ] cute
- [ ] shall
- [ ] them
- [ ] which
- [ ] over
- [ ] There
- [ ] over there
- [ ] funny
- [ ] call
- [ ] Africa
- [ ] Asia
- [ ] Europe
- [ ] little
- [ ] a little
- [ ] only
- [ ] About
- [ ] kilo (= kilogram)

# Chapter 024

- [ ] as well as
- [ ] people
- [ ] all over the world
- [ ] African
- [ ] leaf
- [ ] grass
- [ ] large
- [ ] usually
- [ ] alone
- [ ] be good at
- [ ] strong
- [ ] catch
- [ ] many kinds of
- [ ] even
- [ ] keyboard
- [ ] mouse
- [ ] screen
- [ ] connect
- [ ] turn
- [ ] turn on

# Chapter 025

- [ ] learn
- [ ] document
- [ ] click
- [ ] use
- [ ] save
- [ ] box
- [ ] finally
- [ ] print
- [ ] paper
- [ ] share
- [ ] Australia
- [ ] company
- [ ] often
- [ ] customer
- [ ] Internet
- [ ] check
- [ ] train
- [ ] travel
- [ ] plan
- [ ] ticket

# Chapter 026

- [ ] music
- [ ] movie
- [ ] night
- [ ] search
- [ ] search for
- [ ] information
- [ ] email
- [ ] send
- [ ] game
- [ ] sometimes
- [ ] cinema
- [ ] clothes
- [ ] visit
- [ ] holiday
- [ ] card
- [ ] party
- [ ] present
- [ ] would
- [ ] always
- [ ] great

# Chapter 027

- [ ] cake
- [ ] never
- [ ] special
- [ ] cut
- [ ] give
- [ ] sing
- [ ] happy
- [ ] secret
- [ ] ha ha
- [ ] CD
- [ ] concert
- [ ] magazine
- [ ] scarf
- [ ] silk
- [ ] dress
- [ ] T-shirt
- [ ] choose
- [ ] exercise
- [ ] wear
- [ ] expensive

# Chapter 028

- [ ] shoe
- [ ] spend
- [ ] money
- [ ] film
- [ ] song
- [ ] match
- [ ] weekend
- [ ] at weekends
- [ ] dear
- [ ] hear
- [ ] hear from
- [ ] afraid
- [ ] I'm afraid
- [ ] can't = cannot
- [ ] postcard
- [ ] Call
- [ ] lie
- [ ] sun
- [ ] line
- [ ] take

# Chapter 029

- [ ] take photos
- [ ] wait
- [ ] wait for
- [ ] walk
- [ ] trip
- [ ] few
- [ ] a few
- [ ] sale
- [ ] on sale
- [ ] enjoy
- [ ] anyway
- [ ] back
- [ ] go back
- [ ] drive
- [ ] off
- [ ] get off
- [ ] hot dog
- [ ] leave
- [ ] restaurant
- [ ] moment

# Chapter 030

- [ ] place
- [ ] thing
- [ ] most
- [ ] still
- [ ] star
- [ ] run
- [ ] study
- [ ] lantern
- [ ] dragon
- [ ] dance
- [ ] clean
- [ ] sweep
- [ ] floor
- [ ] cook
- [ ] meal
- [ ] speak
- [ ] happen
- [ ] ready
- [ ] get ready for
- [ ] festival

# Chapter 031

- [ ] quite
- [ ] at the moment
- [ ] beautiful
- [ ] at work
- [ ] away
- [ ] put away
- [ ] hard
- [ ] join
- [ ] hurry
- [ ] hurry up
- [ ] Christmas
- [ ] February
- [ ] January
- [ ] before
- [ ] sweep away
- [ ] luck
- [ ] table
- [ ] celebrate
- [ ] traditional
- [ ] dumpling

# Chapter 032

- [ ] programme (AmE program)
- [ ] sweater
- [ ] coat
- [ ] mean
- [ ] lucky
- [ ] merry
- [ ] Merry Christmas
- [ ] tell
- [ ] think


# Chapter 001

- [ ] California
- [ ] Californian
- [ ] illustrate
- [ ] distinct
- [ ] distinction
- [ ] immigrant
- [ ] live on
- [ ] strait
- [ ] Bering
- [ ] Arctic
- [ ] the Arctic
- [ ] means
- [ ] by means of…
- [ ] prehistoric
- [ ] majority
- [ ] ministry
- [ ] Catholic
- [ ] Alaska
- [ ] San Francisco
- [ ] adventurer

# Chapter 002

- [ ] make a life
- [ ] despite
- [ ] hardship
- [ ] elect
- [ ] federal
- [ ] rail
- [ ] percentage
- [ ] Los Angeles
- [ ] Italy
- [ ] Italian
- [ ] Denmark
- [ ] keep up
- [ ] Hollywood
- [ ] boom
- [ ] aircraft
- [ ] Cambodian
- [ ] Korea
- [ ] Korean
- [ ] Pakistan
- [ ] Pakistani

# Chapter 003

- [ ] immigrate
- [ ] immigration
- [ ] racial
- [ ] crossing
- [ ] vice
- [ ] nephew
- [ ] pole
- [ ] applicant
- [ ] customs
- [ ] socialist
- [ ] socialism
- [ ] occur
- [ ] cattle
- [ ] Hispanic
- [ ] indicate
- [ ] back to back
- [ ] luggage
- [ ] shave
- [ ] cable
- [ ] cable car

# Chapter 004

- [ ] Andrew Hallidie
- [ ] tram
- [ ] apparent
- [ ] apparently
- [ ] brake
- [ ] conductor
- [ ] slip
- [ ] wharf
- [ ] bakery
- [ ] ferry
- [ ] Angel Island
- [ ] team up with
- [ ] hire
- [ ] fascinating
- [ ] mark out
- [ ] seagull
- [ ] take in
- [ ] angle
- [ ] a great many
- [ ] a good many

# Chapter 005

- [ ] apply for
- [ ] nowhere
- [ ] miserable
- [ ] punishment
- [ ] justice
- [ ] mourn
- [ ] civil
- [ ] authority
- [ ] reform
- [ ] grasp
- [ ] thoughtful
- [ ] thankful
- [ ] insert
- [ ] differ
- [ ] exact
- [ ] cutting
- [ ] twin
- [ ] identical
- [ ] commercial
- [ ] straightforward

# Chapter 006

- [ ] complicated
- [ ] undertake
- [ ] pay off
- [ ] breakthrough
- [ ] procedure
- [ ] nucleus
- [ ] somatic
- [ ] embryo
- [ ] carrier
- [ ] cast
- [ ] cast down
- [ ] altogether
- [ ] arbitrary
- [ ] fate
- [ ] correction
- [ ] object
- [ ] objection
- [ ] impact
- [ ] medium
- [ ] the media

# Chapter 007

- [ ] obtain
- [ ] attain
- [ ] moral
- [ ] conservative
- [ ] forbid
- [ ] accumulate
- [ ] in favour of
- [ ] side road
- [ ] constitution
- [ ] compulsory
- [ ] opera
- [ ] chorus
- [ ] loaf
- [ ] flour
- [ ] owe
- [ ] shortly
- [ ] retire
- [ ] bother
- [ ] (be) bound to (do)
- [ ] assumption

# Chapter 008

- [ ] regulation
- [ ] nonsense
- [ ] popularity
- [ ] Jurassic Park
- [ ] strike
- [ ] strike…into one’s heart
- [ ] bison
- [ ] calf
- [ ] from time to time
- [ ] bring back to life
- [ ] initial
- [ ] DNA
- [ ] vain
- [ ] in vain
- [ ] resist
- [ ] drawback
- [ ] merely
- [ ] restore
- [ ] aurochs
- [ ] decoration

# Chapter 009

- [ ] unable
- [ ] great auk
- [ ] feather
- [ ] quagga
- [ ] fairly
- [ ] in good condition
- [ ] in poor condition
- [ ] turkey
- [ ] dye
- [ ] claw
- [ ] adore
- [ ] hatch
- [ ] reasonable
- [ ] amphibious
- [ ] George Stephenson
- [ ] patent
- [ ] call up
- [ ] courtyard
- [ ] now and then
- [ ] walnut

# Chapter 010

- [ ] distinguish
- [ ] merciful
- [ ] product
- [ ] powder
- [ ] set about
- [ ] perfume
- [ ] stainless
- [ ] jelly
- [ ] cube
- [ ] cubic
- [ ] abrupt
- [ ] abruptly
- [ ] convenient
- [ ] caution
- [ ] expectation
- [ ] passive
- [ ] merry
- [ ] merrily
- [ ] seize
- [ ] recognition

# Chapter 011

- [ ] criterion
- [ ] claim
- [ ] valid
- [ ] file
- [ ] ripe
- [ ] string
- [ ] glue
- [ ] rod
- [ ] freezing
- [ ] greengrocer
- [ ] identification
- [ ] directory
- [ ] dial
- [ ] rainfall
- [ ] courtroom
- [ ] innocent
- [ ] lantern
- [ ] bear
- [ ] jam
- [ ] Alexander Graham

# Chapter 012

- [ ] microphone
- [ ] forehead
- [ ] beaten track
- [ ] occasionally
- [ ] dive into
- [ ] dynamic
- [ ] set out (to do)
- [ ] multiple
- [ ] Morse
- [ ] dot
- [ ] tap
- [ ] wire
- [ ] straw
- [ ] reproduce
- [ ] current
- [ ] helicopter
- [ ] triangle
- [ ] tetrahedron
- [ ] stable
- [ ] invaluable

# Chapter 013

- [ ] associate
- [ ] practical
- [ ] James Dyson
- [ ] refrigerator
- [ ] court
- [ ] extension
- [ ] hang on
- [ ] out of order
- [ ] get through
- [ ] ring back
- [ ] ring off
- [ ] version
- [ ] competence
- [ ] competent
- [ ] jeep
- [ ] personnel
- [ ] Pygmalion
- [ ] George Bernard Shaw
- [ ] adaptation
- [ ] classic

# Chapter 014

- [ ] caption
- [ ] plot
- [ ] professor
- [ ] Higgins
- [ ] phonetics
- [ ] colonel
- [ ] Pickering
- [ ] fateful
- [ ] whistle
- [ ] garment
- [ ] woollen
- [ ] hesitate
- [ ] uncomfortable
- [ ] uncomfortably
- [ ] troublesome
- [ ] wallet
- [ ] outcome
- [ ] thief
- [ ] handkerchief
- [ ] disguise

# Chapter 015

- [ ] in disguise
- [ ] mistaken
- [ ] brilliant
- [ ] classify
- [ ] remark
- [ ] betray
- [ ] upper
- [ ] extraordinary
- [ ] condemn
- [ ] gutter
- [ ] properly
- [ ] pass…off as…
- [ ] duchess
- [ ] ambassador
- [ ] acquaintance
- [ ] make one’s acquaintance
- [ ] handful
- [ ] amazement
- [ ] in amazement
- [ ] fortune

# Chapter 016

- [ ] authentic
- [ ] generally speaking
- [ ] status
- [ ] superior
- [ ] in terms of…
- [ ] disapprove
- [ ] rob
- [ ] antique
- [ ] musical
- [ ] stocking
- [ ] believer
- [ ] Buddhism
- [ ] Buddhist
- [ ] Buddha
- [ ] vowel
- [ ] Pearce
- [ ] cookie
- [ ] teapot
- [ ] cream
- [ ] nail

# Chapter 017

- [ ] show…in
- [ ] wax
- [ ] disk
- [ ] wax disk
- [ ] shabby
- [ ] curtsy
- [ ] shilling
- [ ] referee
- [ ] compromise
- [ ] horrible
- [ ] laundry
- [ ] bathtub
- [ ] sob
- [ ] waist
- [ ] vest
- [ ] disgusting
- [ ] once more
- [ ] in need of
- [ ] heartily
- [ ] overlook

# Chapter 018

- [ ] alphabet
- [ ] effective
- [ ] fade
- [ ] fade out
- [ ] identify
- [ ] alternative
- [ ] archaeology
- [ ] archaeological
- [ ] archaeologist
- [ ] starvation
- [ ] tentative
- [ ] accuracy
- [ ] excavate
- [ ] excavation
- [ ] interrupt
- [ ] acute
- [ ] assume
- [ ] regardless
- [ ] regardless of
- [ ] mat

# Chapter 019

- [ ] quilt
- [ ] beast
- [ ] at most
- [ ] centimetre
- [ ] sharpen
- [ ] sharpener
- [ ] cut up
- [ ] scrape
- [ ] scraper
- [ ] ample
- [ ] messy
- [ ] primitive
- [ ] bead
- [ ] botany
- [ ] botanical
- [ ] analysis
- [ ] seashell
- [ ] ripen
- [ ] category
- [ ] significance

# Chapter 020

- [ ] somehow
- [ ] systematic
- [ ] spit
- [ ] delete
- [ ] album
- [ ] scratch
- [ ] academy
- [ ] receptionist
- [ ] onion
- [ ] kindergarten
- [ ] skateboard
- [ ] fed up with
- [ ] yogurt
- [ ] radioactive
- [ ] radioactivity
- [ ] division
- [ ] BC
- [ ] melon
- [ ] wrinkle
- [ ] pulse

# Chapter 021

- [ ] vein
- [ ] applaud
- [ ] look ahead
- [ ] howl
- [ ] accelerate
- [ ] spear
- [ ] arrest
- [ ] dizzy
- [ ] eyebrow
- [ ] cheekbone
- [ ] arrowhead
- [ ] axe
- [ ] hammer
- [ ] gay
- [ ] gaily
- [ ] skilful
- [ ] date back
- [ ] punctuation
- [ ] worship
- [ ] craftsmanship

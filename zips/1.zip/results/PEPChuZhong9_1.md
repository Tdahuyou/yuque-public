
# Chapter 001

- [ ] textbook
- [ ] conversation
- [ ] aloud
- [ ] pronunciation
- [ ] sentence
- [ ] patient
- [ ] expression
- [ ] discover
- [ ] secret
- [ ] fall in love with
- [ ] grammar
- [ ] repeat
- [ ] note
- [ ] pal
- [ ] pattern
- [ ] physics
- [ ] chemistry
- [ ] partner
- [ ] pronounce
- [ ] increase

# Chapter 002

- [ ] speed
- [ ] ability
- [ ] brain
- [ ] active
- [ ] attention
- [ ] pay attention to
- [ ] connect
- [ ] connect … with
- [ ] overnight
- [ ] review
- [ ] knowledge
- [ ] wisely
- [ ] Annie
- [ ] Alexander Graham Bell
- [ ] lantern
- [ ] stranger
- [ ] relative
- [ ] put on
- [ ] pound
- [ ] folk

# Chapter 003

- [ ] goddess
- [ ] steal
- [ ] lay
- [ ] lay out
- [ ] dessert
- [ ] garden
- [ ] admire
- [ ] tie
- [ ] haunted
- [ ] ghost
- [ ] trick
- [ ] treat
- [ ] spider
- [ ] Christmas
- [ ] fool
- [ ] lie
- [ ] novel
- [ ] eve
- [ ] bookstore
- [ ] dead

# Chapter 004

- [ ] business
- [ ] punish
- [ ] warn
- [ ] present
- [ ] nobody
- [ ] warmth
- [ ] spread
- [ ] Macao
- [ ] Chiang Mai
- [ ] Halloween
- [ ] Valentine’s Day
- [ ] Clara
- [ ] Santa
- [ ] Charles  Dickens
- [ ] Scrooge
- [ ] Jacob   Marley
- [ ] restroom
- [ ] stamp
- [ ] postcard
- [ ] pardon

# Chapter 005

- [ ] washroom
- [ ] bathroom
- [ ] quick
- [ ] rush
- [ ] suggest
- [ ] staff
- [ ] grape
- [ ] central
- [ ] mail
- [ ] east
- [ ] fascinating
- [ ] convenient
- [ ] mall
- [ ] clerk
- [ ] corner
- [ ] polite
- [ ] politely
- [ ] speaker
- [ ] request
- [ ] choice

# Chapter 006

- [ ] direction
- [ ] correct
- [ ] direct
- [ ] whom
- [ ] address
- [ ] faithfully
- [ ] Italian
- [ ] Kevin
- [ ] Tim
- [ ] humorous
- [ ] silent
- [ ] helpful
- [ ] from time to time
- [ ] score
- [ ] background
- [ ] interview
- [ ] Asian
- [ ] deal with
- [ ] dare
- [ ] private

# Chapter 007

- [ ] guard
- [ ] require
- [ ] European
- [ ] British
- [ ] speech
- [ ] ant
- [ ] insect
- [ ] influence
- [ ] seldom
- [ ] proud
- [ ] be proud of
- [ ] absent
- [ ] fail
- [ ] examination
- [ ] boarding school
- [ ] leaf
- [ ] in person
- [ ] exactly
- [ ] pride
- [ ] take pride in

# Chapter 008

- [ ] grandson
- [ ] general
- [ ] introduction
- [ ] Paula
- [ ] Alfred
- [ ] Billy
- [ ] Candy
- [ ] Jerry
- [ ] Emily
- [ ] material
- [ ] chopsticks
- [ ] coin
- [ ] fork
- [ ] blouse
- [ ] sliver
- [ ] glass
- [ ] cotton
- [ ] steel
- [ ] grass
- [ ] leaf.

# Chapter 009

- [ ] produce
- [ ] widely
- [ ] process
- [ ] France
- [ ] no matter
- [ ] local
- [ ] even though
- [ ] brand
- [ ] avoid
- [ ] product
- [ ] handbag
- [ ] mobile
- [ ] Germany
- [ ] surface
- [ ] postman
- [ ] cap
- [ ] glove
- [ ] international
- [ ] competitor
- [ ] paint

# Chapter 010

- [ ] its
- [ ] form
- [ ] clay
- [ ] balloon
- [ ] scissors
- [ ] lively
- [ ] fairy
- [ ] heat
- [ ] polish
- [ ] complete
- [ ] Korea
- [ ] Switzerland
- [ ] San Francisco
- [ ] Pam
- [ ] heel
- [ ] electricity
- [ ] scoop
- [ ] style
- [ ] project
- [ ] pleasure

# Chapter 011

- [ ] zipper
- [ ] daily
- [ ] website
- [ ] pioneer
- [ ] list
- [ ] mention
- [ ] by accident
- [ ] nearly
- [ ] boil
- [ ] smell
- [ ] saint
- [ ] take place
- [ ] doubt
- [ ] without doubt
- [ ] fridge
- [ ] translate
- [ ] lock
- [ ] earthquake
- [ ] sudden
- [ ] all of a sudden

# Chapter 012

- [ ] biscuit
- [ ] cookie
- [ ] instrument
- [ ] crispy
- [ ] sour
- [ ] by mistake
- [ ] customer
- [ ] Canadian
- [ ] divide
- [ ] divide ... into
- [ ] purpose
- [ ] basket
- [ ] the Olympics
- [ ] look up to
- [ ] hero
- [ ] Berlin
- [ ] NBA
- [ ] CBA
- [ ] Chelsea Lanmon
- [ ] Jayce  Coziar

# Chapter 013

- [ ] Jamie Ellsworth
- [ ] Julie   Thompson
- [ ] Whitcomb   Judson
- [ ] Thomas  Watson
- [ ] George   Crum
- [ ] James  Naismith
- [ ] smoke
- [ ] pierce
- [ ] license
- [ ] safety
- [ ] earring
- [ ] cry
- [ ] field
- [ ] hug
- [ ] lift
- [ ] talk back
- [ ] awful
- [ ] teen
- [ ] regret
- [ ] poem

# Chapter 014

- [ ] bedroom
- [ ] community
- [ ] keep away from
- [ ] chance
- [ ] make one’s own decision
- [ ] manage
- [ ] society
- [ ] unit
- [ ] educate
- [ ] get in the way of
- [ ] professional
- [ ] enter
- [ ] support
- [ ] Picasso
- [ ] truck
- [ ] rabbit
- [ ] whose
- [ ] attend
- [ ] valuable
- [ ] pink

# Chapter 015

- [ ] picnic
- [ ] somebody
- [ ] anybody
- [ ] noise
- [ ] policeman
- [ ] wolf
- [ ] laboratory
- [ ] coat
- [ ] sleepy
- [ ] pocket
- [ ] alien
- [ ] suit
- [ ] express
- [ ] not only … but also
- [ ] circle
- [ ] Britain
- [ ] receive
- [ ] leader
- [ ] midsummer
- [ ] medical

# Chapter 016

- [ ] prevent
- [ ] energy
- [ ] position
- [ ] burial
- [ ] honor
- [ ] ancestor
- [ ] victory
- [ ] enemy
- [ ] period
- [ ] mystery
- [ ] Stonehenge
- [ ] Carla
- [ ] J. K. Rowling
- [ ] Victor
- [ ] Jean
- [ ] Paul Stoker
- [ ] prefer
- [ ] lyrics
- [ ] Australian
- [ ] electronic

# Chapter 017

- [ ] suppose
- [ ] smooth
- [ ] spare
- [ ] case
- [ ] in that case
- [ ] war
- [ ] director
- [ ] dialogue
- [ ] documentary
- [ ] drama
- [ ] plenty
- [ ] plenty of
- [ ] shut
- [ ] superhero
- [ ] horror
- [ ] thriller
- [ ] intelligent
- [ ] sense
- [ ] pain
- [ ] reflect

# Chapter 018

- [ ] perform
- [ ] amazing
- [ ] pity
- [ ] total
- [ ] in total
- [ ] master
- [ ] praise
- [ ] national
- [ ] recall
- [ ] wound
- [ ] World War II
- [ ] Titanic
- [ ] Carmen
- [ ] Dan
- [ ] custom
- [ ] bow
- [ ] kiss
- [ ] greet
- [ ] value
- [ ] everyday

# Chapter 019

- [ ] drop by
- [ ] capital
- [ ] noon
- [ ] mad
- [ ] get mad
- [ ] make an effort
- [ ] traffic
- [ ] somewhere
- [ ] passport
- [ ] chalk
- [ ] blackboard
- [ ] northern
- [ ] coast
- [ ] season
- [ ] knock
- [ ] eastern
- [ ] worth
- [ ] manner
- [ ] empty
- [ ] basic

# Chapter 020

- [ ] exchange
- [ ] go out of one’s way
- [ ] make ... feel at home
- [ ] granddaughter
- [ ] behave
- [ ] except
- [ ] elbow
- [ ] gradually
- [ ] suggestion
- [ ] Brazil
- [ ] Mexico
- [ ] Cali
- [ ] Colombia  VmbI
- [ ] Lausanne
- [ ] Norway
- [ ] Maria
- [ ] Katie
- [ ] Sato
- [ ] Marie
- [ ] Teresa Lopez Upez

# Chapter 021

- [ ] Marc LeBlanc
- [ ] the more … the more
- [ ] leave out
- [ ] friendship
- [ ] king
- [ ] prime
- [ ] minister
- [ ] prime minister
- [ ] fame
- [ ] pale
- [ ] queen
- [ ] examine
- [ ] nor
- [ ] neither ... nor
- [ ] palace
- [ ] power
- [ ] wealth
- [ ] grey
- [ ] lemon
- [ ] cancel

# Chapter 022

- [ ] weight
- [ ] shoulder
- [ ] goal
- [ ] coach
- [ ] kick
- [ ] teammate
- [ ] courage
- [ ] rather
- [ ] rather than
- [ ] pull
- [ ] pull together
- [ ] relief
- [ ] nod
- [ ] agreement
- [ ] fault
- [ ] disappoint
- [ ] Bert
- [ ] Holly
- [ ] backpack
- [ ] oversleep

# Chapter 023

- [ ] give ... a lift
- [ ] miss
- [ ] unexpected
- [ ] block
- [ ] worker
- [ ] stare
- [ ] disbelief
- [ ] above
- [ ] burn
- [ ] alive
- [ ] take off
- [ ] till
- [ ] west
- [ ] cream
- [ ] boss
- [ ] pie
- [ ] course
- [ ] bean
- [ ] market
- [ ] costume

# Chapter 024

- [ ] embarrassed
- [ ] announce
- [ ] spaghetti
- [ ] hoax
- [ ] discovery
- [ ] lady
- [ ] officer
- [ ] believable
- [ ] embarrassing
- [ ] New Zealand
- [ ] Italy
- [ ] Mars
- [ ] Carl
- [ ] Orson
- [ ] litter
- [ ] bottom
- [ ] fisherman
- [ ] coal
- [ ] public
- [ ] ugly

# Chapter 025

- [ ] advantage
- [ ] cost
- [ ] wooden
- [ ] plastic
- [ ] make a difference
- [ ] shark
- [ ] fin
- [ ] cut off
- [ ] method
- [ ] cruel
- [ ] harmful
- [ ] chain
- [ ] ecosystem
- [ ] low
- [ ] industry
- [ ] law
- [ ] reusable
- [ ] afford
- [ ] transportation
- [ ] recycle

# Chapter 026

- [ ] napkin
- [ ] upside down
- [ ] gate
- [ ] bottle
- [ ] president
- [ ] inspiration
- [ ] metal
- [ ] creativity
- [ ] WildAid
- [ ] WWF
- [ ] Mark
- [ ] Jason
- [ ] Ken
- [ ] Hayes
- [ ] Jessica
- [ ] Survey
- [ ] standard
- [ ] row
- [ ] in a row
- [ ] keyboard

# Chapter 027

- [ ] instruction
- [ ] double
- [ ] shall
- [ ] overcome
- [ ] make a mess
- [ ] graduate
- [ ] keep one’s cool
- [ ] ours
- [ ] senior
- [ ] senior high (school)
- [ ] text
- [ ] level
- [ ] degree
- [ ] manager
- [ ] believe in
- [ ] gentleman
- [ ] graduation
- [ ] ceremony
- [ ] congratulate
- [ ] thirsty

# Chapter 028

- [ ] none
- [ ] task
- [ ] ahead
- [ ] responsible
- [ ] be responsible for
- [ ] separate
- [ ] wing
- [ ] Brian
- [ ] Luke
- [ ] Griffin
- [ ] Trent

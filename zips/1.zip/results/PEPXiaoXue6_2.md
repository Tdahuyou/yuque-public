
# Chapter 001

- [ ] younger
- [ ] older
- [ ] taller
- [ ] shorter
- [ ] longer
- [ ] thinner
- [ ] heavier
- [ ] bigger
- [ ] smaller
- [ ] stronger
- [ ] dinosaur
- [ ] hall
- [ ] metre
- [ ] meter
- [ ] than
- [ ] both
- [ ] kilogram
- [ ] countryside
- [ ] lower
- [ ] shadow

# Chapter 002

- [ ] smarter
- [ ] become
- [ ] cleaned
- [ ] stayed
- [ ] washed
- [ ] watched
- [ ] had
- [ ] had a cold
- [ ] slept
- [ ] read
- [ ] saw
- [ ] last
- [ ] yesterday
- [ ] before
- [ ] drank
- [ ] show
- [ ] magazine
- [ ] better
- [ ] faster
- [ ] hotel

# Chapter 003

- [ ] fixed
- [ ] broken
- [ ] lamp
- [ ] loud
- [ ] enjoy
- [ ] stay
- [ ] went
- [ ] camp
- [ ] went camping
- [ ] fish
- [ ] went fishing
- [ ] rode
- [ ] hurt
- [ ] ate
- [ ] took
- [ ] took pictures
- [ ] bought
- [ ] gift
- [ ] fell
- [ ] off

# Chapter 004

- [ ] Labour Day
- [ ] mule
- [ ] Turpan
- [ ] could
- [ ] till
- [ ] beach
- [ ] basket
- [ ] part
- [ ] licked
- [ ] laughed
- [ ] dining hall
- [ ] grass
- [ ] gym
- [ ] ago
- [ ] cycling
- [ ] go cycling
- [ ] ice-skate
- [ ] badminton
- [ ] star
- [ ] easy

# Chapter 005

- [ ] look up
- [ ] Internet
- [ ] different
- [ ] active
- [ ] race
- [ ] nothing
- [ ] thought
- [ ] felt
- [ ] cheetah
- [ ] trip
- [ ] woke
- [ ] dream
- [ ] straight
- [ ] right
- [ ] ask
- [ ] sir
- [ ] interesting
- [ ] Italian
- [ ] restaurant
- [ ] pizza

# Chapter 006

- [ ] street
- [ ] get
- [ ] GPS
- [ ] gave
- [ ] feature
- [ ] follow
- [ ] far
- [ ] tell

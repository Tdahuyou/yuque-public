
# Chapter 001

- [ ] consistent
- [ ] battery
- [ ] competent
- [ ] preserve
- [ ] possession
- [ ] proximately
- [ ] wildfire
- [ ] compact
- [ ] defy
- [ ] absolutely
- [ ] filter
- [ ] server
- [ ] spoil
- [ ] rustle
- [ ] diversion
- [ ] complaint
- [ ] merge
- [ ] priceless
- [ ] honorary
- [ ] chronic

# Chapter 002

- [ ] extracurricular
- [ ] lobby
- [ ] inexhaustible
- [ ] inevitable
- [ ] contamination
- [ ] suspend
- [ ] imminent
- [ ] obesity
- [ ] aid
- [ ] solution
- [ ] tuition
- [ ] esteem
- [ ] purchase
- [ ] incorporate
- [ ] prevail
- [ ] irrational
- [ ] inherent
- [ ] overexcited
- [ ] preference
- [ ] evolution

# Chapter 003

- [ ] exotic
- [ ] stockbroker
- [ ] misinterpret
- [ ] prosperity
- [ ] tank
- [ ] outdated
- [ ] outnumber
- [ ] supervisor
- [ ] fluctuate
- [ ] substance
- [ ] profitable
- [ ] markedly
- [ ] ineffective
- [ ] bleak
- [ ] optimistic
- [ ] ultimate
- [ ] consumption
- [ ] foster
- [ ] receipt
- [ ] harsh

# Chapter 004

- [ ] misfortune
- [ ] citation
- [ ] rape
- [ ] ecological
- [ ] lag
- [ ] controversy
- [ ] cornerstone
- [ ] erect
- [ ] prematurely
- [ ] initiative
- [ ] dilute
- [ ] viewpoint
- [ ] typical
- [ ] stray
- [ ] imbalance
- [ ] affiliation
- [ ] counterpart
- [ ] classify
- [ ] demonstration
- [ ] outlive

# Chapter 005

- [ ] reservation
- [ ] circumstance
- [ ] revolutionize
- [ ] outweigh
- [ ] cast
- [ ] uncertain
- [ ] threat
- [ ] conservative
- [ ] overestimate
- [ ] documentary
- [ ] relieve
- [ ] regardless
- [ ] pause
- [ ] launch
- [ ] apartment
- [ ] spark
- [ ] eliminate
- [ ] unintentionally
- [ ] opposition
- [ ] polar

# Chapter 006

- [ ] integral
- [ ] guard
- [ ] branch
- [ ] affiliate
- [ ] irrigation
- [ ] stove
- [ ] memorable
- [ ] elimination
- [ ] revenue
- [ ] decisive
- [ ] displace
- [ ] violation
- [ ] ideological
- [ ] neighborhood
- [ ] calorie
- [ ] fierce
- [ ] mention
- [ ] extend
- [ ] column
- [ ] analytical

# Chapter 007

- [ ] figure
- [ ] frighten
- [ ] preindustrial
- [ ] furnish
- [ ] scarcity
- [ ] transform
- [ ] misled
- [ ] intervene
- [ ] vary
- [ ] bureaucracy
- [ ] recruiter
- [ ] pattern
- [ ] necessity
- [ ] deny
- [ ] drift
- [ ] endorsement
- [ ] dare
- [ ] consultancy
- [ ] constant
- [ ] deposit

# Chapter 008

- [ ] transmit
- [ ] undermine
- [ ] resign
- [ ] respective
- [ ] consent
- [ ] reunion
- [ ] premium
- [ ] interpretation
- [ ] concrete
- [ ] facility
- [ ] convert
- [ ] prompt
- [ ] weave
- [ ] conformity
- [ ] inaction
- [ ] trim
- [ ] irony
- [ ] monopolize
- [ ] workload
- [ ] complicated

# Chapter 009

- [ ] property
- [ ] underrepresented
- [ ] philosophy
- [ ] regime
- [ ] bizarre
- [ ] ruin
- [ ] inspire
- [ ] deforestation
- [ ] exceptional
- [ ] hazard
- [ ] upgrade
- [ ] abnormally
- [ ] accidentally
- [ ] frontier
- [ ] considerable
- [ ] legalize
- [ ] dispensable
- [ ] certify
- [ ] insurer
- [ ] overstate

# Chapter 010

- [ ] profound
- [ ] agony
- [ ] craft
- [ ] obscurity
- [ ] guarantee
- [ ] dolphin
- [ ] severity
- [ ] discourage
- [ ] fault
- [ ] robbery
- [ ] inanimate
- [ ] calculation
- [ ] baffle
- [ ] overcharge
- [ ] nap
- [ ] disposal
- [ ] authorities
- [ ] chronicle
- [ ] shade
- [ ] milestone

# Chapter 011

- [ ] unstable
- [ ] strain
- [ ] municipal
- [ ] ideologically
- [ ] greedy
- [ ] robust
- [ ] diagnose
- [ ] definite
- [ ] reserved
- [ ] affection
- [ ] material
- [ ] conduct
- [ ] association
- [ ] collide
- [ ] industrious
- [ ] fascinate
- [ ] prevalence
- [ ] exert
- [ ] minor
- [ ] tempting

# Chapter 012

- [ ] appropriation
- [ ] injustice
- [ ] irrelevant
- [ ] registration
- [ ] democracy
- [ ] grateful
- [ ] offense
- [ ] atmosphere
- [ ] approach
- [ ] rival
- [ ] commitment
- [ ] furious
- [ ] accurate
- [ ] abstract
- [ ] deprivation
- [ ] designate
- [ ] turtle
- [ ] expertise
- [ ] vessel
- [ ] ventilate

# Chapter 013

- [ ] trade-off
- [ ] endless
- [ ] temptation
- [ ] legislation
- [ ] duplication
- [ ] trick
- [ ] evaluation
- [ ] abandonment
- [ ] turbulent
- [ ] expel
- [ ] carpenter
- [ ] hasty
- [ ] unprecedented
- [ ] extreme
- [ ] outperform
- [ ] modernize
- [ ] interactive
- [ ] successively
- [ ] innovation
- [ ] elaborately

# Chapter 014

- [ ] vegetarian
- [ ] faculty
- [ ] render
- [ ] portray
- [ ] notion
- [ ] tropical
- [ ] character
- [ ] infectious
- [ ] lawn
- [ ] permanent
- [ ] transcend
- [ ] kidnap
- [ ] dominate
- [ ] stabilize
- [ ] consult
- [ ] resume
- [ ] migrate
- [ ] isolation
- [ ] derive
- [ ] conservation

# Chapter 015

- [ ] incidence
- [ ] perpetual
- [ ] pessimistic
- [ ] crew
- [ ] mourn
- [ ] vice
- [ ] shot
- [ ] virus
- [ ] dorm
- [ ] erupt
- [ ] impact
- [ ] index
- [ ] claim
- [ ] embrace
- [ ] enviable
- [ ] blouse
- [ ] deliver
- [ ] rhythm
- [ ] code
- [ ] monopoly

# Chapter 016

- [ ] interfere
- [ ] contestant
- [ ] ridiculous
- [ ] glamorous
- [ ] mall
- [ ] chronically
- [ ] prolonged
- [ ] symptom
- [ ] compelling
- [ ] immensely
- [ ] species
- [ ] battle
- [ ] conflict
- [ ] permeate
- [ ] erroneous
- [ ] compartment
- [ ] metropolitan
- [ ] grip
- [ ] crush
- [ ] prior

# Chapter 017

- [ ] formula
- [ ] inescapable
- [ ] skeptical
- [ ] harness
- [ ] destination
- [ ] vocational
- [ ] density
- [ ] variance
- [ ] landmark
- [ ] linger
- [ ] luxurious
- [ ] astronomical
- [ ] coordination
- [ ] currency
- [ ] blame
- [ ] dismiss
- [ ] testify
- [ ] qualify
- [ ] inquire
- [ ] emphasize

# Chapter 018

- [ ] overwhelming
- [ ] flame
- [ ] imitate
- [ ] handle
- [ ] drought
- [ ] drummer
- [ ] revive
- [ ] vulnerable
- [ ] spot
- [ ] suppress
- [ ] diminish
- [ ] reconcile
- [ ] artificial
- [ ] athletic
- [ ] confrontational
- [ ] row
- [ ] navigate
- [ ] panic
- [ ] hostile
- [ ] console

# Chapter 019

- [ ] endanger
- [ ] prospect
- [ ] discern
- [ ] judicial
- [ ] impair
- [ ] motel
- [ ] signal
- [ ] therapy
- [ ] diverse
- [ ] conserve
- [ ] adaptation
- [ ] resist
- [ ] convince
- [ ] burden
- [ ] payroll
- [ ] unified
- [ ] hasten
- [ ] intertwine
- [ ] accommodate
- [ ] prescribe

# Chapter 020

- [ ] construction
- [ ] endure
- [ ] election
- [ ] jury
- [ ] glory
- [ ] sew
- [ ] sector
- [ ] hazardous
- [ ] deprive
- [ ] generous
- [ ] constrain
- [ ] phenomenon
- [ ] assume
- [ ] conscientious
- [ ] concession
- [ ] suspect
- [ ] sample
- [ ] penalty
- [ ] representative
- [ ] soothe

# Chapter 021

- [ ] entail
- [ ] objective
- [ ] submit
- [ ] identify
- [ ] infect
- [ ] burial
- [ ] genius
- [ ] submerge
- [ ] stereotype
- [ ] clarify
- [ ] conversion
- [ ] resident
- [ ] aspect
- [ ] apologize
- [ ] decent
- [ ] fixture
- [ ] institution
- [ ] scent
- [ ] welfare
- [ ] subsidy

# Chapter 022

- [ ] superficial
- [ ] private
- [ ] conventional
- [ ] wonder
- [ ] tedious
- [ ] subordinate
- [ ] frame
- [ ] smuggle
- [ ] reimbursement
- [ ] disappear
- [ ] inhale
- [ ] majority
- [ ] memorize
- [ ] cumulative
- [ ] trap
- [ ] lofty
- [ ] clarity
- [ ] interact
- [ ] refine
- [ ] confer

# Chapter 023

- [ ] anonymous
- [ ] commentator
- [ ] keen
- [ ] enforce
- [ ] grocery
- [ ] spread
- [ ] recruit
- [ ] justified
- [ ] eccentric
- [ ] bridge
- [ ] neglect
- [ ] principle
- [ ] stain
- [ ] encourage
- [ ] convincing
- [ ] indiscriminately
- [ ] resolute
- [ ] indicative
- [ ] perish
- [ ] philosopher

# Chapter 024

- [ ] recipe
- [ ] excessive
- [ ] rigor
- [ ] deficient
- [ ] incompetence
- [ ] entitle
- [ ] adventurer
- [ ] quicken
- [ ] divert
- [ ] recommend
- [ ] incalculable
- [ ] outcome
- [ ] scaffolding
- [ ] garage
- [ ] domestic
- [ ] cultivate
- [ ] formulate
- [ ] shed
- [ ] worldwide
- [ ] fuss

# Chapter 025

- [ ] contention
- [ ] hijack
- [ ] dweller
- [ ] buck
- [ ] view
- [ ] pronoun
- [ ] contribution
- [ ] undecided
- [ ] restrict
- [ ] reverse
- [ ] grasp
- [ ] provoke
- [ ] texture
- [ ] publicity
- [ ] format
- [ ] indifferent
- [ ] incentive
- [ ] prejudice
- [ ] assumption
- [ ] habitual

# Chapter 026

- [ ] sculpture
- [ ] responsibility
- [ ] manuscript
- [ ] duplicate
- [ ] ecosystem
- [ ] humorous
- [ ] contaminate
- [ ] orbit
- [ ] evolve
- [ ] skyrocket
- [ ] portion
- [ ] cautious
- [ ] assassinate
- [ ] narrow
- [ ] botanical
- [ ] conquer
- [ ] regain
- [ ] composition
- [ ] stress
- [ ] yield

# Chapter 027

- [ ] spectacle
- [ ] host
- [ ] release
- [ ] malicious
- [ ] prevailing
- [ ] gratitude
- [ ] mobility
- [ ] ascend
- [ ] fake
- [ ] inflation
- [ ] plot
- [ ] manufacture
- [ ] criticism
- [ ] outsource
- [ ] obstacle
- [ ] appreciative
- [ ] predominantly
- [ ] invasion
- [ ] detect
- [ ] addict

# Chapter 028

- [ ] slash
- [ ] cognitive
- [ ] extinguish
- [ ] disadvantage
- [ ] alien
- [ ] barely
- [ ] simulate
- [ ] prospective
- [ ] interaction
- [ ] materialize
- [ ] contribute
- [ ] dishonest
- [ ] appeal
- [ ] applicant
- [ ] intelligent
- [ ] spacious
- [ ] fatal
- [ ] counselor
- [ ] potential
- [ ] assimilate

# Chapter 029

- [ ] cropland
- [ ] relieved
- [ ] compel
- [ ] program
- [ ] capacity
- [ ] orient
- [ ] undertaking
- [ ] shift
- [ ] liberation
- [ ] utterly
- [ ] immense
- [ ] inferior
- [ ] accrue
- [ ] genuine
- [ ] nominate
- [ ] distinctive
- [ ] mismanagement
- [ ] reckon
- [ ] mask
- [ ] forge

# Chapter 030

- [ ] identical
- [ ] imperial
- [ ] target
- [ ] disconnect
- [ ] immigrant
- [ ] unqualified
- [ ] edit
- [ ] govern
- [ ] assert
- [ ] breezy
- [ ] hesitate
- [ ] presidency
- [ ] quota
- [ ] dropout
- [ ] capture
- [ ] integrity
- [ ] flee
- [ ] certification
- [ ] instant
- [ ] criminal

# Chapter 031

- [ ] clue
- [ ] arrogant
- [ ] elevate
- [ ] expansion
- [ ] authority
- [ ] publicize
- [ ] reflective
- [ ] quantity
- [ ] acutely
- [ ] isolate
- [ ] vigorous
- [ ] counsel
- [ ] vivid
- [ ] hostility
- [ ] collaborate
- [ ] consultation
- [ ] transition
- [ ] deteriorate
- [ ] pasture
- [ ] eyewitness

# Chapter 032

- [ ] trait
- [ ] anticipate
- [ ] numerous
- [ ] combination
- [ ] slightly
- [ ] dividend
- [ ] minimal
- [ ] derail
- [ ] barrier
- [ ] ingenuity
- [ ] bribe
- [ ] guesstimate
- [ ] negotiation
- [ ] hardship
- [ ] badge
- [ ] compromise
- [ ] excess
- [ ] descendant
- [ ] fulfill
- [ ] collective

# Chapter 033

- [ ] amend
- [ ] tangled
- [ ] qualification
- [ ] recall
- [ ] adopt
- [ ] tasteless
- [ ] drown
- [ ] tragedy
- [ ] circulation
- [ ] grand
- [ ] inadequate
- [ ] household
- [ ] authorization
- [ ] auxiliary
- [ ] adverse
- [ ] descriptive
- [ ] trace
- [ ] bloom
- [ ] evaluate
- [ ] humanistic

# Chapter 034

- [ ] cozy
- [ ] plough
- [ ] melt
- [ ] lest
- [ ] ready
- [ ] formidable
- [ ] feasible
- [ ] regarding
- [ ] needle
- [ ] dimension
- [ ] specialize
- [ ] overturn
- [ ] shrank
- [ ] adversely
- [ ] check
- [ ] testimony
- [ ] rigorous
- [ ] privileged
- [ ] expectation
- [ ] bias

# Chapter 035

- [ ] lawsuit
- [ ] eloquent
- [ ] shrink
- [ ] regulation
- [ ] alternative
- [ ] moist
- [ ] surpass
- [ ] fabric
- [ ] distinction
- [ ] eradicate
- [ ] brilliant
- [ ] redefine
- [ ] arm
- [ ] intensely
- [ ] desperate
- [ ] sexism
- [ ] bruise
- [ ] prominent
- [ ] comprehensive
- [ ] forecast

# Chapter 036

- [ ] champion
- [ ] specification
- [ ] layout
- [ ] rally
- [ ] romantic
- [ ] deviate
- [ ] insufficient
- [ ] boost
- [ ] scandal
- [ ] confine
- [ ] conspicuous
- [ ] significant
- [ ] fresh
- [ ] indulge
- [ ] instinctively
- [ ] complement
- [ ] content
- [ ] squalor
- [ ] fatigue
- [ ] awesome

# Chapter 037

- [ ] responsive
- [ ] echo
- [ ] division
- [ ] gender
- [ ] correlation
- [ ] casualty
- [ ] appropriate
- [ ] subtle
- [ ] critical
- [ ] alternatively
- [ ] intimate
- [ ] disengagement
- [ ] lounge
- [ ] gesture
- [ ] script
- [ ] prestige
- [ ] awkward
- [ ] entrepreneur
- [ ] automatic
- [ ] thrive

# Chapter 038

- [ ] enrich
- [ ] chew
- [ ] vehicle
- [ ] intriguing
- [ ] segregation
- [ ] hurl
- [ ] hatch
- [ ] disservice
- [ ] variation
- [ ] enormous
- [ ] scare
- [ ] alphabetical
- [ ] conclusive
- [ ] epidemic
- [ ] solid
- [ ] clause
- [ ] attendant
- [ ] collapse
- [ ] dispatch
- [ ] shrug

# Chapter 039

- [ ] redundant
- [ ] alert
- [ ] deficit
- [ ] restructure
- [ ] tap
- [ ] simultaneous
- [ ] arise
- [ ] wildlife
- [ ] overwhelm
- [ ] motivation
- [ ] delicate
- [ ] remarkable
- [ ] slavery
- [ ] untreated
- [ ] suspicious
- [ ] ancient
- [ ] distort
- [ ] skip
- [ ] wishful
- [ ] entrepreneurship

# Chapter 040

- [ ] bride
- [ ] unfold
- [ ] interference
- [ ] assault
- [ ] shareholder
- [ ] breakthrough
- [ ] footnote
- [ ] applicable
- [ ] controversial
- [ ] inherit
- [ ] facilitate
- [ ] manifest
- [ ] fiscal
- [ ] gown
- [ ] rate
- [ ] mortality
- [ ] decline
- [ ] mournful
- [ ] paradox
- [ ] simultaneously

# Chapter 041

- [ ] strategy
- [ ] literacy
- [ ] apathy
- [ ] boom
- [ ] oblige
- [ ] incompatibility
- [ ] commerce
- [ ] attribute
- [ ] cafeteria
- [ ] cripple
- [ ] shuttle
- [ ] nightmare
- [ ] startle
- [ ] debris
- [ ] assemble
- [ ] perception
- [ ] coastal
- [ ] desert
- [ ] peer
- [ ] embody

# Chapter 042

- [ ] sympathetic
- [ ] backup
- [ ] notably
- [ ] exploit
- [ ] poetry
- [ ] discriminate
- [ ] readjust
- [ ] slight
- [ ] strip
- [ ] tackle
- [ ] steady
- [ ] minority
- [ ] aspirational
- [ ] discipline
- [ ] threshold
- [ ] soar
- [ ] uneven
- [ ] crucial
- [ ] athletics
- [ ] needy

# Chapter 043

- [ ] enthusiastic
- [ ] trigger
- [ ] essential
- [ ] agenda
- [ ] owe
- [ ] justice
- [ ] donor
- [ ] convict
- [ ] underestimate
- [ ] flat
- [ ] confidential
- [ ] unexpected
- [ ] vitamin
- [ ] jeopardize
- [ ] disproportionately
- [ ] bacteria
- [ ] achieve
- [ ] bump
- [ ] existence
- [ ] sweep

# Chapter 044

- [ ] shrewd
- [ ] illuminate
- [ ] realm
- [ ] blueprint
- [ ] pension
- [ ] administration
- [ ] track
- [ ] ponder
- [ ] paradise
- [ ] ethnic
- [ ] accelerate
- [ ] bitter
- [ ] ambition
- [ ] confess
- [ ] extent
- [ ] accountant
- [ ] sheer
- [ ] deliberate
- [ ] pave
- [ ] measure

# Chapter 045

- [ ] potentially
- [ ] remove
- [ ] allergic
- [ ] available
- [ ] initial
- [ ] consensus
- [ ] opponent
- [ ] modify
- [ ] signify
- [ ] accumulate
- [ ] mining
- [ ] violent
- [ ] adversity
- [ ] dynamics
- [ ] chaos
- [ ] persistent
- [ ] ritual
- [ ] criteria
- [ ] impose
- [ ] untiring

# Chapter 046

- [ ] contrary
- [ ] nutritious
- [ ] anxiety
- [ ] rewarding
- [ ] straightforward
- [ ] descent
- [ ] hospitality
- [ ] stuff
- [ ] reflect
- [ ] carpentry
- [ ] decode
- [ ] flaw
- [ ] reveal
- [ ] tutor
- [ ] accustom
- [ ] acquaintance
- [ ] distribution
- [ ] trend
- [ ] irritate
- [ ] intrinsic

# Chapter 047

- [ ] deem
- [ ] arouse
- [ ] suburban
- [ ] pursue
- [ ] ideology
- [ ] layman
- [ ] instantaneous
- [ ] seasick
- [ ] lack
- [ ] exaggerate
- [ ] magnify
- [ ] utilization
- [ ] twist
- [ ] expedition
- [ ] switch
- [ ] inheritance
- [ ] sponsor
- [ ] deterioration
- [ ] ongoing
- [ ] refreshing

# Chapter 048

- [ ] incidentally
- [ ] imprison
- [ ] present
- [ ] uninformed
- [ ] overlap
- [ ] slim
- [ ] urban
- [ ] rank
- [ ] untrustworthy
- [ ] Automatically
- [ ] accountable
- [ ] collaborative
- [ ] practice
- [ ] diligence
- [ ] victim
- [ ] urge
- [ ] fertility
- [ ] foundation
- [ ] reception
- [ ] elite

# Chapter 049

- [ ] suicide
- [ ] incompetent
- [ ] tremendous
- [ ] recyclable
- [ ] visualize
- [ ] exertion
- [ ] slack
- [ ] rigid
- [ ] organic
- [ ] reproduction
- [ ] strap
- [ ] precision
- [ ] standardize
- [ ] aptly
- [ ] promotion
- [ ] paralyze
- [ ] degeneration
- [ ] refrain
- [ ] flavor
- [ ] adventure

# Chapter 050

- [ ] agonize
- [ ] mount
- [ ] oppose
- [ ] justifiable
- [ ] promote
- [ ] renewable
- [ ] hypothesis
- [ ] presentation
- [ ] cater
- [ ] unbiased
- [ ] immersive
- [ ] domain
- [ ] primitive
- [ ] urgent
- [ ] threaten
- [ ] throne
- [ ] underfunded
- [ ] jail
- [ ] assessment
- [ ] frustrate

# Chapter 051

- [ ] abolition
- [ ] detective
- [ ] skyscraper
- [ ] corruption
- [ ] intolerant
- [ ] pierce
- [ ] compensate
- [ ] gap
- [ ] worship
- [ ] gallery
- [ ] coach
- [ ] cancel
- [ ] strike
- [ ] rebellion
- [ ] distract
- [ ] imperative
- [ ] geology
- [ ] sway
- [ ] costume
- [ ] manual

# Chapter 052

- [ ] quantifiable
- [ ] expenditure
- [ ] breed
- [ ] emerge
- [ ] noted
- [ ] position
- [ ] extinction
- [ ] receptionist
- [ ] reckless
- [ ] abuse
- [ ] accuse
- [ ] biochemistry
- [ ] optimism
- [ ] predict
- [ ] notoriously
- [ ] board
- [ ] pose
- [ ] memorandum
- [ ] puzzling
- [ ] reliable

# Chapter 053

- [ ] replacement
- [ ] reinforce
- [ ] impart
- [ ] diversity
- [ ] occupation
- [ ] intense
- [ ] dramatically
- [ ] awareness
- [ ] virtually
- [ ] maturity
- [ ] rare
- [ ] curb
- [ ] favor
- [ ] productivity
- [ ] mechanism
- [ ] helicopter
- [ ] validity
- [ ] relevant
- [ ] miracle
- [ ] fertilizer

# Chapter 054

- [ ] shady
- [ ] poll
- [ ] countermeasure
- [ ] worldly
- [ ] legislator
- [ ] campaign
- [ ] odds
- [ ] shepherd
- [ ] schedule
- [ ] access
- [ ] owl
- [ ] interpret
- [ ] intervention
- [ ] bemoan
- [ ] determine
- [ ] incur
- [ ] literal
- [ ] proposition
- [ ] feasibility
- [ ] destructive

# Chapter 055

- [ ] denationalize
- [ ] resort
- [ ] engage
- [ ] disarm
- [ ] approximately
- [ ] cover
- [ ] validation
- [ ] widespread
- [ ] unethical
- [ ] withdraw
- [ ] relay
- [ ] fluently
- [ ] mysteriously
- [ ] hinder
- [ ] session
- [ ] postdoctoral
- [ ] prioritize
- [ ] bipartisan
- [ ] reluctance
- [ ] intuitive

# Chapter 056

- [ ] quote
- [ ] pragmatic
- [ ] alleviate
- [ ] underlying
- [ ] generate
- [ ] dysfunction
- [ ] invasive
- [ ] ignore
- [ ] specific
- [ ] elegant
- [ ] capital
- [ ] indicate
- [ ] eligible
- [ ] procedure
- [ ] unrealistic
- [ ] occur
- [ ] aggravate
- [ ] frankly
- [ ] thrilling
- [ ] irreversible

# Chapter 057

- [ ] marine
- [ ] interracial
- [ ] grave
- [ ] undocumented
- [ ] appoint
- [ ] rhetorical
- [ ] momentum
- [ ] deserve
- [ ] drastically
- [ ] particle
- [ ] miniature
- [ ] merit
- [ ] category
- [ ] liability
- [ ] hack
- [ ] matter
- [ ] brutal
- [ ] biodiversity
- [ ] subsequently
- [ ] bother

# Chapter 058

- [ ] subconscious
- [ ] genetic
- [ ] recurrence
- [ ] defect
- [ ] retailer
- [ ] memo
- [ ] chain
- [ ] executive
- [ ] ballet
- [ ] enrollment
- [ ] propose
- [ ] frantic
- [ ] allegedly
- [ ] manipulate
- [ ] coverage
- [ ] novel
- [ ] previous
- [ ] neutrality
- [ ] underscore
- [ ] indispensable

# Chapter 059

- [ ] puzzle
- [ ] illustrate
- [ ] sanitation
- [ ] defensive
- [ ] perspective
- [ ] migration
- [ ] float
- [ ] flexible
- [ ] capable
- [ ] practical
- [ ] territory
- [ ] urbanization
- [ ] privilege
- [ ] forthcoming
- [ ] widen
- [ ] deduction
- [ ] virtual
- [ ] boast
- [ ] monetary
- [ ] dim

# Chapter 060

- [ ] sensible
- [ ] infant
- [ ] precedent
- [ ] activate
- [ ] accomplish
- [ ] immigration
- [ ] approve
- [ ] pessimist
- [ ] aggressive
- [ ] toxic
- [ ] ruling
- [ ] prolong
- [ ] tension
- [ ] specialist
- [ ] encounter
- [ ] reap
- [ ] institute
- [ ] maintenance
- [ ] legend
- [ ] groundless

# Chapter 061

- [ ] undertake
- [ ] commodity
- [ ] stimulate
- [ ] tough
- [ ] vital
- [ ] ankle
- [ ] surgical
- [ ] peculiar
- [ ] fade
- [ ] pursuit
- [ ] sophisticated
- [ ] lobbyist
- [ ] lessen
- [ ] handgun
- [ ] influential
- [ ] detached
- [ ] biography
- [ ] curriculum
- [ ] margin
- [ ] fearlessly

# Chapter 062

- [ ] randomly
- [ ] discrimination
- [ ] stimulus
- [ ] competence
- [ ] sneak
- [ ] exceed
- [ ] turbulence
- [ ] address

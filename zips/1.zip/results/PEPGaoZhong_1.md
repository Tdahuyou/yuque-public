
# Chapter 001

- [ ] survey
- [ ] add up
- [ ] upset
- [ ] ignore
- [ ] calm
- [ ] calm(…)down
- [ ] have got to
- [ ] concern
- [ ] be concerned about
- [ ] walk the dog
- [ ] loose
- [ ] vet
- [ ] go through
- [ ] Amsterdam
- [ ] Netherlands
- [ ] Jewish
- [ ] German
- [ ] Nazi
- [ ] set down
- [ ] series

# Chapter 002

- [ ] a series of
- [ ] Kitty
- [ ] outdoors
- [ ] spellbind
- [ ] on purpose
- [ ] in order to
- [ ] dusk
- [ ] at dusk
- [ ] thunder
- [ ] entire
- [ ] entirely
- [ ] power
- [ ] face to face
- [ ] curtain
- [ ] dusty
- [ ] no longer
- [ ] not…any longer
- [ ] partner
- [ ] settle
- [ ] suffer

# Chapter 003

- [ ] suffer from
- [ ] loneliness
- [ ] highway
- [ ] recover
- [ ] get tired of
- [ ] be tired of
- [ ] pack
- [ ] pack (sth) up
- [ ] suitcase
- [ ] Margot
- [ ] Overcoat
- [ ] teenager
- [ ] get along with
- [ ] gossip
- [ ] fall in love
- [ ] exactly
- [ ] disagree
- [ ] grateful
- [ ] dislike
- [ ] join in

# Chapter 004

- [ ] tip
- [ ] secondly
- [ ] swap
- [ ] item
- [ ] subway
- [ ] elevator
- [ ] petrol
- [ ] gas
- [ ] official
- [ ] voyage
- [ ] conquer
- [ ] because of
- [ ] native
- [ ] Amy
- [ ] come up
- [ ] apartment
- [ ] actually
- [ ] AD
- [ ] base
- [ ] at present

# Chapter 005

- [ ] gradual
- [ ] gradually
- [ ] Danish
- [ ] enrich
- [ ] vocabulary
- [ ] Shakespeare
- [ ] make use of
- [ ] spelling
- [ ] Samuel Johnson
- [ ] Noah Webster
- [ ] latter
- [ ] identity
- [ ] fluent
- [ ] fluently
- [ ] Singapore
- [ ] Malaysia
- [ ] such as
- [ ] frequent
- [ ] frequently
- [ ] usage

# Chapter 006

- [ ] command
- [ ] request
- [ ] dialect
- [ ] expression
- [ ] midwestern
- [ ] African
- [ ] Spanish
- [ ] play a part (in)
- [ ] eastern
- [ ] southeastern
- [ ] northwestern
- [ ] recognize
- [ ] lorry
- [ ] Lori
- [ ] Houston
- [ ] Texas
- [ ] accent
- [ ] Buford
- [ ] Lester
- [ ] catfish

# Chapter 007

- [ ] lightning
- [ ] straight
- [ ] block
- [ ] cab
- [ ] journal
- [ ] transport
- [ ] prefer
- [ ] disadvantage
- [ ] fare
- [ ] route
- [ ] Mekong
- [ ] flow
- [ ] ever since
- [ ] persuade
- [ ] cycle
- [ ] graduate
- [ ] finally
- [ ] schedule
- [ ] fond
- [ ] be fond of

# Chapter 008

- [ ] shortcoming
- [ ] stubborn
- [ ] organize
- [ ] care about
- [ ] detail
- [ ] source
- [ ] determine
- [ ] determined
- [ ] change one’s mind
- [ ] journey
- [ ] altitude
- [ ] make up one’s mind
- [ ] give in
- [ ] atlas
- [ ] glacier
- [ ] Tibetan
- [ ] rapids
- [ ] valley
- [ ] waterfall
- [ ] pace

# Chapter 009

- [ ] bend
- [ ] meander
- [ ] delta
- [ ] attitude
- [ ] Qomolangma
- [ ] boil
- [ ] forecast
- [ ] parcel
- [ ] insurance
- [ ] wool
- [ ] as usual
- [ ] reliable
- [ ] view
- [ ] yak
- [ ] pillow
- [ ] midnight
- [ ] at midnight
- [ ] flame
- [ ] beneath
- [ ] Laos

# Chapter 010

- [ ] Laotian
- [ ] temple
- [ ] cave
- [ ] earthquake
- [ ] quake
- [ ] right away
- [ ] well
- [ ] crack
- [ ] smelly
- [ ] farmyard
- [ ] pipe
- [ ] burst
- [ ] million
- [ ] event
- [ ] as if
- [ ] at an end
- [ ] nation
- [ ] canal
- [ ] steam
- [ ] dirt

# Chapter 011

- [ ] ruin
- [ ] in ruins
- [ ] suffering
- [ ] extreme
- [ ] injure
- [ ] survivor
- [ ] destroy
- [ ] brick
- [ ] dam
- [ ] track
- [ ] useless
- [ ] shock
- [ ] rescue
- [ ] trap
- [ ] electricity
- [ ] disaster
- [ ] dig out
- [ ] bury
- [ ] mine
- [ ] miner

# Chapter 012

- [ ] shelter
- [ ] a (great) number of
- [ ] title
- [ ] reporter
- [ ] bar
- [ ] damage
- [ ] frighten
- [ ] frightened
- [ ] frightening
- [ ] congratulation
- [ ] judge
- [ ] sincerely
- [ ] express
- [ ] outline
- [ ] headline
- [ ] cyclist
- [ ] Nelson Mandela
- [ ] quality
- [ ] warm-hearted
- [ ] mean

# Chapter 013

- [ ] active
- [ ] generous
- [ ] easy-going
- [ ] self
- [ ] selfish
- [ ] selfless
- [ ] selflessly
- [ ] devote
- [ ] devoted
- [ ] William Tyndale
- [ ] Bible
- [ ] Norman Bethune
- [ ] invader
- [ ] found
- [ ] republic
- [ ] principle
- [ ] nationalism
- [ ] livelihood
- [ ] Mohandas Gandhi
- [ ] peaceful

# Chapter 014

- [ ] giant
- [ ] leap
- [ ] mankind
- [ ] Elias
- [ ] lawyer
- [ ] guidance
- [ ] legal
- [ ] fee
- [ ] passbook
- [ ] Johannesburg
- [ ] out of work
- [ ] hopeful
- [ ] ANC
- [ ] youth
- [ ] league
- [ ] Youth League
- [ ] stage
- [ ] vote
- [ ] attack
- [ ] violence

# Chapter 015

- [ ] as a matter of fact
- [ ] blow up
- [ ] equal
- [ ] in trouble
- [ ] willing
- [ ] unfair
- [ ] turn to
- [ ] quote
- [ ] release
- [ ] lose heart
- [ ] Robben Island
- [ ] escape
- [ ] blanket
- [ ] educate
- [ ] educated
- [ ] come to power
- [ ] beg
- [ ] relative
- [ ] terror
- [ ] cruelty

# Chapter 016

- [ ] reward
- [ ] Transkei
- [ ] set up
- [ ] sentence
- [ ] be sentenced to
- [ ] anti-
- [ ] anti-black
- [ ] Cape Town
- [ ] president
- [ ] Nobel Peace Prize
- [ ] opinion


# Chapter 001

- [ ] achievement
- [ ] Joan of Arc
- [ ] Elizabeth Fry
- [ ] Quaker
- [ ] welfare
- [ ] project
- [ ] institute
- [ ] China Welfare Institute
- [ ] specialist
- [ ] specialize
- [ ] Jane Goodall
- [ ] chimp
- [ ] connection
- [ ] human being
- [ ] Jody Williams
- [ ] campaign
- [ ] landmine
- [ ] organization
- [ ] Gombe National Park
- [ ] behave

# Chapter 002

- [ ] behaviour
- [ ] shade
- [ ] move off
- [ ] worthwhile
- [ ] nest
- [ ] bond
- [ ] observe
- [ ] observation
- [ ] childhood
- [ ] outspoken
- [ ] respect
- [ ] argue
- [ ] argument
- [ ] entertainment
- [ ] lead a…life
- [ ] crowd
- [ ] crowd in
- [ ] inspire
- [ ] inspiration
- [ ] support

# Chapter 003

- [ ] look down on
- [ ] look down upon
- [ ] refer
- [ ] refer to
- [ ] audience
- [ ] by chance
- [ ] come across
- [ ] career
- [ ] rate
- [ ] sickness
- [ ] intend
- [ ] emergency
- [ ] generation
- [ ] determination
- [ ] kindness
- [ ] considerate
- [ ] consideration
- [ ] deliver
- [ ] carry on
- [ ] modest

# Chapter 004

- [ ] statistic
- [ ] sunburnt
- [ ] struggle
- [ ] decade
- [ ] super
- [ ] hybrid
- [ ] output
- [ ] strain
- [ ] crop
- [ ] hunger
- [ ] disturbing
- [ ] expand
- [ ] circulate
- [ ] Vietnam
- [ ] thanks to
- [ ] battle
- [ ] rid
- [ ] rid…of
- [ ] be satisfied with
- [ ] freedom

# Chapter 005

- [ ] would rather
- [ ] therefore
- [ ] equip
- [ ] sorghum
- [ ] grain
- [ ] peanut
- [ ] export
- [ ] nationality
- [ ] occupation
- [ ] personality
- [ ] confuse
- [ ] regret
- [ ] chemical
- [ ] organic
- [ ] fertile
- [ ] fertilizer
- [ ] production
- [ ] bacteria
- [ ] pest
- [ ] build up

# Chapter 006

- [ ] lead to
- [ ] nutrition
- [ ] mineral
- [ ] discovery
- [ ] focus
- [ ] focus on
- [ ] soil
- [ ] reduce
- [ ] keep…free of
- [ ] keep…free from
- [ ] soybean
- [ ] root
- [ ] skim
- [ ] underline
- [ ] summary
- [ ] comment
- [ ] producer
- [ ] industrial
- [ ] humour
- [ ] punchline

# Chapter 007

- [ ] verbal
- [ ] nonverbal
- [ ] mime
- [ ] Charlie Chaplin
- [ ] Edward Lear
- [ ] comedy
- [ ] Victor Hugo
- [ ] up to now
- [ ] brighten
- [ ] depressed
- [ ] content
- [ ] feel content with
- [ ] be content with
- [ ] performer
- [ ] astonish
- [ ] astonishing
- [ ] fortunate
- [ ] unfortunately
- [ ] badly off
- [ ] teens

# Chapter 008

- [ ] ordinary
- [ ] bored
- [ ] subtle
- [ ] entertain
- [ ] entertaining
- [ ] charming
- [ ] tramp
- [ ] throughout
- [ ] homeless
- [ ] moustache
- [ ] worn
- [ ] worn-out
- [ ] stiffly
- [ ] failure
- [ ] optimism
- [ ] overcome
- [ ] underdog
- [ ] snowstorm
- [ ] leather
- [ ] pick out

# Chapter 009

- [ ] lace
- [ ] cut off
- [ ] chew
- [ ] mouthful
- [ ] enjoyment
- [ ] convince
- [ ] convincing
- [ ] direct
- [ ] star in
- [ ] Oscar
- [ ] outstanding
- [ ] Switzerland
- [ ] confidence
- [ ] costume
- [ ] gesture
- [ ] particular
- [ ] particularly
- [ ] occasion
- [ ] budget
- [ ] actress

# Chapter 010

- [ ] slide
- [ ] amuse
- [ ] amusing
- [ ] pancake
- [ ] explanation
- [ ] detective
- [ ] Sherlock Holmes
- [ ] mountainous
- [ ] whisper
- [ ] vast
- [ ] rhythm
- [ ] mess
- [ ] react
- [ ] porridge
- [ ] drunk
- [ ] statement
- [ ] greet
- [ ] represent
- [ ] association
- [ ] dormitory

# Chapter 011

- [ ] canteen
- [ ] flight
- [ ] curious
- [ ] curiously
- [ ] Garcia
- [ ] Colombia
- [ ] approach
- [ ] cheek
- [ ] defend
- [ ] defend against
- [ ] defence
- [ ] major
- [ ] misunderstand
- [ ] misunderstanding
- [ ] Akira Nagata
- [ ] Ahmed Aziz
- [ ] Jordan
- [ ] Darlene Coulon
- [ ] dash
- [ ] adult

# Chapter 012

- [ ] simply
- [ ] Muslim
- [ ] spoken
- [ ] unspoken
- [ ] posture
- [ ] Spain
- [ ] Italy
- [ ] likely
- [ ] be likely to
- [ ] in general
- [ ] crossroads
- [ ] employee
- [ ] frown
- [ ] misread
- [ ] facial
- [ ] function
- [ ] ease
- [ ] at ease
- [ ] truly
- [ ] false

# Chapter 013

- [ ] anger
- [ ] lose face
- [ ] turn one’s back to
- [ ] fist
- [ ] yawn
- [ ] respectful
- [ ] subjective
- [ ] hug
- [ ] rank
- [ ] cassette
- [ ] theme
- [ ] Camelot Park
- [ ] central
- [ ] Central Park
- [ ] Dollywood
- [ ] various
- [ ] cartoon
- [ ] be famous for
- [ ] roller coaster
- [ ] whichever

# Chapter 014

- [ ] pirate
- [ ] fairy tale
- [ ] fantasy
- [ ] amusement
- [ ] swing
- [ ] attraction
- [ ] no wonder
- [ ] tourism
- [ ] wherever
- [ ] unique
- [ ] carpenter
- [ ] craftsman
- [ ] engine
- [ ] bald
- [ ] preserve
- [ ] length
- [ ] deed
- [ ] knight
- [ ] be modeled after
- [ ] Merlin the Wizard

# Chapter 015

- [ ] sword
- [ ] joust
- [ ] tournament
- [ ] settler
- [ ] athletic
- [ ] translator
- [ ] minority
- [ ] cloth
- [ ] Futuroscope
- [ ] jungle
- [ ] diver
- [ ] creature
- [ ] sunlight
- [ ] T-Rex
- [ ] advance
- [ ] in advance
- [ ] advanced
- [ ] brand
- [ ] get close to
- [ ] come to life

# Chapter 016

- [ ] outing
- [ ] admission
- [ ] shuttle
- [ ] freeway
- [ ] souvenir
- [ ] sneaker
- [ ] brochure

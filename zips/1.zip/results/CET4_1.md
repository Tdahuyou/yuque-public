
# Chapter 001

- [ ] abruptly
- [ ] absorb
- [ ] abuse
- [ ] academic
- [ ] access
- [ ] accessible
- [ ] accommodate
- [ ] accomplish
- [ ] accumulate
- [ ] accurate
- [ ] achieve
- [ ] acknowledge
- [ ] acquire
- [ ] acute
- [ ] adapt
- [ ] addiction
- [ ] additional
- [ ] address
- [ ] adequate
- [ ] administration

# Chapter 002

- [ ] administrative
- [ ] admire
- [ ] admiration
- [ ] admission
- [ ] admit
- [ ] advance
- [ ] advanced
- [ ] advancement
- [ ] advice
- [ ] advisory
- [ ] advocate
- [ ] advocator
- [ ] affectionate
- [ ] affirmation
- [ ] affirm
- [ ] afford
- [ ] agency
- [ ] aggressive
- [ ] album
- [ ] alcohol

# Chapter 003

- [ ] alert
- [ ] alter
- [ ] altitude
- [ ] ambitious
- [ ] analyze
- [ ] ancient
- [ ] announce
- [ ] annual
- [ ] annually
- [ ] anticipate
- [ ] antique
- [ ] apartment
- [ ] appeal
- [ ] appearance
- [ ] appetite
- [ ] applicant
- [ ] application
- [ ] apply
- [ ] appoint
- [ ] appointment

# Chapter 004

- [ ] appreciate
- [ ] appreciation
- [ ] approach
- [ ] approve
- [ ] approval
- [ ] approximately
- [ ] architect
- [ ] archive
- [ ] arrange
- [ ] arrest
- [ ] ashamed
- [ ] assemble
- [ ] assembly
- [ ] asset
- [ ] assign
- [ ] assignment
- [ ] associate
- [ ] assume
- [ ] assumption
- [ ] astonish

# Chapter 005

- [ ] atmosphere
- [ ] attempt
- [ ] automatic
- [ ] available
- [ ] avail
- [ ] average
- [ ] aviation
- [ ] aviate
- [ ] avoid
- [ ] award
- [ ] awareness
- [ ] background
- [ ] backward
- [ ] ban
- [ ] bankrupt
- [ ] bargain
- [ ] battle
- [ ] behave
- [ ] beneficial
- [ ] benefit

# Chapter 006

- [ ] bid
- [ ] blame
- [ ] bless
- [ ] block
- [ ] bogus
- [ ] boost
- [ ] bother
- [ ] broad
- [ ] budget
- [ ] burden
- [ ] bureau
- [ ] calculate
- [ ] campaign
- [ ] cancel
- [ ] candidate
- [ ] canteen
- [ ] capable
- [ ] caregiver
- [ ] careless
- [ ] casual

# Chapter 007

- [ ] catalogue
- [ ] caution
- [ ] cautious
- [ ] ceremony
- [ ] challenge
- [ ] chap
- [ ] character
- [ ] characterize
- [ ] charity
- [ ] cheek
- [ ] chef
- [ ] chemical
- [ ] choke
- [ ] circumstance
- [ ] cite
- [ ] citizen
- [ ] civilian
- [ ] civilized
- [ ] classify
- [ ] classification

# Chapter 008

- [ ] client
- [ ] clinic
- [ ] clumsy
- [ ] coach
- [ ] colleague
- [ ] collision
- [ ] combine
- [ ] comment
- [ ] commit
- [ ] commitment
- [ ] committee
- [ ] compare
- [ ] compel
- [ ] compensate
- [ ] compensation
- [ ] compete
- [ ] competitiveness
- [ ] competitor
- [ ] complacency
- [ ] complain

# Chapter 009

- [ ] complaint
- [ ] complete
- [ ] complicated
- [ ] comply
- [ ] component
- [ ] concentration
- [ ] concept
- [ ] concern
- [ ] conclusion
- [ ] confidence
- [ ] confirm
- [ ] conflict
- [ ] conform
- [ ] confront
- [ ] connectivity
- [ ] conscience
- [ ] consensus
- [ ] consent
- [ ] consequence
- [ ] conservative

# Chapter 010

- [ ] considerable
- [ ] considerably
- [ ] considerate
- [ ] consist
- [ ] consistent
- [ ] conspicuous
- [ ] constant
- [ ] constantly
- [ ] construction
- [ ] constructive
- [ ] consult
- [ ] consultant
- [ ] consumption
- [ ] contact
- [ ] contemporary
- [ ] content
- [ ] context
- [ ] contract
- [ ] contrast
- [ ] contribute

# Chapter 011

- [ ] contribution
- [ ] convenient
- [ ] conventional
- [ ] convey
- [ ] cooperative
- [ ] corporate
- [ ] counsel
- [ ] couple
- [ ] courageous
- [ ] crash
- [ ] creativity
- [ ] crisis
- [ ] critic
- [ ] critical
- [ ] criticize
- [ ] criticism
- [ ] cultivate
- [ ] curb
- [ ] curiosity
- [ ] curious

# Chapter 012

- [ ] current
- [ ] currently
- [ ] debt
- [ ] decent
- [ ] decline
- [ ] decorate
- [ ] definition
- [ ] degree
- [ ] delay
- [ ] deliberate
- [ ] delightful
- [ ] deliver
- [ ] demand
- [ ] democratic
- [ ] demonstrate
- [ ] density
- [ ] department
- [ ] depressed
- [ ] depressing
- [ ] deprive

# Chapter 013

- [ ] derive
- [ ] deserve
- [ ] desire
- [ ] despite
- [ ] dessert
- [ ] detail
- [ ] detailed
- [ ] detect
- [ ] detection
- [ ] detective
- [ ] determine
- [ ] determination
- [ ] device
- [ ] devote
- [ ] dictator
- [ ] diligent
- [ ] diploma
- [ ] disadvantage
- [ ] disappear
- [ ] discharge

# Chapter 014

- [ ] discount
- [ ] discover
- [ ] disorderly
- [ ] display
- [ ] dispute
- [ ] dissatisfy
- [ ] distance
- [ ] distant
- [ ] distinguish
- [ ] distinguished
- [ ] distract
- [ ] distracted
- [ ] distraction
- [ ] distribute
- [ ] district
- [ ] diverse
- [ ] diversity
- [ ] divide
- [ ] division
- [ ] document

# Chapter 015

- [ ] dominant
- [ ] domination
- [ ] donation
- [ ] donate
- [ ] dormitory
- [ ] downfall
- [ ] download
- [ ] dramatically
- [ ] dropout
- [ ] due
- [ ] dump
- [ ] durable
- [ ] ease
- [ ] easygoing
- [ ] effect
- [ ] efficiently
- [ ] eliminate
- [ ] embarrass
- [ ] embarrassed
- [ ] embrace

# Chapter 016

- [ ] emergence
- [ ] emergency
- [ ] emission
- [ ] emit
- [ ] emotional
- [ ] emphasize
- [ ] encourage
- [ ] endurance
- [ ] endure
- [ ] engage
- [ ] engagement
- [ ] enhance
- [ ] enormous
- [ ] enrich
- [ ] enroll
- [ ] enrollment
- [ ] ensure
- [ ] entertaining
- [ ] equal
- [ ] equality

# Chapter 017

- [ ] equivalent
- [ ] equivalence
- [ ] era
- [ ] essay
- [ ] essentially
- [ ] establish
- [ ] establishment
- [ ] esteem
- [ ] estimate
- [ ] evidence
- [ ] evident
- [ ] evil
- [ ] evolve
- [ ] exaggerate
- [ ] excellent
- [ ] exception
- [ ] excessive
- [ ] exchange
- [ ] exclude
- [ ] expand

# Chapter 018

- [ ] exploit
- [ ] explore
- [ ] explosion
- [ ] expose
- [ ] exposure
- [ ] expressiveness
- [ ] extension
- [ ] extracurricular
- [ ] facility
- [ ] faith
- [ ] familiar
- [ ] fantasize
- [ ] fascinate
- [ ] fascination
- [ ] fatal
- [ ] fate
- [ ] fatigue
- [ ] favorable
- [ ] feasible
- [ ] feature

# Chapter 019

- [ ] feedback
- [ ] fiction
- [ ] figure
- [ ] financial
- [ ] finance
- [ ] fine
- [ ] fitness
- [ ] flexible
- [ ] foothold
- [ ] formulate
- [ ] fortunately
- [ ] foundation
- [ ] frighten
- [ ] frontier
- [ ] function
- [ ] fund
- [ ] fuss
- [ ] gambling
- [ ] gap
- [ ] garage

# Chapter 020

- [ ] gear
- [ ] gender
- [ ] generalization
- [ ] generation
- [ ] generosity
- [ ] generous
- [ ] genuine
- [ ] gift
- [ ] gloomy
- [ ] glorious
- [ ] grab
- [ ] grocery
- [ ] groundlessly
- [ ] guarantee
- [ ] guideline
- [ ] guilt
- [ ] gym
- [ ] handle
- [ ] hardworking
- [ ] harm

# Chapter 021

- [ ] harmful
- [ ] harmony
- [ ] harsh
- [ ] hazard
- [ ] highlight
- [ ] hire
- [ ] homemaker
- [ ] honesty
- [ ] honor
- [ ] hospitalize
- [ ] household
- [ ] humanity
- [ ] identical
- [ ] identify
- [ ] identification
- [ ] identity
- [ ] ignorance
- [ ] ignore
- [ ] illegal
- [ ] illustrate

# Chapter 022

- [ ] image
- [ ] imaginary
- [ ] immobile
- [ ] impact
- [ ] impermanent
- [ ] impermanency
- [ ] implement
- [ ] imply
- [ ] import
- [ ] impose
- [ ] improper
- [ ] inadequate
- [ ] inappropriate
- [ ] include
- [ ] incredible
- [ ] indicate
- [ ] indispensable
- [ ] individual
- [ ] induce
- [ ] inevitable

# Chapter 023

- [ ] infinite
- [ ] inflation
- [ ] inflate
- [ ] influence
- [ ] influential
- [ ] ingredient
- [ ] inherit
- [ ] initiate
- [ ] initiative
- [ ] injure
- [ ] innocent
- [ ] innovation
- [ ] insecure
- [ ] insight
- [ ] inspiration
- [ ] inspire
- [ ] install
- [ ] installation
- [ ] installment
- [ ] instant

# Chapter 024

- [ ] institute
- [ ] institution
- [ ] instruction
- [ ] instruct
- [ ] instrument
- [ ] intake
- [ ] integrity
- [ ] intelligence
- [ ] intelligent
- [ ] intend
- [ ] interconnect
- [ ] interdependence
- [ ] interpret
- [ ] interracial
- [ ] intervention
- [ ] interview
- [ ] invade
- [ ] invalid
- [ ] invest
- [ ] involve

# Chapter 025

- [ ] irrationally
- [ ] irritate
- [ ] issue
- [ ] item
- [ ] joint
- [ ] keenly
- [ ] launch
- [ ] laundry
- [ ] legal
- [ ] leisure
- [ ] lengthy
- [ ] liability
- [ ] literature
- [ ] loan
- [ ] locate
- [ ] lodge
- [ ] logic
- [ ] loyalty
- [ ] mainstream
- [ ] maintain

# Chapter 026

- [ ] major
- [ ] majority
- [ ] makeup
- [ ] malfunction
- [ ] manufacture
- [ ] margin
- [ ] marvelous
- [ ] masculine
- [ ] massive
- [ ] matter
- [ ] maximum
- [ ] means
- [ ] measure
- [ ] mechanic
- [ ] mechanism
- [ ] merit
- [ ] migration
- [ ] military
- [ ] mineral
- [ ] miscalculation

# Chapter 027

- [ ] miserable
- [ ] misguided
- [ ] mislead
- [ ] mission
- [ ] misunderstand
- [ ] monitor
- [ ] motivate
- [ ] motivation
- [ ] mutual
- [ ] narrow
- [ ] needy
- [ ] negative
- [ ] negotiate
- [ ] neighborhood
- [ ] obstacle
- [ ] obtain
- [ ] occupation
- [ ] operation
- [ ] opposite
- [ ] organ

# Chapter 028

- [ ] original
- [ ] originate
- [ ] outline
- [ ] overcome
- [ ] overestimate
- [ ] overflow
- [ ] overload
- [ ] overtake
- [ ] overweight
- [ ] overwhelm
- [ ] painful
- [ ] participate
- [ ] particular
- [ ] passionate
- [ ] passion
- [ ] passive
- [ ] patiently
- [ ] pattern
- [ ] peaceful
- [ ] peer

# Chapter 029

- [ ] perceive
- [ ] performance
- [ ] permanent
- [ ] persistence
- [ ] personality
- [ ] perspective
- [ ] persuade
- [ ] persuasion
- [ ] physical
- [ ] physics
- [ ] picky
- [ ] pioneer
- [ ] planet
- [ ] pledge
- [ ] poison
- [ ] poll
- [ ] pop
- [ ] porter
- [ ] pose
- [ ] position

# Chapter 030

- [ ] postgraduate
- [ ] potential
- [ ] praise
- [ ] predict
- [ ] preference
- [ ] pregnant
- [ ] prejudice
- [ ] preservation
- [ ] prevail
- [ ] prevent
- [ ] preventable
- [ ] previous
- [ ] previously
- [ ] primarily
- [ ] primitive
- [ ] principle
- [ ] priority
- [ ] privacy
- [ ] process
- [ ] productive

# Chapter 031

- [ ] profitable
- [ ] profound
- [ ] programming
- [ ] prohibit
- [ ] project
- [ ] prominent
- [ ] promising
- [ ] promote
- [ ] prompt
- [ ] proportion
- [ ] prospect
- [ ] provoke
- [ ] psychological
- [ ] publicize
- [ ] punctual
- [ ] pursue
- [ ] qualification
- [ ] qualify
- [ ] quality
- [ ] quantity

# Chapter 032

- [ ] quit
- [ ] raise
- [ ] range
- [ ] rank
- [ ] rare
- [ ] rational
- [ ] realistic
- [ ] rearrange
- [ ] reception
- [ ] recession
- [ ] recharge
- [ ] recommend
- [ ] recover
- [ ] recruit
- [ ] reduce
- [ ] refreshing
- [ ] refuel
- [ ] refusal
- [ ] regular
- [ ] regularly

# Chapter 033

- [ ] regulate
- [ ] regulation
- [ ] relative
- [ ] release
- [ ] relevant
- [ ] reliable
- [ ] relieve
- [ ] reluctant
- [ ] remedy
- [ ] remove
- [ ] render
- [ ] renew
- [ ] repave
- [ ] replace
- [ ] represent
- [ ] representative
- [ ] reputation
- [ ] request
- [ ] require
- [ ] rescue

# Chapter 034

- [ ] reservation
- [ ] resident
- [ ] resign
- [ ] resist
- [ ] resolve
- [ ] respectful
- [ ] responsibility
- [ ] responsible
- [ ] restock
- [ ] restore
- [ ] restrict
- [ ] restriction
- [ ] retail
- [ ] reveal
- [ ] revenge
- [ ] revenue
- [ ] reverse
- [ ] revise
- [ ] revolution
- [ ] reward

# Chapter 035

- [ ] riotous
- [ ] rocket
- [ ] routinely
- [ ] saint
- [ ] save
- [ ] schedule
- [ ] scholarship
- [ ] scope
- [ ] scratch
- [ ] screen
- [ ] secure
- [ ] seldom
- [ ] selection
- [ ] selective
- [ ] selfish
- [ ] sensitive
- [ ] separately
- [ ] session
- [ ] severe
- [ ] shock

# Chapter 036

- [ ] shortcut
- [ ] showmanship
- [ ] sightseeing
- [ ] signal
- [ ] significant
- [ ] similar
- [ ] simplicity
- [ ] site
- [ ] situation
- [ ] skyrocket
- [ ] slave
- [ ] socialize
- [ ] solution
- [ ] spare
- [ ] specialize
- [ ] specific
- [ ] specify
- [ ] sponsor
- [ ] spontaneous
- [ ] spread

# Chapter 037

- [ ] standardize
- [ ] startle
- [ ] steady
- [ ] steal
- [ ] steer
- [ ] stereotype
- [ ] stimulate
- [ ] stock
- [ ] strategy
- [ ] stressful
- [ ] stress
- [ ] strict
- [ ] structure
- [ ] struggle
- [ ] subsidize
- [ ] substantial
- [ ] suffer
- [ ] sufficient
- [ ] superior
- [ ] supervision

# Chapter 038

- [ ] suppose
- [ ] surf
- [ ] survey
- [ ] suspect
- [ ] sustain
- [ ] sustainable
- [ ] swift
- [ ] switch
- [ ] symbol
- [ ] sympathy
- [ ] tackle
- [ ] tailor
- [ ] takeoff
- [ ] tank
- [ ] tasteless
- [ ] technical
- [ ] technique
- [ ] technician
- [ ] tedious
- [ ] temptation

# Chapter 039

- [ ] tension
- [ ] tent
- [ ] terribly
- [ ] therapy
- [ ] threaten
- [ ] tide
- [ ] tighten
- [ ] tiny
- [ ] tolerance
- [ ] toothache
- [ ] track
- [ ] trait
- [ ] transaction
- [ ] transfer
- [ ] transportation
- [ ] treatment
- [ ] tremble
- [ ] triumph
- [ ] tuition
- [ ] tumor

# Chapter 040

- [ ] ultimately
- [ ] unaffordable
- [ ] uncertain
- [ ] undermine
- [ ] unique
- [ ] universal
- [ ] upbringing
- [ ] update
- [ ] valid
- [ ] value
- [ ] vanish
- [ ] variety
- [ ] vehicle
- [ ] version
- [ ] view
- [ ] violate
- [ ] virtually
- [ ] virus
- [ ] visibility
- [ ] visible

# Chapter 041

- [ ] vital
- [ ] vocabulary
- [ ] vote
- [ ] wise
- [ ] witness
- [ ] worsen
- [ ] worthwhile
- [ ] yield
- [ ] comprehensive
- [ ] synthetic
- [ ] undergo
- [ ] fair
- [ ] bakery
- [ ] lap
- [ ] sideways
- [ ] swallow
- [ ] durability
- [ ] symbolize
- [ ] everlasting
- [ ] wedding

# Chapter 042

- [ ] excess
- [ ] instance
- [ ] slightly
- [ ] undertake
- [ ] frown
- [ ] overcharge
- [ ] grid
- [ ] vary
- [ ] evolutionary
- [ ] psychologist
- [ ] substitute
- [ ] dictate
- [ ] subdivision
- [ ] utility
- [ ] prohibitively
- [ ] sway
- [ ] reproductive
- [ ] exhaust
- [ ] domestic
- [ ] fetch

# Chapter 043

- [ ] retrain
- [ ] biological
- [ ] perception
- [ ] consume
- [ ] solely
- [ ] characteristic
- [ ] complex
- [ ] response
- [ ] rate
- [ ] solid
- [ ] prepare
- [ ] unwilling
- [ ] mature
- [ ] deadline
- [ ] retirement
- [ ] appealing
- [ ] barely
- [ ] unbearable
- [ ] grave
- [ ] implication

# Chapter 044

- [ ] menu
- [ ] standpoint
- [ ] justice
- [ ] expectation
- [ ] professional
- [ ] radically
- [ ] voluntary
- [ ] independently
- [ ] favor
- [ ] puzzling
- [ ] tremendous
- [ ] strain
- [ ] exhibition
- [ ] gallery
- [ ] evaluate
- [ ] dust
- [ ] accompany
- [ ] submit
- [ ] awful
- [ ] chat

# Chapter 045

- [ ] underline
- [ ] survival
- [ ] dishonest
- [ ] neglect
- [ ] treasure
- [ ] rigorous
- [ ] counseling
- [ ] competent
- [ ] divine
- [ ] assess
- [ ] reassess
- [ ] rude
- [ ] tough
- [ ] justify
- [ ] persistent
- [ ] surpass
- [ ] dilemma
- [ ] generate
- [ ] primary
- [ ] vitally

# Chapter 046

- [ ] confuse
- [ ] reframe
- [ ] inquiry
- [ ] intention
- [ ] engine
- [ ] occasion
- [ ] extensively
- [ ] column
- [ ] melt
- [ ] sensible
- [ ] essential
- [ ] solve
- [ ] seize
- [ ] alternative
- [ ] prosperity
- [ ] conservation
- [ ] slippery
- [ ] destruction
- [ ] preserve
- [ ] abstract

# Chapter 047

- [ ] mystery
- [ ] refine
- [ ] quotation
- [ ] react
- [ ] replacement
- [ ] consequently
- [ ] soar
- [ ] incline
- [ ] minor
- [ ] grief
- [ ] facilitate
- [ ] simplify
- [ ] procedure
- [ ] disservice
- [ ] phenomenon
- [ ] endanger
- [ ] overwhelming
- [ ] observe
- [ ] entertainment
- [ ] optimistic

# Chapter 048

- [ ] adversity
- [ ] misguide
- [ ] energetic
- [ ] unintended
- [ ] setting
- [ ] tempting
- [ ] interruption
- [ ] prescription
- [ ] paradox
- [ ] namely
- [ ] undoubtedly
- [ ] distinctive
- [ ] retreat
- [ ] entitle
- [ ] fussy
- [ ] dishwasher
- [ ] forum
- [ ] inadequacy
- [ ] lobby
- [ ] agent

# Chapter 049

- [ ] convince
- [ ] flexibility
- [ ] plastic
- [ ] frame
- [ ] groundsheet
- [ ] geographic
- [ ] diplomatic
- [ ] judgement
- [ ] private
- [ ] cozy
- [ ] mill
- [ ] enable
- [ ] laborious
- [ ] delight
- [ ] scale
- [ ] amusing
- [ ] panic
- [ ] consciousness
- [ ] statistics
- [ ] bride

# Chapter 050

- [ ] absent
- [ ] annoy
- [ ] insist
- [ ] forefinger
- [ ] bow
- [ ] gesture
- [ ] harvest
- [ ] sticky
- [ ] resistance
- [ ] bacteria
- [ ] particle
- [ ] gum
- [ ] resemble
- [ ] trace
- [ ] discrimination
- [ ] pointless
- [ ] rental
- [ ] indifferent
- [ ] reflect
- [ ] liberation

# Chapter 051

- [ ] option
- [ ] initially
- [ ] attribute
- [ ] accelerate
- [ ] sphere
- [ ] widespread
- [ ] transform
- [ ] immeasurable
- [ ] contaminate
- [ ] territory
- [ ] virtual
- [ ] invariably
- [ ] long
- [ ] welfare
- [ ] lessen
- [ ] unrest
- [ ] authoritative
- [ ] neutral
- [ ] racially
- [ ] disappointing

# Chapter 052

- [ ] plant
- [ ] inspector
- [ ] headquarter
- [ ] worldwide
- [ ] council
- [ ] clue
- [ ] cheat
- [ ] insult
- [ ] distress
- [ ] discourage
- [ ] prosper
- [ ] retain
- [ ] contest
- [ ] proposal
- [ ] combination
- [ ] promotional
- [ ] smooth
- [ ] intense
- [ ] irregular
- [ ] incidence

# Chapter 053

- [ ] shade
- [ ] pension
- [ ] deepen
- [ ] complement
- [ ] squeeze
- [ ] civilization
- [ ] extraordinary
- [ ] poisonous
- [ ] recycle
- [ ] inquire
- [ ] mask
- [ ] symptom
- [ ] plague
- [ ] twist
- [ ] terminal
- [ ] passively
- [ ] outcome
- [ ] signature
- [ ] task
- [ ] convincing

# Chapter 054

- [ ] downsize
- [ ] foreseeable
- [ ] status
- [ ] preferentially
- [ ] source
- [ ] riot
- [ ] grain
- [ ] retailer
- [ ] amaze
- [ ] origin
- [ ] commencement
- [ ] innovate
- [ ] hit
- [ ] crucial
- [ ] breakthrough
- [ ] exile
- [ ] element
- [ ] interpretation
- [ ] accustom
- [ ] superficial

# Chapter 055

- [ ] respectively
- [ ] fundamentally
- [ ] cruelty
- [ ] govern
- [ ] hinder
- [ ] undervalue
- [ ] evaluation
- [ ] define
- [ ] backslide
- [ ] offense
- [ ] convict
- [ ] marginalize
- [ ] desert
- [ ] sentence
- [ ] reserve
- [ ] penalty
- [ ] logically
- [ ] abundant
- [ ] overstate
- [ ] snack

# Chapter 056

- [ ] via
- [ ] fade
- [ ] resistant
- [ ] theory
- [ ] protest
- [ ] reject
- [ ] flaw
- [ ] seemingly
- [ ] objection
- [ ] fancy
- [ ] hub
- [ ] incomparable
- [ ] incentive
- [ ] startup
- [ ] reproduce
- [ ] distinct
- [ ] stake
- [ ] moral
- [ ] opponent
- [ ] explicitly

# Chapter 057

- [ ] rival
- [ ] confrontation
- [ ] stale
- [ ] reinforce
- [ ] ring
- [ ] attendance
- [ ] flow
- [ ] mood
- [ ] mutually
- [ ] review
- [ ] elegant
- [ ] hospitable
- [ ] constitute
- [ ] programmer
- [ ] sophisticated
- [ ] ignorant
- [ ] imitate
- [ ] trigger
- [ ] code
- [ ] investigate

# Chapter 058

- [ ] outgoing
- [ ] evolution
- [ ] resourceful
- [ ] myth
- [ ] legend
- [ ] philosopher
- [ ] concrete
- [ ] emerge
- [ ] stir
- [ ] senior
- [ ] nutritious
- [ ] expert
- [ ] carpenter
- [ ] dampen
- [ ] grant
- [ ] security
- [ ] steep
- [ ] implementation
- [ ] weaken
- [ ] puzzle

# Chapter 059

- [ ] memorize
- [ ] cater

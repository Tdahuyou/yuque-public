
# Chapter 001

- [ ] ability
- [ ] able
- [ ] about
- [ ] above
- [ ] abroad
- [ ] absent
- [ ] accent
- [ ] accept
- [ ] accident
- [ ] ache
- [ ] achieve
- [ ] across
- [ ] act
- [ ] action
- [ ] active
- [ ] activity
- [ ] add
- [ ] address
- [ ] advertisement
- [ ] advice

# Chapter 002

- [ ] advise
- [ ] afford
- [ ] afraid
- [ ] after
- [ ] afternoon
- [ ] again
- [ ] against
- [ ] age
- [ ] ago
- [ ] agree
- [ ] agreement
- [ ] air
- [ ] airline
- [ ] airplane
- [ ] airport
- [ ] alive
- [ ] all
- [ ] allow
- [ ] almost
- [ ] alone

# Chapter 003

- [ ] along
- [ ] aloud
- [ ] already
- [ ] also
- [ ] although
- [ ] always
- [ ] America
- [ ] American
- [ ] among
- [ ] ancient
- [ ] and
- [ ] angry
- [ ] animal
- [ ] another
- [ ] answer
- [ ] ant
- [ ] any
- [ ] anyone
- [ ] anything
- [ ] anyway

# Chapter 004

- [ ] anywhere
- [ ] appear
- [ ] apple
- [ ] April
- [ ] area
- [ ] arm
- [ ] army
- [ ] around
- [ ] arrive
- [ ] art
- [ ] article
- [ ] as
- [ ] Asia
- [ ] Asian
- [ ] ask
- [ ] asleep
- [ ] at
- [ ] Atlantic
- [ ] attention
- [ ] August

# Chapter 005

- [ ] aunt
- [ ] Australia
- [ ] Australian
- [ ] autumn
- [ ] available
- [ ] avoid
- [ ] away
- [ ] baby
- [ ] back
- [ ] background
- [ ] bag
- [ ] ball
- [ ] balloon
- [ ] bamboo
- [ ] banana
- [ ] bank
- [ ] basic
- [ ] basket
- [ ] basketball
- [ ] bathroom

# Chapter 006

- [ ] be
- [ ] beach
- [ ] bear
- [ ] beautiful
- [ ] because
- [ ] bed
- [ ] bedroom
- [ ] bee
- [ ] beef
- [ ] before
- [ ] behaviour
- [ ] behind
- [ ] believe
- [ ] bell
- [ ] below
- [ ] beside
- [ ] besides
- [ ] between
- [ ] beyond
- [ ] big

# Chapter 007

- [ ] bike
- [ ] bill
- [ ] bird
- [ ] birth
- [ ] birthday
- [ ] biscuit
- [ ] bit
- [ ] bitter
- [ ] black
- [ ] blackboard
- [ ] blind
- [ ] blood
- [ ] blue
- [ ] board
- [ ] boat
- [ ] body
- [ ] book
- [ ] boring
- [ ] born
- [ ] borrow

# Chapter 008

- [ ] boss
- [ ] both
- [ ] bottle
- [ ] bottom
- [ ] bowl
- [ ] box
- [ ] boy
- [ ] brain
- [ ] brave
- [ ] bread
- [ ] breakfast
- [ ] breath
- [ ] breathe
- [ ] bridge
- [ ] bright
- [ ] brother
- [ ] brown
- [ ] brush
- [ ] building
- [ ] bus

# Chapter 009

- [ ] business
- [ ] busy
- [ ] but
- [ ] butter
- [ ] butterfly
- [ ] by
- [ ] bye
- [ ] cabbage
- [ ] cake
- [ ] call
- [ ] camel
- [ ] camera
- [ ] camp
- [ ] can
- [ ] Canada
- [ ] cancel
- [ ] candle
- [ ] cancer
- [ ] candy
- [ ] cap

# Chapter 010

- [ ] capital
- [ ] captain
- [ ] car
- [ ] card
- [ ] care
- [ ] careful
- [ ] careless
- [ ] carry
- [ ] cat
- [ ] cause
- [ ] CD
- [ ] ceiling
- [ ] celebrate
- [ ] cent
- [ ] centre
- [ ] century
- [ ] certain
- [ ] chair
- [ ] chairman
- [ ] chalk

# Chapter 011

- [ ] chance
- [ ] change
- [ ] chant
- [ ] cheap
- [ ] cheat
- [ ] check
- [ ] cheer
- [ ] cheese
- [ ] chemistry
- [ ] chess
- [ ] chest
- [ ] chicken
- [ ] China
- [ ] Chinese
- [ ] chocolate
- [ ] choice
- [ ] chopsticks
- [ ] Christmas
- [ ] church
- [ ] cinema

# Chapter 012

- [ ] circle
- [ ] city
- [ ] clap
- [ ] class
- [ ] classmate
- [ ] classroom
- [ ] clean
- [ ] clear
- [ ] clever
- [ ] climb
- [ ] clock
- [ ] clone
- [ ] close
- [ ] clothes
- [ ] cloud
- [ ] cloudy
- [ ] club
- [ ] coach
- [ ] coal
- [ ] coast

# Chapter 013

- [ ] coat
- [ ] coffee
- [ ] coin
- [ ] coke
- [ ] cold
- [ ] collect
- [ ] college
- [ ] comfortable
- [ ] common
- [ ] communicate
- [ ] communication
- [ ] company
- [ ] compare
- [ ] competition
- [ ] complete
- [ ] composition
- [ ] computer
- [ ] concert
- [ ] condition
- [ ] conference

# Chapter 014

- [ ] connect
- [ ] continue
- [ ] control
- [ ] conversation
- [ ] cook
- [ ] cooker
- [ ] cool
- [ ] copy
- [ ] corner
- [ ] correct
- [ ] cotton
- [ ] cough
- [ ] could
- [ ] count
- [ ] country
- [ ] countryside
- [ ] couple
- [ ] courage
- [ ] course
- [ ] cousin

# Chapter 015

- [ ] cover
- [ ] cow
- [ ] crayon
- [ ] crazy
- [ ] create
- [ ] cross
- [ ] cruel
- [ ] cry
- [ ] culture
- [ ] cup
- [ ] daily
- [ ] dance
- [ ] danger
- [ ] dangerous
- [ ] dare
- [ ] dark
- [ ] date
- [ ] daughter
- [ ] day
- [ ] dead

# Chapter 016

- [ ] deaf
- [ ] deal
- [ ] dear
- [ ] death
- [ ] December
- [ ] decide
- [ ] decision
- [ ] deep
- [ ] delicious
- [ ] dentist
- [ ] depend
- [ ] describe
- [ ] develop
- [ ] development
- [ ] dialogue
- [ ] diary
- [ ] dictionary
- [ ] die
- [ ] difference
- [ ] different

# Chapter 017

- [ ] difficult
- [ ] difficulty
- [ ] dinner
- [ ] direct
- [ ] dirty
- [ ] discover
- [ ] discovery
- [ ] discuss
- [ ] discussion
- [ ] disease
- [ ] dish
- [ ] dismiss
- [ ] disturb
- [ ] divide
- [ ] doctor
- [ ] dog
- [ ] doll
- [ ] dollar
- [ ] door
- [ ] double

# Chapter 018

- [ ] doubt
- [ ] down
- [ ] downstairs
- [ ] dozen
- [ ] drawer
- [ ] dress
- [ ] driver
- [ ] drop
- [ ] drug
- [ ] drum
- [ ] dry
- [ ] duck
- [ ] dumpling
- [ ] during
- [ ] duty
- [ ] each
- [ ] ear
- [ ] early
- [ ] earth
- [ ] east

# Chapter 019

- [ ] easy
- [ ] edge
- [ ] education
- [ ] effort
- [ ] egg
- [ ] eight
- [ ] eighteen
- [ ] eighth
- [ ] eighty
- [ ] either
- [ ] elder
- [ ] electric
- [ ] elephant
- [ ] eleven
- [ ] else
- [ ] empty
- [ ] encourage
- [ ] end
- [ ] enemy
- [ ] energy

# Chapter 020

- [ ] engineer
- [ ] England
- [ ] English
- [ ] enjoy
- [ ] enough
- [ ] enter
- [ ] environment
- [ ] eraser
- [ ] especially
- [ ] Europe
- [ ] European
- [ ] even
- [ ] evening
- [ ] ever
- [ ] every
- [ ] everybody
- [ ] everyday
- [ ] everyone
- [ ] everything
- [ ] everywhere

# Chapter 021

- [ ] examine
- [ ] example
- [ ] excellent
- [ ] except
- [ ] excite
- [ ] excuse
- [ ] exercise
- [ ] expect
- [ ] expensive
- [ ] experience
- [ ] experiment
- [ ] explain
- [ ] express
- [ ] eye
- [ ] face
- [ ] fact
- [ ] factory
- [ ] fail
- [ ] fair
- [ ] family

# Chapter 022

- [ ] famous
- [ ] fan
- [ ] fantastic
- [ ] farm
- [ ] farmer
- [ ] fast
- [ ] fat
- [ ] father
- [ ] fear
- [ ] February
- [ ] feeling
- [ ] festival
- [ ] fetch
- [ ] fever
- [ ] few
- [ ] field
- [ ] fifteen
- [ ] fifth
- [ ] fifty
- [ ] fill

# Chapter 023

- [ ] film
- [ ] final
- [ ] fine
- [ ] finger
- [ ] finish
- [ ] fire
- [ ] first
- [ ] fish
- [ ] fisherman
- [ ] fit
- [ ] five
- [ ] fix
- [ ] flag
- [ ] flat
- [ ] floor
- [ ] flower
- [ ] flu
- [ ] fly
- [ ] follow
- [ ] food

# Chapter 024

- [ ] football
- [ ] for
- [ ] force
- [ ] foreign
- [ ] foreigner
- [ ] forest
- [ ] fork
- [ ] form
- [ ] forty
- [ ] forward
- [ ] four
- [ ] fourteen
- [ ] fourth
- [ ] fox
- [ ] free
- [ ] fresh
- [ ] Friday
- [ ] fridge
- [ ] friend
- [ ] friendly

# Chapter 025

- [ ] friendship
- [ ] frog
- [ ] front
- [ ] fruit
- [ ] full
- [ ] fun
- [ ] funny
- [ ] future
- [ ] game
- [ ] garden
- [ ] gate
- [ ] general
- [ ] gentleman
- [ ] geography
- [ ] gift
- [ ] giraffe
- [ ] girl
- [ ] glad
- [ ] glass
- [ ] glove

# Chapter 026

- [ ] goat
- [ ] god
- [ ] goal
- [ ] gold
- [ ] golden
- [ ] government
- [ ] grade
- [ ] grammar
- [ ] grandchild
- [ ] granddaughter
- [ ] grandparent
- [ ] grandson
- [ ] granny
- [ ] grape
- [ ] grass
- [ ] great
- [ ] green
- [ ] greeting
- [ ] ground
- [ ] group

# Chapter 027

- [ ] guard
- [ ] guess
- [ ] guest
- [ ] gun
- [ ] gym
- [ ] hair
- [ ] half
- [ ] hall
- [ ] ham
- [ ] hamburger
- [ ] hand
- [ ] handbag
- [ ] handsome
- [ ] happen
- [ ] happy
- [ ] hard
- [ ] hardly
- [ ] hat
- [ ] hate
- [ ] he

# Chapter 028

- [ ] head
- [ ] health
- [ ] healthy
- [ ] heart
- [ ] heat
- [ ] heaven
- [ ] heavy
- [ ] height
- [ ] help
- [ ] helpful
- [ ] hen
- [ ] her
- [ ] hers
- [ ] here
- [ ] herself
- [ ] high
- [ ] hill
- [ ] him
- [ ] himself
- [ ] his

# Chapter 029

- [ ] history
- [ ] hobby
- [ ] holiday
- [ ] home
- [ ] hometown
- [ ] homework
- [ ] honest
- [ ] hope
- [ ] horse
- [ ] hospital
- [ ] hot
- [ ] hotel
- [ ] hour
- [ ] house
- [ ] housework
- [ ] how
- [ ] however
- [ ] huge
- [ ] human
- [ ] hundred

# Chapter 030

- [ ] hungry
- [ ] hurry
- [ ] husband
- [ ] I
- [ ] ice
- [ ] idea
- [ ] if
- [ ] ill
- [ ] illness
- [ ] imagine
- [ ] immediately
- [ ] important
- [ ] improve
- [ ] in
- [ ] inch
- [ ] include
- [ ] increase
- [ ] India
- [ ] Indian
- [ ] industry

# Chapter 031

- [ ] influence
- [ ] information
- [ ] ink
- [ ] inside
- [ ] insist
- [ ] instead
- [ ] instruction
- [ ] intention
- [ ] interest
- [ ] interesting
- [ ] international
- [ ] Internet
- [ ] interview
- [ ] into
- [ ] introduce
- [ ] introduction
- [ ] invent
- [ ] invention
- [ ] invite
- [ ] iron

# Chapter 032

- [ ] island
- [ ] it
- [ ] its
- [ ] itself
- [ ] jacket
- [ ] January
- [ ] Japan
- [ ] Japanese
- [ ] jeans
- [ ] job
- [ ] join
- [ ] joke
- [ ] joy
- [ ] juice
- [ ] jump
- [ ] June
- [ ] just
- [ ] key
- [ ] keyboard
- [ ] kick

# Chapter 033

- [ ] kid
- [ ] kill
- [ ] kilo
- [ ] kilometer
- [ ] kind
- [ ] king
- [ ] kiss
- [ ] kitchen
- [ ] kite
- [ ] knee
- [ ] knock
- [ ] knowledge
- [ ] lab
- [ ] lady
- [ ] lake
- [ ] lamb
- [ ] lamp
- [ ] land
- [ ] language
- [ ] large

# Chapter 034

- [ ] last
- [ ] late
- [ ] laugh
- [ ] law
- [ ] lay
- [ ] lazy
- [ ] lead
- [ ] leader
- [ ] leaf
- [ ] learn
- [ ] least
- [ ] left
- [ ] leg
- [ ] lemonade
- [ ] lesson
- [ ] letter
- [ ] level
- [ ] library
- [ ] license
- [ ] lie

# Chapter 035

- [ ] lift
- [ ] light
- [ ] like
- [ ] line
- [ ] lion
- [ ] list
- [ ] listen
- [ ] litter
- [ ] live
- [ ] lively
- [ ] lock
- [ ] London
- [ ] lonely
- [ ] long
- [ ] look
- [ ] lot
- [ ] loud
- [ ] love
- [ ] lovely
- [ ] low

# Chapter 036

- [ ] luck
- [ ] lucky
- [ ] lunch
- [ ] machine
- [ ] mad
- [ ] madam
- [ ] magazine
- [ ] magic
- [ ] mail
- [ ] main
- [ ] manage
- [ ] manager
- [ ] map
- [ ] March
- [ ] mark
- [ ] market
- [ ] marriage
- [ ] marry
- [ ] master
- [ ] match

# Chapter 037

- [ ] math
- [ ] may
- [ ] May
- [ ] maybe
- [ ] me
- [ ] meal
- [ ] meaning
- [ ] meat
- [ ] medical
- [ ] medicine
- [ ] meeting
- [ ] member
- [ ] memory
- [ ] mend
- [ ] mention
- [ ] menu
- [ ] message
- [ ] metal
- [ ] method
- [ ] middle

# Chapter 038

- [ ] mile
- [ ] milk
- [ ] mind
- [ ] mine
- [ ] minute
- [ ] mirror
- [ ] miss
- [ ] Miss
- [ ] model
- [ ] modern
- [ ] moment
- [ ] Monday
- [ ] money
- [ ] monitor
- [ ] monkey
- [ ] month
- [ ] moon
- [ ] morning
- [ ] mother
- [ ] motorcycle

# Chapter 039

- [ ] mountain
- [ ] mouth
- [ ] move
- [ ] movie
- [ ] murder
- [ ] museum
- [ ] music
- [ ] must
- [ ] my
- [ ] myself
- [ ] name
- [ ] national
- [ ] natural
- [ ] nature
- [ ] near
- [ ] nearly
- [ ] necessary
- [ ] neck
- [ ] need
- [ ] neither

# Chapter 040

- [ ] nervous
- [ ] never
- [ ] new
- [ ] news
- [ ] newspaper
- [ ] next
- [ ] nice
- [ ] night
- [ ] nine
- [ ] nineteen
- [ ] ninety
- [ ] ninth
- [ ] no
- [ ] nobody
- [ ] nod
- [ ] noise
- [ ] none
- [ ] noodle
- [ ] noon
- [ ] nor

# Chapter 041

- [ ] normal
- [ ] north
- [ ] northern
- [ ] nose
- [ ] not
- [ ] note
- [ ] notebook
- [ ] nothing
- [ ] notice
- [ ] November
- [ ] now
- [ ] number
- [ ] nurse
- [ ] object
- [ ] October
- [ ] of
- [ ] off
- [ ] offer
- [ ] office
- [ ] officer

# Chapter 042

- [ ] often
- [ ] oil
- [ ] OK
- [ ] old
- [ ] on
- [ ] once
- [ ] one
- [ ] oneself
- [ ] only
- [ ] open
- [ ] operation
- [ ] or
- [ ] orange
- [ ] order
- [ ] other
- [ ] our
- [ ] ours
- [ ] ourselves
- [ ] out
- [ ] outside

# Chapter 043

- [ ] over
- [ ] overcoat
- [ ] own
- [ ] owner
- [ ] pacific
- [ ] package
- [ ] page
- [ ] paint
- [ ] pair
- [ ] palace
- [ ] pancake
- [ ] panda
- [ ] paper
- [ ] pardon
- [ ] parent
- [ ] park
- [ ] part
- [ ] party
- [ ] pass
- [ ] passage

# Chapter 044

- [ ] passenger
- [ ] passport
- [ ] past
- [ ] path
- [ ] patient
- [ ] peace
- [ ] pear
- [ ] pen
- [ ] pencil
- [ ] people
- [ ] percent
- [ ] perfect
- [ ] perhaps
- [ ] period
- [ ] person
- [ ] personal
- [ ] pet
- [ ] physics
- [ ] piano
- [ ] pick

# Chapter 045

- [ ] picnic
- [ ] picture
- [ ] pie
- [ ] piece
- [ ] pig
- [ ] pilot
- [ ] pink
- [ ] pioneer
- [ ] pity
- [ ] place
- [ ] plain
- [ ] plan
- [ ] plane
- [ ] planet
- [ ] plant
- [ ] plastic
- [ ] plate
- [ ] play
- [ ] playground
- [ ] pleasant

# Chapter 046

- [ ] please
- [ ] pleasure
- [ ] plenty
- [ ] pocket
- [ ] poem
- [ ] point
- [ ] police
- [ ] policy
- [ ] polite
- [ ] pond
- [ ] pool
- [ ] poor
- [ ] popular
- [ ] population
- [ ] pork
- [ ] position
- [ ] possible
- [ ] post
- [ ] postcard
- [ ] postman

# Chapter 047

- [ ] potato
- [ ] pound
- [ ] practice
- [ ] praise
- [ ] prepare
- [ ] present
- [ ] president
- [ ] pretty
- [ ] prevent
- [ ] price
- [ ] pride
- [ ] primary
- [ ] print
- [ ] prison
- [ ] prisoner
- [ ] private
- [ ] prize
- [ ] problem
- [ ] produce
- [ ] progress

# Chapter 048

- [ ] promise
- [ ] pronounce
- [ ] pronunciation
- [ ] proper
- [ ] protect
- [ ] proud
- [ ] prove
- [ ] provide
- [ ] public
- [ ] pull
- [ ] punish
- [ ] pupil
- [ ] purple
- [ ] purse
- [ ] push
- [ ] quarter
- [ ] queen
- [ ] question
- [ ] quick
- [ ] quiet

# Chapter 049

- [ ] quite
- [ ] rabbit
- [ ] race
- [ ] radio
- [ ] railway
- [ ] rain
- [ ] raincoat
- [ ] rainy
- [ ] raise
- [ ] rapid
- [ ] rat
- [ ] rather
- [ ] reach
- [ ] ready
- [ ] real
- [ ] receive
- [ ] recent
- [ ] recite
- [ ] record
- [ ] recorder

# Chapter 050

- [ ] red
- [ ] refuse
- [ ] regard
- [ ] regret
- [ ] relation
- [ ] relax
- [ ] remain
- [ ] remember
- [ ] repair
- [ ] repeat
- [ ] reply
- [ ] report
- [ ] require
- [ ] research
- [ ] rest
- [ ] restaurant
- [ ] result
- [ ] retell
- [ ] return
- [ ] review

# Chapter 051

- [ ] rice
- [ ] rich
- [ ] riddle
- [ ] right
- [ ] risk
- [ ] river
- [ ] road
- [ ] robot
- [ ] rock
- [ ] role
- [ ] room
- [ ] rope
- [ ] rose
- [ ] round
- [ ] row
- [ ] rubber
- [ ] rubbish
- [ ] rule
- [ ] ruler
- [ ] rush

# Chapter 052

- [ ] Rusia
- [ ] Russian
- [ ] sad
- [ ] safe
- [ ] safety
- [ ] sail
- [ ] salad
- [ ] sale
- [ ] salt
- [ ] same
- [ ] sand
- [ ] sandwich
- [ ] Saturday
- [ ] sausage
- [ ] save
- [ ] scarf
- [ ] school
- [ ] schoolbag
- [ ] science
- [ ] scientist

# Chapter 053

- [ ] score
- [ ] screen
- [ ] sea
- [ ] search
- [ ] season
- [ ] seat
- [ ] second
- [ ] secret
- [ ] secretary
- [ ] seem
- [ ] seldom
- [ ] sense
- [ ] sentence
- [ ] separate
- [ ] September
- [ ] serious
- [ ] servant
- [ ] service
- [ ] seven
- [ ] seventeen

# Chapter 054

- [ ] seventh
- [ ] seventy
- [ ] several
- [ ] shame
- [ ] shape
- [ ] share
- [ ] she
- [ ] ship
- [ ] shirt
- [ ] shoe
- [ ] shop
- [ ] short
- [ ] shorts
- [ ] should
- [ ] shoulder
- [ ] shout
- [ ] show
- [ ] shower
- [ ] shy
- [ ] sick

# Chapter 055

- [ ] side
- [ ] sight
- [ ] silence
- [ ] silent
- [ ] silk
- [ ] silly
- [ ] similar
- [ ] simple
- [ ] since
- [ ] single
- [ ] sir
- [ ] sister
- [ ] situation
- [ ] six
- [ ] sixteen
- [ ] sixth
- [ ] sixty
- [ ] size
- [ ] skate
- [ ] skill

# Chapter 056

- [ ] skirt
- [ ] sky
- [ ] sleepy
- [ ] slow
- [ ] small
- [ ] smart
- [ ] smile
- [ ] smoke
- [ ] smooth
- [ ] snake
- [ ] snow
- [ ] snowy
- [ ] so
- [ ] soap
- [ ] social
- [ ] society
- [ ] socks
- [ ] sofa
- [ ] soft
- [ ] soldier

# Chapter 057

- [ ] solid
- [ ] some
- [ ] somebody
- [ ] someone
- [ ] something
- [ ] sometimes
- [ ] somewhere
- [ ] son
- [ ] song
- [ ] soon
- [ ] sorry
- [ ] sort
- [ ] sound
- [ ] soup
- [ ] sour
- [ ] south
- [ ] southern
- [ ] space
- [ ] speaker
- [ ] special

# Chapter 058

- [ ] speech
- [ ] speed
- [ ] spirit
- [ ] spoon
- [ ] spring
- [ ] square
- [ ] stairs
- [ ] stamp
- [ ] standard
- [ ] start
- [ ] state
- [ ] station
- [ ] stay
- [ ] steam
- [ ] steel
- [ ] step
- [ ] still
- [ ] stomach
- [ ] stone
- [ ] stop

# Chapter 059

- [ ] store
- [ ] storm
- [ ] story
- [ ] strange
- [ ] stranger
- [ ] strawberry
- [ ] stream
- [ ] street
- [ ] strict
- [ ] strong
- [ ] student
- [ ] study
- [ ] stupid
- [ ] subject
- [ ] succeed
- [ ] success
- [ ] successful
- [ ] such
- [ ] sudden
- [ ] sugar

# Chapter 060

- [ ] suggest
- [ ] suggestion
- [ ] sun
- [ ] Sunday
- [ ] sunny
- [ ] supermarket
- [ ] supper
- [ ] supply
- [ ] suppose
- [ ] sure
- [ ] surface
- [ ] surprise
- [ ] sweater
- [ ] sweet
- [ ] swimming
- [ ] swing
- [ ] symbol
- [ ] table
- [ ] tail
- [ ] tale

# Chapter 061

- [ ] talk
- [ ] tall
- [ ] tape
- [ ] task
- [ ] taste
- [ ] taxi
- [ ] tea
- [ ] teacher
- [ ] team
- [ ] technology
- [ ] telephone
- [ ] television
- [ ] temperature
- [ ] ten
- [ ] tenth
- [ ] tent
- [ ] term
- [ ] terrible
- [ ] test
- [ ] text

# Chapter 062

- [ ] than
- [ ] thank
- [ ] that
- [ ] the
- [ ] their
- [ ] theirs
- [ ] them
- [ ] themselves
- [ ] then
- [ ] there
- [ ] these
- [ ] they
- [ ] thick
- [ ] thin
- [ ] thing
- [ ] third
- [ ] thirsty
- [ ] thirteen
- [ ] thirty
- [ ] this

# Chapter 063

- [ ] those
- [ ] though
- [ ] thought
- [ ] thousand
- [ ] thread
- [ ] three
- [ ] through
- [ ] Thursday
- [ ] ticket
- [ ] tidy
- [ ] tie
- [ ] tiger
- [ ] till
- [ ] time
- [ ] tiny
- [ ] tired
- [ ] to
- [ ] today
- [ ] together
- [ ] toilet

# Chapter 064

- [ ] tomato
- [ ] tomorrow
- [ ] ton
- [ ] tongue
- [ ] tonight
- [ ] too
- [ ] tool
- [ ] toothache
- [ ] toothbrush
- [ ] toothpaste
- [ ] top
- [ ] total
- [ ] touch
- [ ] tourist
- [ ] towel
- [ ] tower
- [ ] town
- [ ] toy
- [ ] trade
- [ ] traditional

# Chapter 065

- [ ] traffic
- [ ] train
- [ ] training
- [ ] translate
- [ ] treasure
- [ ] treatment
- [ ] tree
- [ ] trip
- [ ] trouble
- [ ] trousers
- [ ] truck
- [ ] true
- [ ] trust
- [ ] truth
- [ ] try
- [ ] Tuesday
- [ ] turn
- [ ] twelfth
- [ ] twelve
- [ ] twentieth

# Chapter 066

- [ ] twenty
- [ ] twice
- [ ] two
- [ ] ugly
- [ ] umbrella
- [ ] uncle
- [ ] under
- [ ] underground
- [ ] unit
- [ ] university
- [ ] unless
- [ ] until
- [ ] up
- [ ] upstairs
- [ ] us
- [ ] use
- [ ] used
- [ ] useful
- [ ] useless
- [ ] usual

# Chapter 067

- [ ] vacation
- [ ] value
- [ ] VCD
- [ ] vegetable
- [ ] vehicle
- [ ] very
- [ ] victory
- [ ] video
- [ ] village
- [ ] violin
- [ ] visit
- [ ] visitor
- [ ] voice
- [ ] volleyball
- [ ] wait
- [ ] walk
- [ ] wall
- [ ] want
- [ ] war
- [ ] warm

# Chapter 068

- [ ] warn
- [ ] wash
- [ ] waste
- [ ] watch
- [ ] water
- [ ] watermelon
- [ ] way
- [ ] we
- [ ] weak
- [ ] wealth
- [ ] weather
- [ ] website
- [ ] Wednesday
- [ ] week
- [ ] weekday
- [ ] weekend
- [ ] weigh
- [ ] weight
- [ ] welcome
- [ ] west

# Chapter 069

- [ ] western
- [ ] wet
- [ ] whale
- [ ] what
- [ ] whatever
- [ ] wheat
- [ ] Wheel
- [ ] when
- [ ] whenever
- [ ] where
- [ ] whether
- [ ] which
- [ ] while
- [ ] white
- [ ] who
- [ ] whole
- [ ] whom
- [ ] whose
- [ ] why
- [ ] wide

# Chapter 070

- [ ] wife
- [ ] wind
- [ ] window
- [ ] windy
- [ ] wine
- [ ] wing
- [ ] winner
- [ ] winter
- [ ] wise
- [ ] wish
- [ ] with
- [ ] without
- [ ] wonder
- [ ] wonderful
- [ ] wood
- [ ] word
- [ ] work
- [ ] worker
- [ ] world
- [ ] worry

# Chapter 071

- [ ] worth
- [ ] would
- [ ] wound
- [ ] write
- [ ] wrong
- [ ] yard
- [ ] year
- [ ] yellow
- [ ] yes
- [ ] yesterday
- [ ] yet
- [ ] you
- [ ] young
- [ ] your
- [ ] yours
- [ ] yourself
- [ ] yourselves
- [ ] zebra
- [ ] zero
- [ ] zoo


# Chapter 001

- [ ] eat breakfast
- [ ] have...class
- [ ] play sports
- [ ] exercise
- [ ] do morning exercise
- [ ] eat dinner
- [ ] clean my room
- [ ] go for a walk
- [ ] go shopping
- [ ] take
- [ ] dancing
- [ ] take a dancing class
- [ ] when
- [ ] after
- [ ] start
- [ ] usually
- [ ] Spain
- [ ] late
- [ ] a.m.
- [ ] p.m.

# Chapter 002

- [ ] why
- [ ] shop
- [ ] work
- [ ] last
- [ ] sound
- [ ] also
- [ ] busy
- [ ] need
- [ ] play
- [ ] letter
- [ ] live
- [ ] island
- [ ] always
- [ ] cave
- [ ] go swimming
- [ ] win
- [ ] spring
- [ ] summer
- [ ] autumn
- [ ] winter

# Chapter 003

- [ ] season
- [ ] picnic
- [ ] go on a picnic
- [ ] pick
- [ ] pick apples
- [ ] snowman
- [ ] make a snowman
- [ ] go swimming.
- [ ] which
- [ ] best
- [ ] snow
- [ ] good job
- [ ] because
- [ ] vacation
- [ ] all
- [ ] pink
- [ ] lovely
- [ ] leaf
- [ ] fall
- [ ] paint

# Chapter 004

- [ ] January
- [ ] February
- [ ] March
- [ ] April
- [ ] May
- [ ] June
- [ ] July
- [ ] August
- [ ] September
- [ ] October
- [ ] November
- [ ] December
- [ ] few
- [ ] a few
- [ ] thing
- [ ] meet
- [ ] sports meet
- [ ] Easter
- [ ] trip
- [ ] year

# Chapter 005

- [ ] plant
- [ ] contest
- [ ] the Great Wall
- [ ] national
- [ ] National Day
- [ ] American
- [ ] Thanksgiving
- [ ] Christmas
- [ ] holiday
- [ ] game
- [ ] roll
- [ ] look for
- [ ] chocolate
- [ ] bunny
- [ ] RSVP
- [ ] by
- [ ] first
- [ ] second
- [ ] third
- [ ] fourth

# Chapter 006

- [ ] fifth
- [ ] twelfth
- [ ] twentieth
- [ ] twenty-first
- [ ] twenty-third
- [ ] thirtieth
- [ ] special
- [ ] fool
- [ ] kitten
- [ ] diary
- [ ] still
- [ ] noise
- [ ] fur
- [ ] open
- [ ] walk
- [ ] mine
- [ ] yours
- [ ] his
- [ ] hers
- [ ] theirs

# Chapter 007

- [ ] ours
- [ ] climbing
- [ ] eating
- [ ] playing
- [ ] jumping
- [ ] drinking
- [ ] sleeping
- [ ] each
- [ ] other
- [ ] each other
- [ ] excited
- [ ] like
- [ ] doing morning exercises
- [ ] having...class
- [ ] eating lunch
- [ ] reading a book
- [ ] listening to music
- [ ] keep
- [ ] keep to the right
- [ ] keep your desk clean

# Chapter 008

- [ ] talk quietly
- [ ] turn
- [ ] take turns
- [ ] bamboo
- [ ] its
- [ ] show
- [ ] anything
- [ ] else
- [ ] exhibition
- [ ] say
- [ ] have a look
- [ ] sushi
- [ ] teach
- [ ] sure
- [ ] Canadian
- [ ] Spanish

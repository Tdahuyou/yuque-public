
# Chapter 001

- [ ] beddings
- [ ] although
- [ ] effort
- [ ] preference
- [ ] beneath
- [ ] currency
- [ ] warmth
- [ ] adapt
- [ ] rewrite
- [ ] fourteen
- [ ] steam
- [ ] piano
- [ ] firm
- [ ] bake
- [ ] suggest
- [ ] happily
- [ ] changeable
- [ ] happen
- [ ] stream
- [ ] late

# Chapter 002

- [ ] hey
- [ ] charge
- [ ] treat
- [ ] simplify
- [ ] statesman
- [ ] reservation
- [ ] framework
- [ ] consider
- [ ] gram
- [ ] DVD
- [ ] superior
- [ ] achievement
- [ ] urgent
- [ ] sense
- [ ] foresee
- [ ] try
- [ ] compass
- [ ] headteacher
- [ ] earn
- [ ] collect

# Chapter 003

- [ ] mask
- [ ] assume
- [ ] player
- [ ] revision
- [ ] farm
- [ ] hive
- [ ] year
- [ ] continue
- [ ] contradict
- [ ] usually
- [ ] persuade
- [ ] mental
- [ ] hawk
- [ ] clothes
- [ ] plastic
- [ ] terrible
- [ ] bedclothes
- [ ] award
- [ ] surround
- [ ] humour

# Chapter 004

- [ ] hostess
- [ ] speaker
- [ ] successful
- [ ] chance
- [ ] lid
- [ ] dollar
- [ ] man
- [ ] ten
- [ ] pay
- [ ] under
- [ ] leading
- [ ] Asia
- [ ] typewriter
- [ ] even
- [ ] luggage
- [ ] escape
- [ ] powder
- [ ] zebra
- [ ] overcoat
- [ ] popcorn

# Chapter 005

- [ ] affair
- [ ] steward
- [ ] available
- [ ] import
- [ ] cupboard
- [ ] date
- [ ] pollution
- [ ] jar
- [ ] anything
- [ ] suspension
- [ ] Italian
- [ ] essay
- [ ] honest
- [ ] new
- [ ] pause
- [ ] sunlight
- [ ] disturb
- [ ] distribute
- [ ] stable
- [ ] straw

# Chapter 006

- [ ] therefore
- [ ] ankle
- [ ] bookstore
- [ ] hardship
- [ ] butter
- [ ] postpone
- [ ] physicist
- [ ] lantern
- [ ] panic
- [ ] Europe
- [ ] disappear
- [ ] downtown
- [ ] ask
- [ ] amuse
- [ ] criterion
- [ ] shuttle
- [ ] publish
- [ ] zoo
- [ ] perhaps
- [ ] pressure

# Chapter 007

- [ ] viewer
- [ ] being
- [ ] anxiety
- [ ] atom
- [ ] basis
- [ ] terrify
- [ ] electric
- [ ] disappoint
- [ ] toast
- [ ] explode
- [ ] retell
- [ ] salary
- [ ] cyclist
- [ ] stomachache
- [ ] agency
- [ ] chalk
- [ ] dignity
- [ ] hard
- [ ] half
- [ ] fragile

# Chapter 008

- [ ] comrade
- [ ] duty
- [ ] pile
- [ ] worn
- [ ] click
- [ ] heaven
- [ ] attentively
- [ ] hamburger
- [ ] pleased
- [ ] ouch
- [ ] carpenter
- [ ] giraffe
- [ ] cycle
- [ ] caption
- [ ] twist
- [ ] prefer
- [ ] shelf
- [ ] civilian
- [ ] pull
- [ ] still

# Chapter 009

- [ ] wildlife
- [ ] training
- [ ] harmless
- [ ] lie
- [ ] spoken
- [ ] native
- [ ] foggy
- [ ] better
- [ ] main
- [ ] meeting
- [ ] advertisement
- [ ] semicircle
- [ ] pioneer
- [ ] paper
- [ ] officer
- [ ] millionaire
- [ ] memorial
- [ ] envy
- [ ] woo
- [ ] mountain

# Chapter 010

- [ ] impress
- [ ] association
- [ ] package
- [ ] shark
- [ ] sort
- [ ] ox
- [ ] nurse
- [ ] enemy
- [ ] grasp
- [ ] movie
- [ ] coincidence
- [ ] appearance
- [ ] garment
- [ ] agricultural
- [ ] become
- [ ] western
- [ ] want
- [ ] worry
- [ ] law
- [ ] minus

# Chapter 011

- [ ] thinking
- [ ] administration
- [ ] eye
- [ ] marriage
- [ ] fifty
- [ ] broom
- [ ] represent
- [ ] to
- [ ] near
- [ ] shabby
- [ ] glory
- [ ] effect
- [ ] liberation
- [ ] fax
- [ ] state
- [ ] friendly
- [ ] forward
- [ ] exchange
- [ ] suppose
- [ ] generous

# Chapter 012

- [ ] hers
- [ ] explain
- [ ] valid
- [ ] tie
- [ ] then
- [ ] sew
- [ ] desperate
- [ ] steak
- [ ] British
- [ ] sailor
- [ ] wear
- [ ] postage
- [ ] presentation
- [ ] wet
- [ ] avoid
- [ ] pity
- [ ] arrangement
- [ ] among
- [ ] author
- [ ] mommy

# Chapter 013

- [ ] theft
- [ ] bathe
- [ ] assistant
- [ ] battle
- [ ] beancurd
- [ ] front
- [ ] work
- [ ] blackboard
- [ ] washroom
- [ ] legal
- [ ] fill
- [ ] crime
- [ ] fifteen
- [ ] indeed
- [ ] clever
- [ ] refuse
- [ ] whichever
- [ ] leftover
- [ ] base
- [ ] action

# Chapter 014

- [ ] catholic
- [ ] succeed
- [ ] track
- [ ] few
- [ ] city
- [ ] Sunday
- [ ] pet
- [ ] into
- [ ] defeat
- [ ] teenager
- [ ] jeep
- [ ] ample
- [ ] mirror
- [ ] typist
- [ ] stadium
- [ ] substitute
- [ ] carve
- [ ] electrical
- [ ] yell
- [ ] wide

# Chapter 015

- [ ] grape
- [ ] resign
- [ ] percentage
- [ ] stout
- [ ] final
- [ ] certain
- [ ] discourage
- [ ] strict
- [ ] visual
- [ ] those
- [ ] needle
- [ ] car
- [ ] put
- [ ] circumstance
- [ ] without
- [ ] mend
- [ ] arithmetic
- [ ] smart
- [ ] fade
- [ ] attain

# Chapter 016

- [ ] Greek
- [ ] smile
- [ ] eventually
- [ ] fortune
- [ ] purpose
- [ ] tense
- [ ] bridge
- [ ] lemonade
- [ ] stranger
- [ ] liberate
- [ ] librarian
- [ ] club
- [ ] suspect
- [ ] tin
- [ ] proper
- [ ] greeting
- [ ] discount
- [ ] delay
- [ ] wheel
- [ ] time

# Chapter 017

- [ ] hit
- [ ] leather
- [ ] correction
- [ ] twelve
- [ ] exact
- [ ] it
- [ ] fisherman
- [ ] know
- [ ] pension
- [ ] ourselves
- [ ] eleven
- [ ] let
- [ ] good
- [ ] unfortunate
- [ ] news
- [ ] watch
- [ ] agreement
- [ ] deposit
- [ ] determine
- [ ] Mexican

# Chapter 018

- [ ] modem
- [ ] salad
- [ ] contrary
- [ ] education
- [ ] cheer
- [ ] shout
- [ ] pardon
- [ ] nice
- [ ] purchase
- [ ] owe
- [ ] awake
- [ ] everywhere
- [ ] fair
- [ ] Ireland
- [ ] pick
- [ ] organiser
- [ ] young
- [ ] chef
- [ ] roller
- [ ] weekend

# Chapter 019

- [ ] video
- [ ] appoint
- [ ] lady
- [ ] slice
- [ ] favour
- [ ] Arctic
- [ ] pulse
- [ ] tune
- [ ] foreign
- [ ] funeral
- [ ] compete
- [ ] gallon
- [ ] conduct
- [ ] worth
- [ ] discovery
- [ ] centre
- [ ] abrupt
- [ ] hot
- [ ] solar
- [ ] clothing

# Chapter 020

- [ ] emergency
- [ ] abandon
- [ ] sheep
- [ ] computer
- [ ] traditional
- [ ] plus
- [ ] band
- [ ] document
- [ ] gate
- [ ] drum
- [ ] library
- [ ] nutrition
- [ ] may
- [ ] shake
- [ ] worthwhile
- [ ] quilt
- [ ] myself
- [ ] tease
- [ ] book
- [ ] modern

# Chapter 021

- [ ] sorry
- [ ] parallel
- [ ] evident
- [ ] snack
- [ ] possibly
- [ ] your
- [ ] authority
- [ ] northern
- [ ] by
- [ ] following
- [ ] seashell
- [ ] pair
- [ ] explore
- [ ] partner
- [ ] spread
- [ ] Swiss
- [ ] microscope
- [ ] monument
- [ ] slow
- [ ] worse

# Chapter 022

- [ ] particular
- [ ] bid
- [ ] battery
- [ ] tape
- [ ] later
- [ ] envelope
- [ ] short
- [ ] insect
- [ ] might
- [ ] zone
- [ ] paint
- [ ] spring
- [ ] personally
- [ ] directory
- [ ] up
- [ ] warehouse
- [ ] freeway
- [ ] that
- [ ] again
- [ ] digital

# Chapter 023

- [ ] random
- [ ] maximum
- [ ] horse
- [ ] monkey
- [ ] flight
- [ ] coin
- [ ] willingness
- [ ] pork
- [ ] abolish
- [ ] flood
- [ ] react
- [ ] offer
- [ ] bend
- [ ] constant
- [ ] guilty
- [ ] web
- [ ] description
- [ ] fear
- [ ] choose
- [ ] prisoner

# Chapter 024

- [ ] towel
- [ ] tiny
- [ ] tension
- [ ] cover
- [ ] tree
- [ ] founding
- [ ] wonderful
- [ ] position
- [ ] yard
- [ ] else
- [ ] expand
- [ ] mm
- [ ] country
- [ ] below
- [ ] press
- [ ] saucer
- [ ] literature
- [ ] meanwhile
- [ ] ridiculous
- [ ] least

# Chapter 025

- [ ] packet
- [ ] failure
- [ ] apartment
- [ ] conscience
- [ ] running
- [ ] worldwide
- [ ] on
- [ ] appendix
- [ ] Canada
- [ ] parent
- [ ] kill
- [ ] frighten
- [ ] unsafe
- [ ] term
- [ ] bureaucratic
- [ ] gown
- [ ] crazy
- [ ] outward
- [ ] exploit
- [ ] divide

# Chapter 026

- [ ] line
- [ ] bag
- [ ] sail
- [ ] untrue
- [ ] reading
- [ ] toward
- [ ] discrimination
- [ ] interval
- [ ] outgoing
- [ ] subtraction
- [ ] kid
- [ ] singer
- [ ] hire
- [ ] Scottish
- [ ] deadline
- [ ] rob
- [ ] April
- [ ] truck
- [ ] gallery
- [ ] stove

# Chapter 027

- [ ] Pacific
- [ ] ripen
- [ ] glad
- [ ] inch
- [ ] teach
- [ ] sausage
- [ ] northeast
- [ ] insurance
- [ ] messy
- [ ] countryside
- [ ] teapot
- [ ] staff
- [ ] canteen
- [ ] touch
- [ ] are
- [ ] fairness
- [ ] report
- [ ] neck
- [ ] member
- [ ] constitution

# Chapter 028

- [ ] pass
- [ ] medical
- [ ] jam
- [ ] behalf
- [ ] govern
- [ ] cross
- [ ] fifth
- [ ] dawn
- [ ] diverse
- [ ] someone
- [ ] skateboard
- [ ] wish
- [ ] smell
- [ ] matter
- [ ] barbecue
- [ ] aside
- [ ] appreciate
- [ ] lake
- [ ] my
- [ ] plate

# Chapter 029

- [ ] approximately
- [ ] diet
- [ ] way
- [ ] diamond
- [ ] remain
- [ ] aircraft
- [ ] curtain
- [ ] dig
- [ ] Scotland
- [ ] age
- [ ] bamboo
- [ ] arch
- [ ] poet
- [ ] fan
- [ ] breast
- [ ] sleeve
- [ ] mentally
- [ ] power
- [ ] via
- [ ] tick

# Chapter 030

- [ ] relax
- [ ] drawing
- [ ] rough
- [ ] systematic
- [ ] barber
- [ ] trouble
- [ ] male
- [ ] production
- [ ] down
- [ ] liquid
- [ ] adolescence
- [ ] neighbour
- [ ] potential
- [ ] first
- [ ] diagram
- [ ] memory
- [ ] unhappy
- [ ] distant
- [ ] fence
- [ ] crowd

# Chapter 031

- [ ] function
- [ ] bird
- [ ] classify
- [ ] explicit
- [ ] lightning
- [ ] step
- [ ] jog
- [ ] already
- [ ] night
- [ ] drawer
- [ ] wooden
- [ ] accessible
- [ ] passive
- [ ] wonder
- [ ] ought
- [ ] transform
- [ ] defend
- [ ] kilometre
- [ ] talk
- [ ] girl

# Chapter 032

- [ ] ambassador
- [ ] grass
- [ ] billion
- [ ] summary
- [ ] Moslem
- [ ] wire
- [ ] morning
- [ ] depend
- [ ] fold
- [ ] precise
- [ ] quick
- [ ] conference
- [ ] instead
- [ ] Canadian
- [ ] properly
- [ ] absolute
- [ ] example
- [ ] bill
- [ ] since
- [ ] almost

# Chapter 033

- [ ] marry
- [ ] adore
- [ ] starvation
- [ ] handful
- [ ] porridge
- [ ] jet
- [ ] volleyball
- [ ] draft
- [ ] festival
- [ ] alarm
- [ ] sharp
- [ ] regular
- [ ] application
- [ ] republic
- [ ] rubbish
- [ ] heavy
- [ ] drown
- [ ] quality
- [ ] catalogue
- [ ] cube

# Chapter 034

- [ ] wrinkle
- [ ] bookshop
- [ ] eat
- [ ] egg
- [ ] highway
- [ ] white
- [ ] pencil
- [ ] weigh
- [ ] abuse
- [ ] tiger
- [ ] TRUE
- [ ] eighty
- [ ] sickness
- [ ] spiritual
- [ ] I
- [ ] blank
- [ ] through
- [ ] boycott
- [ ] harmony
- [ ] aunt

# Chapter 035

- [ ] fuel
- [ ] Paris
- [ ] frost
- [ ] central
- [ ] farmer
- [ ] vote
- [ ] ruin
- [ ] England
- [ ] helmet
- [ ] the
- [ ] seaside
- [ ] perfect
- [ ] airport
- [ ] flee
- [ ] housewife
- [ ] fight
- [ ] piece
- [ ] breath
- [ ] ownership
- [ ] plane

# Chapter 036

- [ ] fluent
- [ ] gun
- [ ] Indian
- [ ] bad
- [ ] boy
- [ ] howl
- [ ] doll
- [ ] yellow
- [ ] settler
- [ ] unwilling
- [ ] bridegroom
- [ ] favourite
- [ ] delicious
- [ ] stage
- [ ] academic
- [ ] rainbow
- [ ] interview
- [ ] income
- [ ] flag
- [ ] spaceship

# Chapter 037

- [ ] deed
- [ ] pain
- [ ] fox
- [ ] penny
- [ ] around
- [ ] grandma
- [ ] read
- [ ] granddaughter
- [ ] trade
- [ ] European
- [ ] mat
- [ ] wine
- [ ] physician
- [ ] hillside
- [ ] Britain
- [ ] hero
- [ ] plan
- [ ] mourn
- [ ] engineer
- [ ] spend

# Chapter 038

- [ ] bread
- [ ] interpreter
- [ ] operate
- [ ] affect
- [ ] bike
- [ ] sacred
- [ ] means
- [ ] tire
- [ ] marble
- [ ] ferry
- [ ] break
- [ ] natural
- [ ] letter
- [ ] extreme
- [ ] disappointment
- [ ] kitchen
- [ ] consideration
- [ ] merchant
- [ ] jewelry
- [ ] status

# Chapter 039

- [ ] homework
- [ ] autumn
- [ ] forever
- [ ] selfish
- [ ] athlete
- [ ] before
- [ ] itself
- [ ] role
- [ ] family
- [ ] victim
- [ ] worm
- [ ] shopkeeper
- [ ] wedding
- [ ] classical
- [ ] surplus
- [ ] steep
- [ ] woollen
- [ ] of
- [ ] fibre
- [ ] tasteless

# Chapter 040

- [ ] dog
- [ ] sensitive
- [ ] junior
- [ ] translator
- [ ] adventure
- [ ] qualification
- [ ] planet
- [ ] ugly
- [ ] history
- [ ] house
- [ ] surface
- [ ] devote
- [ ] aid
- [ ] component
- [ ] generation
- [ ] edge
- [ ] organ
- [ ] federal
- [ ] alive
- [ ] top

# Chapter 041

- [ ] minority
- [ ] have
- [ ] notice
- [ ] tower
- [ ] actress
- [ ] enthusiastic
- [ ] loose
- [ ] adequate
- [ ] lock
- [ ] blood
- [ ] birthplace
- [ ] navy
- [ ] American
- [ ] problem
- [ ] shall
- [ ] for
- [ ] cordless
- [ ] pleasure
- [ ] appointment
- [ ] would

# Chapter 042

- [ ] grandchild
- [ ] window
- [ ] redirect
- [ ] niece
- [ ] coal
- [ ] mainland
- [ ] mother
- [ ] chaos
- [ ] polite
- [ ] entertainment
- [ ] personnel
- [ ] circle
- [ ] Chinese
- [ ] Monday
- [ ] save
- [ ] collar
- [ ] dot
- [ ] coach
- [ ] nuclear
- [ ] voice

# Chapter 043

- [ ] select
- [ ] thunder
- [ ] ancestor
- [ ] tend
- [ ] bowl
- [ ] pretend
- [ ] majority
- [ ] minute
- [ ] weather
- [ ] suggestion
- [ ] sunrise
- [ ] alike
- [ ] district
- [ ] compulsory
- [ ] Tibet
- [ ] lay
- [ ] stomach
- [ ] damage
- [ ] cough
- [ ] shut

# Chapter 044

- [ ] anniversary
- [ ] coat
- [ ] ham
- [ ] depth
- [ ] somebody
- [ ] requirement
- [ ] guard
- [ ] superman
- [ ] artist
- [ ] prove
- [ ] cry
- [ ] lunch
- [ ] fourth
- [ ] tractor
- [ ] entire
- [ ] bare
- [ ] guess
- [ ] outside
- [ ] absent
- [ ] firewood

# Chapter 045

- [ ] our
- [ ] Iceland
- [ ] ecology
- [ ] religion
- [ ] participate
- [ ] unusual
- [ ] gravity
- [ ] dust
- [ ] science
- [ ] money
- [ ] ship
- [ ] precious
- [ ] today
- [ ] overlook
- [ ] hang
- [ ] ticket
- [ ] Mosquito
- [ ] repairs
- [ ] dormitory
- [ ] write

# Chapter 046

- [ ] seat
- [ ] wander
- [ ] tentative
- [ ] eighteen
- [ ] hold
- [ ] habit
- [ ] future
- [ ] independent
- [ ] subject
- [ ] say
- [ ] target
- [ ] disease
- [ ] death
- [ ] ago
- [ ] shore
- [ ] obey
- [ ] thankful
- [ ] restaurant
- [ ] awesome
- [ ] decorate

# Chapter 047

- [ ] judgement
- [ ] congratulation
- [ ] appropriate
- [ ] assessment
- [ ] supper
- [ ] bent
- [ ] they
- [ ] move
- [ ] eagle
- [ ] common
- [ ] customer
- [ ] cast
- [ ] million
- [ ] custom
- [ ] extra
- [ ] ash
- [ ] evaluate
- [ ] suit
- [ ] servant
- [ ] Wednesday

# Chapter 048

- [ ] after
- [ ] attempt
- [ ] retire
- [ ] return
- [ ] celebrate
- [ ] switch
- [ ] cure
- [ ] primary
- [ ] keep
- [ ] pyramid
- [ ] afford
- [ ] cut
- [ ] ban
- [ ] tablet
- [ ] head
- [ ] foreigner
- [ ] willing
- [ ] mineral
- [ ] shade
- [ ] various

# Chapter 049

- [ ] poem
- [ ] above
- [ ] dinosaur
- [ ] valuable
- [ ] swallow
- [ ] blue
- [ ] teamwork
- [ ] wax
- [ ] tyre
- [ ] hour
- [ ] battleground
- [ ] sometimes
- [ ] mud
- [ ] office
- [ ] leg
- [ ] melon
- [ ] race
- [ ] optional
- [ ] stop
- [ ] dustbin

# Chapter 050

- [ ] screen
- [ ] stocking
- [ ] flat
- [ ] alone
- [ ] print
- [ ] die
- [ ] mouse
- [ ] space
- [ ] early
- [ ] athletic
- [ ] cubic
- [ ] secret
- [ ] bush
- [ ] calculate
- [ ] super
- [ ] people
- [ ] brake
- [ ] side
- [ ] safety
- [ ] snowball

# Chapter 051

- [ ] address
- [ ] store
- [ ] institution
- [ ] neat
- [ ] laughter
- [ ] schoolbag
- [ ] clap
- [ ] wall
- [ ] duck
- [ ] download
- [ ] pine
- [ ] agree
- [ ] remember
- [ ] large
- [ ] curious
- [ ] day
- [ ] motorcycle
- [ ] jeans
- [ ] busy
- [ ] astonish

# Chapter 052

- [ ] cotton
- [ ] tax
- [ ] juicy
- [ ] apply
- [ ] aggressive
- [ ] canal
- [ ] achieve
- [ ] straight
- [ ] shoulder
- [ ] bitter
- [ ] growth
- [ ] volunteer
- [ ] lip
- [ ] representative
- [ ] same
- [ ] southern
- [ ] daylight
- [ ] symphony
- [ ] watermelon
- [ ] smoking

# Chapter 053

- [ ] clinic
- [ ] model
- [ ] partly
- [ ] painter
- [ ] purse
- [ ] characteristic
- [ ] skin
- [ ] train
- [ ] vivid
- [ ] operation
- [ ] check
- [ ] alcoholic
- [ ] button
- [ ] salesgirl
- [ ] roast
- [ ] communist
- [ ] give
- [ ] scar
- [ ] found
- [ ] handkerchief

# Chapter 054

- [ ] acquisition
- [ ] cloth
- [ ] single
- [ ] latter
- [ ] patient
- [ ] Mexico
- [ ] paperwork
- [ ] appetite
- [ ] dish
- [ ] tap
- [ ] Buddhism
- [ ] come
- [ ] university
- [ ] bed
- [ ] Egypt
- [ ] necklace
- [ ] unemployment
- [ ] football
- [ ] ahead
- [ ] impression

# Chapter 055

- [ ] buy
- [ ] spit
- [ ] across
- [ ] no
- [ ] announce
- [ ] fare
- [ ] possible
- [ ] bay
- [ ] quarter
- [ ] bang
- [ ] stubborn
- [ ] extremely
- [ ] cost
- [ ] cheese
- [ ] straightforward
- [ ] traveler
- [ ] international
- [ ] acute
- [ ] gentle
- [ ] imagine

# Chapter 056

- [ ] raincoat
- [ ] humorous
- [ ] gruel
- [ ] fine
- [ ] quit
- [ ] ant
- [ ] squeeze
- [ ] elephant
- [ ] pest
- [ ] separate
- [ ] telegram
- [ ] pronounce
- [ ] electronic
- [ ] jump
- [ ] lot
- [ ] deliberately
- [ ] sculpture
- [ ] steal
- [ ] miniskirt
- [ ] research

# Chapter 057

- [ ] refrigerator
- [ ] round
- [ ] casual
- [ ] cancel
- [ ] he
- [ ] colleague
- [ ] whether
- [ ] live
- [ ] beyond
- [ ] ill
- [ ] skate
- [ ] herb
- [ ] recent
- [ ] discuss
- [ ] silent
- [ ] kind
- [ ] badly
- [ ] contradictory
- [ ] shower
- [ ] aspect

# Chapter 058

- [ ] decade
- [ ] distance
- [ ] zipper
- [ ] permanent
- [ ] honour
- [ ] political
- [ ] organise
- [ ] driver
- [ ] complete
- [ ] nowhere
- [ ] shop
- [ ] gradually
- [ ] shaver
- [ ] virus
- [ ] disk
- [ ] loaf
- [ ] arrest
- [ ] square
- [ ] justice
- [ ] Dr

# Chapter 059

- [ ] world
- [ ] if
- [ ] dirt
- [ ] procedure
- [ ] mix
- [ ] strong
- [ ] fact
- [ ] kilo
- [ ] scientific
- [ ] feed
- [ ] category
- [ ] dead
- [ ] against
- [ ] corrupt
- [ ] laugh
- [ ] airspace
- [ ] vanilla
- [ ] hammer
- [ ] perfume
- [ ] whose

# Chapter 060

- [ ] necktie
- [ ] bury
- [ ] cabbage
- [ ] shortcoming
- [ ] salt
- [ ] seventy
- [ ] length
- [ ] worst
- [ ] audience
- [ ] measure
- [ ] outline
- [ ] bathroom
- [ ] height
- [ ] prairie
- [ ] balance
- [ ] blind
- [ ] portable
- [ ] row
- [ ] truly
- [ ] downward

# Chapter 061

- [ ] accent
- [ ] basket
- [ ] shave
- [ ] outer
- [ ] note
- [ ] Ottawa
- [ ] smoker
- [ ] drag
- [ ] unite
- [ ] Spain
- [ ] postcode
- [ ] confident
- [ ] website
- [ ] swell
- [ ] medicine
- [ ] set
- [ ] comb
- [ ] sale
- [ ] immigration
- [ ] process

# Chapter 062

- [ ] east
- [ ] hurry
- [ ] how
- [ ] beast
- [ ] practice
- [ ] reliable
- [ ] evening
- [ ] allocate
- [ ] development
- [ ] paragraph
- [ ] terminal
- [ ] correspond
- [ ] war
- [ ] sleepy
- [ ] surprise
- [ ] snowman
- [ ] search
- [ ] toothache
- [ ] wash
- [ ] classroom

# Chapter 063

- [ ] nephew
- [ ] cap
- [ ] aggression
- [ ] TV
- [ ] notebook
- [ ] bonus
- [ ] drop
- [ ] circus
- [ ] amount
- [ ] bounce
- [ ] married
- [ ] none
- [ ] arrive
- [ ] steady
- [ ] museum
- [ ] enjoyable
- [ ] headache
- [ ] hopeful
- [ ] event
- [ ] ache

# Chapter 064

- [ ] heavily
- [ ] warning
- [ ] form
- [ ] outspoken
- [ ] hungry
- [ ] ton
- [ ] afraid
- [ ] salty
- [ ] need
- [ ] rugby
- [ ] lamb
- [ ] cream
- [ ] fond
- [ ] recite
- [ ] disobey
- [ ] leader
- [ ] fun
- [ ] vain
- [ ] service
- [ ] stainless

# Chapter 065

- [ ] agent
- [ ] maid
- [ ] camera
- [ ] too
- [ ] nine
- [ ] perform
- [ ] doubt
- [ ] digest
- [ ] while
- [ ] pretty
- [ ] studio
- [ ] Moscow
- [ ] disturbing
- [ ] schoolmate
- [ ] adult
- [ ] miss
- [ ] hobby
- [ ] disagree
- [ ] bound
- [ ] approve

# Chapter 066

- [ ] convenience
- [ ] who
- [ ] arm
- [ ] goods
- [ ] butterfly
- [ ] risk
- [ ] African
- [ ] twentieth
- [ ] America
- [ ] bottle
- [ ] literary
- [ ] bicycle
- [ ] wallet
- [ ] superb
- [ ] pool
- [ ] fragrant
- [ ] mercy
- [ ] preview
- [ ] hatch
- [ ] school

# Chapter 067

- [ ] promote
- [ ] crew
- [ ] preparation
- [ ] tomorrow
- [ ] taste
- [ ] abortion
- [ ] sparrow
- [ ] bond
- [ ] face
- [ ] wound
- [ ] mustard
- [ ] ruler
- [ ] umbrella
- [ ] pub
- [ ] playground
- [ ] arbitrary
- [ ] turning
- [ ] account
- [ ] quite
- [ ] wake

# Chapter 068

- [ ] workmate
- [ ] album
- [ ] dangerous
- [ ] replace
- [ ] eyesight
- [ ] tremble
- [ ] cage
- [ ] either
- [ ] lucky
- [ ] order
- [ ] south
- [ ] mobile
- [ ] door
- [ ] list
- [ ] videophone
- [ ] empty
- [ ] armchair
- [ ] self
- [ ] nature
- [ ] transparent

# Chapter 069

- [ ] submit
- [ ] agriculture
- [ ] exactly
- [ ] undo
- [ ] cheerful
- [ ] remind
- [ ] disaster
- [ ] daily
- [ ] cheers
- [ ] season
- [ ] dislike
- [ ] software
- [ ] steel
- [ ] industry
- [ ] there
- [ ] botany
- [ ] unfortunately
- [ ] gain
- [ ] together
- [ ] visit

# Chapter 070

- [ ] gather
- [ ] over
- [ ] madam
- [ ] recreation
- [ ] dive
- [ ] wing
- [ ] lemon
- [ ] record
- [ ] beach
- [ ] chairwoman
- [ ] basement
- [ ] schedule
- [ ] wood
- [ ] deaf
- [ ] architect
- [ ] walnut
- [ ] Irish
- [ ] manner
- [ ] twin
- [ ] powerful

# Chapter 071

- [ ] frequent
- [ ] dam
- [ ] free
- [ ] ninety
- [ ] fright
- [ ] snake
- [ ] version
- [ ] disabled
- [ ] march
- [ ] truth
- [ ] heel
- [ ] furnished
- [ ] nest
- [ ] conclude
- [ ] basin
- [ ] pear
- [ ] awkward
- [ ] stopwatch
- [ ] shame
- [ ] quiz

# Chapter 072

- [ ] forty
- [ ] clumsy
- [ ] ground
- [ ] show
- [ ] rebuild
- [ ] politician
- [ ] north
- [ ] rat
- [ ] nor
- [ ] captain
- [ ] cautious
- [ ] guest
- [ ] hair
- [ ] dozen
- [ ] certificate
- [ ] love
- [ ] container
- [ ] flour
- [ ] total
- [ ] purple

# Chapter 073

- [ ] withdraw
- [ ] insist
- [ ] joke
- [ ] autonomous
- [ ] all
- [ ] score
- [ ] protect
- [ ] handwriting
- [ ] sing
- [ ] deliver
- [ ] meaning
- [ ] balcony
- [ ] hibernation
- [ ] vase
- [ ] resemble
- [ ] cab
- [ ] decision
- [ ] composition
- [ ] tent
- [ ] rewind

# Chapter 074

- [ ] conductor
- [ ] edition
- [ ] female
- [ ] determination
- [ ] equal
- [ ] little
- [ ] hibernate
- [ ] pepper
- [ ] glove
- [ ] diary
- [ ] citizen
- [ ] destroy
- [ ] altogether
- [ ] contribution
- [ ] decoration
- [ ] view
- [ ] darkness
- [ ] bar
- [ ] dessert
- [ ] wag

# Chapter 075

- [ ] vinegar
- [ ] realize
- [ ] exhibition
- [ ] broadcast
- [ ] parrot
- [ ] debt
- [ ] birdcage
- [ ] scare
- [ ] where
- [ ] ambulance
- [ ] easy
- [ ] housework
- [ ] concrete
- [ ] sound
- [ ] scientist
- [ ] construct
- [ ] get
- [ ] tall
- [ ] diploma
- [ ] beside

# Chapter 076

- [ ] photographer
- [ ] anchor
- [ ] a
- [ ] social
- [ ] easily
- [ ] chess
- [ ] strange
- [ ] sick
- [ ] Russian
- [ ] inland
- [ ] academy
- [ ] invent
- [ ] wealth
- [ ] chick
- [ ] companion
- [ ] mouth
- [ ] find
- [ ] town
- [ ] trousers
- [ ] performer

# Chapter 077

- [ ] petrol
- [ ] solid
- [ ] uncomfortable
- [ ] expense
- [ ] bowling
- [ ] metre
- [ ] passage
- [ ] nearly
- [ ] institute
- [ ] draw
- [ ] as
- [ ] meal
- [ ] sneeze
- [ ] bit
- [ ] but
- [ ] monitor
- [ ] thrill
- [ ] advice
- [ ] whale
- [ ] vacant

# Chapter 078

- [ ] underground
- [ ] rocket
- [ ] trial
- [ ] Shanghai
- [ ] root
- [ ] nationwide
- [ ] hotel
- [ ] specialist
- [ ] any
- [ ] thirty
- [ ] attractive
- [ ] phenomenon
- [ ] counter
- [ ] scarf
- [ ] tail
- [ ] swear
- [ ] high
- [ ] adjustment
- [ ] rely
- [ ] deserve

# Chapter 079

- [ ] mine
- [ ] AIDS
- [ ] deal
- [ ] apron
- [ ] data
- [ ] acquaintance
- [ ] great
- [ ] bandage
- [ ] oral
- [ ] throw
- [ ] loss
- [ ] regulation
- [ ] boil
- [ ] Greece
- [ ] chart
- [ ] shape
- [ ] milk
- [ ] group
- [ ] prevent
- [ ] associate

# Chapter 080

- [ ] plug
- [ ] detective
- [ ] alcohol
- [ ] offshore
- [ ] cigar
- [ ] jacket
- [ ] red
- [ ] Christian
- [ ] theoretical
- [ ] also
- [ ] necessary
- [ ] gold
- [ ] sympathy
- [ ] tomato
- [ ] create
- [ ] anyhow
- [ ] declare
- [ ] recommend
- [ ] London
- [ ] addicted

# Chapter 081

- [ ] focus
- [ ] forget
- [ ] sailing
- [ ] serious
- [ ] dad
- [ ] scold
- [ ] vacation
- [ ] immediate
- [ ] timetable
- [ ] recycle
- [ ] fall
- [ ] join
- [ ] pink
- [ ] joy
- [ ] muddy
- [ ] rest
- [ ] exit
- [ ] headline
- [ ] flu
- [ ] network

# Chapter 082

- [ ] vehicle
- [ ] task
- [ ] unbearable
- [ ] rapid
- [ ] concentrate
- [ ] tiresome
- [ ] market
- [ ] burst
- [ ] volcano
- [ ] brush
- [ ] motherland
- [ ] ear
- [ ] circuit
- [ ] in
- [ ] pin
- [ ] belong
- [ ] brotherhood
- [ ] music
- [ ] brother
- [ ] pleasant

# Chapter 083

- [ ] worried
- [ ] chicken
- [ ] argue
- [ ] dress
- [ ] convince
- [ ] reporter
- [ ] sky
- [ ] voluntary
- [ ] drug
- [ ] enquiry
- [ ] dip
- [ ] cuisine
- [ ] daughter
- [ ] product
- [ ] mixture
- [ ] name
- [ ] litre
- [ ] typhoon
- [ ] helpful
- [ ] predict

# Chapter 084

- [ ] uncertain
- [ ] noodle
- [ ] foolish
- [ ] turn
- [ ] horrible
- [ ] cell
- [ ] dismiss
- [ ] boring
- [ ] obvious
- [ ] rainy
- [ ] violence
- [ ] antique
- [ ] experiment
- [ ] field
- [ ] handbag
- [ ] include
- [ ] ripe
- [ ] peasant
- [ ] athletics
- [ ] discover

# Chapter 085

- [ ] leak
- [ ] rainfall
- [ ] tool
- [ ] bite
- [ ] praise
- [ ] activity
- [ ] carry
- [ ] take
- [ ] dimension
- [ ] format
- [ ] start
- [ ] week
- [ ] reject
- [ ] artificial
- [ ] welcome
- [ ] earth
- [ ] avenue
- [ ] strawberry
- [ ] translate
- [ ] sea

# Chapter 086

- [ ] drill
- [ ] page
- [ ] stamp
- [ ] along
- [ ] style
- [ ] garden
- [ ] oppose
- [ ] nationality
- [ ] consultant
- [ ] load
- [ ] behavious
- [ ] nylon
- [ ] statue
- [ ] witness
- [ ] difficult
- [ ] moral
- [ ] evidence
- [ ] pour
- [ ] map
- [ ] blouse

# Chapter 087

- [ ] lab
- [ ] hall
- [ ] compromise
- [ ] motivation
- [ ] unfit
- [ ] lonely
- [ ] gifted
- [ ] considerate
- [ ] plot
- [ ] carrot
- [ ] nothing
- [ ] brochure
- [ ] weight
- [ ] hope
- [ ] lorry
- [ ] noisily
- [ ] cloud
- [ ] topic
- [ ] hug
- [ ] size

# Chapter 088

- [ ] ladder
- [ ] folk
- [ ] energetic
- [ ] mop
- [ ] assumption
- [ ] flesh
- [ ] marathon
- [ ] remove
- [ ] sun
- [ ] expect
- [ ] ward
- [ ] comfortable
- [ ] yesterday
- [ ] feeling
- [ ] spaghetti
- [ ] his
- [ ] media
- [ ] director
- [ ] produce
- [ ] waist

# Chapter 089

- [ ] porter
- [ ] nut
- [ ] westwards
- [ ] offence
- [ ] vocabulary
- [ ] aim
- [ ] receptionist
- [ ] greengrocer
- [ ] box
- [ ] jaw
- [ ] cinema
- [ ] weed
- [ ] merry
- [ ] accident
- [ ] suitable
- [ ] pilot
- [ ] friendship
- [ ] floor
- [ ] magic
- [ ] unfold

# Chapter 090

- [ ] October
- [ ] musician
- [ ] lounge
- [ ] strait
- [ ] suite
- [ ] lively
- [ ] cigarette
- [ ] hometown
- [ ] shortly
- [ ] arrow
- [ ] May
- [ ] attach
- [ ] fortnight
- [ ] expose
- [ ] pollute
- [ ] thank
- [ ] ski
- [ ] sunshine
- [ ] project
- [ ] southwest

# Chapter 091

- [ ] illegal
- [ ] statistics
- [ ] level
- [ ] cosy
- [ ] tight
- [ ] shadow
- [ ] continent
- [ ] bacterium
- [ ] roundabout
- [ ] connection
- [ ] bottom
- [ ] printer
- [ ] aboard
- [ ] writing
- [ ] bleed
- [ ] spy
- [ ] soldier
- [ ] temperature
- [ ] both
- [ ] fresh

# Chapter 092

- [ ] kingdom
- [ ] boating
- [ ] tendency
- [ ] concert
- [ ] consume
- [ ] six
- [ ] refresh
- [ ] broad
- [ ] camp
- [ ] gale
- [ ] borrow
- [ ] demand
- [ ] knock
- [ ] sour
- [ ] grandpa
- [ ] zip
- [ ] rank
- [ ] butcher
- [ ] ready
- [ ] pig

# Chapter 093

- [ ] trap
- [ ] cancer
- [ ] vice
- [ ] harm
- [ ] rare
- [ ] brewery
- [ ] finish
- [ ] cock
- [ ] fairly
- [ ] grandparents
- [ ] instant
- [ ] see
- [ ] back
- [ ] area
- [ ] sacrifice
- [ ] Africa
- [ ] collision
- [ ] homeland
- [ ] technical
- [ ] ink

# Chapter 094

- [ ] faith
- [ ] never
- [ ] quarrel
- [ ] undivided
- [ ] separation
- [ ] Indicate
- [ ] will
- [ ] express
- [ ] fast
- [ ] open
- [ ] pocket
- [ ] soul
- [ ] branch
- [ ] tip
- [ ] mutton
- [ ] boom
- [ ] magazine
- [ ] hospital
- [ ] sock
- [ ] physics

# Chapter 095

- [ ] taxi
- [ ] facial
- [ ] famous
- [ ] China
- [ ] exam
- [ ] passenger
- [ ] seagull
- [ ] when
- [ ] trick
- [ ] fix
- [ ] onto
- [ ] commit
- [ ] oval
- [ ] building
- [ ] evolution
- [ ] disgusting
- [ ] unmarried
- [ ] chair
- [ ] reasonable
- [ ] hide

# Chapter 096

- [ ] bye
- [ ] sharpen
- [ ] fantastic
- [ ] eraser
- [ ] chemical
- [ ] ministry
- [ ] sponsor
- [ ] nose
- [ ] reserve
- [ ] during
- [ ] corn
- [ ] unfair
- [ ] educate
- [ ] arrange
- [ ] rise
- [ ] month
- [ ] competence
- [ ] noon
- [ ] glasshouse
- [ ] water

# Chapter 097

- [ ] key
- [ ] lung
- [ ] sixty
- [ ] January
- [ ] fried
- [ ] kilogram
- [ ] smooth
- [ ] reviewer
- [ ] inside
- [ ] second
- [ ] master
- [ ] healthy
- [ ] file
- [ ] seventh
- [ ] college
- [ ] liberty
- [ ] blow
- [ ] questionnaire
- [ ] Christmas
- [ ] father

# Chapter 098

- [ ] everyone
- [ ] mild
- [ ] could
- [ ] automatic
- [ ] article
- [ ] link
- [ ] CD
- [ ] about
- [ ] local
- [ ] hydrogen
- [ ] backache
- [ ] temptation
- [ ] crayon
- [ ] fruit
- [ ] learned
- [ ] rather
- [ ] job
- [ ] mathematics
- [ ] occupation
- [ ] consequence

# Chapter 099

- [ ] increase
- [ ] forest
- [ ] relative
- [ ] pupil
- [ ] visa
- [ ] restriction
- [ ] fridge
- [ ] behind
- [ ] swing
- [ ] approach
- [ ] correct
- [ ] at
- [ ] pill
- [ ] underline
- [ ] team
- [ ] scholarship
- [ ] committee
- [ ] stick
- [ ] cowboy
- [ ] expectation

# Chapter 100

- [ ] unconditional
- [ ] drier
- [ ] end
- [ ] permission
- [ ] use
- [ ] hearing
- [ ] iron
- [ ] reward
- [ ] signal
- [ ] oneself
- [ ] argument
- [ ] character
- [ ] northwards
- [ ] hat
- [ ] improve
- [ ] fail
- [ ] scholar
- [ ] require
- [ ] mention
- [ ] eight

# Chapter 101

- [ ] attention
- [ ] decline
- [ ] skillfully
- [ ] cat
- [ ] last
- [ ] yourself
- [ ] like
- [ ] west
- [ ] surgeon
- [ ] flow
- [ ] congratulate
- [ ] whole
- [ ] Miss
- [ ] brief
- [ ] animal
- [ ] question
- [ ] inn
- [ ] polish
- [ ] principle
- [ ] satisfaction

# Chapter 102

- [ ] clean
- [ ] reputation
- [ ] belly
- [ ] suck
- [ ] toilet
- [ ] bacon
- [ ] poison
- [ ] motorbike
- [ ] sink
- [ ] tongue
- [ ] violin
- [ ] delicate
- [ ] embassy
- [ ] error
- [ ] disadvantage
- [ ] green
- [ ] seek
- [ ] maybe
- [ ] graph
- [ ] recipe

# Chapter 103

- [ ] laser
- [ ] entrance
- [ ] rent
- [ ] match
- [ ] very
- [ ] raw
- [ ] absurd
- [ ] possibility
- [ ] garage
- [ ] oxygen
- [ ] goat
- [ ] radiation
- [ ] fog
- [ ] host
- [ ] amazing
- [ ] outdoors
- [ ] progress
- [ ] authentic
- [ ] omelette
- [ ] headmistress

# Chapter 104

- [ ] trip
- [ ] transport
- [ ] erupt
- [ ] forgetful
- [ ] sir
- [ ] friend
- [ ] holiday
- [ ] drink
- [ ] commercial
- [ ] whenever
- [ ] emperor
- [ ] bingo
- [ ] operator
- [ ] apology
- [ ] pure
- [ ] devotion
- [ ] grade
- [ ] now
- [ ] wounded
- [ ] hen

# Chapter 105

- [ ] opposite
- [ ] profit
- [ ] courage
- [ ] outstanding
- [ ] shelter
- [ ] look
- [ ] coast
- [ ] ignore
- [ ] different
- [ ] real
- [ ] typical
- [ ] handy
- [ ] broken
- [ ] aloud
- [ ] appear
- [ ] barbershop
- [ ] student
- [ ] yummy
- [ ] midnight
- [ ] addition

# Chapter 106

- [ ] weatherman
- [ ] permit
- [ ] hand
- [ ] obtain
- [ ] prize
- [ ] content
- [ ] firmly
- [ ] colour
- [ ] tired
- [ ] vague
- [ ] classic
- [ ] concern
- [ ] talent
- [ ] several
- [ ] simply
- [ ] India
- [ ] acre
- [ ] potato
- [ ] adopt
- [ ] knee

# Chapter 107

- [ ] newspaper
- [ ] uniform
- [ ] support
- [ ] conservation
- [ ] fundamental
- [ ] wayside
- [ ] request
- [ ] coke
- [ ] between
- [ ] opener
- [ ] credit
- [ ] absorb
- [ ] multiply
- [ ] chocolate
- [ ] ball
- [ ] cheque
- [ ] Russia
- [ ] Tibetan
- [ ] temple
- [ ] fire

# Chapter 108

- [ ] excite
- [ ] parcel
- [ ] ability
- [ ] leave
- [ ] handle
- [ ] flashlight
- [ ] keyboard
- [ ] candidate
- [ ] photograph
- [ ] glass
- [ ] tradition
- [ ] these
- [ ] unlike
- [ ] seldom
- [ ] please
- [ ] overcome
- [ ] except
- [ ] advocate
- [ ] mountainous
- [ ] four

# Chapter 109

- [ ] meet
- [ ] Dynasty
- [ ] reach
- [ ] ordinary
- [ ] challenging
- [ ] speed
- [ ] once
- [ ] type
- [ ] sweet
- [ ] goodness
- [ ] irrigation
- [ ] tourist
- [ ] buffet
- [ ] share
- [ ] intelligence
- [ ] aware
- [ ] adolescent
- [ ] scan
- [ ] anecdote
- [ ] former

# Chapter 110

- [ ] fetch
- [ ] toothbrush
- [ ] Egyptian
- [ ] reform
- [ ] bench
- [ ] best
- [ ] vest
- [ ] weakness
- [ ] luck
- [ ] Friday
- [ ] helicopter
- [ ] dare
- [ ] confidential
- [ ] slight
- [ ] wait
- [ ] journey
- [ ] lazy
- [ ] understanding
- [ ] loudspeaker
- [ ] chimney

# Chapter 111

- [ ] sweep
- [ ] endless
- [ ] instrument
- [ ] zoom
- [ ] prison
- [ ] pianist
- [ ] ballpoint
- [ ] rooster
- [ ] capsule
- [ ] rag
- [ ] game
- [ ] port
- [ ] leaf
- [ ] waiter
- [ ] flower
- [ ] dusty
- [ ] attraction
- [ ] sister
- [ ] vegetable
- [ ] beehive

# Chapter 112

- [ ] fool
- [ ] firework
- [ ] dusk
- [ ] somewhere
- [ ] low
- [ ] motto
- [ ] union
- [ ] most
- [ ] skyscraper
- [ ] chemist
- [ ] apple
- [ ] convey
- [ ] bathrobe
- [ ] enjoy
- [ ] platform
- [ ] dentist
- [ ] turkey
- [ ] eastwards
- [ ] confirm
- [ ] Scratch

# Chapter 113

- [ ] spray
- [ ] happiness
- [ ] sand
- [ ] hook
- [ ] jungle
- [ ] cleaner
- [ ] develop
- [ ] standard
- [ ] patent
- [ ] modest
- [ ] cookie
- [ ] German
- [ ] popular
- [ ] lead
- [ ] labour
- [ ] textbook
- [ ] feather
- [ ] forehead
- [ ] barrier
- [ ] provide

# Chapter 114

- [ ] throughout
- [ ] optimistic
- [ ] careful
- [ ] rose
- [ ] slide
- [ ] sadness
- [ ] cooker
- [ ] runner
- [ ] hunt
- [ ] courtyard
- [ ] seven
- [ ] ballet
- [ ] angry
- [ ] jewel
- [ ] due
- [ ] abroad
- [ ] sob
- [ ] sunny
- [ ] black
- [ ] contain

# Chapter 115

- [ ] comfort
- [ ] sightseeing
- [ ] session
- [ ] toy
- [ ] comprehension
- [ ] unsuccessful
- [ ] annual
- [ ] sunburnt
- [ ] method
- [ ] treasure
- [ ] moment
- [ ] applaud
- [ ] grammar
- [ ] ever
- [ ] fish
- [ ] bright
- [ ] flame
- [ ] light
- [ ] nobody
- [ ] object

# Chapter 116

- [ ] workday
- [ ] film
- [ ] immediately
- [ ] inspire
- [ ] scream
- [ ] table
- [ ] anxious
- [ ] agenda
- [ ] policy
- [ ] panda
- [ ] clay
- [ ] assistance
- [ ] expensive
- [ ] outing
- [ ] Buddhist
- [ ] PM
- [ ] algebra
- [ ] tidy
- [ ] manager
- [ ] funny

# Chapter 117

- [ ] suffer
- [ ] curriculum
- [ ] razor
- [ ] universe
- [ ] suitcase
- [ ] police
- [ ] ceiling
- [ ] theory
- [ ] direct
- [ ] some
- [ ] tasty
- [ ] contemporary
- [ ] punctual
- [ ] must
- [ ] attract
- [ ] wisdom
- [ ] shorts
- [ ] negotiate
- [ ] feast
- [ ] practical

# Chapter 118

- [ ] private
- [ ] technique
- [ ] bun
- [ ] rabbit
- [ ] yet
- [ ] Germany
- [ ] referee
- [ ] policeman
- [ ] normal
- [ ] two
- [ ] comma
- [ ] couple
- [ ] ours
- [ ] cook
- [ ] slim
- [ ] memorize
- [ ] copy
- [ ] thin
- [ ] September
- [ ] burn

# Chapter 119

- [ ] alongside
- [ ] educator
- [ ] sheet
- [ ] baggage
- [ ] wrestle
- [ ] scores
- [ ] otherwise
- [ ] active
- [ ] connect
- [ ] bucket
- [ ] basketball
- [ ] lend
- [ ] mushroom
- [ ] secondhand
- [ ] god
- [ ] souvenirs
- [ ] spin
- [ ] rubber
- [ ] sincerely
- [ ] reception

# Chapter 120

- [ ] sauce
- [ ] spot
- [ ] five
- [ ] workforce
- [ ] concept
- [ ] angle
- [ ] vertical
- [ ] insure
- [ ] coffee
- [ ] gas
- [ ] radium
- [ ] drive
- [ ] kiss
- [ ] attend
- [ ] equipment
- [ ] heroine
- [ ] gentleman
- [ ] difficulty
- [ ] follow
- [ ] him

# Chapter 121

- [ ] old
- [ ] big
- [ ] anyway
- [ ] fry
- [ ] commitment
- [ ] stand
- [ ] Australia
- [ ] recover
- [ ] pint
- [ ] wolf
- [ ] creature
- [ ] sentence
- [ ] street
- [ ] flash
- [ ] equality
- [ ] relate
- [ ] independence
- [ ] willingly
- [ ] basic
- [ ] consist

# Chapter 122

- [ ] land
- [ ] user
- [ ] brain
- [ ] choice
- [ ] introduce
- [ ] ride
- [ ] circulate
- [ ] person
- [ ] nursery
- [ ] regards
- [ ] postman
- [ ] sceptical
- [ ] cruel
- [ ] seem
- [ ] access
- [ ] statement
- [ ] ambiguous
- [ ] island
- [ ] honey
- [ ] wherever

# Chapter 123

- [ ] yes
- [ ] breathless
- [ ] golf
- [ ] danger
- [ ] interest
- [ ] flaming
- [ ] temporary
- [ ] accomplish
- [ ] stupid
- [ ] glue
- [ ] exercise
- [ ] winner
- [ ] sandwich
- [ ] heap
- [ ] trend
- [ ] cellar
- [ ] visitor
- [ ] seed
- [ ] out
- [ ] breakfast

# Chapter 124

- [ ] certainly
- [ ] them
- [ ] kindergarten
- [ ] microwave
- [ ] hur
- [ ] sofa
- [ ] camel
- [ ] engine
- [ ] lift
- [ ] surrounding
- [ ] flexible
- [ ] holy
- [ ] wrong
- [ ] crop
- [ ] subjective
- [ ] blame
- [ ] fireplace
- [ ] cheek
- [ ] fluency
- [ ] pen

# Chapter 125

- [ ] survival
- [ ] slavery
- [ ] explorer
- [ ] admission
- [ ] stress
- [ ] brunch
- [ ] victory
- [ ] safe
- [ ] passport
- [ ] pregnant
- [ ] stair
- [ ] bravery
- [ ] struggle
- [ ] abundant
- [ ] pronunciation
- [ ] relay
- [ ] unconscious
- [ ] racial
- [ ] silly
- [ ] remote

# Chapter 126

- [ ] shallow
- [ ] satellite
- [ ] expert
- [ ] bath
- [ ] haircut
- [ ] friction
- [ ] primitive
- [ ] moustache
- [ ] goose
- [ ] absence
- [ ] repair
- [ ] admit
- [ ] valley
- [ ] bomb
- [ ] choir
- [ ] thing
- [ ] toothpaste
- [ ] yours
- [ ] geography
- [ ] loudly

# Chapter 127

- [ ] wealthy
- [ ] hi
- [ ] channel
- [ ] pillow
- [ ] soup
- [ ] analysis
- [ ] cassette
- [ ] laundry
- [ ] decrease
- [ ] insert
- [ ] encouragement
- [ ] youth
- [ ] thousand
- [ ] physical
- [ ] change
- [ ] allowance
- [ ] asleep
- [ ] swimming
- [ ] alternative
- [ ] kindness

# Chapter 128

- [ ] accept
- [ ] noise
- [ ] clear
- [ ] adaptation
- [ ] novel
- [ ] inventor
- [ ] merciful
- [ ] shopping
- [ ] soccer
- [ ] pan
- [ ] forecast
- [ ] drunk
- [ ] whom
- [ ] mind
- [ ] sideways
- [ ] spare
- [ ] unique
- [ ] export
- [ ] success
- [ ] mess

# Chapter 129

- [ ] airmail
- [ ] innocent
- [ ] care
- [ ] grand
- [ ] triangle
- [ ] full
- [ ] translation
- [ ] pound
- [ ] count
- [ ] or
- [ ] paddle
- [ ] invitation
- [ ] test
- [ ] bathtub
- [ ] opinion
- [ ] delight
- [ ] thirst
- [ ] register
- [ ] opening
- [ ] puzzle

# Chapter 130

- [ ] we
- [ ] bear
- [ ] bedroom
- [ ] hurricane
- [ ] mouthful
- [ ] apologize
- [ ] handtruck
- [ ] garbage
- [ ] spelling
- [ ] useful
- [ ] astronomy
- [ ] lesson
- [ ] harbour
- [ ] herself
- [ ] quiet
- [ ] downstairs
- [ ] violent
- [ ] dictation
- [ ] cathedral
- [ ] respect

# Chapter 131

- [ ] expression
- [ ] dioxide
- [ ] villager
- [ ] guidance
- [ ] grey
- [ ] refer
- [ ] booth
- [ ] bookmark
- [ ] walkman
- [ ] ha
- [ ] culture
- [ ] burial
- [ ] bored
- [ ] possess
- [ ] ease
- [ ] gardening
- [ ] whatever
- [ ] drawback
- [ ] database
- [ ] poisonous

# Chapter 132

- [ ] throat
- [ ] wise
- [ ] importance
- [ ] Baby
- [ ] hunter
- [ ] acid
- [ ] signature
- [ ] board
- [ ] November
- [ ] accelerate
- [ ] cow
- [ ] motor
- [ ] birth
- [ ] wife
- [ ] totally
- [ ] situation
- [ ] winter
- [ ] apparent
- [ ] picnic
- [ ] carbon

# Chapter 133

- [ ] proud
- [ ] Italy
- [ ] energy
- [ ] lifetime
- [ ] entry
- [ ] general
- [ ] bean
- [ ] such
- [ ] instruct
- [ ] amusement
- [ ] afterward
- [ ] defense
- [ ] fellow
- [ ] accumulate
- [ ] opera
- [ ] phrase
- [ ] cheap
- [ ] deer
- [ ] internet
- [ ] course

# Chapter 134

- [ ] glare
- [ ] walk
- [ ] weep
- [ ] brilliant
- [ ] radioactive
- [ ] wave
- [ ] tomb
- [ ] seize
- [ ] design
- [ ] small
- [ ] heat
- [ ] junk
- [ ] sorrow
- [ ] bungalow
- [ ] technology
- [ ] hardly
- [ ] fee
- [ ] promise
- [ ] mass
- [ ] settle

# Chapter 135

- [ ] competitor
- [ ] chapter
- [ ] electricity
- [ ] sudden
- [ ] supreme
- [ ] eyewitness
- [ ] information
- [ ] queue
- [ ] candy
- [ ] sleep
- [ ] act
- [ ] belt
- [ ] widespread
- [ ] study
- [ ] advantage
- [ ] abnormal
- [ ] output
- [ ] headmaster
- [ ] sport
- [ ] admirable

# Chapter 136

- [ ] dash
- [ ] thirteen
- [ ] ambition
- [ ] enter
- [ ] able
- [ ] severe
- [ ] sharpener
- [ ] dream
- [ ] bookshelf
- [ ] analyze
- [ ] woman
- [ ] extraordinary
- [ ] outcome
- [ ] yoghurt
- [ ] make
- [ ] only
- [ ] title
- [ ] card
- [ ] spell
- [ ] win

# Chapter 137

- [ ] Australian
- [ ] champion
- [ ] clarify
- [ ] comedy
- [ ] biography
- [ ] clock
- [ ] employ
- [ ] sixth
- [ ] injure
- [ ] period
- [ ] excuse
- [ ] prayer
- [ ] fork
- [ ] greet
- [ ] pray
- [ ] brown
- [ ] burden
- [ ] civilization
- [ ] rate
- [ ] system

# Chapter 138

- [ ] advertise
- [ ] metal
- [ ] forgive
- [ ] fat
- [ ] go
- [ ] collection
- [ ] rich
- [ ] underwear
- [ ] choke
- [ ] oh
- [ ] sixteenth
- [ ] elder
- [ ] beauty
- [ ] shy
- [ ] existence
- [ ] run
- [ ] geometry
- [ ] living
- [ ] carriage
- [ ] chain

# Chapter 139

- [ ] sweater
- [ ] Lost
- [ ] careless
- [ ] river
- [ ] routine
- [ ] gymnastics
- [ ] storage
- [ ] within
- [ ] queen
- [ ] wheat
- [ ] number
- [ ] palace
- [ ] childhood
- [ ] violate
- [ ] tale
- [ ] society
- [ ] restrict
- [ ] speech
- [ ] harvest
- [ ] recorder

# Chapter 140

- [ ] be
- [ ] son
- [ ] attitude
- [ ] AD
- [ ] altitude
- [ ] everything
- [ ] upper
- [ ] trunk
- [ ] other
- [ ] tram
- [ ] debate
- [ ] sell
- [ ] belief
- [ ] bookcase
- [ ] ninth
- [ ] hardworking
- [ ] unrest
- [ ] prejudice
- [ ] dial
- [ ] variety

# Chapter 141

- [ ] wipe
- [ ] peach
- [ ] third
- [ ] tube
- [ ] delighted
- [ ] why
- [ ] control
- [ ] Saturday
- [ ] alley
- [ ] home
- [ ] smog
- [ ] survive
- [ ] stewardess
- [ ] snow
- [ ] cool
- [ ] useless
- [ ] secure
- [ ] pipe
- [ ] minibus
- [ ] me

# Chapter 142

- [ ] arrival
- [ ] conservative
- [ ] however
- [ ] mature
- [ ] guide
- [ ] traffic
- [ ] block
- [ ] happy
- [ ] elect
- [ ] August
- [ ] past
- [ ] saying
- [ ] hello
- [ ] repeat
- [ ] separately
- [ ] cave
- [ ] urge
- [ ] whistle
- [ ] instruction
- [ ] postcard

# Chapter 143

- [ ] civil
- [ ] knowledge
- [ ] fantasy
- [ ] airline
- [ ] till
- [ ] sixteen
- [ ] born
- [ ] actual
- [ ] wage
- [ ] aeroplane
- [ ] word
- [ ] significance
- [ ] quantity
- [ ] shock
- [ ] recognise
- [ ] twice
- [ ] special
- [ ] major
- [ ] minimum
- [ ] earthquake

# Chapter 144

- [ ] troublesome
- [ ] skillful
- [ ] away
- [ ] anger
- [ ] spade
- [ ] section
- [ ] railway
- [ ] comment
- [ ] salute
- [ ] part
- [ ] hate
- [ ] thirsty
- [ ] enterprise
- [ ] freeze
- [ ] candle
- [ ] campaign
- [ ] vast
- [ ] maple
- [ ] benefit
- [ ] neither

# Chapter 145

- [ ] sword
- [ ] desire
- [ ] relief
- [ ] catch
- [ ] consult
- [ ] preserve
- [ ] next
- [ ] numb
- [ ] one
- [ ] shoe
- [ ] so
- [ ] husband
- [ ] occur
- [ ] prescription
- [ ] spoonful
- [ ] mankind
- [ ] slip
- [ ] eastern
- [ ] thought
- [ ] cattle

# Chapter 146

- [ ] dumpling
- [ ] accountant
- [ ] path
- [ ] veal
- [ ] initial
- [ ] medium
- [ ] beat
- [ ] background
- [ ] caution
- [ ] beef
- [ ] Belgium
- [ ] stare
- [ ] mistake
- [ ] freedom
- [ ] fountain
- [ ] bakery
- [ ] juice
- [ ] similar
- [ ] pond
- [ ] swim

# Chapter 147

- [ ] tonight
- [ ] apart
- [ ] fly
- [ ] undertake
- [ ] punctuate
- [ ] brick
- [ ] dictionary
- [ ] carrier
- [ ] quake
- [ ] medal
- [ ] theatre
- [ ] shot
- [ ] roof
- [ ] harmful
- [ ] socialist
- [ ] ring
- [ ] supermarket
- [ ] pattern
- [ ] kite
- [ ] remark

# Chapter 148

- [ ] greedy
- [ ] savage
- [ ] novelist
- [ ] close
- [ ] northwest
- [ ] not
- [ ] grateful
- [ ] unknown
- [ ] pump
- [ ] publicly
- [ ] fortunate
- [ ] assist
- [ ] weak
- [ ] accommodation
- [ ] kettle
- [ ] Easter
- [ ] result
- [ ] Japanese
- [ ] simple
- [ ] president

# Chapter 149

- [ ] mark
- [ ] tournament
- [ ] musical
- [ ] invite
- [ ] merely
- [ ] punctuation
- [ ] stay
- [ ] examine
- [ ] difference
- [ ] than
- [ ] poster
- [ ] rice
- [ ] hooray
- [ ] hay
- [ ] construction
- [ ] art
- [ ] crossing
- [ ] whisper
- [ ] consensus
- [ ] secretary

# Chapter 150

- [ ] midday
- [ ] every
- [ ] until
- [ ] gay
- [ ] virtue
- [ ] glance
- [ ] conflict
- [ ] telephone
- [ ] bell
- [ ] cold
- [ ] dance
- [ ] bank
- [ ] thread
- [ ] skilled
- [ ] boxing
- [ ] air
- [ ] exist
- [ ] tobacco
- [ ] snatch
- [ ] three

# Chapter 151

- [ ] double
- [ ] invention
- [ ] printing
- [ ] worthless
- [ ] tortoise
- [ ] because
- [ ] dirty
- [ ] supply
- [ ] inform
- [ ] responsibility
- [ ] class
- [ ] frontier
- [ ] dine
- [ ] life
- [ ] child
- [ ] UN
- [ ] overweight
- [ ] important
- [ ] fist
- [ ] factory

# Chapter 152

- [ ] division
- [ ] wrist
- [ ] hundred
- [ ] chat
- [ ] bring
- [ ] amaze
- [ ] village
- [ ] journalist
- [ ] symbol
- [ ] spirit
- [ ] kick
- [ ] ice
- [ ] distinguish
- [ ] gesture
- [ ] Tokyo
- [ ] puzzled
- [ ] respond
- [ ] latest
- [ ] pride
- [ ] UK

# Chapter 153

- [ ] wind
- [ ] split
- [ ] and
- [ ] handsome
- [ ] left
- [ ] storm
- [ ] shirt
- [ ] seventeen
- [ ] unhealthy
- [ ] lap
- [ ] neighbourhood
- [ ] used
- [ ] windy
- [ ] murder
- [ ] nation
- [ ] cake
- [ ] often
- [ ] accompany
- [ ] subscribe
- [ ] relation

# Chapter 154

- [ ] anywhere
- [ ] dilemma
- [ ] beard
- [ ] though
- [ ] bow
- [ ] many
- [ ] what
- [ ] shooting
- [ ] government
- [ ] right
- [ ] cash
- [ ] chest
- [ ] advise
- [ ] sad
- [ ] another
- [ ] pole
- [ ] average
- [ ] capital
- [ ] sit
- [ ] stain

# Chapter 155

- [ ] aluminium
- [ ] conventional
- [ ] prepare
- [ ] elegant
- [ ] present
- [ ] bachelor
- [ ] religious
- [ ] mailbox
- [ ] dizzy
- [ ] chopsticks
- [ ] accustomed
- [ ] ancient
- [ ] acquire
- [ ] regardless
- [ ] firefighter
- [ ] pineapple
- [ ] impossible
- [ ] classmate
- [ ] pop
- [ ] contribute

# Chapter 156

- [ ] license
- [ ] peaceful
- [ ] probable
- [ ] admire
- [ ] identity
- [ ] observe
- [ ] profession
- [ ] with
- [ ] minister
- [ ] enough
- [ ] cup
- [ ] gy
- [ ] movement
- [ ] ending
- [ ] centigrade
- [ ] ceremony
- [ ] point
- [ ] sniff
- [ ] annoy
- [ ] architecture

# Chapter 157

- [ ] television
- [ ] editor
- [ ] criminal
- [ ] dialogue
- [ ] per
- [ ] programme
- [ ] menu
- [ ] pancake
- [ ] her
- [ ] mist
- [ ] pace
- [ ] story
- [ ] regret
- [ ] grocer
- [ ] celebration
- [ ] build
- [ ] smoke
- [ ] confuse
- [ ] cottage
- [ ] manage

# Chapter 158

- [ ] lovely
- [ ] rude
- [ ] nursing
- [ ] compensate
- [ ] yourselves
- [ ] always
- [ ] origin
- [ ] distinction
- [ ] begin
- [ ] garlic
- [ ] tailor
- [ ] off
- [ ] unit
- [ ] allergic
- [ ] finger
- [ ] upstairs
- [ ] misunderstand
- [ ] cater
- [ ] riddle
- [ ] huge

# Chapter 159

- [ ] centimetre
- [ ] more
- [ ] unable
- [ ] telescope
- [ ] castle
- [ ] noisy
- [ ] which
- [ ] equip
- [ ] rain
- [ ] hill
- [ ] doctor
- [ ] incorrect
- [ ] help
- [ ] room
- [ ] park
- [ ] idiom
- [ ] beneficial
- [ ] incident
- [ ] text
- [ ] strength

# Chapter 160

- [ ] their
- [ ] material
- [ ] receipt
- [ ] actor
- [ ] globe
- [ ] chief
- [ ] politics
- [ ] heart
- [ ] chew
- [ ] extension
- [ ] botanical
- [ ] lame
- [ ] rectangle
- [ ] thief
- [ ] brand
- [ ] litter
- [ ] sneaker
- [ ] abstract
- [ ] nowadays
- [ ] unimportant

# Chapter 161

- [ ] just
- [ ] acknowledge
- [ ] enlarge
- [ ] Switzerland
- [ ] conclusion
- [ ] theirs
- [ ] labourer
- [ ] forbid
- [ ] weekly
- [ ] skip
- [ ] something
- [ ] themselves
- [ ] net
- [ ] rail
- [ ] interrupt
- [ ] case
- [ ] bless
- [ ] shoot
- [ ] upward
- [ ] atmosphere

# Chapter 162

- [ ] consistent
- [ ] organization
- [ ] each
- [ ] stone
- [ ] afternoon
- [ ] loud
- [ ] foot
- [ ] sunglasses
- [ ] hilly
- [ ] command
- [ ] string
- [ ] thus
- [ ] percent
- [ ] banana
- [ ] thick
- [ ] far
- [ ] astronaut
- [ ] much
- [ ] security
- [ ] rigid

# Chapter 163

- [ ] keeper
- [ ] backward
- [ ] uncle
- [ ] reality
- [ ] rot
- [ ] receive
- [ ] bee
- [ ] appreciation
- [ ] chairman
- [ ] swift
- [ ] lavatory
- [ ] judge
- [ ] tough
- [ ] biochemistry
- [ ] dull
- [ ] king
- [ ] crash
- [ ] church
- [ ] language
- [ ] boundary

# Chapter 164

- [ ] cheat
- [ ] cocoa
- [ ] idea
- [ ] climb
- [ ] upset
- [ ] Thursday
- [ ] performance
- [ ] appeal
- [ ] national
- [ ] socket
- [ ] burglar
- [ ] owner
- [ ] grow
- [ ] beautiful
- [ ] fierce
- [ ] pedestrian
- [ ] court
- [ ] badminton
- [ ] postbox
- [ ] photo

# Chapter 165

- [ ] onion
- [ ] meat
- [ ] Atlantic
- [ ] voyage
- [ ] excellent
- [ ] telegraph
- [ ] breakthrough
- [ ] cause
- [ ] swap
- [ ] nervous
- [ ] thorough
- [ ] seal
- [ ] tissue
- [ ] damp
- [ ] condemn
- [ ] yawn
- [ ] biology
- [ ] announcement
- [ ] punish
- [ ] army

# Chapter 166

- [ ] hunger
- [ ] businesswoman
- [ ] well
- [ ] airplane
- [ ] boss
- [ ] warm
- [ ] figure
- [ ] condition
- [ ] bus
- [ ] works
- [ ] bargain
- [ ] Dynamic
- [ ] song
- [ ] goal
- [ ] grain
- [ ] add
- [ ] premier
- [ ] starve
- [ ] himself
- [ ] pie

# Chapter 167

- [ ] slave
- [ ] December
- [ ] budget
- [ ] dinner
- [ ] patience
- [ ] should
- [ ] mistaken
- [ ] adjust
- [ ] possession
- [ ] blanket
- [ ] ashamed
- [ ] crowded
- [ ] long
- [ ] review
- [ ] shine
- [ ] rid
- [ ] learn
- [ ] disagreement
- [ ] lose
- [ ] graduate

# Chapter 168

- [ ] everybody
- [ ] describe
- [ ] especially
- [ ] Tuesday
- [ ] crossroads
- [ ] soon
- [ ] inspect
- [ ] protection
- [ ] fasten
- [ ] deeply
- [ ] tanker
- [ ] lion
- [ ] skill
- [ ] familiar
- [ ] silence
- [ ] send
- [ ] birthday
- [ ] compare
- [ ] illness
- [ ] universal

# Chapter 169

- [ ] arise
- [ ] reason
- [ ] picture
- [ ] lack
- [ ] westerner
- [ ] unless
- [ ] everyday
- [ ] gift
- [ ] soap
- [ ] painting
- [ ] advance
- [ ] sex
- [ ] thunderstorm
- [ ] privilege
- [ ] personal
- [ ] introduction
- [ ] carpet
- [ ] chemistry
- [ ] hear
- [ ] combine

# Chapter 170

- [ ] smelly
- [ ] tourism
- [ ] Japan
- [ ] affection
- [ ] locust
- [ ] accuse
- [ ] beam
- [ ] embarrass
- [ ] businessman
- [ ] bat
- [ ] English
- [ ] reference
- [ ] beer
- [ ] public
- [ ] breathe
- [ ] eggplant
- [ ] cousin
- [ ] push
- [ ] tolerate
- [ ] golden

# Chapter 171

- [ ] waitress
- [ ] senior
- [ ] FALSE
- [ ] February
- [ ] suffering
- [ ] peace
- [ ] astronomer
- [ ] biscuit
- [ ] reuse
- [ ] rope
- [ ] radio
- [ ] cent
- [ ] refreshments
- [ ] vital
- [ ] settlement
- [ ] pot
- [ ] windbreaker
- [ ] frog
- [ ] sure
- [ ] poor

# Chapter 172

- [ ] soft
- [ ] relevant
- [ ] limit
- [ ] sow
- [ ] usual
- [ ] jazz
- [ ] century
- [ ] tea
- [ ] corner
- [ ] fiction
- [ ] understand
- [ ] mean
- [ ] resist
- [ ] playmate
- [ ] fault
- [ ] thriller
- [ ] message
- [ ] theme
- [ ] am
- [ ] accuracy

# Chapter 173

- [ ] balloon
- [ ] you
- [ ] oil
- [ ] departure
- [ ] eighth
- [ ] corporation
- [ ] salesman
- [ ] chorus
- [ ] competition
- [ ] boat
- [ ] fur
- [ ] trainer
- [ ] encourage
- [ ] road
- [ ] punishment
- [ ] place
- [ ] parking
- [ ] machine
- [ ] tell
- [ ] think

# Chapter 174

- [ ] nearby
- [ ] human
- [ ] range
- [ ] complex
- [ ] fever
- [ ] royal
- [ ] brave
- [ ] irrigate
- [ ] desert
- [ ] urban
- [ ] splendid
- [ ] Asian
- [ ] conversation
- [ ] rescue
- [ ] microcomputer
- [ ] lamp
- [ ] lecture
- [ ] teacher
- [ ] beg
- [ ] trust

# Chapter 175

- [ ] strike
- [ ] thermos
- [ ] amateur
- [ ] March
- [ ] its
- [ ] phone
- [ ] province
- [ ] workplace
- [ ] play
- [ ] reply
- [ ] department
- [ ] intention
- [ ] tutor
- [ ] graduation
- [ ] spear
- [ ] communication
- [ ] plant
- [ ] listen
- [ ] this
- [ ] decide

# Chapter 176

- [ ] empire
- [ ] worker
- [ ] weekday
- [ ] controversial
- [ ] company
- [ ] Spanish
- [ ] mile
- [ ] dry
- [ ] skirt
- [ ] sign
- [ ] playroom
- [ ] hole
- [ ] fingernail
- [ ] spoon
- [ ] assess
- [ ] middle
- [ ] cartoon
- [ ] mail
- [ ] cafeteria
- [ ] violinist

# Chapter 177

- [ ] unpleasant
- [ ] relationship
- [ ] receiver
- [ ] health
- [ ] pea
- [ ] grill
- [ ] softball
- [ ] seaweed
- [ ] coral
- [ ] rush
- [ ] narrow
- [ ] boot
- [ ] claw
- [ ] answer
- [ ] own
- [ ] rhyme
- [ ] likely
- [ ] plain
- [ ] Frenchman
- [ ] socialism

# Chapter 178

- [ ] experience
- [ ] awful
- [ ] applicant
- [ ] speak
- [ ] saleswoman
- [ ] twelfth
- [ ] nail
- [ ] fancy
- [ ] disability
- [ ] besides
- [ ] beginning
- [ ] rock
- [ ] betray
- [ ] soil
- [ ] sunset
- [ ] allow
- [ ] clerk
- [ ] chant
- [ ] cloudy
- [ ] here

# Chapter 179

- [ ] price
- [ ] bride
- [ ] challenge
- [ ] painful
- [ ] cushion
- [ ] oilfield
- [ ] fit
- [ ] value
- [ ] scene
- [ ] freezing
- [ ] wild
- [ ] scenery
- [ ] sideway
- [ ] squid
- [ ] convenient
- [ ] dark
- [ ] zero
- [ ] interesting
- [ ] chips
- [ ] sugar

# Chapter 180

- [ ] silk
- [ ] nod
- [ ] float
- [ ] believe
- [ ] Mom
- [ ] June
- [ ] treatment
- [ ] sight
- [ ] calm
- [ ] plenty
- [ ] missile
- [ ] environment
- [ ] anyone
- [ ] clearly
- [ ] climate
- [ ] behave
- [ ] delete
- [ ] call
- [ ] catastrophe
- [ ] orbit

# Chapter 181

- [ ] customs
- [ ] snowy
- [ ] waste
- [ ] regard
- [ ] communism
- [ ] less
- [ ] French
- [ ] reduce
- [ ] identification
- [ ] alphabet
- [ ] lawyer
- [ ] moon
- [ ] robot
- [ ] nineteen
- [ ] sigh
- [ ] food
- [ ] raise
- [ ] strengthen
- [ ] league
- [ ] scissors

# Chapter 182

- [ ] sweat
- [ ] reflect
- [ ] deep
- [ ] tooth
- [ ] orange
- [ ] prohibit
- [ ] finance
- [ ] rule
- [ ] tank
- [ ] worthy
- [ ] communicate
- [ ] population
- [ ] influence
- [ ] Oceania
- [ ] noble
- [ ] knife
- [ ] grandson
- [ ] revolution
- [ ] clone
- [ ] post

# Chapter 183

- [ ] bunch
- [ ] twenty
- [ ] troop
- [ ] kangaroo
- [ ] dear
- [ ] welfare
- [ ] roll
- [ ] explanation
- [ ] feel
- [ ] mad
- [ ] squirrel
- [ ] she
- [ ] destination
- [ ] differ
- [ ] pack
- [ ] seaman
- [ ] terror
- [ ] force
- [ ] discussion
- [ ] station

# Chapter 184

- [ ] business
- [ ] granny
- [ ] Arabic
- [ ] bone
- [ ] OK
- [ ] bishop
- [ ] refusal
- [ ] eager

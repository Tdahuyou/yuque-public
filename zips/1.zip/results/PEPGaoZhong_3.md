
# Chapter 001

- [ ] take place
- [ ] beauty
- [ ] harvest
- [ ] celebration
- [ ] hunter
- [ ] starve
- [ ] origin
- [ ] religious
- [ ] seasonal
- [ ] ancestor
- [ ] Obon
- [ ] grave
- [ ] incense
- [ ] in memory of
- [ ] Mexico
- [ ] feast
- [ ] skull
- [ ] bone
- [ ] Halloween
- [ ] belief

# Chapter 002

- [ ] dress up
- [ ] trick
- [ ] play a trick on
- [ ] poet
- [ ] Columbus Day
- [ ] arrival
- [ ] Christopher Columbus
- [ ] gain
- [ ] independence
- [ ] independent
- [ ] gather
- [ ] agriculture
- [ ] agricultural
- [ ] award
- [ ] produce
- [ ] rooster
- [ ] admire
- [ ] energetic
- [ ] look forward to
- [ ] carnival

# Chapter 003

- [ ] lunar
- [ ] Easter
- [ ] parade
- [ ] day and night
- [ ] clothing
- [ ] Christian
- [ ] Jesus
- [ ] cherry
- [ ] blossom
- [ ] as though
- [ ] have fun with
- [ ] custom
- [ ] worldwide
- [ ] rosebud
- [ ] fool
- [ ] necessity
- [ ] permission
- [ ] prediction
- [ ] fashion
- [ ] Trinidad

# Chapter 004

- [ ] Carla
- [ ] Hari
- [ ] parking
- [ ] parking lot
- [ ] Valentine’s Day
- [ ] turn up
- [ ] keep one’s word
- [ ] hold one’s breath
- [ ] apologize
- [ ] drown
- [ ] sadness
- [ ] obvious
- [ ] wipe
- [ ] weave
- [ ] herd
- [ ] the Milky Way
- [ ] magpie
- [ ] weep
- [ ] announcer
- [ ] set off

# Chapter 005

- [ ] remind
- [ ] remind…of…
- [ ] forgive
- [ ] Diet
- [ ] spaghetti
- [ ] nut
- [ ] muscle
- [ ] protective
- [ ] bean
- [ ] pea
- [ ] cucumber
- [ ] eggplant
- [ ] pepper
- [ ] mushroom
- [ ] peach
- [ ] lemon
- [ ] balance
- [ ] balanced diet
- [ ] barbecue
- [ ] mutton

# Chapter 006

- [ ] kebab
- [ ] roast
- [ ] stir
- [ ] fry
- [ ] stir-fry
- [ ] ought
- [ ] ought to
- [ ] bacon
- [ ] cola
- [ ] sugary
- [ ] sign
- [ ] lose weight
- [ ] slim
- [ ] curiosity
- [ ] hostess
- [ ] raw
- [ ] vinegar
- [ ] get away with
- [ ] lie
- [ ] tell a lie

# Chapter 007

- [ ] customer
- [ ] discount
- [ ] win…back
- [ ] weakness
- [ ] strength
- [ ] consult
- [ ] fibre
- [ ] digest
- [ ] poisonous
- [ ] carrot
- [ ] scurvy
- [ ] rickets
- [ ] obesity
- [ ] vitamin
- [ ] protein
- [ ] earn one’s living
- [ ] debt
- [ ] in debt
- [ ] glare
- [ ] spy

# Chapter 008

- [ ] spy on
- [ ] limit
- [ ] limited
- [ ] benefit
- [ ] breast
- [ ] garlic
- [ ] sigh
- [ ] combine
- [ ] cut down
- [ ] before long
- [ ] put on weight
- [ ] cooperation
- [ ] ingredient
- [ ] flavour
- [ ] Mark Twain
- [ ] birthplace
- [ ] Florida
- [ ] bring up
- [ ] Hannibal
- [ ] Missouri

# Chapter 009

- [ ] Mississippi
- [ ] novel
- [ ] boyhood
- [ ] adventure
- [ ] Tom Sawyer
- [ ] Huckleberry Finn
- [ ] phrase
- [ ] fathom
- [ ] author
- [ ] Samuel Langhorne Clemens
- [ ] scene
- [ ] narrator
- [ ] Roderick
- [ ] Oliver
- [ ] bet
- [ ] make a bet
- [ ] penniless
- [ ] wander
- [ ] pavement
- [ ] businessman

# Chapter 010

- [ ] permit
- [ ] ahead
- [ ] go ahead
- [ ] by accident
- [ ] bay
- [ ] stare
- [ ] stare at
- [ ] nightfall
- [ ] fault
- [ ] spot
- [ ] passage
- [ ] unpaid
- [ ] account
- [ ] account for
- [ ] embassy
- [ ] seek
- [ ] patience
- [ ] contrary
- [ ] on the contrary
- [ ] charity

# Chapter 011

- [ ] envelope
- [ ] unbelievable
- [ ] Horace
- [ ] steak
- [ ] pineapple
- [ ] dessert
- [ ] amount
- [ ] take a chance
- [ ] rude
- [ ] manner
- [ ] scream
- [ ] genuine
- [ ] issue
- [ ] fake
- [ ] rag
- [ ] in rags
- [ ] indeed
- [ ] as for
- [ ] bow
- [ ] barber

# Chapter 012

- [ ] astronomy
- [ ] astronomer
- [ ] solar
- [ ] system
- [ ] solar system
- [ ] religion
- [ ] theory
- [ ] Big Bang
- [ ] atom
- [ ] billion
- [ ] globe
- [ ] global
- [ ] violent
- [ ] in time
- [ ] carbon
- [ ] nitrogen
- [ ] vapour
- [ ] atmosphere
- [ ] unlike
- [ ] fundamental

# Chapter 013

- [ ] presence
- [ ] dissolve
- [ ] harmful
- [ ] acid
- [ ] chain
- [ ] reaction
- [ ] multiply
- [ ] oxygen
- [ ] shellfish
- [ ] amphibian
- [ ] reptile
- [ ] lay eggs
- [ ] dinosaur
- [ ] exist
- [ ] mammal
- [ ] give birth to
- [ ] thus
- [ ] in one’s turn
- [ ] dioxide
- [ ] carbon dioxide

# Chapter 014

- [ ] prevent...from
- [ ] puzzle
- [ ] biology
- [ ] biologist
- [ ] gravity
- [ ] satellite
- [ ] gentle
- [ ] geologist
- [ ] physicist
- [ ] block out
- [ ] extinct
- [ ] climate
- [ ] comet
- [ ] crash
- [ ] Isaac Newton
- [ ] Albert Einstein
- [ ] Stephen Hawking
- [ ] spaceship
- [ ] pull
- [ ] lessen

# Chapter 015

- [ ] cheer up
- [ ] float
- [ ] weightlessly
- [ ] cabin
- [ ] mass
- [ ] now that
- [ ] get the hang of
- [ ] break out
- [ ] exhaust
- [ ] watch out
- [ ] multicultural
- [ ] quiz
- [ ] Canadian
- [ ] Vancouver
- [ ] Toronto
- [ ] Calgary
- [ ] Ottawa
- [ ] beaver
- [ ] grizzly
- [ ] polar

# Chapter 016

- [ ] penguin
- [ ] prime
- [ ] minister
- [ ] prime minister
- [ ] governor
- [ ] rather than
- [ ] continent
- [ ] baggage
- [ ] chat
- [ ] scenery
- [ ] eastward
- [ ] westward
- [ ] upward
- [ ] surround
- [ ] the Rocky Mountains
- [ ] Harbour
- [ ] measure
- [ ] aboard
- [ ] settle down
- [ ] manage to do

# Chapter 017

- [ ] catch sight of
- [ ] eagle
- [ ] stampede
- [ ] cowboy
- [ ] have a gift for
- [ ] within
- [ ] border
- [ ] slight
- [ ] slightly
- [ ] acre
- [ ] urban
- [ ] Thunder Bay
- [ ] Lake Superior
- [ ] location
- [ ] the Vatican City State
- [ ] topic
- [ ] mix
- [ ] mixture
- [ ] bush
- [ ] maple

# Chapter 018

- [ ] frost
- [ ] confirm
- [ ] wealthy
- [ ] distance
- [ ] in the distance
- [ ] mist
- [ ] misty
- [ ] Niagara
- [ ] schoolmate
- [ ] booth
- [ ] downtown
- [ ] pearl
- [ ] Cantonese
- [ ] approximately
- [ ] dawn
- [ ] workplace
- [ ] buffet
- [ ] broad
- [ ] St Lawrence River
- [ ] nearby

# Chapter 019

- [ ] tradition
- [ ] terrify
- [ ] terrified
- [ ] pleased
- [ ] impress
- [ ] impressive

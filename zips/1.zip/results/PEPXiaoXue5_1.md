
# Chapter 001

- [ ] old
- [ ] young
- [ ] funny
- [ ] kind
- [ ] strict
- [ ] polite
- [ ] hard-working
- [ ] helpful
- [ ] clever
- [ ] shy
- [ ] know
- [ ] our
- [ ] Ms
- [ ] will
- [ ] sometimes
- [ ] robot
- [ ] him
- [ ] speak
- [ ] finish
- [ ] Monday

# Chapter 002

- [ ] Tuesday
- [ ] Wednesday
- [ ] Thursday
- [ ] Friday
- [ ] Saturday
- [ ] Sunday
- [ ] weekend
- [ ] wash
- [ ] wash my clothes
- [ ] watch
- [ ] watch TV
- [ ] do
- [ ] do homework
- [ ] read
- [ ] read books
- [ ] play
- [ ] play football
- [ ] cooking
- [ ] often
- [ ] park

# Chapter 003

- [ ] tired
- [ ] sport
- [ ] play sports
- [ ] should
- [ ] every
- [ ] day
- [ ] schedule
- [ ] sandwich
- [ ] salad
- [ ] hamburger
- [ ] ice cream
- [ ] tea
- [ ] fresh
- [ ] healthy
- [ ] delicious
- [ ] hot
- [ ] sweet
- [ ] drink
- [ ] thirsty
- [ ] favourite

# Chapter 004

- [ ] food
- [ ] Dear
- [ ] onion
- [ ] sing
- [ ] song
- [ ] sing English songs
- [ ] play the pipa
- [ ] kung fu
- [ ] do kung fu
- [ ] dance
- [ ] draw
- [ ] cartoon
- [ ] draw cartoons
- [ ] cook
- [ ] swim
- [ ] play basketball
- [ ] ping-pong
- [ ] play ping-pong
- [ ] speak English
- [ ] we'll

# Chapter 005

- [ ] party
- [ ] next
- [ ] wonderful
- [ ] learn
- [ ] any
- [ ] problem
- [ ] no problem
- [ ] want
- [ ] send
- [ ] email
- [ ] at
- [ ] clock
- [ ] plant
- [ ] bottle
- [ ] water bottle
- [ ] bike
- [ ] photo
- [ ] front
- [ ] in front of
- [ ] between

# Chapter 006

- [ ] above
- [ ] beside
- [ ] behind
- [ ] there
- [ ] grandparent
- [ ] their
- [ ] house
- [ ] lot
- [ ] lots of
- [ ] flower
- [ ] move
- [ ] dirty
- [ ] everywhere
- [ ] mouse
- [ ] live
- [ ] nature
- [ ] forest
- [ ] river
- [ ] lake
- [ ] mountain

# Chapter 007

- [ ] hill
- [ ] tree
- [ ] bridge
- [ ] building
- [ ] village
- [ ] house.
- [ ] boating
- [ ] go boating
- [ ] aren't
- [ ] rabbit
- [ ] high

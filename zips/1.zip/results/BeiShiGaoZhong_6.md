
# Chapter 001

- [ ] biography
- [ ] fantasy
- [ ] horror
- [ ] abandon
- [ ] come into view
- [ ] knock sb. over
- [ ] victim
- [ ] once upon a time
- [ ] princess
- [ ] criteria
- [ ] novelist
- [ ] volcanic eruption
- [ ] preserve
- [ ] capsule
- [ ] witness
- [ ] occur
- [ ] tremble
- [ ] block out
- [ ] particularly
- [ ] loss

# Chapter 002

- [ ] awesome
- [ ] in a way
- [ ] rewind
- [ ] architecture
- [ ] authentic
- [ ] characteristic
- [ ] monument
- [ ] gather
- [ ] on one's side
- [ ] sorrow
- [ ] sympathy
- [ ] burst
- [ ] split up
- [ ] on the way to
- [ ] pay rise
- [ ] specific
- [ ] significance
- [ ] abnormal
- [ ] vivid
- [ ] hardship

# Chapter 003

- [ ] pillar
- [ ] violinist
- [ ] name... after
- [ ] come across
- [ ] hold up
- [ ] count on
- [ ] origin
- [ ] figure out
- [ ] heather
- [ ] discourage
- [ ] end up
- [ ] put up with
- [ ] suffering
- [ ] musical
- [ ] admirable
- [ ] tease
- [ ] suspension bridge
- [ ] videophone
- [ ] in particular
- [ ] superb

# Chapter 004

- [ ] severe
- [ ] restriction
- [ ] unbearable
- [ ] stubborn
- [ ] former
- [ ] troublesome
- [ ] straightforward
- [ ] precise
- [ ] imitation
- [ ] precious
- [ ] now that
- [ ] eager
- [ ] gradual
- [ ] expand
- [ ] complex
- [ ] apparent
- [ ] violet
- [ ] sweetness
- [ ] warmth
- [ ] breakthrough

# Chapter 005

- [ ] uncertain
- [ ] tiresome
- [ ] awkward
- [ ] spill
- [ ] nasty
- [ ] tense
- [ ] dizzy
- [ ] applaud
- [ ] clumsy
- [ ] harp
- [ ] fairy
- [ ] amuse
- [ ] burst out laughing
- [ ] giggle
- [ ] anecdote
- [ ] ridiculous
- [ ] politician
- [ ] response
- [ ] unbelievable
- [ ] agency

# Chapter 006

- [ ] visa
- [ ] my goodness
- [ ] harmony
- [ ] cash a cheque
- [ ] withdraw
- [ ] forgetful
- [ ] mature
- [ ] overlook
- [ ] clarify
- [ ] delay
- [ ] counter
- [ ] agent
- [ ] queue
- [ ] yell
- [ ] wait in line
- [ ] identification
- [ ] sunburnt
- [ ] messy
- [ ] scared
- [ ] thriller

# Chapter 007

- [ ] swiftly
- [ ] black eye
- [ ] pool
- [ ] tournament
- [ ] nap
- [ ] border
- [ ] psychology
- [ ] acknowledge
- [ ] being
- [ ] get rid of
- [ ] profession
- [ ] fool around
- [ ] from time to time
- [ ] authority
- [ ] figure
- [ ] campaign
- [ ] result in
- [ ] alongside
- [ ] resist
- [ ] tension

# Chapter 008

- [ ] caution
- [ ] scratch
- [ ] scold
- [ ] forbid
- [ ] run into
- [ ] comedy
- [ ] comedian
- [ ] imitate
- [ ] put on
- [ ] turn sb. off
- [ ] regardless of
- [ ] purely
- [ ] universal
- [ ] seal
- [ ] astonish
- [ ] saucer
- [ ] steak tartare
- [ ] raw
- [ ] disgusting
- [ ] desperate

# Chapter 009

- [ ] boarding school
- [ ] obtain
- [ ] partly
- [ ] compensate
- [ ] convince
- [ ] play around
- [ ] pull faces
- [ ] rarely
- [ ] presence
- [ ] genius
- [ ] depth
- [ ] scare
- [ ] string
- [ ] starve
- [ ] loaf
- [ ] yawn
- [ ] tough
- [ ] cross-talk
- [ ] component
- [ ] thanks to

# Chapter 010

- [ ] accomplish
- [ ] breathless
- [ ] masterpiece
- [ ] scenic
- [ ] superior
- [ ] sideways
- [ ] vertical
- [ ] adore
- [ ] rainbow
- [ ] flock
- [ ] beholder
- [ ] consistent
- [ ] corset
- [ ] woollen
- [ ] shawl
- [ ] tattoo
- [ ] slim
- [ ] overweight
- [ ] commitment
- [ ] die out

# Chapter 011

- [ ] accompany
- [ ] range
- [ ] conscience
- [ ] inner
- [ ] subjective
- [ ] dimension
- [ ] command
- [ ] tasteless
- [ ] botany
- [ ] skateboard
- [ ] symphony
- [ ] accessible
- [ ] delicate
- [ ] tune
- [ ] deliver
- [ ] thrill
- [ ] dignity
- [ ] polished
- [ ] refresh
- [ ] sentimental

# Chapter 012

- [ ] shabby
- [ ] harsh
- [ ] chorus
- [ ] tendency
- [ ] vain
- [ ] lyrics
- [ ] abrupt
- [ ] disturbing
- [ ] version
- [ ] stuff
- [ ] steady
- [ ] Christian
- [ ] endless
- [ ] freezing
- [ ] romantic
- [ ] tranquil
- [ ] hoarfrost
- [ ] bend
- [ ] homesickness
- [ ] drown

# Chapter 013

- [ ] vague
- [ ] hoof
- [ ] stout
- [ ] bound
- [ ] oval
- [ ] bow
- [ ] jerk
- [ ] chimney
- [ ] sleigh
- [ ] thistle
- [ ] tone
- [ ] unlike
- [ ] convey
- [ ] affection
- [ ] merchant
- [ ] treat
- [ ] trap
- [ ] theme
- [ ] manner
- [ ] drawback

# Chapter 014

- [ ] strike
- [ ] striking
- [ ] evident
- [ ] cute
- [ ] recommend
- [ ] plot
- [ ] DJ
- [ ] hang on a second
- [ ] catalogue
- [ ] bits and pieces
- [ ] childish

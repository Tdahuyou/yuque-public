
# Chapter 001

- [ ] likely
- [ ] concept
- [ ] chart
- [ ] focus
- [ ] skip
- [ ] fist
- [ ] waist
- [ ] nail
- [ ] gallery
- [ ] cyberspace
- [ ] come ture
- [ ] artificial
- [ ] climate
- [ ] global
- [ ] flood
- [ ] virtual
- [ ] reality
- [ ] virus
- [ ] affect
- [ ] rapidly

# Chapter 002

- [ ] growth
- [ ] pessimistic
- [ ] crime
- [ ] hacker
- [ ] terrorist
- [ ] attack
- [ ] chaos
- [ ] crash
- [ ] optimistic
- [ ] entertainment
- [ ] disappear
- [ ] as if
- [ ] harm
- [ ] obvious
- [ ] destruction
- [ ] military
- [ ] scientific
- [ ] the Pentagon
- [ ] nuclear
- [ ] network

# Chapter 003

- [ ] project
- [ ] get in touch
- [ ] hang on
- [ ] be up to
- [ ] fashion
- [ ] fancy
- [ ] suggestion
- [ ] reject
- [ ] arrangement
- [ ] title
- [ ] destination
- [ ] flesh
- [ ] exit
- [ ] historical
- [ ] site
- [ ] pack
- [ ] dip
- [ ] toe
- [ ] millionaire
- [ ] smoker

# Chapter 004

- [ ] tourism
- [ ] guide
- [ ] locate
- [ ] seaside
- [ ] Maori
- [ ] settle
- [ ] settlement
- [ ] central
- [ ] suburb
- [ ] zone
- [ ] volcano
- [ ] as well as
- [ ] harbour
- [ ] view
- [ ] sunshine
- [ ] average
- [ ] surfing
- [ ] regular
- [ ] location
- [ ] steel

# Chapter 005

- [ ] material
- [ ] be known as
- [ ] Chinatown
- [ ] officially
- [ ] scenery
- [ ] cuisine
- [ ] attractive
- [ ] spider
- [ ] web
- [ ] folk
- [ ] jazz
- [ ] rock ’n’ roll
- [ ] disco
- [ ] ballet
- [ ] effect
- [ ] disappoint
- [ ] extraordinary
- [ ] unclear
- [ ] be used to
- [ ] album

# Chapter 006

- [ ] performance
- [ ] perform
- [ ] award
- [ ] base
- [ ] extremely
- [ ] creative
- [ ] powerful
- [ ] anger
- [ ] system
- [ ] audience
- [ ] throughout
- [ ] impress
- [ ] performer
- [ ] instrument
- [ ] male
- [ ] female
- [ ] clown
- [ ] carriage
- [ ] treasure
- [ ] combine

# Chapter 007

- [ ] mask
- [ ] acrobatics
- [ ] costume
- [ ] represent
- [ ] general
- [ ] in other words
- [ ] pianist
- [ ] musician
- [ ] at times
- [ ] quit
- [ ] talent
- [ ] worldwide
- [ ] in some ways
- [ ] identity
- [ ] root
- [ ] rediscover
- [ ] beauty
- [ ] appearance
- [ ] shave
- [ ] hairstyle

# Chapter 008

- [ ] transform
- [ ] waltz
- [ ] breakdance
- [ ] encyclopedia
- [ ] sword
- [ ] peacock
- [ ] Swan Lake
- [ ] ordinary
- [ ] generation
- [ ] type
- [ ] skip.
- [ ] back and forth
- [ ] unique
- [ ] noble
- [ ] ballroom
- [ ] immigrant
- [ ] tap dancing
- [ ] tango
- [ ] reaction
- [ ] responsible

# Chapter 009

- [ ] permission
- [ ] realistic
- [ ] abstract
- [ ] straight
- [ ] wavy
- [ ] imagination
- [ ] painter
- [ ] pain
- [ ] exhibition
- [ ] poetry
- [ ] missile
- [ ] mane
- [ ] shade
- [ ] sweat
- [ ] youth
- [ ] insect
- [ ] fix one's eyes on
- [ ] creature
- [ ] artist
- [ ] valuable

# Chapter 010

- [ ] typical
- [ ] elegantly
- [ ] emphasize
- [ ] detail
- [ ] cloth
- [ ] fold
- [ ] shallow
- [ ] shore
- [ ] eyesight
- [ ] marble
- [ ] concrete
- [ ] feature
- [ ] balcony
- [ ] roof
- [ ] statue
- [ ] castle
- [ ] skyscraper
- [ ] angel
- [ ] architect
- [ ] ruin

# Chapter 011

- [ ] loch
- [ ] fairytale
- [ ] granite
- [ ] sort of
- [ ] cafe
- [ ] phoenix
- [ ] rooster
- [ ] bat
- [ ] tomb
- [ ] date back to
- [ ] dynasty
- [ ] religious
- [ ] purpose
- [ ] pattern
- [ ] character
- [ ] happiness
- [ ] temple
- [ ] offering
- [ ] relate
- [ ] jewellery

# Chapter 012

- [ ] try out
- [ ] cottage
- [ ] rent
- [ ] landlord
- [ ] worm
- [ ] pipe
- [ ] mercy
- [ ] washroom
- [ ] damp
- [ ] bathtub
- [ ] basement
- [ ] bathe
- [ ] fence
- [ ] narrow
- [ ] hold one's breath
- [ ] garage
- [ ] garbage
- [ ] apartment
- [ ] subway
- [ ] downtown

# Chapter 013

- [ ] lorry
- [ ] curtain
- [ ] air conditioner
- [ ] conclusion


# Chapter 001

- [ ] matter
- [ ] What’s the matter?
- [ ] sore
- [ ] have a cold
- [ ] stomach
- [ ] stomachache
- [ ] have a stomachache
- [ ] foot
- [ ] neck
- [ ] throat
- [ ] fever
- [ ] lie
- [ ] lie down
- [ ] rest
- [ ] cough
- [ ] X-ray
- [ ] toothache
- [ ] take one's temperature
- [ ] headache
- [ ] have a fever

# Chapter 002

- [ ] break
- [ ] take breaks
- [ ] hurt
- [ ] passenger
- [ ] off
- [ ] get off
- [ ] to one's surprise
- [ ] onto
- [ ] trouble
- [ ] hit
- [ ] right away
- [ ] get into
- [ ] herself
- [ ] bandage
- [ ] sick
- [ ] knee
- [ ] nosebleed
- [ ] breathe
- [ ] sunburned
- [ ] ourselves

# Chapter 003

- [ ] climber
- [ ] be used to
- [ ] risk
- [ ] take risks
- [ ] accident
- [ ] situation
- [ ] kg
- [ ] rock
- [ ] run out (of)
- [ ] knife
- [ ] cut off
- [ ] blood
- [ ] mean
- [ ] get out of
- [ ] importance
- [ ] decision
- [ ] control
- [ ] be in control of
- [ ] spirit
- [ ] death

# Chapter 004

- [ ] give up
- [ ] nurse
- [ ] clean up
- [ ] cheer
- [ ] cheer up
- [ ] give out
- [ ] volunteer
- [ ] come up with
- [ ] put off
- [ ] sign
- [ ] notice
- [ ] hand out
- [ ] call up
- [ ] used to
- [ ] lonely
- [ ] care for
- [ ] several
- [ ] strong
- [ ] feeling
- [ ] satisfaction

# Chapter 005

- [ ] joy
- [ ] owner
- [ ] try out
- [ ] journey
- [ ] raise
- [ ] alone
- [ ] repair
- [ ] fix
- [ ] fix up
- [ ] give away
- [ ] take after
- [ ] broken
- [ ] wheel
- [ ] letter
- [ ] Miss
- [ ] set up
- [ ] disabled
- [ ] make a difference
- [ ] blind
- [ ] deaf

# Chapter 006

- [ ] imagine
- [ ] difficulty
- [ ] open
- [ ] door
- [ ] carry
- [ ] train
- [ ] training
- [ ] excited
- [ ] kindness
- [ ] clever
- [ ] understand
- [ ] change
- [ ] interest
- [ ] sir
- [ ] madam
- [ ] rubbish
- [ ] take out the rubbish
- [ ] fold
- [ ] mess
- [ ] throw

# Chapter 007

- [ ] all the time
- [ ] neither
- [ ] shirt
- [ ] as soon as
- [ ] pass
- [ ] borrow
- [ ] lend
- [ ] finger
- [ ] hate
- [ ] chore
- [ ] while
- [ ] snack
- [ ] stress
- [ ] waste
- [ ] in order to
- [ ] provide
- [ ] anyway
- [ ] depend
- [ ] depend on
- [ ] develop

# Chapter 008

- [ ] independent
- [ ] independence
- [ ] fair
- [ ] unfair
- [ ] fairness
- [ ] since
- [ ] neighbor
- [ ] take care of
- [ ] ill
- [ ] drop
- [ ] allow
- [ ] wrong
- [ ] What's wrong?
- [ ] midnight
- [ ] look through
- [ ] guess
- [ ] deal
- [ ] big deal
- [ ] work out
- [ ] get on well (with)

# Chapter 009

- [ ] relation
- [ ] communicate
- [ ] communication
- [ ] argue
- [ ] cloud
- [ ] elder
- [ ] instead
- [ ] whatever
- [ ] nervous
- [ ] offer
- [ ] proper
- [ ] secondly
- [ ] explain
- [ ] clear
- [ ] copy
- [ ] return
- [ ] anymore
- [ ] member
- [ ] pressure
- [ ] compete

# Chapter 010

- [ ] opinion
- [ ] skill
- [ ] typical
- [ ] football
- [ ] cut out
- [ ] quick
- [ ] continue
- [ ] compare
- [ ] compare…with
- [ ] crazy
- [ ] development
- [ ] cause
- [ ] usual
- [ ] in one's opinion
- [ ] perhaps
- [ ] rainstorm
- [ ] alarm
- [ ] go off
- [ ] begin
- [ ] heavily

# Chapter 011

- [ ] suddenly
- [ ] pick up
- [ ] strange
- [ ] storm
- [ ] wind
- [ ] light
- [ ] report
- [ ] area
- [ ] wood
- [ ] window
- [ ] flashlight
- [ ] match
- [ ] beat
- [ ] against
- [ ] asleep
- [ ] fall asleep
- [ ] die down
- [ ] rise
- [ ] fallen
- [ ] apart

# Chapter 012

- [ ] have a look
- [ ] icy
- [ ] kid
- [ ] realize
- [ ] make one's way
- [ ] passage
- [ ] pupil
- [ ] completely
- [ ] shocked
- [ ] silence
- [ ] in silence
- [ ] recently
- [ ] take down
- [ ] terrorist
- [ ] date
- [ ] tower
- [ ] at first
- [ ] truth
- [ ] shoot
- [ ] stone

# Chapter 013

- [ ] weak
- [ ] god
- [ ] remind
- [ ] bit
- [ ] a little bit
- [ ] silly
- [ ] instead of
- [ ] turn into
- [ ] object
- [ ] hide
- [ ] tail
- [ ] magic
- [ ] stick
- [ ] excite
- [ ] Western
- [ ] once upon
- [ ] stepsister
- [ ] prince
- [ ] fall in love
- [ ] fit

# Chapter 014

- [ ] couple
- [ ] smile
- [ ] marry
- [ ] get married
- [ ] gold
- [ ] emperor
- [ ] silk
- [ ] underwear
- [ ] nobody
- [ ] stupid
- [ ] cheat
- [ ] stepmother
- [ ] wife
- [ ] husband
- [ ] whole
- [ ] scene
- [ ] moonlight
- [ ] shine
- [ ] bright
- [ ] ground

# Chapter 015

- [ ] lead
- [ ] voice
- [ ] brave
- [ ] square
- [ ] meter
- [ ] deep
- [ ] desert
- [ ] population
- [ ] Asia
- [ ] feel free
- [ ] tour
- [ ] wall
- [ ] amazing
- [ ] ancient
- [ ] protect
- [ ] wide
- [ ] as far as I know
- [ ] achieve
- [ ] achievement
- [ ] southwestern

# Chapter 016

- [ ] thick
- [ ] include
- [ ] freezing
- [ ] condition
- [ ] take in
- [ ] succeed
- [ ] challenge
- [ ] in the face of
- [ ] force
- [ ] nature
- [ ] even though
- [ ] ocean
- [ ] the Pacific Ocean
- [ ] cm
- [ ] weigh
- [ ] birth
- [ ] at birth
- [ ] up to
- [ ] adult
- [ ] bamboo

# Chapter 017

- [ ] endangered
- [ ] research
- [ ] keeper
- [ ] awake
- [ ] excitement
- [ ] walk into
- [ ] fall over
- [ ] illness
- [ ] remaining
- [ ] or so
- [ ] artwork
- [ ] wild
- [ ] government
- [ ] whale
- [ ] protection
- [ ] huge
- [ ] dynasty
- [ ] base
- [ ] treasure
- [ ] island

# Chapter 018

- [ ] full of
- [ ] classic
- [ ] page
- [ ] hurry
- [ ] hurry up
- [ ] due
- [ ] ship
- [ ] tool
- [ ] gun
- [ ] mark
- [ ] sand
- [ ] cannibal
- [ ] towards
- [ ] land
- [ ] fiction
- [ ] science fiction
- [ ] technology
- [ ] French
- [ ] pop
- [ ] rock

# Chapter 019

- [ ] band
- [ ] country music
- [ ] forever
- [ ] abroad
- [ ] actually
- [ ] ever since
- [ ] fan
- [ ] southern
- [ ] modern
- [ ] success
- [ ] belong
- [ ] one another
- [ ] laughter
- [ ] beauty
- [ ] million
- [ ] record
- [ ] introduce
- [ ] line
- [ ] amusement
- [ ] amusement park

# Chapter 020

- [ ] somewhere
- [ ] camera
- [ ] invention
- [ ] invent
- [ ] unbelievable
- [ ] progress
- [ ] rapid
- [ ] unusual
- [ ] toilet
- [ ] encourage
- [ ] social
- [ ] peaceful
- [ ] tea art
- [ ] performance
- [ ] perfect
- [ ] tea set
- [ ] itself
- [ ] collect
- [ ] a couple of
- [ ] German

# Chapter 021

- [ ] theme
- [ ] ride
- [ ] province
- [ ] thousand
- [ ] thousands of
- [ ] safe
- [ ] simply
- [ ] fear
- [ ] whether
- [ ] Indian
- [ ] Japanese
- [ ] fox
- [ ] all year around
- [ ] equator
- [ ] whenever
- [ ] spring
- [ ] mostly
- [ ] location
- [ ] yard
- [ ] yard sale

# Chapter 022

- [ ] sweet
- [ ] memory
- [ ] cent
- [ ] toy
- [ ] bear
- [ ] maker
- [ ] bread maker
- [ ] scarf
- [ ] soft
- [ ] soft toy
- [ ] check
- [ ] check out
- [ ] board
- [ ] board game
- [ ] junior
- [ ] junior high school
- [ ] clear
- [ ] clear out
- [ ] bedroom
- [ ] no longer

# Chapter 023

- [ ] own
- [ ] railway
- [ ] part
- [ ] part with
- [ ] certain
- [ ] as for
- [ ] honest
- [ ] to be honest
- [ ] while
- [ ] truthful
- [ ] hometown
- [ ] nowadays
- [ ] search
- [ ] among
- [ ] crayon
- [ ] shame
- [ ] regard
- [ ] count
- [ ] century
- [ ] according

# Chapter 024

- [ ] opposite
- [ ] especially
- [ ] childhood
- [ ] consider
- [ ] close to
- [ ] hold

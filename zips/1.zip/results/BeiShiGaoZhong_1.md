
# Chapter 001

- [ ] questionnaire
- [ ] matter
- [ ] partner
- [ ] lifestyle
- [ ] shepherd
- [ ] peaceful
- [ ] relaxing
- [ ] stressful
- [ ] suppose
- [ ] series
- [ ] cartoon
- [ ] talk show
- [ ] complain
- [ ] couch
- [ ] switch
- [ ] BBC
- [ ] portable
- [ ] remote
- [ ] workaholic
- [ ] paperwork

# Chapter 002

- [ ] alarm
- [ ] go off
- [ ] take
- [ ] be filled with
- [ ] urgent
- [ ] document
- [ ] midnight
- [ ] bored
- [ ] stress
- [ ] studio
- [ ] expert
- [ ] suffer
- [ ] pressure
- [ ] social
- [ ] reduce
- [ ] organise
- [ ] diet
- [ ] prefer
- [ ] stand
- [ ] volunteer

# Chapter 003

- [ ] graduate
- [ ] minus
- [ ] basin
- [ ] challenge
- [ ] support
- [ ] dial
- [ ] design
- [ ] advertisement
- [ ] presentation
- [ ] solve
- [ ] accountant
- [ ] tube
- [ ] crowded
- [ ] nearby
- [ ] otherwise
- [ ] forecast
- [ ] crowd
- [ ] lung
- [ ] sickness
- [ ] distance

# Chapter 004

- [ ] cigar
- [ ] at the moment
- [ ] over the years
- [ ] survey
- [ ] classical
- [ ] mini-skirt
- [ ] formal
- [ ] cycle
- [ ] kung fu
- [ ] style
- [ ] calm
- [ ] generous
- [ ] violent
- [ ] character
- [ ] spaceship
- [ ] province
- [ ] astronaut
- [ ] flight
- [ ] launch
- [ ] gravity

# Chapter 005

- [ ] rocket
- [ ] soar
- [ ] the United Nations
- [ ] explore
- [ ] peacefully
- [ ] reporter
- [ ] glow
- [ ] atmosphere
- [ ] parachute
- [ ] helicopter
- [ ] million
- [ ] wave
- [ ] revolution
- [ ] found
- [ ] republic
- [ ] light bulb
- [ ] opinion
- [ ] personally
- [ ] racism
- [ ] equal

# Chapter 006

- [ ] struggle
- [ ] protest
- [ ] march
- [ ] brilliant
- [ ] skilful
- [ ] awful
- [ ] useless
- [ ] unusual
- [ ] champion
- [ ] violence
- [ ] bullet
- [ ] compete
- [ ] keen
- [ ] career
- [ ] amazing
- [ ] event
- [ ] fortunately
- [ ] athlete
- [ ] superhero
- [ ] afterwards

# Chapter 007

- [ ] superman
- [ ] disaster
- [ ] on one's own
- [ ] promote
- [ ] injury
- [ ] give up
- [ ] come to do something
- [ ] pull through
- [ ] commit
- [ ] get on
- [ ] relationship
- [ ] react
- [ ] divorce
- [ ] involve
- [ ] charity
- [ ] quality
- [ ] disabled
- [ ] confident
- [ ] far too
- [ ] come off it

# Chapter 008

- [ ] Olympic
- [ ] badminton
- [ ] admire
- [ ] dead (right)
- [ ] absolutely
- [ ] medal
- [ ] You've got a point there.
- [ ] dive
- [ ] graduation
- [ ] scholarship
- [ ] the Mid Autumn Festival
- [ ] wedding
- [ ] Halloween
- [ ] dragon
- [ ] turkey
- [ ] occasion
- [ ] traditional
- [ ] bean paste
- [ ] nowadays
- [ ] lantern

# Chapter 009

- [ ] lunar
- [ ] celebration
- [ ] power
- [ ] darkness
- [ ] destroy
- [ ] burn down
- [ ] decorate
- [ ] battery
- [ ] sweet dumpling
- [ ] boil
- [ ] serve
- [ ] tradition
- [ ] take part in
- [ ] sticky
- [ ] alcohol
- [ ] hot pot
- [ ] snack
- [ ] reception
- [ ] retire
- [ ] salary

# Chapter 010

- [ ] apply
- [ ] opportunity
- [ ] teenager
- [ ] depend on
- [ ] smartly
- [ ] on time
- [ ] bunch
- [ ] congratulation
- [ ] bride
- [ ] bridegroom
- [ ] best man
- [ ] ceremony
- [ ] entrance
- [ ] invitation
- [ ] even if
- [ ] attend
- [ ] Indonesian
- [ ] ought
- [ ] contribute
- [ ] Greek

# Chapter 011

- [ ] crown
- [ ] ribbon
- [ ] link
- [ ] carol
- [ ] stocking
- [ ] seriously
- [ ] pole
- [ ] envelope
- [ ] calendar
- [ ] put up
- [ ] decoration
- [ ] pudding
- [ ] breast
- [ ] swallow
- [ ] adult
- [ ] carry on
- [ ] merry
- [ ] production
- [ ] needle
- [ ] pillow

# Chapter 012

- [ ] as well
- [ ] mat
- [ ] litre
- [ ] fry
- [ ] unfortunately
- [ ] mess

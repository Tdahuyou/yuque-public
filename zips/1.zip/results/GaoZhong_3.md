
# Chapter 001

- [ ] cancel
- [ ] prepare
- [ ] govern
- [ ] surgeon
- [ ] analyse
- [ ] abrupt
- [ ] resemble
- [ ] discourage
- [ ] hall
- [ ] pollution
- [ ] remote
- [ ] explanation
- [ ] cafeteria
- [ ] salary
- [ ] pretend
- [ ] youth
- [ ] without
- [ ] drunk
- [ ] would
- [ ] pick

# Chapter 002

- [ ] customs
- [ ] calculate
- [ ] energy
- [ ] audience
- [ ] solid
- [ ] thus
- [ ] meanwhile
- [ ] sniff
- [ ] possess
- [ ] require
- [ ] optional
- [ ] scratch
- [ ] analysis
- [ ] click
- [ ] apparent
- [ ] journalist
- [ ] left
- [ ] dawn
- [ ] sideways
- [ ] object

# Chapter 003

- [ ] harbour
- [ ] chapter
- [ ] accessible
- [ ] flight
- [ ] hang
- [ ] role
- [ ] independent
- [ ] carriage
- [ ] defence
- [ ] achieve
- [ ] ahead
- [ ] anybody
- [ ] roll
- [ ] turn
- [ ] elect
- [ ] example
- [ ] result
- [ ] same
- [ ] selfish
- [ ] after

# Chapter 004

- [ ] headline
- [ ] connect
- [ ] hand
- [ ] merciful
- [ ] rebuild
- [ ] sharpen
- [ ] committee
- [ ] address
- [ ] union
- [ ] straight
- [ ] wipe
- [ ] sale
- [ ] component
- [ ] suite
- [ ] consultant
- [ ] outdoors
- [ ] throw
- [ ] obvious
- [ ] arch
- [ ] discuss

# Chapter 005

- [ ] standard
- [ ] violent
- [ ] harmony
- [ ] correct
- [ ] empty
- [ ] wish
- [ ] institution
- [ ] tie
- [ ] wise
- [ ] ambition
- [ ] tin
- [ ] enlarge
- [ ] besides
- [ ] serious
- [ ] tip
- [ ] export
- [ ] conversation
- [ ] laugh
- [ ] murder
- [ ] fantasy

# Chapter 006

- [ ] pay
- [ ] check
- [ ] list
- [ ] strange
- [ ] lack
- [ ] toast
- [ ] aside
- [ ] circumstance
- [ ] success
- [ ] brunch
- [ ] authority
- [ ] creature
- [ ] outgoing
- [ ] tasteless
- [ ] harm
- [ ] instrument
- [ ] medium
- [ ] remove
- [ ] wisdom
- [ ] starvation

# Chapter 007

- [ ] nowhere
- [ ] psychology
- [ ] wrestle
- [ ] treasure
- [ ] multiply
- [ ] live
- [ ] approval
- [ ] victory
- [ ] mobile
- [ ] perform
- [ ] evolution
- [ ] expose
- [ ] concentrate
- [ ] cheer
- [ ] with
- [ ] there
- [ ] permit
- [ ] well
- [ ] suitable
- [ ] personnel

# Chapter 008

- [ ] hopeless
- [ ] freeway
- [ ] fountain
- [ ] pile
- [ ] channel
- [ ] sunburnt
- [ ] focus
- [ ] entire
- [ ] approach
- [ ] wrist
- [ ] experiment
- [ ] fierce
- [ ] reservation
- [ ] e-mail
- [ ] hate
- [ ] block
- [ ] write
- [ ] pet
- [ ] flow
- [ ] order

# Chapter 009

- [ ] wage
- [ ] period
- [ ] musical
- [ ] corporation
- [ ] distant
- [ ] understand
- [ ] dismiss
- [ ] intelligence
- [ ] reform
- [ ] ever
- [ ] even
- [ ] restriction
- [ ] crazy
- [ ] razor
- [ ] coach
- [ ] champion
- [ ] wait
- [ ] circuit
- [ ] pint
- [ ] matter

# Chapter 010

- [ ] instant
- [ ] personalization
- [ ] shaver
- [ ] top
- [ ] native
- [ ] too
- [ ] have
- [ ] violence
- [ ] roast
- [ ] energetic
- [ ] consequence
- [ ] quilt
- [ ] famous
- [ ] question
- [ ] vinegar
- [ ] spirit
- [ ] premier
- [ ] produce
- [ ] allergic
- [ ] cheat

# Chapter 011

- [ ] framework
- [ ] regard
- [ ] anecdote
- [ ] prohibit
- [ ] almost
- [ ] steward
- [ ] fuel
- [ ] manner
- [ ] upon
- [ ] foresee
- [ ] harmful
- [ ] associate
- [ ] pray
- [ ] wake
- [ ] pin
- [ ] academic
- [ ] whether
- [ ] function
- [ ] raise
- [ ] spoon

# Chapter 012

- [ ] quite
- [ ] lap
- [ ] mineral
- [ ] representative
- [ ] terror
- [ ] beneath
- [ ] everyone
- [ ] lay
- [ ] swap
- [ ] hatch
- [ ] pardon
- [ ] plenty
- [ ] tick
- [ ] basis
- [ ] adventure
- [ ] condition
- [ ] improve
- [ ] ceremony
- [ ] bingo
- [ ] try

# Chapter 013

- [ ] gym
- [ ] basic
- [ ] twist
- [ ] unite
- [ ] bush
- [ ] technique
- [ ] cause
- [ ] dioxide
- [ ] wound
- [ ] catastrophe
- [ ] busy
- [ ] convey
- [ ] extra
- [ ] design
- [ ] generous
- [ ] land
- [ ] coincidence
- [ ] victim
- [ ] department
- [ ] possibility

# Chapter 014

- [ ] direction
- [ ] exhibition
- [ ] burn
- [ ] garlic
- [ ] alcoholic
- [ ] bachelor
- [ ] countryside
- [ ] chief
- [ ] automatic
- [ ] lamp
- [ ] cry
- [ ] Antarctic
- [ ] conduct
- [ ] bury
- [ ] obey
- [ ] stable
- [ ] lamb
- [ ] fantastic
- [ ] changeable
- [ ] spoken

# Chapter 015

- [ ] respond
- [ ] incident
- [ ] walk
- [ ] lame
- [ ] marry
- [ ] pity
- [ ] absorb
- [ ] supply
- [ ] uncertain
- [ ] concern
- [ ] circulate
- [ ] liberty
- [ ] recycle
- [ ] let
- [ ] state
- [ ] press
- [ ] welcome
- [ ] confidential
- [ ] chaos
- [ ] abundant

# Chapter 016

- [ ] want
- [ ] pace
- [ ] ballet
- [ ] opposite
- [ ] forecast
- [ ] recognize
- [ ] warehouse
- [ ] pack
- [ ] each
- [ ] abnormal
- [ ] difference
- [ ] must
- [ ] circle
- [ ] resign
- [ ] drier
- [ ] bathe
- [ ] polite
- [ ] cut
- [ ] entertainment
- [ ] probably

# Chapter 017

- [ ] document
- [ ] aluminum
- [ ] ward
- [ ] starve
- [ ] prize
- [ ] accident
- [ ] clay
- [ ] moment
- [ ] anyway
- [ ] promote
- [ ] routine
- [ ] found
- [ ] tear
- [ ] excuse
- [ ] attack
- [ ] spoonful
- [ ] humour
- [ ] divorce
- [ ] currency
- [ ] distribute

# Chapter 018

- [ ] worried
- [ ] attach
- [ ] canal
- [ ] shout
- [ ] escape
- [ ] flashlight
- [ ] ankle
- [ ] situation
- [ ] think
- [ ] receive
- [ ] thirst
- [ ] participate
- [ ] surplus
- [ ] refresh
- [ ] librarian
- [ ] theft
- [ ] religion
- [ ] diagram
- [ ] claw
- [ ] prayer

# Chapter 019

- [ ] speech
- [ ] watch
- [ ] clap
- [ ] quit
- [ ] polish
- [ ] chart
- [ ] insurance
- [ ] medical
- [ ] principle
- [ ] till
- [ ] attend
- [ ] goods
- [ ] lie
- [ ] secure
- [ ] smell
- [ ] used to
- [ ] unable
- [ ] glare
- [ ] disappointed
- [ ] irrigation

# Chapter 020

- [ ] late
- [ ] continue
- [ ] shoot
- [ ] realize
- [ ] budget
- [ ] actual
- [ ] tension
- [ ] chest
- [ ] eastern
- [ ] marathon
- [ ] last
- [ ] adapt
- [ ] wash
- [ ] weight
- [ ] doubt
- [ ] cheerful
- [ ] uncomfortable
- [ ] develop
- [ ] misunderstand
- [ ] warn

# Chapter 021

- [ ] measure
- [ ] guilty
- [ ] crossroads
- [ ] district
- [ ] receipt
- [ ] assume
- [ ] swim
- [ ] full
- [ ] basement
- [ ] pepper
- [ ] chant
- [ ] capsule
- [ ] away
- [ ] memory
- [ ] concept
- [ ] motivation
- [ ] impossible
- [ ] effort
- [ ] wave
- [ ] disaster

# Chapter 022

- [ ] anything
- [ ] agriculture
- [ ] grocer
- [ ] ecology
- [ ] stare
- [ ] painful
- [ ] steady
- [ ] vote
- [ ] early
- [ ] harvest
- [ ] pain
- [ ] disease
- [ ] start
- [ ] purchase
- [ ] yet
- [ ] engineer
- [ ] pair
- [ ] manage
- [ ] equal
- [ ] alike

# Chapter 023

- [ ] gravity
- [ ] typical
- [ ] bravery
- [ ] finance
- [ ] parking
- [ ] shadow
- [ ] hydrogen
- [ ] put
- [ ] climb
- [ ] offence
- [ ] carbon
- [ ] circus
- [ ] controversial
- [ ] dinosaur
- [ ] enter
- [ ] attain
- [ ] trap
- [ ] lonely
- [ ] tram
- [ ] pale

# Chapter 024

- [ ] struggle
- [ ] gallery
- [ ] pest
- [ ] warmth
- [ ] lesson
- [ ] destroy
- [ ] supreme
- [ ] ambulance
- [ ] junior
- [ ] coast
- [ ] shuttle
- [ ] provide
- [ ] allocate
- [ ] light
- [ ] valuable
- [ ] primary
- [ ] stubborn
- [ ] enterprise
- [ ] paperwork
- [ ] solar

# Chapter 025

- [ ] consume
- [ ] triangle
- [ ] competence
- [ ] helmet
- [ ] theme
- [ ] consult
- [ ] merely
- [ ] wealth
- [ ] editor
- [ ] means
- [ ] chain
- [ ] desire
- [ ] survive
- [ ] initial
- [ ] muddy
- [ ] consistent
- [ ] sword
- [ ] fingernail
- [ ] permanent
- [ ] chat

# Chapter 026

- [ ] fetch
- [ ] fellow
- [ ] choice
- [ ] travel
- [ ] civilization
- [ ] before
- [ ] fiction
- [ ] friendly
- [ ] possession
- [ ] tell
- [ ] replace
- [ ] appointment
- [ ] stomach
- [ ] experience
- [ ] listen
- [ ] hit
- [ ] major
- [ ] interrupt
- [ ] beat
- [ ] worldwide

# Chapter 027

- [ ] bear
- [ ] affair
- [ ] consider
- [ ] housework
- [ ] potential
- [ ] accustomed
- [ ] group
- [ ] jewelry
- [ ] obtain
- [ ] lounge
- [ ] rugby
- [ ] resist
- [ ] format
- [ ] sacrifice
- [ ] particular
- [ ] illegal
- [ ] pause
- [ ] congratulate
- [ ] careless
- [ ] square

# Chapter 028

- [ ] rainbow
- [ ] twice
- [ ] ample
- [ ] altitude
- [ ] request
- [ ] classify
- [ ] part
- [ ] percent
- [ ] point
- [ ] paddle
- [ ] general
- [ ] tend
- [ ] frighten
- [ ] relief
- [ ] boycott
- [ ] dimension
- [ ] park
- [ ] unbelievable
- [ ] process
- [ ] deserve

# Chapter 029

- [ ] subscribe
- [ ] clear
- [ ] chef
- [ ] alternative
- [ ] zoom
- [ ] colleague
- [ ] diamond
- [ ] someone
- [ ] build
- [ ] mean
- [ ] approve
- [ ] neither
- [ ] earn
- [ ] glad
- [ ] chew
- [ ] pedestrian
- [ ] hurry
- [ ] account
- [ ] tolerate
- [ ] radioactive

# Chapter 030

- [ ] underline
- [ ] innocent
- [ ] chopsticks
- [ ] alphabet
- [ ] ambiguous
- [ ] advance
- [ ] trip
- [ ] botanical
- [ ] appreciate
- [ ] record
- [ ] diverse
- [ ] cube
- [ ] strict
- [ ] jump
- [ ] knowledge
- [ ] happen
- [ ] pass
- [ ] past
- [ ] festival
- [ ] shock

# Chapter 031

- [ ] delighted
- [ ] pancake
- [ ] active
- [ ] bill
- [ ] whichever
- [ ] court
- [ ] whose
- [ ] bucket
- [ ] senior
- [ ] flexible
- [ ] relative
- [ ] attitude
- [ ] organ
- [ ] average
- [ ] compare
- [ ] sceptical
- [ ] unwilling
- [ ] thriller
- [ ] transparent
- [ ] characteristic

# Chapter 032

- [ ] how
- [ ] grasp
- [ ] Buddhism
- [ ] receptionist
- [ ] composition
- [ ] unlike
- [ ] hearing
- [ ] term
- [ ] volcano
- [ ] wedding
- [ ] acquisition
- [ ] rigid
- [ ] deadline
- [ ] spare
- [ ] mine
- [ ] mind
- [ ] grateful
- [ ] business
- [ ] bungalow
- [ ] staff

# Chapter 033

- [ ] possible
- [ ] partly
- [ ] breathless
- [ ] meet
- [ ] answer
- [ ] borrow
- [ ] maximum
- [ ] under
- [ ] desert
- [ ] represent
- [ ] compete
- [ ] die
- [ ] radium
- [ ] fragrant
- [ ] dig
- [ ] accountant
- [ ] stocking
- [ ] sometimes
- [ ] emergency
- [ ] promise

# Chapter 034

- [ ] dip
- [ ] hold
- [ ] habit
- [ ] passport
- [ ] absurd
- [ ] burglar
- [ ] considerate
- [ ] rubber
- [ ] legal
- [ ] underwear
- [ ] talk
- [ ] reply
- [ ] train
- [ ] parcel
- [ ] test
- [ ] journey
- [ ] count
- [ ] graph
- [ ] upwards
- [ ] feast

# Chapter 035

- [ ] contradictory
- [ ] take
- [ ] accompany
- [ ] petrol
- [ ] beneficial
- [ ] blame
- [ ] final
- [ ] some
- [ ] squeeze
- [ ] blank
- [ ] rather
- [ ] importance
- [ ] session
- [ ] back
- [ ] worthy
- [ ] endless
- [ ] training
- [ ] expectation
- [ ] mist
- [ ] miss

# Chapter 036

- [ ] pound
- [ ] load
- [ ] bite
- [ ] ferry
- [ ] disgusting
- [ ] ignore
- [ ] loaf
- [ ] reception
- [ ] applaud
- [ ] just
- [ ] outward
- [ ] notice
- [ ] yummy
- [ ] holy
- [ ] relax
- [ ] relay
- [ ] custom
- [ ] length
- [ ] permission
- [ ] grand

# Chapter 037

- [ ] schedule
- [ ] eastwards
- [ ] print
- [ ] rewind
- [ ] although
- [ ] material
- [ ] approximately
- [ ] encouragement
- [ ] universe
- [ ] biochemistry
- [ ] iron
- [ ] idiom
- [ ] blanket
- [ ] hug
- [ ] explain
- [ ] envy
- [ ] discount
- [ ] construct
- [ ] hope
- [ ] attempt

# Chapter 038

- [ ] soon
- [ ] division
- [ ] tablet
- [ ] hook
- [ ] balance
- [ ] bend
- [ ] action
- [ ] lock
- [ ] stadium
- [ ] fear
- [ ] appreciation
- [ ] electrical
- [ ] statue
- [ ] sense
- [ ] cream
- [ ] sensitive
- [ ] being
- [ ] vacant
- [ ] afford
- [ ] birthplace

# Chapter 039

- [ ] dustbin
- [ ] impression
- [ ] interval
- [ ] evaluate
- [ ] status
- [ ] upset
- [ ] dot
- [ ] deliver
- [ ] tailor
- [ ] stamp
- [ ] skip
- [ ] phenomenon
- [ ] mention
- [ ] mad
- [ ] barbecue
- [ ] file
- [ ] laundry
- [ ] member
- [ ] brewery
- [ ] accumulate

# Chapter 040

- [ ] crime
- [ ] stand
- [ ] surround
- [ ] together
- [ ] pavement
- [ ] cigarette
- [ ] may
- [ ] could
- [ ] forward
- [ ] bent
- [ ] strike
- [ ] health
- [ ] positive
- [ ] favourite
- [ ] bless
- [ ] menu
- [ ] Pacific
- [ ] able
- [ ] mend
- [ ] return

# Chapter 041

- [ ] mail
- [ ] conscience
- [ ] subject
- [ ] use
- [ ] bonus
- [ ] feel
- [ ] main
- [ ] thrill
- [ ] serve
- [ ] cassette
- [ ] smile
- [ ] fine
- [ ] find
- [ ] host
- [ ] accelerate
- [ ] grain
- [ ] international
- [ ] maid
- [ ] credit
- [ ] oxygen

# Chapter 042

- [ ] regardless
- [ ] terrible
- [ ] combine
- [ ] upward
- [ ] waste
- [ ] citizen
- [ ] occur
- [ ] comedy
- [ ] pleasant
- [ ] difficult
- [ ] pressure
- [ ] sort
- [ ] fill
- [ ] dentist
- [ ] numb
- [ ] feed
- [ ] forget
- [ ] professor
- [ ] convenient
- [ ] specialist

# Chapter 043

- [ ] compass
- [ ] background
- [ ] true
- [ ] adolescent
- [ ] valley
- [ ] position
- [ ] present
- [ ] laughter
- [ ] since
- [ ] patent
- [ ] belong
- [ ] soul
- [ ] dangerous
- [ ] certificate
- [ ] mess
- [ ] sour
- [ ] delete
- [ ] stain
- [ ] breath
- [ ] transform

# Chapter 044

- [ ] advise
- [ ] repeat
- [ ] physical
- [ ] make
- [ ] microwave
- [ ] rooster
- [ ] brochure
- [ ] master
- [ ] extraordinary
- [ ] witness
- [ ] conventional
- [ ] regulation
- [ ] due
- [ ] ripen
- [ ] puzzle
- [ ] evident
- [ ] accommodation
- [ ] authentic
- [ ] socket
- [ ] biscuit

# Chapter 045

- [ ] fence
- [ ] breast
- [ ] mercy
- [ ] annoy
- [ ] inform
- [ ] depend
- [ ] commit
- [ ] about
- [ ] scream
- [ ] sorrow
- [ ] cure
- [ ] danger
- [ ] crash
- [ ] cover
- [ ] firm
- [ ] character
- [ ] reflect
- [ ] contribution
- [ ] above
- [ ] fire

# Chapter 046

- [ ] stick
- [ ] orbit
- [ ] band
- [ ] height
- [ ] spray
- [ ] distinguish
- [ ] outer
- [ ] invent
- [ ] fluent
- [ ] wonderful
- [ ] shortcoming
- [ ] haircut
- [ ] howl
- [ ] something
- [ ] benefit
- [ ] flood
- [ ] quality
- [ ] intention
- [ ] booth
- [ ] rude

# Chapter 047

- [ ] enthusiastic
- [ ] symptom
- [ ] funeral
- [ ] unique
- [ ] except
- [ ] ministry
- [ ] religious
- [ ] shelter
- [ ] fact
- [ ] examine
- [ ] scan
- [ ] fundamental
- [ ] association
- [ ] believe
- [ ] remember
- [ ] outline
- [ ] fade
- [ ] unless
- [ ] glance
- [ ] free

# Chapter 048

- [ ] equality
- [ ] mix
- [ ] ought
- [ ] dictation
- [ ] crayon
- [ ] honour
- [ ] bother
- [ ] expression
- [ ] middle
- [ ] childhood
- [ ] though
- [ ] thorough
- [ ] appeal
- [ ] everyday
- [ ] stay
- [ ] appear
- [ ] face
- [ ] abandon
- [ ] congratulation
- [ ] inspire

# Chapter 049

- [ ] afraid
- [ ] progress
- [ ] geometry
- [ ] invite
- [ ] open
- [ ] devote
- [ ] agent
- [ ] treat
- [ ] abortion
- [ ] bishop
- [ ] suffering
- [ ] afterward
- [ ] reputation
- [ ] project
- [ ] inside
- [ ] independence
- [ ] presentation
- [ ] whenever
- [ ] dynasty
- [ ] bark

# Chapter 050

- [ ] greedy
- [ ] awkward
- [ ] bare
- [ ] ruin
- [ ] mutton
- [ ] celebrate
- [ ] admirable
- [ ] please
- [ ] look
- [ ] offshore
- [ ] fortnight
- [ ] scar
- [ ] mountainous
- [ ] inspect
- [ ] campaign
- [ ] vital
- [ ] conflict
- [ ] allow
- [ ] rough
- [ ] knock

# Chapter 051

- [ ] mass
- [ ] rule
- [ ] proper
- [ ] update
- [ ] amateur
- [ ] poisonous
- [ ] condemn
- [ ] assistance
- [ ] bitter
- [ ] speed
- [ ] gesture
- [ ] admit
- [ ] common
- [ ] interest
- [ ] wonder
- [ ] sleepy
- [ ] sneeze
- [ ] bath
- [ ] every
- [ ] mask

# Chapter 052

- [ ] thermos
- [ ] summary
- [ ] apply
- [ ] overlook
- [ ] politician
- [ ] taxpayer
- [ ] indeed
- [ ] seagull
- [ ] artificial
- [ ] disagree
- [ ] comment
- [ ] step
- [ ] forever
- [ ] mark
- [ ] base
- [ ] employ
- [ ] trend
- [ ] achievement
- [ ] whole
- [ ] fair

# Chapter 053

- [ ] during
- [ ] balcony
- [ ] revolution
- [ ] mop
- [ ] consist
- [ ] preparation
- [ ] relation
- [ ] reliable
- [ ] loss
- [ ] relate
- [ ] typhoon
- [ ] decoration
- [ ] eggplant
- [ ] zip
- [ ] profession
- [ ] still
- [ ] worn
- [ ] arise
- [ ] dizzy
- [ ] work

# Chapter 054

- [ ] lose
- [ ] agree
- [ ] fail
- [ ] toward
- [ ] enjoyable
- [ ] anyone
- [ ] convince
- [ ] pride
- [ ] emperor
- [ ] word
- [ ] theory
- [ ] broadcast
- [ ] love
- [ ] extension
- [ ] signature
- [ ] steep
- [ ] seize
- [ ] literary
- [ ] architect
- [ ] forehead

# Chapter 055

- [ ] enjoy
- [ ] privilege
- [ ] fireworks
- [ ] substitute
- [ ] foreign
- [ ] across
- [ ] uniform
- [ ] fall
- [ ] identity
- [ ] violate
- [ ] federal
- [ ] event
- [ ] academy
- [ ] wherever
- [ ] reward
- [ ] include
- [ ] alongside
- [ ] swallow
- [ ] agency
- [ ] abstract

# Chapter 056

- [ ] agenda
- [ ] opinion
- [ ] altogether
- [ ] appearance
- [ ] culture
- [ ] devotion
- [ ] prefer
- [ ] perfect
- [ ] butcher
- [ ] float
- [ ] pole
- [ ] minority
- [ ] tight
- [ ] space
- [ ] reference
- [ ] arrange
- [ ] from
- [ ] alley
- [ ] discover
- [ ] bench

# Chapter 057

- [ ] commitment
- [ ] excite
- [ ] rhyme
- [ ] spade
- [ ] revision
- [ ] qualification
- [ ] collision
- [ ] bridegroom
- [ ] repair
- [ ] advice
- [ ] frequent
- [ ] insure
- [ ] elder
- [ ] error
- [ ] windy
- [ ] Oceania
- [ ] public
- [ ] spend
- [ ] barbershop
- [ ] track

# Chapter 058

- [ ] value
- [ ] foggy
- [ ] quantity
- [ ] fortune
- [ ] advantage
- [ ] instead
- [ ] rush
- [ ] command
- [ ] expensive
- [ ] cloudy
- [ ] compulsory
- [ ] trade
- [ ] dessert
- [ ] round
- [ ] ambassador
- [ ] non-stop
- [ ] temple
- [ ] growth
- [ ] vague
- [ ] communist

# Chapter 059

- [ ] fare
- [ ] temporary
- [ ] desperate
- [ ] unrest
- [ ] kangaroo
- [ ] accuracy
- [ ] awful
- [ ] handy
- [ ] urge
- [ ] via
- [ ] score
- [ ] poor
- [ ] graduate
- [ ] visual
- [ ] absent
- [ ] rag
- [ ] because
- [ ] near
- [ ] educate
- [ ] ashamed

# Chapter 060

- [ ] appendix
- [ ] instruct
- [ ] excellent
- [ ] fairly
- [ ] handwriting
- [ ] raw
- [ ] merchant
- [ ] retell
- [ ] ray
- [ ] version
- [ ] exam
- [ ] stop
- [ ] nationality
- [ ] guess
- [ ] adolescence
- [ ] aboard
- [ ] institute
- [ ] poster
- [ ] shortly
- [ ] appropriate

# Chapter 061

- [ ] criterion
- [ ] least
- [ ] immediately
- [ ] symphony
- [ ] optimistic
- [ ] sleep
- [ ] vocabulary
- [ ] refuse
- [ ] aspect
- [ ] aggressive
- [ ] close
- [ ] sweep
- [ ] website
- [ ] learn
- [ ] swing
- [ ] ridiculous
- [ ] severe
- [ ] spin
- [ ] grocery
- [ ] communism

# Chapter 062

- [ ] spit
- [ ] anniversary
- [ ] register
- [ ] couple
- [ ] communicate
- [ ] eager
- [ ] evidence
- [ ] republic
- [ ] official
- [ ] acid
- [ ] assessment
- [ ] post
- [ ] agricultural
- [ ] leave
- [ ] duck
- [ ] cottage
- [ ] tiresome
- [ ] finish
- [ ] discrimination
- [ ] female

# Chapter 063

- [ ] melon
- [ ] swift
- [ ] add
- [ ] minister
- [ ] need
- [ ] cruel
- [ ] erupt
- [ ] shade
- [ ] often
- [ ] gather
- [ ] insist
- [ ] article
- [ ] respect
- [ ] ache
- [ ] loose
- [ ] therefore
- [ ] exchange
- [ ] adjustment
- [ ] hesitate
- [ ] hardly

# Chapter 064

- [ ] bored
- [ ] trust
- [ ] income
- [ ] private
- [ ] technical
- [ ] companion
- [ ] choose
- [ ] directory
- [ ] peaceful
- [ ] prevent
- [ ] behave
- [ ] accomplish
- [ ] disturbing
- [ ] engine
- [ ] photographer
- [ ] end
- [ ] mistake
- [ ] pour
- [ ] message
- [ ] praise

# Chapter 065

- [ ] significance
- [ ] special
- [ ] scissors
- [ ] environment
- [ ] truth
- [ ] clone
- [ ] betray
- [ ] pronounce
- [ ] family
- [ ] swear
- [ ] gift
- [ ] atmosphere
- [ ] decorate
- [ ] education
- [ ] occupation
- [ ] tendency
- [ ] slim
- [ ] arithmetic
- [ ] caption
- [ ] rid

# Chapter 066

- [ ] moral
- [ ] number
- [ ] explode
- [ ] greengrocer
- [ ] punish
- [ ] casual
- [ ] decline
- [ ] narrow
- [ ] judge
- [ ] similar
- [ ] contradict
- [ ] Catholic
- [ ] shape
- [ ] nothing
- [ ] headmistress
- [ ] anyhow
- [ ] whistle
- [ ] handle
- [ ] chain stores
- [ ] crossing

# Chapter 067

- [ ] tough
- [ ] exit
- [ ] system
- [ ] giraffe
- [ ] spot
- [ ] aid
- [ ] other
- [ ] aim
- [ ] against
- [ ] confident
- [ ] cell
- [ ] swell
- [ ] courage
- [ ] local
- [ ] remind
- [ ] crew
- [ ] valid
- [ ] defeat
- [ ] spear
- [ ] encourage

# Chapter 068

- [ ] electronic
- [ ] vacation
- [ ] speak
- [ ] share
- [ ] bureaucratic
- [ ] sacred
- [ ] elegant
- [ ] outcome
- [ ] curriculum
- [ ] satisfaction
- [ ] sharp
- [ ] powerful
- [ ] slip
- [ ] future
- [ ] anchor
- [ ] acquaintance
- [ ] novelist
- [ ] royal
- [ ] shake
- [ ] eyesight

# Chapter 069

- [ ] semicircle
- [ ] screen
- [ ] autonomous
- [ ] referee
- [ ] trial
- [ ] correspond
- [ ] undertake
- [ ] insect
- [ ] buffet
- [ ] entrance
- [ ] pregnant
- [ ] all
- [ ] always
- [ ] border
- [ ] below
- [ ] already
- [ ] touch
- [ ] shall
- [ ] admission
- [ ] real

# Chapter 070

- [ ] expense
- [ ] unit
- [ ] yell
- [ ] contemporary
- [ ] collect
- [ ] dusty
- [ ] amusement
- [ ] boundary
- [ ] shame
- [ ] rob
- [ ] outing
- [ ] trick
- [ ] favour
- [ ] around
- [ ] pollute
- [ ] disappoint
- [ ] rot
- [ ] construction
- [ ] predict
- [ ] row

# Chapter 071

- [ ] universal
- [ ] abroad
- [ ] frontier
- [ ] subjective
- [ ] deliberately
- [ ] seaweed
- [ ] drawer
- [ ] transport
- [ ] specific
- [ ] any
- [ ] application
- [ ] freezing
- [ ] punctuation
- [ ] acre
- [ ] whisper
- [ ] appetite
- [ ] until
- [ ] dull
- [ ] clumsy
- [ ] reason

# Chapter 072

- [ ] thought
- [ ] accurate
- [ ] ring
- [ ] taste
- [ ] anywhere
- [ ] bargain
- [ ] identification
- [ ] jam
- [ ] annual
- [ ] gentle
- [ ] cheers
- [ ] boil
- [ ] sneaker
- [ ] lightning
- [ ] remain
- [ ] shabby
- [ ] amaze
- [ ] demand
- [ ] envelope
- [ ] slow

# Chapter 073

- [ ] turkey
- [ ] grade
- [ ] deposit
- [ ] tasty
- [ ] telescope
- [ ] flash
- [ ] skillful
- [ ] continent
- [ ] accuse
- [ ] maybe
- [ ] another
- [ ] guarantee
- [ ] algebra
- [ ] recommend
- [ ] acquire
- [ ] worth
- [ ] helicopter
- [ ] ripe
- [ ] where
- [ ] disabled

# Chapter 074

- [ ] watermelon
- [ ] arm
- [ ] popular
- [ ] broken
- [ ] outwards
- [ ] vice
- [ ] poison
- [ ] silly
- [ ] liberation
- [ ] fortunate
- [ ] wrinkle
- [ ] tour
- [ ] persuade
- [ ] call
- [ ] consensus
- [ ] such
- [ ] calm
- [ ] boring
- [ ] classic
- [ ] kick

# Chapter 075

- [ ] absolute
- [ ] ask
- [ ] canteen
- [ ] describe
- [ ] suck
- [ ] dilemma
- [ ] wealthy
- [ ] strength
- [ ] dusk
- [ ] administration
- [ ] run
- [ ] challenging
- [ ] research
- [ ] debate
- [ ] view
- [ ] either
- [ ] furniture
- [ ] jet
- [ ] donate
- [ ] helpful

# Chapter 076

- [ ] dust
- [ ] worry
- [ ] cater
- [ ] imagine
- [ ] attractive
- [ ] superb
- [ ] might
- [ ] bleed
- [ ] catalogue
- [ ] whatever
- [ ] decrease
- [ ] camp
- [ ] difficulty
- [ ] volunteer
- [ ] everywhere
- [ ] clothing
- [ ] aloud
- [ ] thunderstorm
- [ ] mourn
- [ ] next

# Chapter 077

- [ ] blind
- [ ] nod
- [ ] string
- [ ] import
- [ ] distance
- [ ] occupy
- [ ] submit
- [ ] boom
- [ ] abolish
- [ ] absence
- [ ] nearly
- [ ] attract
- [ ] show
- [ ] edition
- [ ] cautious
- [ ] disappear
- [ ] perfume
- [ ] shot
- [ ] conclusion
- [ ] nor

# Chapter 078

- [ ] central
- [ ] defend
- [ ] arrive
- [ ] memorial
- [ ] wag
- [ ] race
- [ ] introduce
- [ ] greet
- [ ] sculpture
- [ ] bond
- [ ] way
- [ ] target
- [ ] wax
- [ ] grey
- [ ] what
- [ ] urban
- [ ] guidance
- [ ] refer
- [ ] nervous
- [ ] duty

# Chapter 079

- [ ] risk
- [ ] flame
- [ ] rise
- [ ] play
- [ ] delicate
- [ ] fancy
- [ ] bounce
- [ ] tissue
- [ ] decide
- [ ] rent
- [ ] when
- [ ] nearby
- [ ] carpenter
- [ ] modest
- [ ] cast
- [ ] anxious
- [ ] fan
- [ ] slice
- [ ] far
- [ ] frost

# Chapter 080

- [ ] catch
- [ ] fax
- [ ] plan
- [ ] cash
- [ ] case
- [ ] generation
- [ ] give
- [ ] double
- [ ] downtown
- [ ] trunk
- [ ] stainless
- [ ] explicit
- [ ] rely
- [ ] phone
- [ ] slide
- [ ] comfortable
- [ ] waist
- [ ] style
- [ ] jungle
- [ ] flesh

# Chapter 081

- [ ] suit
- [ ] grill
- [ ] care
- [ ] damage
- [ ] guard
- [ ] settle
- [ ] direct
- [ ] pattern
- [ ] exercise
- [ ] labour
- [ ] gain
- [ ] vehicle
- [ ] hardship
- [ ] confuse
- [ ] kilo
- [ ] freedom
- [ ] cushion
- [ ] scold
- [ ] modern
- [ ] physics

# Chapter 082

- [ ] seldom
- [ ] physician
- [ ] protect
- [ ] architecture
- [ ] souvenir
- [ ] dial
- [ ] stress
- [ ] explore
- [ ] more
- [ ] wet
- [ ] born
- [ ] strawberry
- [ ] electricity
- [ ] tentative
- [ ] climate
- [ ] kill
- [ ] conductor
- [ ] porridge
- [ ] pleased
- [ ] certain

# Chapter 083

- [ ] woolen
- [ ] board
- [ ] statistics
- [ ] shut
- [ ] arrest
- [ ] distinction
- [ ] widow
- [ ] mature
- [ ] navy
- [ ] disability
- [ ] fee
- [ ] section
- [ ] simple
- [ ] used
- [ ] influence
- [ ] mustard
- [ ] percentage
- [ ] talent
- [ ] few
- [ ] otherwise

# Chapter 084

- [ ] negotiate
- [ ] hunt
- [ ] package
- [ ] pronunciation
- [ ] kind
- [ ] survival
- [ ] strait
- [ ] both
- [ ] voyage
- [ ] important
- [ ] nutrition
- [ ] detective
- [ ] phrase
- [ ] personally
- [ ] outside
- [ ] passer-by
- [ ] keep
- [ ] effect
- [ ] affection
- [ ] yoghurt

# Chapter 085

- [ ] skate
- [ ] correction
- [ ] embarrass
- [ ] who
- [ ] weigh
- [ ] sponsor
- [ ] acute
- [ ] kindergarten
- [ ] jog
- [ ] terrify
- [ ] contribute
- [ ] faith
- [ ] insert
- [ ] why
- [ ] remark
- [ ] forbid
- [ ] microscope
- [ ] tortoise
- [ ] candidate
- [ ] alone

# Chapter 086

- [ ] database
- [ ] parallel
- [ ] patient
- [ ] reject
- [ ] dialogue
- [ ] diet
- [ ] profit
- [ ] win
- [ ] rest
- [ ] move
- [ ] amount
- [ ] handful
- [ ] album
- [ ] electric
- [ ] yawn
- [ ] say
- [ ] also
- [ ] terminal
- [ ] enough
- [ ] increase

# Chapter 087

- [ ] differ
- [ ] shine
- [ ] spread
- [ ] various
- [ ] attention
- [ ] latter
- [ ] front
- [ ] visit
- [ ] clinic
- [ ] customer
- [ ] stupid
- [ ] greeting
- [ ] bring
- [ ] beddings
- [ ] awake
- [ ] kiss
- [ ] ban
- [ ] hamburger
- [ ] fond
- [ ] fit

# Chapter 088

- [ ] offer
- [ ] robot
- [ ] bar
- [ ] suffer
- [ ] fix
- [ ] neighbourhood
- [ ] complex
- [ ] draft
- [ ] honest
- [ ] pension
- [ ] assumption
- [ ] rank
- [ ] rubbish
- [ ] addition
- [ ] afterwards
- [ ] sure
- [ ] grow
- [ ] carve
- [ ] shrink
- [ ] ancestor

# Chapter 089

- [ ] league
- [ ] personal
- [ ] angry
- [ ] former
- [ ] panic
- [ ] fold
- [ ] stewardess
- [ ] as
- [ ] delay
- [ ] at
- [ ] chemical
- [ ] turning
- [ ] peace
- [ ] plant
- [ ] folk
- [ ] enquiry
- [ ] drive
- [ ] hurt
- [ ] deal
- [ ] abuse

# Chapter 090

- [ ] prove
- [ ] homeland
- [ ] affect
- [ ] deaf
- [ ] admire
- [ ] virus
- [ ] amuse
- [ ] see
- [ ] search
- [ ] furnished
- [ ] responsibility
- [ ] sudden
- [ ] fool
- [ ] civil
- [ ] by
- [ ] whom
- [ ] indicate
- [ ] set
- [ ] charge
- [ ] contain

# Chapter 091

- [ ] outstanding
- [ ] litter
- [ ] oval
- [ ] procedure
- [ ] familiar
- [ ] biography
- [ ] breathe
- [ ] applicant
- [ ] battle
- [ ] awesome
- [ ] partner
- [ ] gifted
- [ ] visa
- [ ] zipper
- [ ] Arctic
- [ ] unfit
- [ ] interview
- [ ] clarify
- [ ] beauty
- [ ] beg

# Chapter 092

- [ ] scare
- [ ] do
- [ ] observe
- [ ] humorous
- [ ] garment
- [ ] rare
- [ ] useless
- [ ] which
- [ ] disadvantage
- [ ] garbage
- [ ] mainland
- [ ] downstairs
- [ ] marble
- [ ] never
- [ ] anxiety
- [ ] piece
- [ ] adjust
- [ ] carry
- [ ] burst
- [ ] western

# Chapter 093

- [ ] debt
- [ ] little
- [ ] however
- [ ] deep
- [ ] goose
- [ ] forgive
- [ ] origin
- [ ] for
- [ ] mistaken
- [ ] content
- [ ] deed
- [ ] burden
- [ ] salute
- [ ] random
- [ ] perhaps
- [ ] plot
- [ ] rate
- [ ] skill
- [ ] trouble
- [ ] unfair

# Chapter 094

- [ ] divide
- [ ] contrary
- [ ] sit
- [ ] digital
- [ ] over
- [ ] brilliant
- [ ] practical
- [ ] pesticide
- [ ] bound
- [ ] false
- [ ] go
- [ ] tease
- [ ] fork
- [ ] form
- [ ] publish
- [ ] pyramid
- [ ] cheque
- [ ] avoid
- [ ] bid
- [ ] fresh

# Chapter 095

- [ ] astonish
- [ ] withdraw
- [ ] straightforward
- [ ] very
- [ ] decade
- [ ] expert
- [ ] practice
- [ ] select
- [ ] crowd
- [ ] sick
- [ ] bit
- [ ] welfare
- [ ] output
- [ ] corner
- [ ] else
- [ ] modem
- [ ] majority
- [ ] beside
- [ ] join
- [ ] drag

# Chapter 096

- [ ] reduce
- [ ] likely
- [ ] large
- [ ] bakery
- [ ] vain
- [ ] ordinary
- [ ] fry
- [ ] somebody
- [ ] drink
- [ ] announce
- [ ] traditional
- [ ] lively
- [ ] operate
- [ ] begin
- [ ] become
- [ ] bacterium
- [ ] paragraph
- [ ] oilfield
- [ ] alive
- [ ] eventually

# Chapter 097

- [ ] neighbour
- [ ] tournament
- [ ] cycle
- [ ] thinking
- [ ] literature
- [ ] astronomer
- [ ] prejudice
- [ ] digest
- [ ] angle
- [ ] tradition
- [ ] ability
- [ ] everything
- [ ] unbearable
- [ ] urgent
- [ ] programme
- [ ] belief
- [ ] delight
- [ ] immigration
- [ ] break
- [ ] chain store

# Chapter 098

- [ ] vest
- [ ] change
- [ ] suggestion
- [ ] fluency
- [ ] draw
- [ ] systematic
- [ ] trolleybus
- [ ] lantern
- [ ] cupboard
- [ ] off
- [ ] comfort
- [ ] joke
- [ ] knee
- [ ] punishment
- [ ] hide
- [ ] troublesome
- [ ] instruction
- [ ] report
- [ ] oral
- [ ] complete

# Chapter 099

- [ ] compensate
- [ ] fun
- [ ] constant
- [ ] smog
- [ ] sob
- [ ] political
- [ ] while
- [ ] anger
- [ ] second
- [ ] that
- [ ] edge
- [ ] download
- [ ] split
- [ ] than
- [ ] limit
- [ ] widespread
- [ ] antique
- [ ] sow
- [ ] different
- [ ] fasten

# Chapter 100

- [ ] porter
- [ ] level
- [ ] dirt
- [ ] videophone
- [ ] preserve
- [ ] plus
- [ ] relevant
- [ ] license
- [ ] entry
- [ ] expand
- [ ] dream
- [ ] noble
- [ ] plug
- [ ] bunch
- [ ] spy
- [ ] postpone
- [ ] tense
- [ ] bride
- [ ] heat
- [ ] behind

# Chapter 101

- [ ] hammer
- [ ] seal
- [ ] recipe
- [ ] ambassadress
- [ ] mental
- [ ] bow
- [ ] storage
- [ ] racial
- [ ] switch
- [ ] total
- [ ] of
- [ ] reserve
- [ ] somehow
- [ ] brick
- [ ] dive
- [ ] heap
- [ ] sympathy
- [ ] hear
- [ ] fight
- [ ] roundabout

# Chapter 102

- [ ] rescue
- [ ] facial
- [ ] on
- [ ] zebra
- [ ] brief
- [ ] unfortunate
- [ ] recover
- [ ] or
- [ ] chance
- [ ] determine
- [ ] nature
- [ ] social
- [ ] wheel
- [ ] interesting
- [ ] cross
- [ ] control
- [ ] drill
- [ ] friction
- [ ] clerk
- [ ] walnut

# Chapter 103

- [ ] acknowledge
- [ ] equip
- [ ] radiation
- [ ] quarrel
- [ ] Christian
- [ ] pulse
- [ ] maple
- [ ] spiritual
- [ ] worthwhile
- [ ] nation
- [ ] upper
- [ ] splendid
- [ ] adaptation
- [ ] behalf
- [ ] somewhere
- [ ] scene
- [ ] injure
- [ ] freeze
- [ ] eastward
- [ ] geography

# Chapter 104

- [ ] horrible
- [ ] strengthen
- [ ] injury
- [ ] diploma
- [ ] brand
- [ ] suspension
- [ ] choke
- [ ] alcohol
- [ ] pleasure
- [ ] old
- [ ] recreation
- [ ] allowance
- [ ] interpreter
- [ ] hurricane
- [ ] portable
- [ ] then
- [ ] ancient
- [ ] accept
- [ ] glory
- [ ] seat

# Chapter 105

- [ ] wander
- [ ] adopt
- [ ] oppose
- [ ] minus
- [ ] belly
- [ ] conservative
- [ ] access
- [ ] conference
- [ ] primitive
- [ ] activity
- [ ] dormitory
- [ ] overcome
- [ ] recite
- [ ] seek
- [ ] seem
- [ ] heel
- [ ] variety
- [ ] disturb
- [ ] adore
- [ ] lecture

# Chapter 106

- [ ] civilian
- [ ] so
- [ ] pump
- [ ] caution
- [ ] key
- [ ] teenager
- [ ] dumpling
- [ ] silent
- [ ] decision
- [ ] addicted
- [ ] necessary
- [ ] one
- [ ] garage
- [ ] badminton
- [ ] confirm
- [ ] single
- [ ] pull
- [ ] unconditional
- [ ] gallon
- [ ] appoint

# Chapter 107

- [ ] assist
- [ ] bun
- [ ] but
- [ ] symbol
- [ ] sincerely
- [ ] commercial
- [ ] separate
- [ ] declare
- [ ] reasonable
- [ ] dislike
- [ ] willing
- [ ] available
- [ ] express
- [ ] advocate
- [ ] amazing
- [ ] luggage
- [ ] drawback
- [ ] dynamic
- [ ] up
- [ ] unusual

# Chapter 108

- [ ] extreme
- [ ] usual
- [ ] sink
- [ ] degree
- [ ] astronomy
- [ ] suppose
- [ ] brake
- [ ] tube
- [ ] outspoken
- [ ] especially
- [ ] once
- [ ] failure
- [ ] quake
- [ ] know
- [ ] sing
- [ ] organise
- [ ] support
- [ ] drop
- [ ] preview
- [ ] questionnaire

# Chapter 109

- [ ] saucer
- [ ] hire
- [ ] breakthrough
- [ ] idea
- [ ] destination
- [ ] apron
- [ ] vertical
- [ ] monument
- [ ] pure
- [ ] vivid
- [ ] damp
- [ ] throughout
- [ ] virtue
- [ ] overweight
- [ ] gay
- [ ] successful
- [ ] lovely
- [ ] normal
- [ ] gradual
- [ ] figure

# Chapter 110

- [ ] socialist
- [ ] airmail
- [ ] slight
- [ ] corrupt
- [ ] wide
- [ ] previous
- [ ] teach
- [ ] socialism
- [ ] argue
- [ ] technology
- [ ] superior
- [ ] succeed
- [ ] choir
- [ ] punctual
- [ ] advertise
- [ ] compromise
- [ ] software
- [ ] seminar
- [ ] reach
- [ ] react

# Chapter 111

- [ ] competition
- [ ] none
- [ ] type
- [ ] beyond
- [ ] practise
- [ ] review
- [ ] sight
- [ ] voluntary
- [ ] asleep
- [ ] nobody
- [ ] guide
- [ ] between
- [ ] surrounding
- [ ] goal
- [ ] collar
- [ ] natural
- [ ] overhead
- [ ] conclude
- [ ] come
- [ ] comprehension

# Chapter 112

- [ ] leather
- [ ] comb
- [ ] exist
- [ ] unemployment
- [ ] exact
- [ ] lift
- [ ] motto
- [ ] nationwide
- [ ] force
- [ ] centigrade
- [ ] botany
- [ ] wear
- [ ] range
- [ ] weak
- [ ] leak
- [ ] impress
- [ ] flat
- [ ] get
- [ ] course
- [ ] barber

# Chapter 113

- [ ] copy
- [ ] precise
- [ ] power
- [ ] place
- [ ] dare
- [ ] regular
- [ ] precious
- [ ] sell
- [ ] tired
- [ ] tremble
- [ ] gymnastics
- [ ] suspect
- [ ] suggest
- [ ] apologize
- [ ] expect
- [ ] help
- [ ] depth
- [ ] assess
- [ ] prescription
- [ ] behaviour

# Chapter 114

- [ ] chorus
- [ ] minimum
- [ ] queue
- [ ] apology
- [ ] date
- [ ] magic
- [ ] dress
- [ ] argument
- [ ] passage
- [ ] theoretical
- [ ] adequate
- [ ] sound
- [ ] own
- [ ] hopeful
- [ ] dozen
- [ ] translate
- [ ] drug
- [ ] barrier
- [ ] plain
- [ ] should

# Chapter 115

- [ ] only
- [ ] create
- [ ] justice
- [ ] criminal
- [ ] blow
- [ ] curious
- [ ] proud
- [ ] like
- [ ] ugly
- [ ] earthquake
- [ ] tax
- [ ] towards
- [ ] messy
- [ ] embassy
- [ ] rectangle
- [ ] fragile
- [ ] departure
- [ ] dash
- [ ] send
- [ ] concrete

# Chapter 116

- [ ] note
- [ ] everybody
- [ ] sail
- [ ] cab
- [ ] purpose
- [ ] regret
- [ ] line
- [ ] stout
- [ ] link
- [ ] flee
- [ ] weep
- [ ] tune
- [ ] aware
- [ ] can
- [ ] security
- [ ] award
- [ ] ready
- [ ] alarm
- [ ] weed
- [ ] herb

# Chapter 117

- [ ] unconscious
- [ ] rainfall
- [ ] cost
- [ ] will
- [ ] satisfy
- [ ] smoke
- [ ] match
- [ ] arbitrary
- [ ] cuisine
- [ ] fault
- [ ] follow
- [ ] passive
- [ ] hard-working
- [ ] carrier
- [ ] dignity
- [ ] challenge
- [ ] category
- [ ] cosy
- [ ] intend
- [ ] wild

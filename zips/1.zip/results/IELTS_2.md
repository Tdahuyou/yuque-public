
# Chapter 001

- [ ] abandon
- [ ] abbreviation
- [ ] abnormal
- [ ] abolish
- [ ] aboriginal
- [ ] abort
- [ ] abortion
- [ ] abound
- [ ] abrasion
- [ ] abridge
- [ ] abrupt
- [ ] absorb
- [ ] abstract
- [ ] absurd
- [ ] abundance
- [ ] abuse
- [ ] academic
- [ ] accelerate
- [ ] access
- [ ] accessory

# Chapter 002

- [ ] air
- [ ] airing
- [ ] aisle
- [ ] alarm
- [ ] album
- [ ] alien
- [ ] alienate
- [ ] all
- [ ] apparent
- [ ] appeal
- [ ] appendix
- [ ] appetite
- [ ] applaud
- [ ] appliance
- [ ] applicant
- [ ] apply
- [ ] appointment
- [ ] appraisal
- [ ] appreciable
- [ ] appreciate

# Chapter 003

- [ ] apprehension
- [ ] apprentice
- [ ] approach
- [ ] appropriate
- [ ] approval
- [ ] approximate
- [ ] apt
- [ ] aptitude
- [ ] attractive
- [ ] attribute
- [ ] auction
- [ ] audible
- [ ] audience
- [ ] audit
- [ ] audition
- [ ] auditorium
- [ ] augment
- [ ] aupair
- [ ] authentic
- [ ] authoritative

# Chapter 004

- [ ] authority
- [ ] authorize
- [ ] automatic
- [ ] automation
- [ ] automobile
- [ ] autonomy
- [ ] auxiliary
- [ ] avail
- [ ] available
- [ ] censor
- [ ] census
- [ ] centenary
- [ ] ceramic
- [ ] cereal
- [ ] ceremony
- [ ] certainty
- [ ] certificate
- [ ] certify
- [ ] challenge
- [ ] chamber

# Chapter 005

- [ ] champagne
- [ ] champion
- [ ] chant
- [ ] chaos
- [ ] chapel
- [ ] characteristic
- [ ] characterize
- [ ] charge
- [ ] charity
- [ ] charm
- [ ] clumsy
- [ ] cluster
- [ ] clutch
- [ ] coach
- [ ] coalition
- [ ] coarse
- [ ] cocaine
- [ ] code
- [ ] coed
- [ ] coeducation

# Chapter 006

- [ ] coerce
- [ ] cognitive
- [ ] coherent
- [ ] coil
- [ ] coin
- [ ] coincide
- [ ] coincidence
- [ ] collaboration
- [ ] collapse
- [ ] collide
- [ ] collision
- [ ] compliance
- [ ] complicated
- [ ] complication
- [ ] compliment
- [ ] comply
- [ ] component
- [ ] compose
- [ ] composite
- [ ] compound

# Chapter 007

- [ ] compress
- [ ] comprise
- [ ] compromise
- [ ] compulsory
- [ ] compute
- [ ] conceal
- [ ] concede
- [ ] conceive
- [ ] concentrate
- [ ] conception
- [ ] concern
- [ ] concerted
- [ ] contemplate
- [ ] contemporary
- [ ] contempt
- [ ] contend
- [ ] content
- [ ] contention
- [ ] contest
- [ ] context

# Chapter 008

- [ ] contingency
- [ ] continuity
- [ ] contract
- [ ] contradict
- [ ] contradiction
- [ ] contrast
- [ ] contribute
- [ ] contribution
- [ ] contrive
- [ ] controversy
- [ ] controversial
- [ ] convene
- [ ] convenience
- [ ] crooked
- [ ] crouch
- [ ] crown
- [ ] crucial
- [ ] crude
- [ ] cruise
- [ ] crumb

# Chapter 009

- [ ] crumble
- [ ] crumple
- [ ] crush
- [ ] crust
- [ ] crystal
- [ ] cube
- [ ] cucumber
- [ ] cue
- [ ] culminate
- [ ] cultivate
- [ ] culture
- [ ] cumbersome
- [ ] cumulative
- [ ] deduct
- [ ] deem
- [ ] default
- [ ] defeat
- [ ] defect
- [ ] defence
- [ ] defendant

# Chapter 010

- [ ] defer
- [ ] defiance
- [ ] deficiency
- [ ] deficit
- [ ] defile
- [ ] definite
- [ ] definitive
- [ ] deflate
- [ ] deflect
- [ ] defraud
- [ ] deft
- [ ] defy
- [ ] degenerate
- [ ] degrade
- [ ] deviate
- [ ] devise
- [ ] devote
- [ ] devour
- [ ] diagnose
- [ ] diagram

# Chapter 011

- [ ] dentist
- [ ] deny
- [ ] desirable
- [ ] desolate
- [ ] devastate
- [ ] devastating
- [ ] dial
- [ ] dialect
- [ ] diameter
- [ ] dictate
- [ ] diet
- [ ] differ
- [ ] differentiate
- [ ] diffuse
- [ ] dividend
- [ ] divine
- [ ] dizzy
- [ ] dock
- [ ] doctrine
- [ ] dodge

# Chapter 012

- [ ] dole
- [ ] domain
- [ ] dome
- [ ] domestic
- [ ] dominant
- [ ] dominate
- [ ] donation
- [ ] doom
- [ ] dormant
- [ ] dose
- [ ] dot
- [ ] doubtful
- [ ] doubtless
- [ ] elevator
- [ ] elicit
- [ ] eligible
- [ ] eliminate
- [ ] elite
- [ ] eloquent
- [ ] elsewhere

# Chapter 013

- [ ] embargo
- [ ] embark
- [ ] embarrass
- [ ] embassy
- [ ] embed
- [ ] embody
- [ ] embrace
- [ ] emerge
- [ ] emergency
- [ ] emigrate
- [ ] eminent
- [ ] emit
- [ ] emotion
- [ ] emphasize
- [ ] empirical
- [ ] employment
- [ ] essay
- [ ] essence
- [ ] essential
- [ ] establish

# Chapter 014

- [ ] estate
- [ ] esteem
- [ ] estimate
- [ ] eternal
- [ ] ethnic
- [ ] etiquette
- [ ] evacuate
- [ ] evade
- [ ] evaluate
- [ ] evaporate
- [ ] even
- [ ] eventually
- [ ] everlasting
- [ ] evict
- [ ] evoke
- [ ] evolution
- [ ] exacerbate
- [ ] exaggerate
- [ ] exasperate
- [ ] facet

# Chapter 015

- [ ] facilitate
- [ ] facility
- [ ] factor
- [ ] faculty
- [ ] fade
- [ ] fahrenheit
- [ ] faint
- [ ] faith
- [ ] fake
- [ ] fall
- [ ] fallacy
- [ ] fallible
- [ ] flash
- [ ] flask
- [ ] flatter
- [ ] flaunt
- [ ] flavour
- [ ] flaw
- [ ] flee
- [ ] fleet

# Chapter 016

- [ ] fleeting
- [ ] flesh
- [ ] flexible
- [ ] flicker
- [ ] fling
- [ ] flip
- [ ] flirt
- [ ] float
- [ ] flock
- [ ] flour
- [ ] flourish
- [ ] flu
- [ ] fluctuate
- [ ] fluent
- [ ] fluff
- [ ] gale
- [ ] gallery
- [ ] gamble
- [ ] gang
- [ ] gaol

# Chapter 017

- [ ] jail
- [ ] gape
- [ ] garbage
- [ ] garment
- [ ] gasp
- [ ] gaudy
- [ ] gauge
- [ ] gaunt
- [ ] gear
- [ ] gene
- [ ] generalize
- [ ] generate
- [ ] generic
- [ ] generous
- [ ] genetic
- [ ] genial
- [ ] genius
- [ ] gentle
- [ ] go
- [ ] goad

# Chapter 018

- [ ] goal
- [ ] good
- [ ] haphazard
- [ ] harass
- [ ] harassment
- [ ] harbour
- [ ] hard
- [ ] hardware
- [ ] hardy
- [ ] harmony
- [ ] harness
- [ ] harsh
- [ ] haste
- [ ] hasty
- [ ] hatch
- [ ] haul
- [ ] haunt
- [ ] haven
- [ ] havoc
- [ ] hawk

# Chapter 019

- [ ] hazard
- [ ] hazardous
- [ ] hubbub
- [ ] huddle
- [ ] hug
- [ ] hum
- [ ] humanity
- [ ] humble
- [ ] humdrum
- [ ] humidity
- [ ] humiliate
- [ ] hurl
- [ ] hurricane
- [ ] hydrogen
- [ ] hygiene
- [ ] hypothesis
- [ ] hysterical
- [ ] ideal
- [ ] identical
- [ ] identify

# Chapter 020

- [ ] identification
- [ ] identity
- [ ] ideology
- [ ] idiom
- [ ] idiot
- [ ] inflation
- [ ] inflict
- [ ] influence
- [ ] influx
- [ ] infringe
- [ ] ingenious
- [ ] ingredient
- [ ] inhabit
- [ ] inhabitant
- [ ] inherent
- [ ] inherit
- [ ] inhibit
- [ ] initial
- [ ] initiate
- [ ] initiative

# Chapter 021

- [ ] inject
- [ ] inland
- [ ] innocent
- [ ] innovation
- [ ] innumerable
- [ ] inquire
- [ ] insane
- [ ] insert
- [ ] jam
- [ ] janitor
- [ ] jealous
- [ ] jeer
- [ ] jeopardize
- [ ] jerk
- [ ] jog
- [ ] jolt
- [ ] journal
- [ ] journalist
- [ ] judicial
- [ ] jumble

# Chapter 022

- [ ] junction
- [ ] jungle
- [ ] junior
- [ ] junk
- [ ] jury
- [ ] justify
- [ ] justification
- [ ] juvenile
- [ ] keen
- [ ] keep
- [ ] legislation
- [ ] legitimate
- [ ] lenient
- [ ] lens
- [ ] let
- [ ] lethal
- [ ] lever
- [ ] levy
- [ ] liability
- [ ] liable

# Chapter 023

- [ ] liaison
- [ ] liberal
- [ ] licence
- [ ] lick
- [ ] light
- [ ] likelihood
- [ ] lump
- [ ] lunar
- [ ] lure
- [ ] lurk
- [ ] luxury
- [ ] mackintosh
- [ ] madden
- [ ] magistrate
- [ ] magnanimous
- [ ] magnate
- [ ] magnetic
- [ ] magnificent
- [ ] magnify
- [ ] magnitude

# Chapter 024

- [ ] maiden
- [ ] maim
- [ ] main
- [ ] maintain
- [ ] maintenance
- [ ] maize
- [ ] majestic
- [ ] majority
- [ ] medal
- [ ] meddle
- [ ] mediate
- [ ] medieval
- [ ] mediocre
- [ ] meditate
- [ ] medium
- [ ] meek
- [ ] melancholy
- [ ] melodious
- [ ] melody
- [ ] memorandum

# Chapter 025

- [ ] menace
- [ ] mentality
- [ ] mercantile
- [ ] mercenary
- [ ] mercy
- [ ] merge
- [ ] merit
- [ ] mesh
- [ ] mess
- [ ] monopoly
- [ ] monetary
- [ ] monotonous
- [ ] monsoon
- [ ] monster
- [ ] monstrous
- [ ] moped
- [ ] morality
- [ ] morbid
- [ ] moreover
- [ ] mortal

# Chapter 026

- [ ] mortgage
- [ ] mosaic
- [ ] most
- [ ] motel
- [ ] motif
- [ ] motion
- [ ] motivate
- [ ] motto
- [ ] mould
- [ ] mount
- [ ] notion
- [ ] notorious
- [ ] naught
- [ ] nourish
- [ ] nourishment
- [ ] novel
- [ ] novelty
- [ ] novice
- [ ] nowhere
- [ ] noxious

# Chapter 027

- [ ] nuance
- [ ] nucleus
- [ ] nuisance
- [ ] null
- [ ] nullify
- [ ] numb
- [ ] numerate
- [ ] numerical
- [ ] numerous
- [ ] nursery
- [ ] onlooker
- [ ] onset
- [ ] opaque
- [ ] opening
- [ ] opinion
- [ ] opponent
- [ ] opportunity
- [ ] oppose
- [ ] as
- [ ] opposite

# Chapter 028

- [ ] oppress
- [ ] opt
- [ ] optical
- [ ] optimism
- [ ] optimum
- [ ] option
- [ ] optional
- [ ] orbit
- [ ] orchard
- [ ] orchestra
- [ ] ordeal
- [ ] orderly
- [ ] ore
- [ ] palpitate
- [ ] pamper
- [ ] pamphlet
- [ ] panel
- [ ] panic
- [ ] panorama
- [ ] pant

# Chapter 029

- [ ] pants
- [ ] parachute
- [ ] parade
- [ ] paradise
- [ ] paradox
- [ ] parallel
- [ ] paralyse
- [ ] paramount
- [ ] paralysis
- [ ] paranoia
- [ ] paraphernalia
- [ ] paraphrase
- [ ] parasite
- [ ] parliament
- [ ] parody
- [ ] part
- [ ] permissible
- [ ] permit
- [ ] perpendicular
- [ ] perpetual

# Chapter 030

- [ ] perplex
- [ ] perplexity
- [ ] persecute
- [ ] persevere
- [ ] persist
- [ ] personal
- [ ] personality
- [ ] personnel
- [ ] perspective
- [ ] perspire
- [ ] pertain
- [ ] pertinent
- [ ] perturb
- [ ] pervade
- [ ] perverse
- [ ] pervert
- [ ] pessimism
- [ ] plight
- [ ] plot
- [ ] plough

# Chapter 031

- [ ] plug
- [ ] plumb
- [ ] plummet
- [ ] plunder
- [ ] plunge
- [ ] plus
- [ ] pointed
- [ ] pointless
- [ ] poise
- [ ] poke
- [ ] polar
- [ ] pole
- [ ] policy
- [ ] polish
- [ ] politic
- [ ] pollinate
- [ ] pompous
- [ ] ponder
- [ ] ponderous
- [ ] porcelain

# Chapter 032

- [ ] prey
- [ ] primary
- [ ] prime
- [ ] primitive
- [ ] principal
- [ ] prior
- [ ] priority
- [ ] privacy
- [ ] privilege
- [ ] probation
- [ ] probe
- [ ] procedure
- [ ] proceed
- [ ] proceeding
- [ ] proclaim
- [ ] procure
- [ ] prodigious
- [ ] productive
- [ ] productivity
- [ ] profane

# Chapter 033

- [ ] professional
- [ ] proficiency
- [ ] profile
- [ ] puzzle
- [ ] quaint
- [ ] qualification
- [ ] qualify
- [ ] qualitative
- [ ] quantitative
- [ ] quarry
- [ ] quarterly
- [ ] queer
- [ ] quench
- [ ] quest
- [ ] questionnaire
- [ ] regarding
- [ ] regeneration
- [ ] regime
- [ ] register
- [ ] registrar

# Chapter 034

- [ ] regulate
- [ ] rehabilitate
- [ ] reign
- [ ] reimburse
- [ ] reinforce
- [ ] rejoice
- [ ] relapse
- [ ] relay
- [ ] release
- [ ] relentless
- [ ] relevant
- [ ] reliable
- [ ] relief
- [ ] relinguish
- [ ] reluctant
- [ ] rely
- [ ] remarkable
- [ ] remedy
- [ ] rigid
- [ ] rigorous

# Chapter 035

- [ ] rim
- [ ] riot
- [ ] rip
- [ ] ripple
- [ ] ritual
- [ ] rival
- [ ] rivet
- [ ] roam
- [ ] roar
- [ ] roast
- [ ] robust
- [ ] role
- [ ] roll
- [ ] rot
- [ ] rotate
- [ ] rough
- [ ] rouse
- [ ] routine
- [ ] rub
- [ ] ruffle

# Chapter 036

- [ ] ruinous
- [ ] section
- [ ] sectional
- [ ] sector
- [ ] secular
- [ ] sediment
- [ ] seemingly
- [ ] seep
- [ ] segment
- [ ] segregate
- [ ] seismic
- [ ] semblance
- [ ] sensible
- [ ] sensitive
- [ ] sentiment
- [ ] septic
- [ ] sequence
- [ ] series
- [ ] session
- [ ] set

# Chapter 037

- [ ] skim
- [ ] skip
- [ ] slab
- [ ] slack
- [ ] slag
- [ ] slam
- [ ] slander
- [ ] slap
- [ ] slate
- [ ] slaughter
- [ ] slender
- [ ] slice
- [ ] slide
- [ ] slight
- [ ] slippery
- [ ] slim
- [ ] slip
- [ ] slit
- [ ] slogan
- [ ] slope

# Chapter 038

- [ ] slot
- [ ] sluggish
- [ ] slum
- [ ] sporadic
- [ ] spotlight
- [ ] spouse
- [ ] sprawl
- [ ] spray
- [ ] spring
- [ ] sprint
- [ ] sprout
- [ ] spur
- [ ] square
- [ ] squeeze
- [ ] stabilize
- [ ] stack
- [ ] stadium
- [ ] staff
- [ ] stagger
- [ ] stagnant

# Chapter 039

- [ ] stain
- [ ] stake
- [ ] stale
- [ ] stall
- [ ] stand
- [ ] stroke
- [ ] structural
- [ ] stubborn
- [ ] studio
- [ ] stuff
- [ ] stuffing
- [ ] stumble
- [ ] stuntman
- [ ] sturdy
- [ ] style
- [ ] subdue
- [ ] subject
- [ ] subjective
- [ ] submarine
- [ ] submerge

# Chapter 040

- [ ] submit
- [ ] subordinate
- [ ] subscribe
- [ ] subsequent
- [ ] subside
- [ ] subsidiary
- [ ] subsidy
- [ ] symposium
- [ ] symptom
- [ ] synchronize
- [ ] synonym
- [ ] synthesis
- [ ] synthetic
- [ ] systematic
- [ ] tablet
- [ ] taboo
- [ ] tacit
- [ ] tackle
- [ ] tactic
- [ ] tag

# Chapter 041

- [ ] take
- [ ] thermal
- [ ] thermometer
- [ ] thermostat
- [ ] thesaurus
- [ ] thesis
- [ ] thigh
- [ ] thirst
- [ ] thorn
- [ ] thorough
- [ ] thoughtful
- [ ] threshold
- [ ] thrill
- [ ] thrive
- [ ] throat
- [ ] throbbing
- [ ] throng
- [ ] throughout
- [ ] thrust
- [ ] thumb

# Chapter 042

- [ ] thunder
- [ ] tick
- [ ] tide
- [ ] translucent
- [ ] transmission
- [ ] transparent
- [ ] transplant
- [ ] transport
- [ ] trap
- [ ] trauma
- [ ] traverse
- [ ] treatise
- [ ] treatment
- [ ] treaty
- [ ] treble
- [ ] trek
- [ ] tremble
- [ ] tremendous
- [ ] trench
- [ ] trend

# Chapter 043

- [ ] trespass
- [ ] trial
- [ ] triangle
- [ ] tributary
- [ ] trick
- [ ] trickle
- [ ] unravel
- [ ] unrest
- [ ] untold
- [ ] upbringing
- [ ] update
- [ ] uphold
- [ ] upkeep
- [ ] upright
- [ ] uprising
- [ ] upset
- [ ] utility
- [ ] utmost
- [ ] utterly
- [ ] vacant

# Chapter 044

- [ ] vacation
- [ ] vacuum
- [ ] vain
- [ ] validity
- [ ] valuation
- [ ] valley
- [ ] valve
- [ ] wail
- [ ] wander
- [ ] wane
- [ ] ward
- [ ] warden
- [ ] wardrobe
- [ ] warehouse
- [ ] warranty
- [ ] wary
- [ ] waver
- [ ] wax
- [ ] weary
- [ ] weave

# Chapter 045

- [ ] web
- [ ] wedge
- [ ] weed
- [ ] weird
- [ ] weld
- [ ] welfare
- [ ] whatever
- [ ] whereas
- [ ] accord
- [ ] account
- [ ] accountable
- [ ] accountant
- [ ] accumulate
- [ ] accuse
- [ ] achieve
- [ ] acid
- [ ] acknowledge
- [ ] acquaint
- [ ] acquire
- [ ] acquisition

# Chapter 046

- [ ] activate
- [ ] allege
- [ ] allegiance
- [ ] alleviate
- [ ] alliance
- [ ] allocate
- [ ] allot
- [ ] allowance
- [ ] alloy
- [ ] ally
- [ ] alone
- [ ] alongside
- [ ] alphabetical
- [ ] alter
- [ ] alternate
- [ ] alternative
- [ ] altitude
- [ ] amateur
- [ ] amaze
- [ ] aquarium

# Chapter 047

- [ ] aquatic
- [ ] arbitrary
- [ ] arc
- [ ] arch
- [ ] archaic
- [ ] architect
- [ ] archives
- [ ] arctic
- [ ] ardent
- [ ] arduous
- [ ] arena
- [ ] argue
- [ ] arise
- [ ] armour
- [ ] arouse
- [ ] array
- [ ] arrogant
- [ ] artery
- [ ] artillery
- [ ] article

# Chapter 048

- [ ] avalanche
- [ ] avert
- [ ] aviation
- [ ] avoid
- [ ] aware
- [ ] awful
- [ ] awkward
- [ ] axis
- [ ] candidate
- [ ] cane
- [ ] cannon
- [ ] canteen
- [ ] canvas
- [ ] capacity
- [ ] cape
- [ ] capital
- [ ] capsule
- [ ] caption
- [ ] captive
- [ ] capture

# Chapter 049

- [ ] cardinal
- [ ] chart
- [ ] charter
- [ ] chase
- [ ] chasm
- [ ] chaste
- [ ] chat
- [ ] check
- [ ] checkup
- [ ] cheer
- [ ] cherish
- [ ] chew
- [ ] chic
- [ ] chief
- [ ] chill
- [ ] chin
- [ ] chip
- [ ] chisel
- [ ] choir
- [ ] choke

# Chapter 050

- [ ] colonial
- [ ] colony
- [ ] colossal
- [ ] column
- [ ] combat
- [ ] combine
- [ ] combustible
- [ ] come
- [ ] concession
- [ ] concise
- [ ] concoct
- [ ] concrete
- [ ] condemn
- [ ] condense
- [ ] condition
- [ ] condolence
- [ ] conducive
- [ ] confer
- [ ] confess
- [ ] confidence

# Chapter 051

- [ ] confident
- [ ] confidential
- [ ] configuration
- [ ] confine
- [ ] confirm
- [ ] conflict
- [ ] conform
- [ ] confront
- [ ] convention
- [ ] converge
- [ ] conversely
- [ ] conversion
- [ ] convert
- [ ] convey
- [ ] convict
- [ ] conviction
- [ ] convince
- [ ] cooperate
- [ ] coordinate
- [ ] cordial

# Chapter 052

- [ ] cork
- [ ] corporate
- [ ] corporation
- [ ] corpse
- [ ] corps
- [ ] correlate
- [ ] correspond
- [ ] correspondence
- [ ] correspondent
- [ ] cunning
- [ ] cupboard
- [ ] curb
- [ ] cure
- [ ] curl
- [ ] currency
- [ ] current
- [ ] curriculum
- [ ] curse
- [ ] curtail
- [ ] curve

# Chapter 053

- [ ] cushion
- [ ] custodian
- [ ] custom
- [ ] customary
- [ ] cut
- [ ] cute
- [ ] delectable
- [ ] delegate
- [ ] delete
- [ ] deliberate
- [ ] delicate
- [ ] delicious
- [ ] delinquency
- [ ] delirium
- [ ] deliver
- [ ] delude
- [ ] deluge
- [ ] democracy
- [ ] demolish
- [ ] demonstrate

# Chapter 054

- [ ] denial
- [ ] denomination
- [ ] denote
- [ ] denounce
- [ ] dense
- [ ] digest
- [ ] digital
- [ ] dignity
- [ ] dilapidated
- [ ] dilate
- [ ] dilemma
- [ ] diligent
- [ ] dilute
- [ ] dim
- [ ] dimension
- [ ] diminish
- [ ] din
- [ ] dine
- [ ] dingy
- [ ] dip

# Chapter 055

- [ ] diploma
- [ ] diplomat
- [ ] diplomatic
- [ ] directory
- [ ] disable
- [ ] disarray
- [ ] disaster
- [ ] disc
- [ ] downpour
- [ ] downtown
- [ ] doze
- [ ] draft
- [ ] drain
- [ ] drainage
- [ ] dramatic
- [ ] drastic
- [ ] drawback
- [ ] dread
- [ ] dreadful
- [ ] dreary

# Chapter 056

- [ ] drench
- [ ] drift
- [ ] drill
- [ ] drought
- [ ] drown
- [ ] drowse
- [ ] drudgery
- [ ] dual
- [ ] dub
- [ ] dubious
- [ ] due
- [ ] enclose
- [ ] enclosure
- [ ] encounter
- [ ] encyclopedia
- [ ] end
- [ ] endeavor
- [ ] endorse
- [ ] endow
- [ ] endurance

# Chapter 057

- [ ] energetic
- [ ] enforce
- [ ] engage
- [ ] engagement
- [ ] engrave
- [ ] engross
- [ ] enhance
- [ ] enlighten
- [ ] excavate
- [ ] exceed
- [ ] exceedingly
- [ ] excel
- [ ] exceptional
- [ ] excerpt
- [ ] excess
- [ ] exchange
- [ ] exclaim
- [ ] exclude
- [ ] exclusive
- [ ] exclusively

# Chapter 058

- [ ] excrement
- [ ] excursion
- [ ] execute
- [ ] execution
- [ ] executive
- [ ] exemplify
- [ ] exempt
- [ ] exert
- [ ] exhaust
- [ ] exhilarate
- [ ] exhort
- [ ] falter
- [ ] fame
- [ ] familiar
- [ ] famine
- [ ] fanatic
- [ ] fancy
- [ ] fantastic
- [ ] fantasy
- [ ] fare

# Chapter 059

- [ ] farewell
- [ ] fascinate
- [ ] fascinating
- [ ] fastidious
- [ ] fatal
- [ ] fatigue
- [ ] fatuous
- [ ] fault
- [ ] favour
- [ ] in
- [ ] fluid
- [ ] flush
- [ ] flutter
- [ ] flux
- [ ] flyover
- [ ] foam
- [ ] focus
- [ ] foil
- [ ] forecast
- [ ] foremost

# Chapter 060

- [ ] forerunner
- [ ] foresee
- [ ] forfeit
- [ ] forge
- [ ] forgive
- [ ] format
- [ ] formidable
- [ ] formula
- [ ] formulate
- [ ] fort
- [ ] forte
- [ ] forthcoming
- [ ] genuine
- [ ] geology
- [ ] geometry
- [ ] germ
- [ ] gesture
- [ ] get
- [ ] gorgeous
- [ ] gossip

# Chapter 061

- [ ] gown
- [ ] grab
- [ ] grace
- [ ] gracious
- [ ] gradual
- [ ] granary
- [ ] grand
- [ ] grant
- [ ] granular
- [ ] graph
- [ ] graphic
- [ ] grate
- [ ] gratitude
- [ ] gratuity
- [ ] grave
- [ ] gravel
- [ ] gravity
- [ ] graze
- [ ] headstrong
- [ ] heal

# Chapter 062

- [ ] heap
- [ ] hearing
- [ ] heart
- [ ] heave
- [ ] hectic
- [ ] hedge
- [ ] heighten
- [ ] heir
- [ ] helicopter
- [ ] hell
- [ ] hemisphere
- [ ] hence
- [ ] henceforth
- [ ] herb
- [ ] herd
- [ ] idle
- [ ] ignite
- [ ] ignorance
- [ ] illiterate
- [ ] illuminate

# Chapter 063

- [ ] illusion
- [ ] illustrate
- [ ] imaginative
- [ ] imitate
- [ ] imitation
- [ ] immense
- [ ] immerse
- [ ] immigrant
- [ ] imminent
- [ ] immune
- [ ] impact
- [ ] impair
- [ ] impart
- [ ] impede
- [ ] imperative
- [ ] imperial
- [ ] impetus
- [ ] implement
- [ ] insight
- [ ] insipid

# Chapter 064

- [ ] insolent
- [ ] insolvent
- [ ] inspection
- [ ] inspiration
- [ ] inspire
- [ ] inspiring
- [ ] install
- [ ] instalment
- [ ] instantaneous
- [ ] instinct
- [ ] instrument
- [ ] instrumental
- [ ] insulate
- [ ] insult
- [ ] insurance
- [ ] insure
- [ ] intact
- [ ] integral
- [ ] integrate
- [ ] integrity

# Chapter 065

- [ ] intellect
- [ ] kernel
- [ ] kidnap
- [ ] kidney
- [ ] kin
- [ ] kindle
- [ ] kit
- [ ] knit
- [ ] knob
- [ ] likewise
- [ ] limb
- [ ] limp
- [ ] line
- [ ] out
- [ ] linear
- [ ] linen
- [ ] liner
- [ ] linger
- [ ] liquor
- [ ] literacy

# Chapter 066

- [ ] literally
- [ ] literature
- [ ] litter
- [ ] live
- [ ] make
- [ ] making
- [ ] malice
- [ ] malignant
- [ ] mall
- [ ] malleable
- [ ] malnutrition
- [ ] maltreat
- [ ] metabolism
- [ ] metallic
- [ ] metaphor
- [ ] meteoric
- [ ] meteorology
- [ ] meticulous
- [ ] metric
- [ ] metropolitan

# Chapter 067

- [ ] microbe
- [ ] microcosm
- [ ] microfilm
- [ ] might
- [ ] mighty
- [ ] migrate
- [ ] mildew
- [ ] militant
- [ ] millennium
- [ ] mimic
- [ ] mind
- [ ] mourn
- [ ] moustache
- [ ] mucous
- [ ] muddle
- [ ] multilateral
- [ ] multiply
- [ ] multitude
- [ ] mundane
- [ ] municipal

# Chapter 068

- [ ] murmur
- [ ] muscular
- [ ] mushroom
- [ ] muster
- [ ] mutation
- [ ] mutter
- [ ] mutual
- [ ] myriad
- [ ] myth
- [ ] mythology
- [ ] native
- [ ] naked
- [ ] namely
- [ ] nurture
- [ ] nutrition
- [ ] nylon
- [ ] oar
- [ ] oasis
- [ ] oath
- [ ] obedient

# Chapter 069

- [ ] object
- [ ] objection
- [ ] objective
- [ ] oblong
- [ ] obligation
- [ ] obligatory
- [ ] oblige
- [ ] obliging
- [ ] oblique
- [ ] oblivious
- [ ] obnoxious
- [ ] obscene
- [ ] obscure
- [ ] observance
- [ ] observatory
- [ ] observe
- [ ] organ
- [ ] organism
- [ ] oriental
- [ ] orientate

# Chapter 070

- [ ] origin
- [ ] original
- [ ] originate
- [ ] ornament
- [ ] orthodox
- [ ] oscillate
- [ ] ostensible
- [ ] ostentation
- [ ] otherwise
- [ ] oust
- [ ] outbreak
- [ ] outcast
- [ ] outcome
- [ ] outcry
- [ ] outdated
- [ ] outdo
- [ ] outfit
- [ ] outlaw
- [ ] partial
- [ ] participate

# Chapter 071

- [ ] particle
- [ ] partisan
- [ ] partition
- [ ] pass
- [ ] passion
- [ ] passive
- [ ] passport
- [ ] pastime
- [ ] pesticide
- [ ] pester
- [ ] petal
- [ ] petition
- [ ] petroleum
- [ ] petty
- [ ] pharmaceutical
- [ ] pharmacy
- [ ] phase
- [ ] phenomenal
- [ ] phenomenon
- [ ] phobia

# Chapter 072

- [ ] phonetic
- [ ] physician
- [ ] physiological
- [ ] physique
- [ ] pick
- [ ] porch
- [ ] pore
- [ ] porous
- [ ] port
- [ ] portable
- [ ] portfolio
- [ ] portion
- [ ] portray
- [ ] pose
- [ ] positive
- [ ] possession
- [ ] postage
- [ ] poster
- [ ] posterity
- [ ] postgraduate

# Chapter 073

- [ ] posthumous
- [ ] postmortem
- [ ] postpone
- [ ] postscript
- [ ] posture
- [ ] potent
- [ ] potential
- [ ] potion
- [ ] profit
- [ ] profound
- [ ] profuse
- [ ] prohibit
- [ ] project
- [ ] prolific
- [ ] prologue
- [ ] prolong
- [ ] prominent
- [ ] promise
- [ ] promising
- [ ] promote

# Chapter 074

- [ ] prompt
- [ ] prone
- [ ] propaganda
- [ ] propagate
- [ ] propel
- [ ] property
- [ ] prophecy
- [ ] proportion
- [ ] propose
- [ ] proposition
- [ ] propriety
- [ ] quit
- [ ] quiver
- [ ] quota
- [ ] rack
- [ ] racket
- [ ] radar
- [ ] radiate
- [ ] radical
- [ ] radius

# Chapter 075

- [ ] raft
- [ ] rage
- [ ] ragged
- [ ] raid
- [ ] rail
- [ ] rally
- [ ] ramble
- [ ] rampant
- [ ] random
- [ ] range
- [ ] ransom
- [ ] rarely
- [ ] ratio
- [ ] rational
- [ ] remind
- [ ] remittance
- [ ] remnant
- [ ] remorse
- [ ] renaissance
- [ ] render

# Chapter 076

- [ ] rendezvous
- [ ] renovation
- [ ] renowned
- [ ] repel
- [ ] repatriate
- [ ] repent
- [ ] repertoire
- [ ] repetition
- [ ] represent
- [ ] reproach
- [ ] reptile
- [ ] reputation
- [ ] request
- [ ] rescue
- [ ] resemblance
- [ ] resemble
- [ ] rumour
- [ ] rupture
- [ ] rural
- [ ] rust

# Chapter 077

- [ ] ruthless
- [ ] sabotage
- [ ] sack
- [ ] sacred
- [ ] sacrifice
- [ ] saddle
- [ ] safeguard
- [ ] sake
- [ ] saline
- [ ] salute
- [ ] salvage
- [ ] sanction
- [ ] sanitary
- [ ] sanity
- [ ] sarcasm
- [ ] saturate
- [ ] sauce
- [ ] savage
- [ ] setting
- [ ] settle

# Chapter 078

- [ ] severe
- [ ] sewer
- [ ] shabby
- [ ] shaft
- [ ] shallow
- [ ] shamble
- [ ] shanty
- [ ] shatter
- [ ] smart
- [ ] smash
- [ ] smooth
- [ ] smother
- [ ] smuggle
- [ ] snack
- [ ] snap
- [ ] snatch
- [ ] soak
- [ ] soar
- [ ] sober
- [ ] sociable

# Chapter 079

- [ ] sociology
- [ ] soil
- [ ] solar
- [ ] sole
- [ ] solemn
- [ ] solidarity
- [ ] solitary
- [ ] solo
- [ ] standard
- [ ] standing
- [ ] staple
- [ ] starch
- [ ] startle
- [ ] starve
- [ ] statesman
- [ ] static
- [ ] stationary
- [ ] stationery
- [ ] statistics
- [ ] statue

# Chapter 080

- [ ] status
- [ ] statute
- [ ] steadfast
- [ ] steady
- [ ] substantial
- [ ] substantiate
- [ ] substitute
- [ ] subtitle
- [ ] subtle
- [ ] subtract
- [ ] succession
- [ ] succinct
- [ ] succumb
- [ ] suck
- [ ] sue
- [ ] sufficient
- [ ] suicide
- [ ] suitcase
- [ ] suite
- [ ] sulphur

# Chapter 081

- [ ] summary
- [ ] summit
- [ ] summon
- [ ] superb
- [ ] superficial
- [ ] superfluous
- [ ] superintend
- [ ] talented
- [ ] tame
- [ ] tamper
- [ ] tangible
- [ ] tangle
- [ ] tap
- [ ] tar
- [ ] target
- [ ] tariff
- [ ] tarnish
- [ ] taxation
- [ ] tear
- [ ] tease

# Chapter 082

- [ ] tidy
- [ ] tighten
- [ ] tile
- [ ] tilt
- [ ] timber
- [ ] time
- [ ] timely
- [ ] timidity
- [ ] tinge
- [ ] trifle
- [ ] trigger
- [ ] trim
- [ ] triple
- [ ] triumph
- [ ] trivial
- [ ] tropic
- [ ] troupe
- [ ] truant
- [ ] truce
- [ ] trumpet

# Chapter 083

- [ ] trunk
- [ ] trustworthy
- [ ] tube
- [ ] tuck
- [ ] tug
- [ ] tuition
- [ ] tumble
- [ ] tumour
- [ ] tumult
- [ ] tune
- [ ] vanish
- [ ] vanity
- [ ] vanquish
- [ ] variable
- [ ] variant
- [ ] variation
- [ ] varied
- [ ] variety
- [ ] vary
- [ ] vegetarian

# Chapter 084

- [ ] vegetation
- [ ] vehement
- [ ] vehicle
- [ ] veil
- [ ] vein
- [ ] velocity
- [ ] venerate
- [ ] vengeance
- [ ] vent
- [ ] ventilate
- [ ] venture
- [ ] verbal
- [ ] verdict
- [ ] whereby
- [ ] whilst
- [ ] whip
- [ ] whirl
- [ ] whistle
- [ ] wholesale
- [ ] wholesome

# Chapter 085

- [ ] wicked
- [ ] width
- [ ] wield
- [ ] wilderness
- [ ] wisdom
- [ ] wit
- [ ] withdraw
- [ ] wither
- [ ] withhold
- [ ] withstand
- [ ] witness
- [ ] wording
- [ ] worship
- [ ] worthwhile
- [ ] wrap
- [ ] adequate
- [ ] adhere
- [ ] adjacent
- [ ] adjoin
- [ ] adjust

# Chapter 086

- [ ] administer
- [ ] administration
- [ ] admission
- [ ] adolescence
- [ ] adopt
- [ ] adore
- [ ] advent
- [ ] adverse
- [ ] advertise
- [ ] advocate
- [ ] aerial
- [ ] aesthetic
- [ ] affect
- [ ] affection
- [ ] affiliate
- [ ] ambassador
- [ ] ambiguous
- [ ] ambiguity
- [ ] ambition
- [ ] ambitious

# Chapter 087

- [ ] ambulance
- [ ] amend
- [ ] amends
- [ ] amid
- [ ] amidst
- [ ] ammunition
- [ ] amount
- [ ] amphibian
- [ ] ample
- [ ] amplify
- [ ] amuse
- [ ] analogy
- [ ] analytical
- [ ] ancestor
- [ ] anchor
- [ ] anecdote
- [ ] articulate
- [ ] artificial
- [ ] ascend
- [ ] ascent

# Chapter 088

- [ ] ascertain
- [ ] ascribe
- [ ] ashamed
- [ ] aspiration
- [ ] aspire
- [ ] assassination
- [ ] assault
- [ ] assemble
- [ ] assert
- [ ] assess
- [ ] asset
- [ ] carpenter
- [ ] carrier
- [ ] carrot
- [ ] carry
- [ ] cart
- [ ] carton
- [ ] cartoon
- [ ] carve
- [ ] cash

# Chapter 089

- [ ] cashier
- [ ] cassette
- [ ] cast
- [ ] chop
- [ ] chord
- [ ] chore
- [ ] chorus
- [ ] Christian
- [ ] chronic
- [ ] chronological
- [ ] chunk
- [ ] circuit
- [ ] circulate
- [ ] circumference
- [ ] circumstance
- [ ] circus
- [ ] cite
- [ ] civic
- [ ] civilian
- [ ] claim

# Chapter 090

- [ ] clamp
- [ ] clan
- [ ] clarify
- [ ] clarity
- [ ] comedy
- [ ] comet
- [ ] comic
- [ ] commemorate
- [ ] commence
- [ ] commend
- [ ] comment
- [ ] commentary
- [ ] commercial
- [ ] commission
- [ ] commit
- [ ] commitment
- [ ] committee
- [ ] commodity
- [ ] commonplace
- [ ] commonwealth

# Chapter 091

- [ ] confuse
- [ ] confusion
- [ ] congestion
- [ ] congress
- [ ] congruent
- [ ] conjunction
- [ ] conquer
- [ ] conquest
- [ ] conscience
- [ ] conscientious
- [ ] conscious
- [ ] consecutive
- [ ] consensus
- [ ] consent
- [ ] consequence
- [ ] consequent
- [ ] conservation
- [ ] conservative
- [ ] conservatory
- [ ] conserve

# Chapter 092

- [ ] corresponding
- [ ] corrode
- [ ] corrupt
- [ ] cosmic
- [ ] cosmopolitan
- [ ] costume
- [ ] cosy
- [ ] couch
- [ ] council
- [ ] counsel
- [ ] counter
- [ ] counterbalance
- [ ] counterfeit
- [ ] counterpart
- [ ] coupon
- [ ] courier
- [ ] courtesy
- [ ] coverage
- [ ] coward
- [ ] crack

# Chapter 093

- [ ] cradle
- [ ] cutting
- [ ] cylinder
- [ ] cynical
- [ ] dairy
- [ ] dam
- [ ] damp
- [ ] dart
- [ ] dash
- [ ] database
- [ ] date
- [ ] dawn
- [ ] day
- [ ] dazzle
- [ ] deadlock
- [ ] deadly
- [ ] deaf
- [ ] depart
- [ ] depict
- [ ] deplete

# Chapter 094

- [ ] depletion
- [ ] deplore
- [ ] deposit
- [ ] depress
- [ ] depression
- [ ] deprive
- [ ] deputy
- [ ] derelict
- [ ] derive
- [ ] descend
- [ ] descent
- [ ] description
- [ ] desert
- [ ] deserve
- [ ] design
- [ ] designate
- [ ] discard
- [ ] discern
- [ ] discharge
- [ ] discipline

# Chapter 095

- [ ] disclose
- [ ] discord
- [ ] discount
- [ ] discreet
- [ ] discrete
- [ ] discrepancy
- [ ] discriminate
- [ ] disdain
- [ ] disguise
- [ ] disgust
- [ ] dismay
- [ ] dismiss
- [ ] disorder
- [ ] dispatch
- [ ] dispel
- [ ] disperse
- [ ] displace
- [ ] display
- [ ] dispose
- [ ] dull

# Chapter 096

- [ ] duly
- [ ] dumb
- [ ] dump
- [ ] duplicate
- [ ] durable
- [ ] dwarf
- [ ] dwell
- [ ] dwindle
- [ ] dynamic
- [ ] earnest
- [ ] ease
- [ ] Easter
- [ ] eccentric
- [ ] echo
- [ ] eclipse
- [ ] ecology
- [ ] economic
- [ ] economical
- [ ] economics
- [ ] economy

# Chapter 097

- [ ] eddy
- [ ] edge
- [ ] enormous
- [ ] enquire
- [ ] enquiry
- [ ] enrich
- [ ] enroll
- [ ] enrolment
- [ ] ensemble
- [ ] ensue
- [ ] entail
- [ ] entangle
- [ ] enterprise
- [ ] entertainment
- [ ] enthusiasm
- [ ] enthusiastic
- [ ] entitle
- [ ] entity
- [ ] entreat
- [ ] entrepreneur

# Chapter 098

- [ ] entry
- [ ] environment
- [ ] envisage
- [ ] envy
- [ ] enzyme
- [ ] exile
- [ ] exorbitant
- [ ] exotic
- [ ] expand
- [ ] expedient
- [ ] expedition
- [ ] expel
- [ ] expend
- [ ] expenditure
- [ ] expertise
- [ ] expire
- [ ] explicit
- [ ] explode
- [ ] exploit
- [ ] explore

# Chapter 099

- [ ] explosive
- [ ] export
- [ ] expose
- [ ] exposition
- [ ] expulsion
- [ ] exquisite
- [ ] extend
- [ ] extent
- [ ] feasible
- [ ] feast
- [ ] feat
- [ ] feature
- [ ] federation
- [ ] fee
- [ ] feeble
- [ ] feedback
- [ ] feel
- [ ] fellowship
- [ ] female
- [ ] fend

# Chapter 100

- [ ] ferocious
- [ ] ferry
- [ ] fertile
- [ ] fervent
- [ ] fester
- [ ] festival
- [ ] fetch
- [ ] fortify
- [ ] fortnight
- [ ] forum
- [ ] fossil
- [ ] foster
- [ ] foul
- [ ] fountain
- [ ] fraction
- [ ] fracture
- [ ] fragile
- [ ] fragment
- [ ] fragrance
- [ ] frail

# Chapter 101

- [ ] framework
- [ ] frantic
- [ ] fraud
- [ ] fraught
- [ ] freak
- [ ] freight
- [ ] fret
- [ ] friction
- [ ] fridge
- [ ] fringe
- [ ] ghastly
- [ ] gigantic
- [ ] giggle
- [ ] gist
- [ ] give
- [ ] given
- [ ] glacier
- [ ] glamour
- [ ] gland
- [ ] grease

# Chapter 102

- [ ] greedy
- [ ] grid
- [ ] grief
- [ ] grieve
- [ ] grill
- [ ] grim
- [ ] grin
- [ ] grind
- [ ] grip
- [ ] grit
- [ ] groa
- [ ] grope
- [ ] gross
- [ ] growl
- [ ] grudge
- [ ] grumble
- [ ] guarantee
- [ ] guardian
- [ ] guideline
- [ ] guild

# Chapter 103

- [ ] gush
- [ ] gust
- [ ] hereditary
- [ ] heritage
- [ ] hierarchy
- [ ] highlight
- [ ] hijack
- [ ] hike
- [ ] hilarious
- [ ] hinder
- [ ] hinge
- [ ] hint
- [ ] historian
- [ ] historic
- [ ] hit
- [ ] hitchhike
- [ ] hitherto
- [ ] hobby
- [ ] hoist
- [ ] hold

# Chapter 104

- [ ] implicit
- [ ] impose
- [ ] imposing
- [ ] impressive
- [ ] impromptu
- [ ] improvise
- [ ] impulse
- [ ] inapt
- [ ] inaugurate
- [ ] incentive
- [ ] incidence
- [ ] incidentally
- [ ] incipient
- [ ] incite
- [ ] inclination
- [ ] incline
- [ ] inclusive
- [ ] incongruous
- [ ] incorporate
- [ ] incredible

# Chapter 105

- [ ] increment
- [ ] incur
- [ ] indefinite
- [ ] intellectual
- [ ] intelligible
- [ ] intense
- [ ] intensify
- [ ] intent
- [ ] interact
- [ ] interim
- [ ] interior
- [ ] intermediate
- [ ] intermittent
- [ ] interpret
- [ ] interrogate
- [ ] intersection
- [ ] interval
- [ ] intervene
- [ ] intimate
- [ ] intimidate

# Chapter 106

- [ ] intricate
- [ ] intrigue
- [ ] intrinsic
- [ ] intuition
- [ ] inundate
- [ ] invade
- [ ] knot
- [ ] laborious
- [ ] lace
- [ ] laden
- [ ] lag
- [ ] lamb
- [ ] lame
- [ ] lament
- [ ] landscape
- [ ] lane
- [ ] languid
- [ ] lap
- [ ] lapse
- [ ] lash

# Chapter 107

- [ ] latent
- [ ] lateral
- [ ] latitude
- [ ] laudable
- [ ] launch
- [ ] laundry
- [ ] lavish
- [ ] lawn
- [ ] lax
- [ ] livestock
- [ ] loaf
- [ ] loan
- [ ] loath
- [ ] lobby
- [ ] locality
- [ ] locker
- [ ] locomotive
- [ ] lodge
- [ ] lodging
- [ ] lofty

# Chapter 108

- [ ] log
- [ ] logic
- [ ] loll
- [ ] longitude
- [ ] lock
- [ ] mammal
- [ ] manacle
- [ ] mandate
- [ ] mandatory
- [ ] maneuver
- [ ] mania
- [ ] maniac
- [ ] manifest
- [ ] manifold
- [ ] manipulate
- [ ] mantle
- [ ] mansion
- [ ] manual
- [ ] manure
- [ ] manufacture

# Chapter 109

- [ ] manuscript
- [ ] mar
- [ ] marble
- [ ] march
- [ ] margin
- [ ] marginal
- [ ] marine
- [ ] marital
- [ ] mingle
- [ ] minimal
- [ ] minimum
- [ ] minister
- [ ] minority
- [ ] mint
- [ ] minus
- [ ] minute
- [ ] miracle
- [ ] mirage
- [ ] mire
- [ ] misappropriate

# Chapter 110

- [ ] miscarriage
- [ ] mischance
- [ ] mischief
- [ ] misconceive
- [ ] misdeed
- [ ] miserable
- [ ] misery
- [ ] misfortune
- [ ] misgiving
- [ ] misguided
- [ ] nap
- [ ] narcotic
- [ ] narrative
- [ ] nasty
- [ ] natal
- [ ] nautical
- [ ] nausea
- [ ] naval
- [ ] navigable
- [ ] navigation

# Chapter 111

- [ ] neat
- [ ] necessitate
- [ ] negation
- [ ] negative
- [ ] neglect
- [ ] negligence
- [ ] negligible
- [ ] negotiable
- [ ] neurosis
- [ ] neurotic
- [ ] neutralize
- [ ] nevertheless
- [ ] nibble
- [ ] obsess
- [ ] obsession
- [ ] obsolete
- [ ] obstacle
- [ ] obstinate
- [ ] obstruct
- [ ] obvious

# Chapter 112

- [ ] occasion
- [ ] occupy
- [ ] occur
- [ ] occurrence
- [ ] odd
- [ ] odds
- [ ] be
- [ ] odor
- [ ] odyssey
- [ ] offence
- [ ] offend
- [ ] offer
- [ ] outlet
- [ ] outline
- [ ] outlying
- [ ] output
- [ ] outrageous
- [ ] outright
- [ ] outset
- [ ] outskirts

# Chapter 113

- [ ] outspoken
- [ ] outstrip
- [ ] outweigh
- [ ] oval
- [ ] ovation
- [ ] overall
- [ ] overcome
- [ ] overdue
- [ ] overflow
- [ ] overhaul
- [ ] overhear
- [ ] overlap
- [ ] overlook
- [ ] pasture
- [ ] patch
- [ ] patent
- [ ] paternity
- [ ] pathetic
- [ ] pathos
- [ ] patio

# Chapter 114

- [ ] patriotism
- [ ] patrol
- [ ] patron
- [ ] pave
- [ ] pavement
- [ ] pay
- [ ] peculiar
- [ ] pedal
- [ ] pedestrian
- [ ] peel
- [ ] picnic
- [ ] picturesque
- [ ] piecemeal
- [ ] pier
- [ ] pierce
- [ ] piety
- [ ] pigment
- [ ] pilgrim
- [ ] pillar
- [ ] pillow

# Chapter 115

- [ ] pilot
- [ ] pimple
- [ ] pin
- [ ] pinch
- [ ] pine
- [ ] pinnacle
- [ ] pinpoint
- [ ] piracy
- [ ] piston
- [ ] pit
- [ ] pottery
- [ ] poultry
- [ ] pounce
- [ ] pour
- [ ] poverty
- [ ] practicable
- [ ] practical
- [ ] practically
- [ ] practitioner
- [ ] pragmatic

# Chapter 116

- [ ] preach
- [ ] precarious
- [ ] precaution
- [ ] precedence
- [ ] precedent
- [ ] preceding
- [ ] precious
- [ ] precipice
- [ ] precipitate
- [ ] precise
- [ ] predecessor
- [ ] predictable
- [ ] predisposition
- [ ] propulsion
- [ ] prosecute
- [ ] prospect
- [ ] prospective
- [ ] prospectus
- [ ] protein
- [ ] protest

# Chapter 117

- [ ] protocol
- [ ] prototype
- [ ] protract
- [ ] protrude
- [ ] provided
- [ ] provision
- [ ] provisional
- [ ] provoke
- [ ] proximity
- [ ] proxy
- [ ] pry
- [ ] pseudonym
- [ ] psychiatry
- [ ] psychology
- [ ] publicity
- [ ] ravage
- [ ] rave
- [ ] raw
- [ ] readily
- [ ] realm

# Chapter 118

- [ ] reap
- [ ] rear
- [ ] reasonable
- [ ] reassure
- [ ] recall
- [ ] recede
- [ ] receipt
- [ ] reception
- [ ] recession
- [ ] recipe
- [ ] recipient
- [ ] reciprocal
- [ ] recital
- [ ] recite
- [ ] reckless
- [ ] reckon
- [ ] resent
- [ ] reserve
- [ ] reservoir
- [ ] residence

# Chapter 119

- [ ] resign
- [ ] resignation
- [ ] resilience
- [ ] resolution
- [ ] resolve
- [ ] resonant
- [ ] resort
- [ ] resource
- [ ] respiration
- [ ] responsive
- [ ] restless
- [ ] restore
- [ ] restrain
- [ ] resume
- [ ] retail
- [ ] retain
- [ ] reticent
- [ ] say
- [ ] scale
- [ ] scalpel

# Chapter 120

- [ ] scan
- [ ] scandal
- [ ] scant
- [ ] scapegoat
- [ ] scar
- [ ] scarcely
- [ ] scatter
- [ ] scenery
- [ ] scent
- [ ] sceptical
- [ ] schedule
- [ ] scheme
- [ ] scholarship
- [ ] shave
- [ ] shear
- [ ] shed
- [ ] sheer
- [ ] sheet
- [ ] shell
- [ ] shelter

# Chapter 121

- [ ] shepherd
- [ ] shield
- [ ] shift
- [ ] shimmer
- [ ] shiver
- [ ] shoal
- [ ] shock
- [ ] shovel
- [ ] shower
- [ ] shred
- [ ] shrewd
- [ ] shrink
- [ ] shrub
- [ ] shrug
- [ ] shutter
- [ ] shuttle
- [ ] soluble
- [ ] solution
- [ ] solvent
- [ ] somehow

# Chapter 122

- [ ] somewhat
- [ ] sophisticated
- [ ] sore
- [ ] sort
- [ ] sound
- [ ] sour
- [ ] souvenir
- [ ] sovereign
- [ ] sow
- [ ] spacious
- [ ] span
- [ ] spare
- [ ] spark
- [ ] sparkle
- [ ] sparse
- [ ] spatial
- [ ] speciality
- [ ] specialize
- [ ] steak
- [ ] steamer

# Chapter 123

- [ ] steep
- [ ] steer
- [ ] stem
- [ ] stereo
- [ ] stereotype
- [ ] sterilize
- [ ] sterling
- [ ] stern
- [ ] steward
- [ ] stick
- [ ] stiff
- [ ] stimulate
- [ ] stimulus
- [ ] sting
- [ ] stipulate
- [ ] superior
- [ ] supersede
- [ ] supersonic
- [ ] superstition
- [ ] superstructure

# Chapter 124

- [ ] supervise
- [ ] supplementary
- [ ] supposedly
- [ ] supposition
- [ ] suppress
- [ ] supreme
- [ ] surcharge
- [ ] surge
- [ ] surgeon
- [ ] surgery
- [ ] surmount
- [ ] surpass
- [ ] surplus
- [ ] surrender
- [ ] survey
- [ ] survival
- [ ] susceptible
- [ ] suspect
- [ ] technician
- [ ] technique

# Chapter 125

- [ ] tedious
- [ ] teem
- [ ] telecommunication
- [ ] telex
- [ ] telling
- [ ] temper
- [ ] temperament
- [ ] temperate
- [ ] tempo
- [ ] temporary
- [ ] temptation
- [ ] tenable
- [ ] tenacious
- [ ] tenancy
- [ ] tendency
- [ ] tender
- [ ] tension
- [ ] tentacle
- [ ] tentative
- [ ] term

# Chapter 126

- [ ] tissue
- [ ] title
- [ ] toast
- [ ] toddle
- [ ] toil
- [ ] token
- [ ] tolerance
- [ ] tolerable
- [ ] toll
- [ ] toneless
- [ ] tongue
- [ ] tonic
- [ ] torch
- [ ] torment
- [ ] tornado
- [ ] torrent
- [ ] torture
- [ ] toss
- [ ] touchy
- [ ] tough

# Chapter 127

- [ ] tourism
- [ ] tournament
- [ ] tow
- [ ] tunnel
- [ ] turbulent
- [ ] turf
- [ ] turmoil
- [ ] turnover
- [ ] tutor
- [ ] tweezers
- [ ] twig
- [ ] twilight
- [ ] twinkle
- [ ] twist
- [ ] typical
- [ ] typhoon
- [ ] tyrannical
- [ ] tyre
- [ ] ugly
- [ ] ultimately

# Chapter 128

- [ ] ultimatum
- [ ] ultraviolet
- [ ] unanimous
- [ ] unconditional
- [ ] unconscious
- [ ] verge
- [ ] versatile
- [ ] version
- [ ] versus
- [ ] vertical
- [ ] vessel
- [ ] veteran
- [ ] veto
- [ ] vex
- [ ] via
- [ ] viable
- [ ] vibrate
- [ ] vice
- [ ] vicinity
- [ ] vicious

# Chapter 129

- [ ] vigilant
- [ ] vigorous
- [ ] vindicate
- [ ] violate
- [ ] violent
- [ ] virtually
- [ ] wreathe
- [ ] wreck
- [ ] wrench
- [ ] wrestle
- [ ] wretched
- [ ] wrinkle
- [ ] wrought
- [ ] yacht
- [ ] yard
- [ ] yarn
- [ ] yawn
- [ ] yearn
- [ ] yield
- [ ] yoke

# Chapter 130

- [ ] zeal
- [ ] zest
- [ ] zoology
- [ ] accommodate
- [ ] accommodation
- [ ] accompany
- [ ] acute
- [ ] adapt
- [ ] addict
- [ ] address
- [ ] affirm
- [ ] affix
- [ ] afflict
- [ ] afford
- [ ] agency
- [ ] agenda
- [ ] aggravate
- [ ] aggregate
- [ ] aggressive
- [ ] agitation

# Chapter 131

- [ ] agony
- [ ] agreeable
- [ ] agreement
- [ ] annihilate
- [ ] anniversary
- [ ] annoy
- [ ] annual
- [ ] annuity
- [ ] anonymous
- [ ] antagonism
- [ ] antecedent
- [ ] anthem
- [ ] anthology
- [ ] anthropology
- [ ] antibiotic
- [ ] anticipate
- [ ] anticipation
- [ ] antique
- [ ] antonym
- [ ] anxiety

# Chapter 132

- [ ] anyhow
- [ ] apologetic
- [ ] apparatus
- [ ] assign
- [ ] assimilate
- [ ] associate
- [ ] assorted
- [ ] assume
- [ ] assumption
- [ ] assurance
- [ ] assure
- [ ] astound
- [ ] astronomy
- [ ] asylum
- [ ] athlete
- [ ] atlas
- [ ] attach
- [ ] attack
- [ ] attain
- [ ] attempt

# Chapter 133

- [ ] attend
- [ ] attendance
- [ ] attendant
- [ ] attorney
- [ ] casual
- [ ] casualty
- [ ] catalogue
- [ ] catalyst
- [ ] catastrophe
- [ ] catch
- [ ] catching
- [ ] category
- [ ] cater
- [ ] cathedral
- [ ] Catholic
- [ ] caustic
- [ ] caution
- [ ] cautious
- [ ] cavity
- [ ] cease

# Chapter 134

- [ ] cellar
- [ ] cement
- [ ] cemetery
- [ ] clasp
- [ ] classic
- [ ] classical
- [ ] classify
- [ ] clause
- [ ] clear
- [ ] clearance
- [ ] chiche
- [ ] click
- [ ] client
- [ ] climax
- [ ] cling
- [ ] clinic
- [ ] clip
- [ ] clockwise
- [ ] closet
- [ ] clue

# Chapter 135

- [ ] clash
- [ ] commotion
- [ ] communication
- [ ] commute
- [ ] commuter
- [ ] compact
- [ ] company
- [ ] comparable
- [ ] compare
- [ ] compartment
- [ ] compass
- [ ] compatible
- [ ] compel
- [ ] compensate
- [ ] compensation
- [ ] competence
- [ ] competition
- [ ] competitive
- [ ] compile
- [ ] complement

# Chapter 136

- [ ] complex
- [ ] complexion
- [ ] considerable
- [ ] considerate
- [ ] consign
- [ ] consist
- [ ] console
- [ ] consolidate
- [ ] conspicuous
- [ ] conspiracy
- [ ] constant
- [ ] constituent
- [ ] constitute
- [ ] constitution
- [ ] constrain
- [ ] constrict
- [ ] consult
- [ ] consumer
- [ ] consumption
- [ ] contact

# Chapter 137

- [ ] contaminate
- [ ] crash
- [ ] crater
- [ ] crawl
- [ ] crease
- [ ] create
- [ ] creation
- [ ] credentials
- [ ] credible
- [ ] credit
- [ ] creep
- [ ] crevice
- [ ] cricket
- [ ] criminal
- [ ] cripple
- [ ] crisis
- [ ] crisp
- [ ] criterion
- [ ] critical
- [ ] craft

# Chapter 138

- [ ] dean
- [ ] dearth
- [ ] debris
- [ ] decade
- [ ] decay
- [ ] deceive
- [ ] decent
- [ ] decimal
- [ ] decipher
- [ ] deck
- [ ] declaration
- [ ] declare
- [ ] decline
- [ ] decompose
- [ ] decorate
- [ ] decrease
- [ ] decree
- [ ] decrepit
- [ ] dedicate
- [ ] dedicated

# Chapter 139

- [ ] deduce
- [ ] despair
- [ ] desperate
- [ ] despise
- [ ] destination
- [ ] destine
- [ ] destiny
- [ ] destructive
- [ ] detach
- [ ] detain
- [ ] detect
- [ ] detective
- [ ] deter
- [ ] detergent
- [ ] deteriorate
- [ ] determination
- [ ] detest
- [ ] detriment
- [ ] detrimental
- [ ] disposition

# Chapter 140

- [ ] dispute
- [ ] disregard
- [ ] disrupt
- [ ] dissertation
- [ ] dissipate
- [ ] dissolve
- [ ] distend
- [ ] distil
- [ ] distinct
- [ ] distinction
- [ ] distinguish
- [ ] distort
- [ ] distract
- [ ] distraction
- [ ] distress
- [ ] distribute
- [ ] disturb
- [ ] disturbance
- [ ] ditch
- [ ] diverse

# Chapter 141

- [ ] diversion
- [ ] divert
- [ ] edible
- [ ] edit
- [ ] edition
- [ ] editorial
- [ ] efficient
- [ ] ego
- [ ] eject
- [ ] elaborate
- [ ] elapse
- [ ] eke
- [ ] elastic
- [ ] elated
- [ ] elbow
- [ ] elderly
- [ ] electrical
- [ ] electrician
- [ ] electronic
- [ ] electronics

# Chapter 142

- [ ] elegant
- [ ] elementary
- [ ] elevate
- [ ] ephemeral
- [ ] epidemic
- [ ] episode
- [ ] epoch
- [ ] equal
- [ ] equation
- [ ] equator
- [ ] equilibrium
- [ ] equitable
- [ ] equity
- [ ] equivalent
- [ ] equivocal
- [ ] eradicate
- [ ] erase
- [ ] erect
- [ ] erosion
- [ ] errand

# Chapter 143

- [ ] erratic
- [ ] erroneous
- [ ] erupt
- [ ] escalate
- [ ] escalator
- [ ] escort
- [ ] exterior
- [ ] exterminate
- [ ] external
- [ ] extinct
- [ ] extinguish
- [ ] extort
- [ ] extra
- [ ] extract
- [ ] extravagant
- [ ] extreme
- [ ] exuberant
- [ ] eye
- [ ] fabric
- [ ] fabricate

# Chapter 144

- [ ] fabulous
- [ ] face
- [ ] fetter
- [ ] feud
- [ ] fibre
- [ ] fickle
- [ ] fidelity
- [ ] fierce
- [ ] figure
- [ ] file
- [ ] filter
- [ ] filth
- [ ] finance
- [ ] finite
- [ ] fist
- [ ] fit
- [ ] fitting
- [ ] fixture
- [ ] flabby
- [ ] flake

# Chapter 145

- [ ] flame
- [ ] flank
- [ ] flap
- [ ] flare
- [ ] frontier
- [ ] frost
- [ ] frown
- [ ] frugal
- [ ] fruition
- [ ] frustrate
- [ ] fry
- [ ] fuel
- [ ] fulfil
- [ ] fume
- [ ] function
- [ ] fundamental
- [ ] funeral
- [ ] funnel
- [ ] furious
- [ ] furnace

# Chapter 146

- [ ] furnish
- [ ] fury
- [ ] fuse
- [ ] fusion
- [ ] fuss
- [ ] gaily
- [ ] galaxy
- [ ] glare
- [ ] gleam
- [ ] glide
- [ ] glimmer
- [ ] glimpse
- [ ] glitter
- [ ] global
- [ ] gloomy
- [ ] glorious
- [ ] gloss
- [ ] glossary
- [ ] glow
- [ ] glue

# Chapter 147

- [ ] guy
- [ ] gymnasium
- [ ] hail
- [ ] halt
- [ ] hamper
- [ ] hand
- [ ] handbook
- [ ] handicap
- [ ] handsome
- [ ] hang
- [ ] holocaust
- [ ] homestay
- [ ] homogeneous
- [ ] hop
- [ ] horizon
- [ ] horrible
- [ ] horticulture
- [ ] hose
- [ ] hospitality
- [ ] host

# Chapter 148

- [ ] hostage
- [ ] hostile
- [ ] hound
- [ ] hover
- [ ] howl
- [ ] indelible
- [ ] indemnity
- [ ] indicative
- [ ] indicator
- [ ] indifferent
- [ ] indigenous
- [ ] indignant
- [ ] indispensable
- [ ] individual
- [ ] induce
- [ ] indulge
- [ ] inept
- [ ] inert
- [ ] inertia
- [ ] inevitable

# Chapter 149

- [ ] infant
- [ ] infect
- [ ] infectious
- [ ] inference
- [ ] inferior
- [ ] infest
- [ ] infinite
- [ ] infirmary
- [ ] invalid
- [ ] invaluable
- [ ] invariably
- [ ] inventory
- [ ] invert
- [ ] invest
- [ ] investigate
- [ ] invigilate
- [ ] invincible
- [ ] invisible
- [ ] invoice
- [ ] involve

# Chapter 150

- [ ] irony
- [ ] irrespective
- [ ] irrigation
- [ ] irritate
- [ ] isle
- [ ] isolate
- [ ] issue
- [ ] item
- [ ] itinerary
- [ ] ivory
- [ ] jagged
- [ ] lay
- [ ] layer
- [ ] layman
- [ ] layoff
- [ ] layout
- [ ] leaflet
- [ ] leak
- [ ] leap
- [ ] lease

# Chapter 151

- [ ] leave
- [ ] legal
- [ ] legend
- [ ] legislate
- [ ] loom
- [ ] loop
- [ ] lottery
- [ ] lounge
- [ ] loyal
- [ ] lubricate
- [ ] lucid
- [ ] lucrative
- [ ] ludicrous
- [ ] lull
- [ ] luminous
- [ ] maritime
- [ ] marrow
- [ ] marsh
- [ ] martial
- [ ] martyr

# Chapter 152

- [ ] marvel
- [ ] marvelous
- [ ] masculine
- [ ] mask
- [ ] massacre
- [ ] massive
- [ ] masterpiece
- [ ] match
- [ ] maternal
- [ ] matrimony
- [ ] mature
- [ ] maximum
- [ ] meadow
- [ ] meager
- [ ] mean
- [ ] means
- [ ] measure
- [ ] mechanism
- [ ] mishap
- [ ] misrepresent

# Chapter 153

- [ ] missile
- [ ] mission
- [ ] mist
- [ ] misuse
- [ ] mitigate
- [ ] mobile
- [ ] mobilize
- [ ] mock
- [ ] mode
- [ ] moderate
- [ ] modest
- [ ] modify
- [ ] module
- [ ] moist
- [ ] molecule
- [ ] molest
- [ ] momentous
- [ ] momentum
- [ ] monarchy
- [ ] monitor

# Chapter 154

- [ ] monologue
- [ ] nicety
- [ ] nickel
- [ ] nightmare
- [ ] nil
- [ ] nitrogen
- [ ] nobility
- [ ] nominal
- [ ] nominate
- [ ] nominee
- [ ] norm
- [ ] nostalgia
- [ ] notable
- [ ] notary
- [ ] notation
- [ ] notch
- [ ] nothing
- [ ] notify
- [ ] offset
- [ ] offshore

# Chapter 155

- [ ] offspring
- [ ] omen
- [ ] ominous
- [ ] omit
- [ ] on
- [ ] once
- [ ] oncoming
- [ ] one
- [ ] ongoing
- [ ] override
- [ ] overrun
- [ ] oversee
- [ ] overtake
- [ ] overt
- [ ] overthrow
- [ ] overture
- [ ] overwhelm
- [ ] overwrought
- [ ] owe
- [ ] ownership

# Chapter 156

- [ ] oxide
- [ ] pace
- [ ] pacify
- [ ] pad
- [ ] paddle
- [ ] pageant
- [ ] pains
- [ ] painstaking
- [ ] palatable
- [ ] palm
- [ ] peer
- [ ] penalty
- [ ] pendulum
- [ ] penetrate
- [ ] pension
- [ ] perceive
- [ ] perceptible
- [ ] perception
- [ ] percussion
- [ ] perennial

# Chapter 157

- [ ] performance
- [ ] perfume
- [ ] peril
- [ ] perimeter
- [ ] periodical
- [ ] periodically
- [ ] periphery
- [ ] periscope
- [ ] perish
- [ ] perishable
- [ ] permanent
- [ ] permeate
- [ ] pitch
- [ ] pivot
- [ ] placard
- [ ] placid
- [ ] plagiarize
- [ ] plague
- [ ] plaintive
- [ ] planetarium

# Chapter 158

- [ ] plank
- [ ] plankton
- [ ] plantation
- [ ] plaster
- [ ] plateau
- [ ] platform
- [ ] platitude
- [ ] plausible
- [ ] plea
- [ ] plead
- [ ] pledge
- [ ] pliable
- [ ] predominant
- [ ] preface
- [ ] pregnant
- [ ] prejudice
- [ ] preliminary
- [ ] prelude
- [ ] premise
- [ ] premium

# Chapter 159

- [ ] prerogative
- [ ] prescribe
- [ ] prescription
- [ ] presence
- [ ] presentation
- [ ] preserve
- [ ] prestige
- [ ] prestigious
- [ ] presumably
- [ ] presumption
- [ ] pretentious
- [ ] pretext
- [ ] prevail
- [ ] prevalent
- [ ] previous
- [ ] pull
- [ ] pulp
- [ ] pump
- [ ] punctual
- [ ] puncture

# Chapter 160

- [ ] pungent
- [ ] pupil
- [ ] purge
- [ ] purity
- [ ] pursuit
- [ ] put
- [ ] reclaim
- [ ] recline
- [ ] recommendation
- [ ] reconcile
- [ ] recover
- [ ] recruit
- [ ] rectangle
- [ ] rectify
- [ ] recycle
- [ ] redeem
- [ ] redundant
- [ ] reel
- [ ] reference
- [ ] referendum

# Chapter 161

- [ ] refine
- [ ] refrain
- [ ] refreshing
- [ ] refreshment
- [ ] refugee
- [ ] refund
- [ ] refusal
- [ ] regardless
- [ ] retort
- [ ] retreat
- [ ] retrieve
- [ ] retrospect
- [ ] revelation
- [ ] revenge
- [ ] revenue
- [ ] reverent
- [ ] reverse
- [ ] review
- [ ] revise
- [ ] revive

# Chapter 162

- [ ] revolt
- [ ] revolve
- [ ] reward
- [ ] rhetoric
- [ ] rhythm
- [ ] ribbon
- [ ] ridge
- [ ] ridiculous
- [ ] rig
- [ ] righteous
- [ ] scissors
- [ ] scold
- [ ] scoop
- [ ] scorch
- [ ] score
- [ ] scorn
- [ ] scout
- [ ] scrap
- [ ] scrape
- [ ] scratch

# Chapter 163

- [ ] screw
- [ ] script
- [ ] scroll
- [ ] scrutiny
- [ ] sculpture
- [ ] scum
- [ ] seal
- [ ] seam
- [ ] seclude
- [ ] secondary
- [ ] secretion
- [ ] sicken
- [ ] siege
- [ ] sieve
- [ ] sigh
- [ ] sightseeing
- [ ] sign
- [ ] signal
- [ ] signature
- [ ] significant

# Chapter 164

- [ ] signify
- [ ] similar
- [ ] simplify
- [ ] simulate
- [ ] simultaneous
- [ ] sincere
- [ ] single
- [ ] singular
- [ ] sink
- [ ] site
- [ ] situated
- [ ] skeleton
- [ ] sketch
- [ ] species
- [ ] specific
- [ ] specification
- [ ] specimen
- [ ] spectacle
- [ ] spectacular
- [ ] spectator

# Chapter 165

- [ ] spectrum
- [ ] speculate
- [ ] sphere
- [ ] spill
- [ ] spin
- [ ] spiral
- [ ] spiritual
- [ ] spit
- [ ] splash
- [ ] splendid
- [ ] split
- [ ] spoil
- [ ] spokesman
- [ ] sponge
- [ ] sponsor
- [ ] spontaneous
- [ ] stitch
- [ ] stock
- [ ] stoop
- [ ] storage

# Chapter 166

- [ ] storey
- [ ] straightforward
- [ ] strain
- [ ] strait
- [ ] strap
- [ ] strategic
- [ ] strengthen
- [ ] strenuous
- [ ] stress
- [ ] stretch
- [ ] stride
- [ ] striking
- [ ] string
- [ ] strip
- [ ] stripe
- [ ] strive
- [ ] suspend
- [ ] suspense
- [ ] suspension
- [ ] suspicious

# Chapter 167

- [ ] sustain
- [ ] sustenance
- [ ] swallow
- [ ] swamp
- [ ] swarm
- [ ] sway
- [ ] swear
- [ ] sweater
- [ ] sweep
- [ ] swell
- [ ] swerve
- [ ] swift
- [ ] swing
- [ ] swirl
- [ ] syllabus
- [ ] symbolize
- [ ] symmetry
- [ ] sympathetic
- [ ] symphony
- [ ] terminal

# Chapter 168

- [ ] terminate
- [ ] terrace
- [ ] terrain
- [ ] terrestrial
- [ ] terrific
- [ ] terrify
- [ ] territorial
- [ ] territory
- [ ] terror
- [ ] terse
- [ ] testimony
- [ ] textile
- [ ] texture
- [ ] thaw
- [ ] theft
- [ ] theme
- [ ] therapy
- [ ] thereby
- [ ] towel
- [ ] toxic

# Chapter 169

- [ ] trace
- [ ] track
- [ ] tract
- [ ] traction
- [ ] tragedy
- [ ] trail
- [ ] trait
- [ ] tramp
- [ ] trample
- [ ] tranquility
- [ ] transaction
- [ ] transcend
- [ ] transcript
- [ ] transfer
- [ ] transform
- [ ] transfuse
- [ ] traitor
- [ ] transgress
- [ ] transistor
- [ ] transit

# Chapter 170

- [ ] transition
- [ ] undercharge
- [ ] underestimate
- [ ] undergo
- [ ] underline
- [ ] underlying
- [ ] undermine
- [ ] underneath
- [ ] undertake
- [ ] underwrite
- [ ] undo
- [ ] undoubtedly
- [ ] undue
- [ ] uneasy
- [ ] unemployment
- [ ] uneven
- [ ] unfold
- [ ] ungainly
- [ ] uniform
- [ ] unify

# Chapter 171

- [ ] unilateral
- [ ] unique
- [ ] universal
- [ ] unlikely
- [ ] virtuous
- [ ] virus
- [ ] visible
- [ ] visualize
- [ ] vital
- [ ] vivid
- [ ] vocational
- [ ] vogue
- [ ] void
- [ ] volatile
- [ ] volcano
- [ ] voltage
- [ ] volume
- [ ] voluntary
- [ ] volunteer
- [ ] vomit

# Chapter 172

- [ ] voucher
- [ ] vow
- [ ] vulgar
- [ ] vulnerable
- [ ] wage
- [ ] wager
- [ ] waggon

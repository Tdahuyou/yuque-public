
# Chapter 001

- [ ] act
- [ ] action
- [ ] activate
- [ ] active
- [ ] actress
- [ ] actual
- [ ] interact
- [ ] radioactive
- [ ] react
- [ ] transaction
- [ ] character
- [ ] characteristic
- [ ] characterize
- [ ] agency
- [ ] agenda
- [ ] agent
- [ ] agony
- [ ] agitate
- [ ] art
- [ ] artery

# Chapter 002

- [ ] article
- [ ] articulate
- [ ] artificial
- [ ] artist
- [ ] artistic
- [ ] ban
- [ ] abandon
- [ ] band
- [ ] bandage
- [ ] bank
- [ ] bankrupt
- [ ] banner
- [ ] banquet
- [ ] husband
- [ ] urban
- [ ] bar
- [ ] barbecue
- [ ] barber
- [ ] bare
- [ ] barely

# Chapter 003

- [ ] bargain
- [ ] barn
- [ ] barrel
- [ ] barren
- [ ] barrier
- [ ] embark
- [ ] embarrass
- [ ] base
- [ ] ambassador
- [ ] baseball
- [ ] basement
- [ ] basic
- [ ] basin
- [ ] basis
- [ ] basket
- [ ] database
- [ ] embassy
- [ ] bat
- [ ] acrobat
- [ ] bacterium

# Chapter 004

- [ ] batch
- [ ] bath
- [ ] bathe
- [ ] bathroom
- [ ] battery
- [ ] battle
- [ ] combat
- [ ] debate
- [ ] call
- [ ] recall
- [ ] calcium
- [ ] calculate
- [ ] calendar
- [ ] scale
- [ ] escalate
- [ ] accelerate
- [ ] celebrate
- [ ] celebrity
- [ ] cap
- [ ] capable

# Chapter 005

- [ ] capacity
- [ ] cape
- [ ] capital
- [ ] capitalism
- [ ] capsule
- [ ] captain
- [ ] captive
- [ ] capture
- [ ] escape
- [ ] handicap
- [ ] car
- [ ] cargo
- [ ] carpenter
- [ ] carpet
- [ ] carriage
- [ ] carrier
- [ ] carrot
- [ ] carry
- [ ] cart
- [ ] cartoon

# Chapter 006

- [ ] carve
- [ ] care
- [ ] career
- [ ] careful
- [ ] caress
- [ ] cat
- [ ] catalog
- [ ] catastrophe
- [ ] catch
- [ ] category
- [ ] cater
- [ ] cathedral
- [ ] Catholic
- [ ] cattle
- [ ] accident
- [ ] accidental
- [ ] acid
- [ ] coincide
- [ ] coincidence
- [ ] decide

# Chapter 007

- [ ] incidence
- [ ] incident
- [ ] suicide
- [ ] decision
- [ ] decisive
- [ ] incidentally
- [ ] concise
- [ ] cut
- [ ] execute
- [ ] executive
- [ ] accept
- [ ] acceptance
- [ ] concept
- [ ] except
- [ ] exception
- [ ] exceptional
- [ ] reception
- [ ] susceptible
- [ ] conceive
- [ ] deceit

# Chapter 008

- [ ] deceive
- [ ] perceive
- [ ] receipt
- [ ] receive
- [ ] anticipate
- [ ] discipline
- [ ] municipal
- [ ] principal
- [ ] principle
- [ ] recipient
- [ ] reciprocal
- [ ] recipe
- [ ] cup
- [ ] cupboard
- [ ] occupation
- [ ] occupy
- [ ] ascertain
- [ ] certain
- [ ] certainly
- [ ] certainty

# Chapter 009

- [ ] certificate
- [ ] certify
- [ ] concert
- [ ] access
- [ ] accessory
- [ ] concession
- [ ] excess
- [ ] excessive
- [ ] predecessor
- [ ] process
- [ ] procession
- [ ] success
- [ ] successful
- [ ] succession
- [ ] successive
- [ ] successor
- [ ] concede
- [ ] precede
- [ ] precedent
- [ ] preceding

# Chapter 010

- [ ] procedure
- [ ] recede
- [ ] exceed
- [ ] exceedingly
- [ ] proceed
- [ ] proceeding
- [ ] succeed
- [ ] aggressive
- [ ] congress
- [ ] progress
- [ ] progressive
- [ ] circle
- [ ] circuit
- [ ] circular
- [ ] circulate
- [ ] circumference
- [ ] circumstance
- [ ] circus
- [ ] bicycle
- [ ] cycle

# Chapter 011

- [ ] recycle
- [ ] close
- [ ] conclude
- [ ] conclusion
- [ ] exclude
- [ ] exclusive
- [ ] include
- [ ] inclusive
- [ ] preclude
- [ ] closet
- [ ] cloth
- [ ] clothe
- [ ] clothes
- [ ] clothing
- [ ] disclose
- [ ] enclose
- [ ] enclosure
- [ ] count
- [ ] account
- [ ] accountant

# Chapter 012

- [ ] counter
- [ ] country
- [ ] countryside
- [ ] counterpart
- [ ] county
- [ ] discount
- [ ] discourse
- [ ] encounter
- [ ] cover
- [ ] discover
- [ ] discovery
- [ ] recover
- [ ] recovery
- [ ] uncover
- [ ] create
- [ ] acre
- [ ] concrete
- [ ] cream
- [ ] creative
- [ ] creature

# Chapter 013

- [ ] decrease
- [ ] discreet
- [ ] discrepancy
- [ ] increase
- [ ] increasingly
- [ ] massacre
- [ ] recreation
- [ ] secret
- [ ] secretary
- [ ] cry
- [ ] crystal
- [ ] crime
- [ ] criminal
- [ ] cripple
- [ ] crisis
- [ ] crisp
- [ ] criterion
- [ ] critic
- [ ] critical
- [ ] criticism

# Chapter 014

- [ ] criticize
- [ ] discriminate
- [ ] cure
- [ ] accuracy
- [ ] accurate
- [ ] curb
- [ ] curiosity
- [ ] curious
- [ ] curl
- [ ] currency
- [ ] current
- [ ] curriculum
- [ ] curtain
- [ ] curve
- [ ] excursion
- [ ] incur
- [ ] mercury
- [ ] obscure
- [ ] occur
- [ ] occurrence

# Chapter 015

- [ ] recur
- [ ] secure
- [ ] security
- [ ] dictation
- [ ] addict
- [ ] addition
- [ ] contradict
- [ ] contradiction
- [ ] dictionary
- [ ] predict
- [ ] dedicate
- [ ] indicate
- [ ] indication
- [ ] indicative
- [ ] verdict
- [ ] doctor
- [ ] doctorate
- [ ] document
- [ ] documentary
- [ ] conduct

# Chapter 016

- [ ] conductor
- [ ] deduce
- [ ] deduct
- [ ] educate
- [ ] education
- [ ] induce
- [ ] introduce
- [ ] introduction
- [ ] produce
- [ ] product
- [ ] production
- [ ] productive
- [ ] productivity
- [ ] reduce
- [ ] reduction
- [ ] reproduce
- [ ] semiconductor
- [ ] dome
- [ ] domain
- [ ] domestic

# Chapter 017

- [ ] dominant
- [ ] dominate
- [ ] predominant
- [ ] doom
- [ ] dorm
- [ ] democracy
- [ ] democratic
- [ ] equal
- [ ] adequate
- [ ] equality
- [ ] equation
- [ ] equator
- [ ] equip
- [ ] equipment
- [ ] quarrel
- [ ] fact
- [ ] factor
- [ ] factory
- [ ] satisfaction
- [ ] satisfactory

# Chapter 018

- [ ] affect
- [ ] affection
- [ ] defect
- [ ] perfect
- [ ] perfection
- [ ] effect
- [ ] effective
- [ ] efficiency
- [ ] efficient
- [ ] infect
- [ ] infectious
- [ ] beneficial
- [ ] benefit
- [ ] classification
- [ ] classify
- [ ] deficiency
- [ ] deficit
- [ ] difficult
- [ ] difficulty
- [ ] fiction

# Chapter 019

- [ ] identification
- [ ] identify
- [ ] magnificent
- [ ] magnify
- [ ] office
- [ ] officer
- [ ] official
- [ ] proficiency
- [ ] significance
- [ ] significant
- [ ] suffice
- [ ] sufficient
- [ ] superficial
- [ ] profit
- [ ] profitable
- [ ] fin
- [ ] confine
- [ ] define
- [ ] definite
- [ ] definition

# Chapter 020

- [ ] final
- [ ] finally
- [ ] finance
- [ ] financial
- [ ] fine
- [ ] finger
- [ ] finish
- [ ] finite
- [ ] infinite
- [ ] refine
- [ ] fraction
- [ ] fracture
- [ ] fragile
- [ ] fragment
- [ ] fragrant
- [ ] fierce
- [ ] form
- [ ] conform
- [ ] formal
- [ ] format

# Chapter 021

- [ ] formation
- [ ] former
- [ ] formidable
- [ ] formula
- [ ] formulate
- [ ] inform
- [ ] information
- [ ] perform
- [ ] performance
- [ ] platform
- [ ] reform
- [ ] transform
- [ ] uniform
- [ ] fur
- [ ] furious
- [ ] furnace
- [ ] furnish
- [ ] furniture
- [ ] fuse
- [ ] confuse

# Chapter 022

- [ ] confusion
- [ ] diffuse
- [ ] refusal
- [ ] refuse
- [ ] gene
- [ ] degenerate
- [ ] gender
- [ ] general
- [ ] generalize
- [ ] generate
- [ ] generation
- [ ] generator
- [ ] generous
- [ ] genetic
- [ ] genius
- [ ] gentle
- [ ] gently
- [ ] genuine
- [ ] homogeneous
- [ ] ingenious

# Chapter 023

- [ ] pregnant
- [ ] malignant
- [ ] diagnose
- [ ] dignity
- [ ] indignant
- [ ] indignation
- [ ] cognitive
- [ ] recognition
- [ ] recognize
- [ ] grade
- [ ] centigrade
- [ ] gradual
- [ ] graduate
- [ ] upgrade
- [ ] congratulate
- [ ] congratulation
- [ ] disgrace
- [ ] grace
- [ ] graceful
- [ ] gracious

# Chapter 024

- [ ] grand
- [ ] grandmother
- [ ] grant
- [ ] grateful
- [ ] gratitude
- [ ] greet
- [ ] greeting
- [ ] great
- [ ] her
- [ ] herb
- [ ] herd
- [ ] here
- [ ] heritage
- [ ] hero
- [ ] heroic
- [ ] heroine
- [ ] hers
- [ ] herself
- [ ] inherent
- [ ] inherit

# Chapter 025

- [ ] shepherd
- [ ] adhere
- [ ] coherent
- [ ] cohesive
- [ ] hesitate
- [ ] eject
- [ ] inject
- [ ] object
- [ ] objection
- [ ] objective
- [ ] project
- [ ] projector
- [ ] reject
- [ ] subject
- [ ] subjective
- [ ] collect
- [ ] collection
- [ ] collective
- [ ] dialect
- [ ] elect

# Chapter 026

- [ ] intellectual
- [ ] intelligence
- [ ] intelligent
- [ ] intelligible
- [ ] lecture
- [ ] neglect
- [ ] recollect
- [ ] select
- [ ] selection
- [ ] lever
- [ ] alleviate
- [ ] elevate
- [ ] elevator
- [ ] level
- [ ] levy
- [ ] light
- [ ] highlight
- [ ] daylight
- [ ] delight
- [ ] enlighten

# Chapter 027

- [ ] lightning
- [ ] illuminate
- [ ] lure
- [ ] illusion
- [ ] illustrate
- [ ] illustration
- [ ] luxury
- [ ] local
- [ ] allocate
- [ ] locality
- [ ] locate
- [ ] location
- [ ] locomotive
- [ ] logic
- [ ] analogue
- [ ] analogy
- [ ] dialog
- [ ] eloquent
- [ ] log
- [ ] logical

# Chapter 028

- [ ] technology
- [ ] biology
- [ ] ecology
- [ ] geology
- [ ] ideology
- [ ] physiological
- [ ] psychology
- [ ] sociology
- [ ] legacy
- [ ] legal
- [ ] legend
- [ ] legislation
- [ ] legitimate
- [ ] college
- [ ] elegant
- [ ] diligent
- [ ] negligible
- [ ] obligation
- [ ] oblige
- [ ] eligible

# Chapter 029

- [ ] religion
- [ ] religious
- [ ] law
- [ ] lawyer
- [ ] limit
- [ ] limitation
- [ ] limited
- [ ] preliminary
- [ ] dilemma
- [ ] low
- [ ] below
- [ ] blow
- [ ] fellow
- [ ] fellowship
- [ ] follow
- [ ] following
- [ ] hollow
- [ ] lower
- [ ] loyal
- [ ] loyalty

# Chapter 030

- [ ] allow
- [ ] allowance
- [ ] pillow
- [ ] shallow
- [ ] swallow
- [ ] yellow
- [ ] slow
- [ ] man
- [ ] chairman
- [ ] gentleman
- [ ] human
- [ ] humanity
- [ ] layman
- [ ] manage
- [ ] management
- [ ] manager
- [ ] mankind
- [ ] manner
- [ ] permanent
- [ ] policeman

# Chapter 031

- [ ] postman
- [ ] romance
- [ ] romantic
- [ ] salesman
- [ ] spokesman
- [ ] sportsman
- [ ] statesman
- [ ] woman
- [ ] fireman
- [ ] fisherman
- [ ] maneuver
- [ ] manifest
- [ ] manipulate
- [ ] manual
- [ ] manufacture
- [ ] manuscript
- [ ] abdomen
- [ ] specimen
- [ ] commence
- [ ] menace

# Chapter 032

- [ ] menu
- [ ] communicate
- [ ] communication
- [ ] communism
- [ ] community
- [ ] immune
- [ ] mark
- [ ] marble
- [ ] march
- [ ] March
- [ ] margin
- [ ] marginal
- [ ] marine
- [ ] marital
- [ ] market
- [ ] marriage
- [ ] married
- [ ] marry
- [ ] marvelous
- [ ] remark

# Chapter 033

- [ ] remarkable
- [ ] grammar
- [ ] nightmare
- [ ] submarine
- [ ] supermarket
- [ ] trademark
- [ ] summarize
- [ ] summary
- [ ] admire
- [ ] miracle
- [ ] mirror
- [ ] commerce
- [ ] commercial
- [ ] emerge
- [ ] emergency
- [ ] immerse
- [ ] merchandise
- [ ] merchant
- [ ] mercy
- [ ] mere

# Chapter 034

- [ ] merely
- [ ] merge
- [ ] merit
- [ ] merry
- [ ] submerge
- [ ] summer
- [ ] memo
- [ ] commemorate
- [ ] member
- [ ] membership
- [ ] memorial
- [ ] memory
- [ ] remember
- [ ] metre
- [ ] arithmetic
- [ ] cemetery
- [ ] centimetre
- [ ] diameter
- [ ] geometry
- [ ] helmet

# Chapter 035

- [ ] kilometre
- [ ] metal
- [ ] metaphor
- [ ] method
- [ ] metric
- [ ] metropolitan
- [ ] millimeter
- [ ] parameter
- [ ] symmetry
- [ ] thermometer
- [ ] middle
- [ ] amid
- [ ] humid
- [ ] humidity
- [ ] midst
- [ ] pyramid
- [ ] comedy
- [ ] immediate
- [ ] medal
- [ ] medical

# Chapter 036

- [ ] medicine
- [ ] medieval
- [ ] meditate
- [ ] meditation
- [ ] medium
- [ ] mode
- [ ] accommodate
- [ ] accommodation
- [ ] commodity
- [ ] model
- [ ] moderate
- [ ] modern
- [ ] modernization
- [ ] modest
- [ ] mood
- [ ] modify
- [ ] module
- [ ] moon
- [ ] among
- [ ] ceremony

# Chapter 037

- [ ] common
- [ ] commonplace
- [ ] commonwealth
- [ ] demonstrate
- [ ] harmony
- [ ] monarch
- [ ] Monday
- [ ] monetary
- [ ] money
- [ ] monitor
- [ ] monkey
- [ ] monopoly
- [ ] monotonous
- [ ] monster
- [ ] month
- [ ] monthly
- [ ] monument
- [ ] summon
- [ ] testimony
- [ ] move

# Chapter 038

- [ ] movement
- [ ] movie
- [ ] removal
- [ ] remove
- [ ] mob
- [ ] mobile
- [ ] mobilize
- [ ] emotion
- [ ] motel
- [ ] motion
- [ ] motivate
- [ ] motive
- [ ] motor
- [ ] promote
- [ ] remote
- [ ] name
- [ ] namely
- [ ] nickname
- [ ] ornament
- [ ] anonymous

# Chapter 039

- [ ] nominal
- [ ] nominate
- [ ] astronomy
- [ ] autonomy
- [ ] economic
- [ ] economical
- [ ] economics
- [ ] economy
- [ ] noun
- [ ] pronoun
- [ ] pronounce
- [ ] pronunciation
- [ ] announce
- [ ] denounce
- [ ] order
- [ ] coordinate
- [ ] disorder
- [ ] extraordinary
- [ ] orderly
- [ ] ordinary

# Chapter 040

- [ ] subordinate
- [ ] pale
- [ ] appal
- [ ] palace
- [ ] pan
- [ ] accompany
- [ ] companion
- [ ] company
- [ ] expand
- [ ] expansion
- [ ] panel
- [ ] panic
- [ ] panorama
- [ ] part
- [ ] apart
- [ ] apartment
- [ ] compartment
- [ ] depart
- [ ] department
- [ ] departure

# Chapter 041

- [ ] impart
- [ ] partial
- [ ] participant
- [ ] participate
- [ ] particle
- [ ] particular
- [ ] partly
- [ ] partner
- [ ] party
- [ ] parachute
- [ ] parade
- [ ] paradigm
- [ ] paradox
- [ ] parallel
- [ ] paralyze
- [ ] parasite
- [ ] apparatus
- [ ] apparent
- [ ] comparable
- [ ] comparative

# Chapter 042

- [ ] compare
- [ ] comparison
- [ ] parcel
- [ ] pardon
- [ ] parent
- [ ] parliament
- [ ] preparation
- [ ] prepare
- [ ] separate
- [ ] transparent
- [ ] penny
- [ ] pension
- [ ] compensate
- [ ] compensation
- [ ] expense
- [ ] expensive
- [ ] indispensable
- [ ] pet
- [ ] appetite
- [ ] compete

# Chapter 043

- [ ] competent
- [ ] competition
- [ ] competitive
- [ ] impetus
- [ ] perpetual
- [ ] petition
- [ ] petty
- [ ] puppet
- [ ] repetition
- [ ] trumpet
- [ ] poll
- [ ] police
- [ ] policy
- [ ] polite
- [ ] political
- [ ] politician
- [ ] politics
- [ ] apologise
- [ ] apology
- [ ] metropolis

# Chapter 044

- [ ] port
- [ ] airport
- [ ] corporation
- [ ] evaporate
- [ ] export
- [ ] import
- [ ] importance
- [ ] important
- [ ] opportunity
- [ ] portable
- [ ] porter
- [ ] portion
- [ ] portrait
- [ ] portray
- [ ] proportion
- [ ] report
- [ ] reporter
- [ ] support
- [ ] transport
- [ ] incorporate

# Chapter 045

- [ ] contemporary
- [ ] temporary
- [ ] pose
- [ ] compose
- [ ] composite
- [ ] composition
- [ ] deposit
- [ ] disposal
- [ ] dispose
- [ ] disposition
- [ ] expose
- [ ] exposure
- [ ] impose
- [ ] impossible
- [ ] oppose
- [ ] opposite
- [ ] position
- [ ] positive
- [ ] preposition
- [ ] proposal

# Chapter 046

- [ ] propose
- [ ] proposition
- [ ] purpose
- [ ] suppose
- [ ] symposium
- [ ] possess
- [ ] possession
- [ ] possibility
- [ ] possible
- [ ] possibly
- [ ] pray
- [ ] appraisal
- [ ] prayer
- [ ] price
- [ ] appropriate
- [ ] comprise
- [ ] enterprise
- [ ] pride
- [ ] priest
- [ ] primary

# Chapter 047

- [ ] prime
- [ ] primitive
- [ ] prince
- [ ] princess
- [ ] prior
- [ ] priority
- [ ] prison
- [ ] prisoner
- [ ] privacy
- [ ] private
- [ ] privilege
- [ ] prize
- [ ] surprise
- [ ] appreciate
- [ ] precious
- [ ] precise
- [ ] precision
- [ ] prove
- [ ] approval
- [ ] approve

# Chapter 048

- [ ] improve
- [ ] improvement
- [ ] waterproof
- [ ] proof
- [ ] correct
- [ ] direct
- [ ] direction
- [ ] directly
- [ ] director
- [ ] directory
- [ ] erect
- [ ] rectangle
- [ ] rectify
- [ ] same
- [ ] sample
- [ ] assembly
- [ ] resemblance
- [ ] resemble
- [ ] simple
- [ ] simplicity

# Chapter 049

- [ ] simplify
- [ ] simply
- [ ] pessimistic
- [ ] similar
- [ ] simulate
- [ ] simultaneous
- [ ] approximate
- [ ] assimilate
- [ ] resume
- [ ] assume
- [ ] assumption
- [ ] consume
- [ ] consumption
- [ ] presume
- [ ] sympathetic
- [ ] sympathize
- [ ] sympathy
- [ ] symphony
- [ ] symptom
- [ ] sanction

# Chapter 050

- [ ] sane
- [ ] syndrome
- [ ] synthesis
- [ ] synthetic
- [ ] script
- [ ] description
- [ ] prescription
- [ ] describe
- [ ] subscribe
- [ ] prescribe
- [ ] second
- [ ] consecutive
- [ ] persecute
- [ ] prosecute
- [ ] secondary
- [ ] consequence
- [ ] consequently
- [ ] sequence
- [ ] subsequent
- [ ] sense

# Chapter 051

- [ ] absence
- [ ] absent
- [ ] consensus
- [ ] consent
- [ ] essence
- [ ] essential
- [ ] presence
- [ ] present
- [ ] presently
- [ ] represent
- [ ] representative
- [ ] resent
- [ ] senate
- [ ] senator
- [ ] senior
- [ ] sensation
- [ ] sensible
- [ ] sensitive
- [ ] sentence
- [ ] sentiment

# Chapter 052

- [ ] side
- [ ] aside
- [ ] alongside
- [ ] beside
- [ ] besides
- [ ] consider
- [ ] considerable
- [ ] considerate
- [ ] consideration
- [ ] inside
- [ ] outside
- [ ] preside
- [ ] president
- [ ] prestige
- [ ] residence
- [ ] resident
- [ ] seaside
- [ ] sideways
- [ ] subsidy
- [ ] sign

# Chapter 053

- [ ] assign
- [ ] assignment
- [ ] design
- [ ] designate
- [ ] resign
- [ ] signal
- [ ] signature
- [ ] signify
- [ ] assist
- [ ] assistance
- [ ] assistant
- [ ] consist
- [ ] consistent
- [ ] insist
- [ ] persist
- [ ] resist
- [ ] resistance
- [ ] resistant
- [ ] sister
- [ ] transistor

# Chapter 054

- [ ] system
- [ ] systematic
- [ ] sole
- [ ] obsolete
- [ ] resolute
- [ ] resolution
- [ ] resolve
- [ ] solar
- [ ] soldier
- [ ] solemn
- [ ] solid
- [ ] solidarity
- [ ] solitary
- [ ] solo
- [ ] soluble
- [ ] solution
- [ ] solve
- [ ] absolute
- [ ] console
- [ ] consolidate

# Chapter 055

- [ ] desolate
- [ ] dissolve
- [ ] isle
- [ ] isolate
- [ ] island
- [ ] consult
- [ ] consultant
- [ ] insulate
- [ ] insult
- [ ] result
- [ ] resultant
- [ ] aspect
- [ ] expect
- [ ] expectation
- [ ] inspect
- [ ] irrespective
- [ ] perspective
- [ ] prospect
- [ ] prospective
- [ ] respect

# Chapter 056

- [ ] respective
- [ ] retrospect
- [ ] spectacle
- [ ] spectacular
- [ ] spectator
- [ ] spectrum
- [ ] suspect
- [ ] unexpected
- [ ] especially
- [ ] special
- [ ] specialist
- [ ] speciality
- [ ] specialize
- [ ] species
- [ ] specific
- [ ] specification
- [ ] specify
- [ ] speculate
- [ ] conspicuous
- [ ] spicy

# Chapter 057

- [ ] suspicion
- [ ] suspicious
- [ ] spirit
- [ ] aspire
- [ ] conspiracy
- [ ] inspiration
- [ ] inspire
- [ ] spiral
- [ ] spiritual
- [ ] desperate
- [ ] disperse
- [ ] prosper
- [ ] prosperity
- [ ] prosperous
- [ ] contact
- [ ] intact
- [ ] tactic
- [ ] architect
- [ ] architecture
- [ ] detach

# Chapter 058

- [ ] detect
- [ ] detective
- [ ] detector
- [ ] protect
- [ ] technical
- [ ] technician
- [ ] technique
- [ ] time
- [ ] intimate
- [ ] intimidate
- [ ] daytime
- [ ] estimate
- [ ] overtime
- [ ] sometime
- [ ] sometimes
- [ ] timber
- [ ] timely
- [ ] timid
- [ ] underestimate
- [ ] attempt

# Chapter 059

- [ ] contemplate
- [ ] contempt
- [ ] temper
- [ ] temperament
- [ ] temperature
- [ ] temple
- [ ] tempo
- [ ] tempt
- [ ] temptation
- [ ] determine
- [ ] term
- [ ] terminal
- [ ] terminate
- [ ] tin
- [ ] bulletin
- [ ] continent
- [ ] continual
- [ ] continue
- [ ] continuous
- [ ] tiny

# Chapter 060

- [ ] contain
- [ ] container
- [ ] detain
- [ ] entertain
- [ ] entertainment
- [ ] obtain
- [ ] retain
- [ ] attain
- [ ] tomb
- [ ] accustomed
- [ ] atom
- [ ] bottom
- [ ] custom
- [ ] customary
- [ ] customer
- [ ] tomato
- [ ] to
- [ ] abstract
- [ ] attract
- [ ] attractive

# Chapter 061

- [ ] contract
- [ ] distract
- [ ] extract
- [ ] tractor
- [ ] subtract
- [ ] vacant
- [ ] vacation
- [ ] vacuum
- [ ] evacuate
- [ ] vague
- [ ] extravagant
- [ ] equivalent
- [ ] evaluate
- [ ] interval
- [ ] invalid
- [ ] invaluable
- [ ] prevalent
- [ ] valid
- [ ] valley
- [ ] valuable

# Chapter 062

- [ ] value
- [ ] advent
- [ ] adventure
- [ ] avenue
- [ ] convenience
- [ ] convenient
- [ ] convention
- [ ] conventional
- [ ] event
- [ ] eventually
- [ ] intervene
- [ ] revenge
- [ ] invent
- [ ] invention
- [ ] inventory
- [ ] prevent
- [ ] revenue
- [ ] ventilate
- [ ] venture
- [ ] advance

# Chapter 063

- [ ] advantage
- [ ] van
- [ ] vanish
- [ ] vanity
- [ ] evade
- [ ] invade
- [ ] invasion
- [ ] verse
- [ ] adverb
- [ ] adverse
- [ ] advertise
- [ ] anniversary
- [ ] average
- [ ] avert
- [ ] beverage
- [ ] controversial
- [ ] controversy
- [ ] conversation
- [ ] conversely
- [ ] conversion

# Chapter 064

- [ ] convert
- [ ] diverse
- [ ] diversion
- [ ] divert
- [ ] inverse
- [ ] invert
- [ ] reverse
- [ ] shiver
- [ ] silver
- [ ] universal
- [ ] universe
- [ ] university
- [ ] verb
- [ ] verbal
- [ ] verge
- [ ] verify
- [ ] versatile
- [ ] version
- [ ] versus
- [ ] vertical

# Chapter 065

- [ ] very
- [ ] volcano
- [ ] volume
- [ ] voluntary
- [ ] volunteer
- [ ] evolution
- [ ] evolve
- [ ] involve
- [ ] revolt
- [ ] revolution
- [ ] revolutionary
- [ ] revolve
- [ ] vision
- [ ] advisable
- [ ] advise
- [ ] advice
- [ ] device
- [ ] devise
- [ ] division
- [ ] envisage

# Chapter 066

- [ ] invisible
- [ ] provision
- [ ] revise
- [ ] supervise
- [ ] visa
- [ ] visible
- [ ] visit
- [ ] visitor
- [ ] visual
- [ ] inevitable
- [ ] invitation
- [ ] invite
- [ ] vital
- [ ] divide
- [ ] dividend
- [ ] evidence
- [ ] evident
- [ ] individual
- [ ] provide
- [ ] provided

# Chapter 067

- [ ] video
- [ ] vivid
- [ ] review
- [ ] view
- [ ] viewpoint
- [ ] revive
- [ ] survival
- [ ] survive
- [ ] vigorous
- [ ] voice
- [ ] void
- [ ] avoid
- [ ] victory
- [ ] convict
- [ ] conviction
- [ ] advocate
- [ ] vocabulary
- [ ] vocal
- [ ] vocation
- [ ] evoke

# Chapter 068

- [ ] provoke


# Chapter 001

- [ ] disability
- [ ] disabled
- [ ] hearing
- [ ] eyesight
- [ ] syndrome
- [ ] infantile paralysis
- [ ] Rosalyn
- [ ] lap
- [ ] ambition
- [ ] ambitious
- [ ] dictation
- [ ] Sally
- [ ] noisy
- [ ] suitable
- [ ] entry
- [ ] beneficial
- [ ] Marty
- [ ] in other words
- [ ] clumsy
- [ ] bump

# Chapter 002

- [ ] outgoing
- [ ] adapt
- [ ] adapt to
- [ ] bench
- [ ] cut out
- [ ] microscope
- [ ] out of breath
- [ ] absence
- [ ] fellow
- [ ] annoy
- [ ] annoyed
- [ ] annoyance
- [ ] all in all
- [ ] firm
- [ ] software
- [ ] sit around
- [ ] as well as
- [ ] parrot
- [ ] tank
- [ ] tortoise

# Chapter 003

- [ ] in many ways
- [ ] psychology
- [ ] psychologically
- [ ] make fun of
- [ ] encouragement
- [ ] conduct
- [ ] mainstream
- [ ] fulfilling
- [ ] never mind
- [ ] politics
- [ ] abolish
- [ ] abolition
- [ ] resign
- [ ] slavery
- [ ] literature
- [ ] Barry Minto
- [ ] Mount Kilimanjaro
- [ ] companion
- [ ] assistance
- [ ] congratulate

# Chapter 004

- [ ] congratulation
- [ ] bowling
- [ ] graduation
- [ ] certificate
- [ ] all the best
- [ ] architect
- [ ] Sanders
- [ ] adequate
- [ ] access
- [ ] accessible
- [ ] wheelchair
- [ ] handy
- [ ] earphone
- [ ] impair
- [ ] row
- [ ] basement
- [ ] outwards
- [ ] exit
- [ ] meet with
- [ ] approval

# Chapter 005

- [ ] dignity
- [ ] profit
- [ ] italics
- [ ] community
- [ ] household
- [ ] fiction
- [ ] desire
- [ ] Isaac Asimov
- [ ] satisfaction
- [ ] Larry Belmont
- [ ] test out
- [ ] Claire
- [ ] bonus
- [ ] alarm
- [ ] alarmed
- [ ] apron
- [ ] sympathy
- [ ] overweight
- [ ] elegant
- [ ] Gladys Claffern

# Chapter 006

- [ ] favour
- [ ] pile
- [ ] scan
- [ ] fingernail
- [ ] absurd
- [ ] haircut
- [ ] makeup
- [ ] accompany
- [ ] cushion
- [ ] bedding
- [ ] necklace
- [ ] clerk
- [ ] counter
- [ ] ring up
- [ ] turn around
- [ ] awful
- [ ] affair
- [ ] armchair
- [ ] declare
- [ ] cuisine

# Chapter 007

- [ ] envy
- [ ] leave…alone
- [ ] digital
- [ ] mailbox
- [ ] state
- [ ] aside
- [ ] set aside
- [ ] grand
- [ ] Marion
- [ ] alphabetical
- [ ] receiver
- [ ] in all
- [ ] affection
- [ ] bound
- [ ] be bound to
- [ ] biography
- [ ] holy
- [ ] imagination
- [ ] transfusion
- [ ] part-time

# Chapter 008

- [ ] master’s degree
- [ ] staff
- [ ] Philadelphia
- [ ] navy
- [ ] junior
- [ ] PhD=Doctor of Philosophy
- [ ] biochemistry
- [ ] Boston
- [ ] talent
- [ ] chapter
- [ ] the Foundation
- [ ] empire
- [ ] theoretical
- [ ] framework
- [ ] thinking
- [ ] divorce
- [ ] obey
- [ ] disobey
- [ ] assessment
- [ ] snorkel

# Chapter 009

- [ ] aquarium
- [ ] anecdote
- [ ] Clancy
- [ ] baleen
- [ ] baleen whale
- [ ] annual
- [ ] migration
- [ ] witness
- [ ] accommodation
- [ ] shore
- [ ] offshore
- [ ] opposite
- [ ] yell
- [ ] pause
- [ ] oar
- [ ] telescope
- [ ] teamwork
- [ ] blow-hole
- [ ] dive
- [ ] flee

# Chapter 010

- [ ] harpoon
- [ ] drag
- [ ] depth
- [ ] meantime
- [ ] in the meantime
- [ ] lip
- [ ] overboard
- [ ] urge
- [ ] abandon
- [ ] shark
- [ ] Help (…) out
- [ ] relationship
- [ ] conservation
- [ ] iceberg
- [ ] jog
- [ ] seaside
- [ ] net
- [ ] target
- [ ] tide
- [ ] driftnet

# Chapter 011

- [ ] dimension
- [ ] reflect
- [ ] pure
- [ ] cell
- [ ] aware
- [ ] become aware of
- [ ] be aware of
- [ ] vivid
- [ ] neat
- [ ] seaweed
- [ ] narrow
- [ ] flashlight
- [ ] upside down
- [ ] suck
- [ ] sea-slug
- [ ] turtle
- [ ] eel
- [ ] sharp
- [ ] tasty
- [ ] giant

# Chapter 012

- [ ] clam
- [ ] grey
- [ ] scare
- [ ] (be) scared to death
- [ ] shallow
- [ ] steep
- [ ] boundary
- [ ] Antarctic
- [ ] the Antarctic
- [ ] awesome
- [ ] leap
- [ ] seal
- [ ] refund
- [ ] pension
- [ ] pensioner
- [ ] airmail
- [ ] Papua
- [ ] fortnight
- [ ] hear from
- [ ] (be) dying to

# Chapter 013

- [ ] roof
- [ ] muddy
- [ ] textbook
- [ ] concept
- [ ] bucket
- [ ] the other day
- [ ] weekly
- [ ] bubble
- [ ] relevant
- [ ] remote
- [ ] ridge
- [ ] weed
- [ ] hut
- [ ] rectangle
- [ ] rectangular
- [ ] adjust
- [ ] platform
- [ ] broom
- [ ] tin
- [ ] jar

# Chapter 014

- [ ] sniff
- [ ] participate
- [ ] interpreter
- [ ] grill
- [ ] dry out
- [ ] leftover
- [ ] evil
- [ ] dry up
- [ ] otherwise
- [ ] privilege
- [ ] paperwork
- [ ] arrangement
- [ ] toast
- [ ] comb
- [ ] astronaut
- [ ] angle
- [ ] catalogue
- [ ] donate
- [ ] voluntary
- [ ] in need

# Chapter 015

- [ ] purchase
- [ ] anniversary
- [ ] seed
- [ ] seedling
- [ ] vaccination
- [ ] loan
- [ ] sew
- [ ] sewing machine
- [ ] supplement
- [ ] ox
- [ ] plough
- [ ] trunk
- [ ] trunk library
- [ ] tractor
- [ ] Kenya
- [ ] Bangladesh
- [ ] click
- [ ] tailor
- [ ] Tanzania
- [ ] economic

# Chapter 016

- [ ] political
- [ ] Nepal
- [ ] Uganda
- [ ] distribute
- [ ] distribution
- [ ] financial
- [ ] security
- [ ] operate
- [ ] Sudan
- [ ] clinic
- [ ] Malawi
- [ ] adjust to
- [ ] keep it up
- [ ] fit in
- [ ] motherland
- [ ] visa
- [ ] queue
- [ ] cafeteria
- [ ] lecture
- [ ] qualification

# Chapter 017

- [ ] preparation
- [ ] recommend
- [ ] shopkeeper
- [ ] idiom
- [ ] comfort
- [ ] substitute
- [ ] academic
- [ ] requirement
- [ ] essay
- [ ] tutor
- [ ] revise
- [ ] revision
- [ ] draft
- [ ] numb
- [ ] acknowledge
- [ ] as far as one is concerned
- [ ] contradict
- [ ] autonomous
- [ ] occupy
- [ ] be occupied with

# Chapter 018

- [ ] enterprise
- [ ] apology
- [ ] seminar
- [ ] videophone
- [ ] Rugby
- [ ] bachelor
- [ ] bachelor’s degree
- [ ] routine
- [ ] minibus
- [ ] optional
- [ ] day in and day out
- [ ] cage
- [ ] bark
- [ ] battery
- [ ] site
- [ ] Julie
- [ ] Abigail
- [ ] drill
- [ ] oilfield
- [ ] Jamie

# Chapter 019

- [ ] Sam
- [ ] Lima
- [ ] Cuzco
- [ ] the Andes
- [ ] Peru
- [ ] Lia
- [ ] agent
- [ ] travel agent
- [ ] geographical
- [ ] parallel
- [ ] Lake Titicaca
- [ ] abundant
- [ ] Inca
- [ ] govern
- [ ] onwards
- [ ] destination
- [ ] Machu Picchu
- [ ] inn
- [ ] out of the question
- [ ] hike

# Chapter 020

- [ ] Puno
- [ ] tomb
- [ ] the Amazon
- [ ] settle in


# Chapter 001

- [ ] man-made
- [ ] natural
- [ ] wonder
- [ ] discussion
- [ ] eastern
- [ ] though
- [ ] loud
- [ ] wow
- [ ] opinion
- [ ] in one's opinion
- [ ] more than
- [ ] electricity
- [ ] millions of
- [ ] below
- [ ] shine
- [ ] sign
- [ ] silent
- [ ] silver
- [ ] sky
- [ ] grey

# Chapter 002

- [ ] go through
- [ ] beside
- [ ] reply
- [ ] clear
- [ ] fall away
- [ ] stream
- [ ] nearly
- [ ] on top of
- [ ] canyon
- [ ] remain
- [ ] by
- [ ] found
- [ ] since then
- [ ] flag
- [ ] until
- [ ] off
- [ ] all kinds of
- [ ] vacation
- [ ] take a vacation
- [ ] season

# Chapter 003

- [ ] kid
- [ ] have fun
- [ ] band
- [ ] UK
- [ ] as soon as
- [ ] fourth
- [ ] sixth
- [ ] seventh
- [ ] eighth
- [ ] ninth
- [ ] tenth
- [ ] twelfth
- [ ] twentieth
- [ ] among
- [ ] speech
- [ ] pioneer
- [ ] grow
- [ ] corn
- [ ] following
- [ ] lay

# Chapter 004

- [ ] lay the table
- [ ] over
- [ ] dish
- [ ] parade
- [ ] ourselves
- [ ] including
- [ ] medal
- [ ] attend
- [ ] broad
- [ ] once again
- [ ] doctor
- [ ] degree
- [ ] whatever
- [ ] give up
- [ ] amazing
- [ ] will
- [ ] victory
- [ ] simply
- [ ] Canadian
- [ ] sick

# Chapter 005

- [ ] soldier
- [ ] treat
- [ ] war
- [ ] wound
- [ ] die for
- [ ] wounded
- [ ] realise
- [ ] dying
- [ ] care
- [ ] take care of
- [ ] tool
- [ ] invention
- [ ] at that time
- [ ] on one's own
- [ ] useful
- [ ] rest
- [ ] himself
- [ ] manage
- [ ] operation
- [ ] continue

# Chapter 006

- [ ] die of
- [ ] Canada
- [ ] platform
- [ ] meeting
- [ ] miss
- [ ] shut
- [ ] lock
- [ ] simple
- [ ] anybody
- [ ] clock
- [ ] ring
- [ ] passenger
- [ ] address
- [ ] text
- [ ] text message
- [ ] couple
- [ ] a couple of
- [ ] actually
- [ ] Manage
- [ ] unhappy

# Chapter 007

- [ ] turn off
- [ ] order
- [ ] be worried about
- [ ] business
- [ ] on business
- [ ] sofa
- [ ] snack
- [ ] midnight
- [ ] wake up
- [ ] hand in
- [ ] empty
- [ ] unable
- [ ] all day long
- [ ] burn
- [ ] cup
- [ ] task
- [ ] upstairs
- [ ] exhibition
- [ ] rule
- [ ] against the rules

# Chapter 008

- [ ] in trouble
- [ ] tail
- [ ] rope
- [ ] entry
- [ ] No entry.
- [ ] no good
- [ ] no wonder
- [ ] missing
- [ ] downstairs
- [ ] punish
- [ ] communications
- [ ] physics
- [ ] chemistry
- [ ] dig
- [ ] coal
- [ ] energy
- [ ] X-ray
- [ ] experiment
- [ ] sand
- [ ] control

# Chapter 009

- [ ] truck
- [ ] wheel
- [ ] compare ⋯ with ⋯
- [ ] of all ages
- [ ] whole
- [ ] deal
- [ ] exam
- [ ] fail
- [ ] guitar
- [ ] instrument
- [ ] musical
- [ ] habit
- [ ] get into the habit of ⋯
- [ ] schoolwork
- [ ] volunteer
- [ ] necessary
- [ ] shame
- [ ] instead
- [ ] instead of
- [ ] community

# Chapter 010

- [ ] knowledge
- [ ] point
- [ ] consider
- [ ] last word
- [ ] come round
- [ ] reason
- [ ] try out
- [ ] angry
- [ ] no longer
- [ ] be angry with sb.
- [ ] repair
- [ ] truth
- [ ] least
- [ ] at least
- [ ] honest
- [ ] apologise
- [ ] bill
- [ ] pocket money
- [ ] discuss
- [ ] thinker

# Chapter 011

- [ ] wise
- [ ] review
- [ ] influence
- [ ] sense
- [ ] make sense
- [ ] by the way
- [ ] suppose
- [ ] well-known
- [ ] adventure
- [ ] get into trouble
- [ ] run away
- [ ] escape
- [ ] cave
- [ ] dead
- [ ] for a time
- [ ] neighbour
- [ ] funeral
- [ ] surprised
- [ ] alive
- [ ] southern

# Chapter 012

- [ ] state
- [ ] pay for
- [ ] action
- [ ] everyday
- [ ] dialogue
- [ ] stand for
- [ ] memory
- [ ] Point
- [ ] decision
- [ ] excuse
- [ ] noon
- [ ] seat
- [ ] no way
- [ ] fair
- [ ] kick
- [ ] mad
- [ ] sportsman
- [ ] high jump
- [ ] ability
- [ ] hurdling

# Chapter 013

- [ ] sportswoman
- [ ] race
- [ ] record
- [ ] method
- [ ] hurdles
- [ ] Japan
- [ ] break
- [ ] sportsperson
- [ ] Asian
- [ ] suffer
- [ ] suffer from
- [ ] first place
- [ ] stop sb. (from) doing sth.
- [ ] courage
- [ ] pride
- [ ] take pride in
- [ ] borrow
- [ ] put up
- [ ] website
- [ ] mail

# Chapter 014

- [ ] textbook
- [ ] mainly
- [ ] thousands of
- [ ] page
- [ ] electronic
- [ ] technology
- [ ] powerful
- [ ] Memory
- [ ] full
- [ ] fix
- [ ] instructions
- [ ] lend
- [ ] properly
- [ ] look through
- [ ] printing
- [ ] at a time
- [ ] by hand
- [ ] development
- [ ] trade
- [ ] result

# Chapter 015

- [ ] spread
- [ ] in a way
- [ ] compare ⋯ to
- [ ] introduction
- [ ] amount
- [ ] store
- [ ] varied
- [ ] form
- [ ] connection
- [ ] single
- [ ] direction
- [ ] replace
- [ ] wait and see
- [ ] here we go
- [ ] central
- [ ] according to
- [ ] magical
- [ ] height
- [ ] sailing boat
- [ ] northeast

# Chapter 016

- [ ] sheep
- [ ] hat
- [ ] keep x
- [ ] keep sb./sth. away
- [ ] fly
- [ ] scissors
- [ ] cut sth. off sth.
- [ ] wool
- [ ] diary
- [ ] keep a diary
- [ ] hate
- [ ] ant
- [ ] brush
- [ ] brush sth. off sth.
- [ ] at the time
- [ ] be surprised at
- [ ] period
- [ ] spirit
- [ ] relationship
- [ ] relative

# Chapter 017

- [ ] ham
- [ ] salad
- [ ] grape
- [ ] surf
- [ ] kangaroo
- [ ] riding
- [ ] lazy
- [ ] ride
- [ ] bet
- [ ] you bet
- [ ] the thing is
- [ ] general
- [ ] standard
- [ ] feeling
- [ ] difficulty
- [ ] subject
- [ ] add
- [ ] recently
- [ ] menu
- [ ] be in with a chance

# Chapter 018

- [ ] tonight
- [ ] read out
- [ ] winner
- [ ] compared with
- [ ] even though
- [ ] rush
- [ ] blouse
- [ ] skirt
- [ ] protect sth. against sth.
- [ ] singer
- [ ] congratulations
- [ ] headmaster
- [ ] present
- [ ] factory
- [ ] pollute
- [ ] recycle
- [ ] waste
- [ ] enemy
- [ ] crop
- [ ] kill

# Chapter 019

- [ ] oil
- [ ] less
- [ ] hopeless
- [ ] china
- [ ] divide
- [ ] plastic
- [ ] policy
- [ ] reuse
- [ ] bottle
- [ ] throw away
- [ ] repeat
- [ ] reduce
- [ ] cloth
- [ ] ton
- [ ] tons of
- [ ] rubber
- [ ] recycling
- [ ] rapid
- [ ] step
- [ ] grandson

# Chapter 020

- [ ] granddaughter


# Chapter 001

- [ ] crayon
- [ ] eraser
- [ ] glove
- [ ] wallet
- [ ] watch
- [ ] whose
- [ ] first of all
- [ ] lose
- [ ] find
- [ ] lost and found box
- [ ] mine
- [ ] yours
- [ ] tape
- [ ] purple
- [ ] hers
- [ ] careful
- [ ] be careful with
- [ ] on
- [ ] from now on
- [ ] here is/are ⋯

# Chapter 002

- [ ] camera
- [ ] phone
- [ ] mobile phone
- [ ] lost and found office
- [ ] in a hurry
- [ ] leave
- [ ] plane
- [ ] taxi
- [ ] why
- [ ] airport
- [ ] hundred
- [ ] hundreds of
- [ ] look for
- [ ] thousand
- [ ] strange
- [ ] boat
- [ ] duck
- [ ] pig
- [ ] sausage
- [ ] play

# Chapter 003

- [ ] tennis
- [ ] piano
- [ ] ride
- [ ] club
- [ ] term
- [ ] board
- [ ] would like
- [ ] well
- [ ] all
- [ ] that's all
- [ ] worry
- [ ] worry about
- [ ] teach
- [ ] then
- [ ] monitor
- [ ] start
- [ ] get on well with sb.
- [ ] ready
- [ ] ready to do sth.
- [ ] promise

# Chapter 004

- [ ] fast
- [ ] fit
- [ ] just
- [ ] ball
- [ ] game
- [ ] team
- [ ] best
- [ ] score
- [ ] tidy
- [ ] sure
- [ ] everybody
- [ ] just like
- [ ] beautiful
- [ ] fly
- [ ] kite
- [ ] swim
- [ ] go over
- [ ] picnic
- [ ] housework
- [ ] else

# Chapter 005

- [ ] nobody
- [ ] at
- [ ] nothing
- [ ] silly
- [ ] fantastic
- [ ] forward
- [ ] look forward to
- [ ] fan
- [ ] make friends
- [ ] shirt
- [ ] cheer
- [ ] player
- [ ] hope
- [ ] win
- [ ] enjoy oneself
- [ ] myself
- [ ] during
- [ ] May
- [ ] May Day
- [ ] late

# Chapter 006

- [ ] walk
- [ ] take a walk
- [ ] country
- [ ] second
- [ ] collect
- [ ] litter
- [ ] fun
- [ ] summer holiday
- [ ] camp
- [ ] Australian
- [ ] sightseeing
- [ ] go sightseeing
- [ ] beach
- [ ] early
- [ ] chalk
- [ ] ruler
- [ ] carry
- [ ] change
- [ ] everything
- [ ] future

# Chapter 007

- [ ] in the future
- [ ] life
- [ ] need
- [ ] will
- [ ] maybe
- [ ] ask
- [ ] question
- [ ] by
- [ ] level
- [ ] able
- [ ] be able to
- [ ] more
- [ ] not ⋯ any more
- [ ] free
- [ ] air
- [ ] land
- [ ] machine
- [ ] rain
- [ ] robot
- [ ] sea

# Chapter 008

- [ ] space
- [ ] traffic
- [ ] jam
- [ ] traffic jam
- [ ] wind
- [ ] true
- [ ] come true
- [ ] here is/are
- [ ] bike (=bicycle)
- [ ] car
- [ ] cheap
- [ ] everywhere
- [ ] not only ⋯ but also ⋯
- [ ] into
- [ ] long
- [ ] heavy
- [ ] light
- [ ] easy
- [ ] working
- [ ] hour

# Chapter 009

- [ ] short
- [ ] rise
- [ ] as well
- [ ] market
- [ ] supermarket
- [ ] biscuit
- [ ] lemon
- [ ] strawberry
- [ ] Mother's Day
- [ ] size
- [ ] take
- [ ] may
- [ ] try
- [ ] try on
- [ ] certainly
- [ ] wait a minute
- [ ] sale
- [ ] price
- [ ] look
- [ ] fresh

# Chapter 010

- [ ] advantage
- [ ] anyone
- [ ] anything
- [ ] anywhere
- [ ] compare
- [ ] pay
- [ ] post
- [ ] product
- [ ] receive
- [ ] safe
- [ ] several
- [ ] online
- [ ] shopping
- [ ] way
- [ ] one of ⋯⋯
- [ ] almost
- [ ] something
- [ ] later
- [ ] open
- [ ] out

# Chapter 011

- [ ] go out
- [ ] over
- [ ] one day
- [ ] one
- [ ] bank
- [ ] museum
- [ ] along
- [ ] across
- [ ] cross
- [ ] opposite
- [ ] tourist
- [ ] excuse
- [ ] excuse me
- [ ] street
- [ ] turn
- [ ] third
- [ ] guidebook
- [ ] bookshop
- [ ] right
- [ ] Why not ⋯?

# Chapter 012

- [ ] could
- [ ] underground
- [ ] Take
- [ ] tour
- [ ] square
- [ ] middle
- [ ] famous
- [ ] painting
- [ ] from
- [ ] metre (AmE meter)
- [ ] above
- [ ] river
- [ ] clear
- [ ] bridge
- [ ] railway
- [ ] past
- [ ] church
- [ ] finish
- [ ] high
- [ ] post office

# Chapter 013

- [ ] up
- [ ] down
- [ ] stop
- [ ] horse
- [ ] born
- [ ] strict
- [ ] friendly
- [ ] primary
- [ ] primary school
- [ ] town
- [ ] US
- [ ] hey
- [ ] village
- [ ] nice
- [ ] good
- [ ] difficult
- [ ] bathroom
- [ ] bedroom
- [ ] garden
- [ ] living room

# Chapter 014

- [ ] east
- [ ] coast
- [ ] ago
- [ ] store
- [ ] movie theater (BrE theatre)
- [ ] bored
- [ ] president
- [ ] comfortable
- [ ] lake
- [ ] last
- [ ] yesterday
- [ ] hair
- [ ] gold
- [ ] forest
- [ ] once
- [ ] upon
- [ ] once upon a time
- [ ] decide
- [ ] go for a walk
- [ ] basket

# Chapter 015

- [ ] notice
- [ ] all alone
- [ ] dark
- [ ] pick
- [ ] pick up
- [ ] soon
- [ ] lost
- [ ] around
- [ ] little
- [ ] towards
- [ ] knock
- [ ] door
- [ ] answer
- [ ] push
- [ ] enter
- [ ] bowl
- [ ] hungry
- [ ] Right
- [ ] Finish
- [ ] either

# Chapter 016

- [ ] piece
- [ ] in pieces
- [ ] asleep
- [ ] return
- [ ] cry
- [ ] at first
- [ ] point
- [ ] point at
- [ ] shout
- [ ] jump
- [ ] without
- [ ] part
- [ ] March
- [ ] April
- [ ] June
- [ ] Women's Day
- [ ] National Day
- [ ] Children's Day
- [ ] July
- [ ] August

# Chapter 017

- [ ] September
- [ ] October
- [ ] November
- [ ] December
- [ ] writer
- [ ] find out
- [ ] real
- [ ] at the age of
- [ ] newspaper
- [ ] exact
- [ ] date
- [ ] become
- [ ] in the 1860s
- [ ] Play
- [ ] poem
- [ ] marry
- [ ] successful
- [ ] work
- [ ] build
- [ ] fire

# Chapter 018

- [ ] die
- [ ] rich
- [ ] language
- [ ] around the world
- [ ] young
- [ ] Pacific
- [ ] so
- [ ] guess
- [ ] excited
- [ ] wow
- [ ] arrive
- [ ] relax
- [ ] world-famous
- [ ] French
- [ ] sell
- [ ] top
- [ ] till
- [ ] Light
- [ ] wonderful
- [ ] palace

# Chapter 019

- [ ] bow
- [ ] kiss
- [ ] shake
- [ ] shake hands
- [ ] smile
- [ ] British
- [ ] German
- [ ] Japanese
- [ ] Russian
- [ ] visitor
- [ ] 2ussian
- [ ] what
- [ ] nod
- [ ] head
- [ ] hug
- [ ] each
- [ ] each other
- [ ] India
- [ ] together
- [ ] Maori

# Chapter 020

- [ ] touch
- [ ] nose
- [ ] finger
- [ ] foot
- [ ] knee
- [ ] leg
- [ ] mouth
- [ ] body
- [ ] foreign
- [ ] North American
- [ ] personal
- [ ] arm
- [ ] arm in arm
- [ ] South American
- [ ] hold
- [ ] move
- [ ] Britain
- [ ] not at all
- [ ] polite
- [ ] somewhere

# Chapter 021

- [ ] wave
- [ ] fact
- [ ] in fact
- [ ] rude
- [ ] bring
- [ ] lively
- [ ] modern
- [ ] noisy
- [ ] pop (=popular)
- [ ] rock
- [ ] sound
- [ ] violin
- [ ] Western
- [ ] hmm
- [ ] By
- [ ] through
- [ ] both
- [ ] opera
- [ ] voice
- [ ] drum

# Chapter 022

- [ ] believe
- [ ] musician
- [ ] centre (AmE center)
- [ ] European
- [ ] classical
- [ ] century
- [ ] composer
- [ ] elder
- [ ] waltz
- [ ] dance music
- [ ] another
- [ ] Piece
- [ ] poor
- [ ] perfect
- [ ] sad
- [ ] slow
- [ ] feel
- [ ] ship

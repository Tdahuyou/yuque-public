
# Chapter 001

- [ ] guitar
- [ ] sing
- [ ] swim
- [ ] dance
- [ ] draw
- [ ] chess
- [ ] play  chess
- [ ] speak
- [ ] speak  English
- [ ] join
- [ ] club
- [ ] be good at…
- [ ] tell
- [ ] story
- [ ] write
- [ ] show
- [ ] or
- [ ] talk
- [ ] talk to …
- [ ] kungfu

# Chapter 002

- [ ] drum
- [ ] play the drums
- [ ] piano
- [ ] play the piano
- [ ] violin
- [ ] play the violin
- [ ] also
- [ ] people
- [ ] home
- [ ] be good with…
- [ ] make
- [ ] make friends
- [ ] today
- [ ] help (sb) with sth
- [ ] center
- [ ] weekend
- [ ] on the weekend
- [ ] teach
- [ ] musician
- [ ] up

# Chapter 003

- [ ] get up
- [ ] dress
- [ ] get dressed
- [ ] brush
- [ ] tooth
- [ ] shower
- [ ] take a shower
- [ ] usually
- [ ] forty
- [ ] Wow
- [ ] never
- [ ] early
- [ ] fifty
- [ ] job
- [ ] work
- [ ] station
- [ ] radio station
- [ ] o'clock
- [ ] night
- [ ] funny

# Chapter 004

- [ ] exercise
- [ ] on weekends
- [ ] best
- [ ] half
- [ ] past
- [ ] quarter
- [ ] homework
- [ ] do (one’s) homework
- [ ] run
- [ ] clean
- [ ] walk
- [ ] take a walk
- [ ] quickly
- [ ] either
- [ ] Either…or ……
- [ ] lot
- [ ] lots of
- [ ] sometimes
- [ ] taste
- [ ] Life

# Chapter 005

- [ ] train
- [ ] bus
- [ ] subway
- [ ] take the subway
- [ ] ride
- [ ] bike
- [ ] ride a bike
- [ ] sixty
- [ ] seventy
- [ ] eighty
- [ ] ninety
- [ ] hundred
- [ ] minute
- [ ] far
- [ ] kilometer
- [ ] new
- [ ] every
- [ ] every day
- [ ] by
- [ ] by bike

# Chapter 006

- [ ] drive
- [ ] car
- [ ] live
- [ ] stop
- [ ] think of
- [ ] cross
- [ ] river
- [ ] many
- [ ] village
- [ ] between
- [ ] between… and…
- [ ] bridge
- [ ] boat
- [ ] ropeway
- [ ] year
- [ ] afraid
- [ ] like
- [ ] leave
- [ ] dream
- [ ] true

# Chapter 007

- [ ] come true
- [ ] rule
- [ ] arrive
- [ ] (be) on time
- [ ] hallway
- [ ] hall
- [ ] dining hall
- [ ] listen
- [ ] listen to…
- [ ] fight
- [ ] sorry
- [ ] outside
- [ ] wear
- [ ] important
- [ ] bring
- [ ] uniform
- [ ] quiet
- [ ] out
- [ ] go out
- [ ] practice

# Chapter 008

- [ ] dish
- [ ] do the dishes
- [ ] before
- [ ] make (one’s) bed
- [ ] dirty
- [ ] kitchen
- [ ] more
- [ ] noisy
- [ ] relax
- [ ] read
- [ ] terrible
- [ ] feel
- [ ] strict
- [ ] be strict (with sb)
- [ ] remember
- [ ] follow
- [ ] follow the rules
- [ ] luck
- [ ] keep
- [ ] hair

# Chapter 009

- [ ] learn
- [ ] panda
- [ ] zoo
- [ ] tiger
- [ ] elephant
- [ ] koala
- [ ] lion
- [ ] giraffe
- [ ] animal
- [ ] cute
- [ ] lazy
- [ ] smart
- [ ] beautiful
- [ ] scary
- [ ] kind
- [ ] kind of
- [ ] Australia
- [ ] south
- [ ] Africa
- [ ] South  Africa

# Chapter 010

- [ ] pet
- [ ] leg
- [ ] cat
- [ ] sleep
- [ ] friendly
- [ ] shy
- [ ] save
- [ ] symbol
- [ ] flag
- [ ] forget
- [ ] get lost
- [ ] place
- [ ] water
- [ ] danger
- [ ] be in (great) danger
- [ ] cut
- [ ] down
- [ ] cut down
- [ ] tree
- [ ] kill

# Chapter 011

- [ ] ivory
- [ ] over
- [ ] (be) made of
- [ ] Julie
- [ ] Becky
- [ ] Thailand
- [ ] Thai
- [ ] newspaper
- [ ] read a newspaper
- [ ] use
- [ ] Soup
- [ ] make soup
- [ ] wash
- [ ] movie
- [ ] go to movies
- [ ] just
- [ ] eat out
- [ ] house
- [ ] drink
- [ ] tea

# Chapter 012

- [ ] drink  tea
- [ ] tomorrow
- [ ] pool
- [ ] shop
- [ ] supermarket
- [ ] man
- [ ] race
- [ ] host
- [ ] study
- [ ] state
- [ ] the United States
- [ ] American
- [ ] dragon
- [ ] Dragon Boat Festival
- [ ] any
- [ ] other
- [ ] young
- [ ] children
- [ ] miss
- [ ] wish

# Chapter 013

- [ ] delicious
- [ ] still
- [ ] living room
- [ ] rain
- [ ] windy
- [ ] cloudy
- [ ] sunny
- [ ] snow
- [ ] weather
- [ ] cook
- [ ] bad
- [ ] park
- [ ] message
- [ ] take a message
- [ ] him
- [ ] could
- [ ] back
- [ ] call(sb)back
- [ ] problem
- [ ] again

# Chapter 014

- [ ] dry
- [ ] cold
- [ ] hot
- [ ] warm
- [ ] visit
- [ ] Canada
- [ ] summer
- [ ] sit
- [ ] juice
- [ ] soon
- [ ] vacation
- [ ] on(a)vacation
- [ ] hard
- [ ] Europe
- [ ] mountain
- [ ] country
- [ ] skate
- [ ] snowy
- [ ] winter
- [ ] Russian

# Chapter 015

- [ ] snowman
- [ ] rainy
- [ ] Moscow
- [ ] Toronto
- [ ] Boston
- [ ] post
- [ ] office
- [ ] post office
- [ ] police
- [ ] police station
- [ ] hotel
- [ ] restaurant
- [ ] bank
- [ ] hospital
- [ ] street
- [ ] pay
- [ ] pay phone
- [ ] near
- [ ] across
- [ ] across from

# Chapter 016

- [ ] front
- [ ] in front of
- [ ] behind
- [ ] town
- [ ] around
- [ ] north
- [ ] along
- [ ] go along
- [ ] turn
- [ ] right
- [ ] left
- [ ] turn right/left
- [ ] crossing
- [ ] neighborhood
- [ ] spend
- [ ] spend time
- [ ] climb
- [ ] road
- [ ] often
- [ ] air

# Chapter 017

- [ ] sunshine
- [ ] free
- [ ] enjoy
- [ ] enjoy reading
- [ ] easily
- [ ] money
- [ ] curly
- [ ] straight
- [ ] tall
- [ ] medium
- [ ] height
- [ ] of medium height
- [ ] thin
- [ ] heavy
- [ ] build
- [ ] of medium build
- [ ] tonight
- [ ] little
- [ ] a little
- [ ] cinema

# Chapter 018

- [ ] glasses
- [ ] later
- [ ] handsome
- [ ] actor
- [ ] actress
- [ ] person
- [ ] nose
- [ ] blonde
- [ ] mouth
- [ ] round
- [ ] face
- [ ] eye
- [ ] singer
- [ ] artist
- [ ] crime
- [ ] criminal
- [ ] put
- [ ] each
- [ ] way
- [ ] describe

# Chapter 019

- [ ] differently
- [ ] another
- [ ] end
- [ ] in the end
- [ ] real
- [ ] jeans
- [ ] noodle
- [ ] mutton
- [ ] beef
- [ ] cabbage
- [ ] potato
- [ ] special
- [ ] would
- [ ] would like
- [ ] yet
- [ ] large
- [ ] order
- [ ] take one's order
- [ ] size
- [ ] bowl

# Chapter 020

- [ ] one(large)bowl of
- [ ] tofu
- [ ] meat
- [ ] dumpling
- [ ] porridge
- [ ] onion
- [ ] fish
- [ ] pancake
- [ ] world
- [ ] around the world
- [ ] answer
- [ ] different
- [ ] cake
- [ ] candle
- [ ] age
- [ ] make a wish
- [ ] blow
- [ ] blow out
- [ ] if
- [ ] will

# Chapter 021

- [ ] the UK
- [ ] candy
- [ ] lucky
- [ ] popular
- [ ] get popular
- [ ] cut up
- [ ] idea
- [ ] bring good luck to…
- [ ] milk
- [ ] cow
- [ ] milk a cow
- [ ] horse
- [ ] ride a horse
- [ ] feed
- [ ] feed chickens
- [ ] farmer
- [ ] quite
- [ ] quite a lot(of…)
- [ ] anything
- [ ] grow

# Chapter 022

- [ ] farm
- [ ] pick
- [ ] excellent
- [ ] countryside
- [ ] in the countryside
- [ ] yesterday
- [ ] flower
- [ ] worry
- [ ] luckily
- [ ] sun
- [ ] museum
- [ ] fire
- [ ] fire station
- [ ] painting
- [ ] exciting
- [ ] lovely
- [ ] expensive
- [ ] cheap
- [ ] slow
- [ ] fast

# Chapter 023

- [ ] robot
- [ ] guide
- [ ] gift
- [ ] all in all
- [ ] everything
- [ ] interested
- [ ] be interested in
- [ ] dark
- [ ] hear
- [ ] camp
- [ ] lake
- [ ] beach
- [ ] badminton
- [ ] sheep
- [ ] as
- [ ] natural
- [ ] butterfly
- [ ] visitor
- [ ] tired
- [ ] stay

# Chapter 024

- [ ] stay up late
- [ ] away
- [ ] run away
- [ ] mouse
- [ ] baby
- [ ] shout
- [ ] shout at…
- [ ] woof
- [ ] language
- [ ] fly
- [ ] kite
- [ ] fly a kite
- [ ] high
- [ ] high school
- [ ] ago
- [ ] India
- [ ] tent
- [ ] put up
- [ ] moon
- [ ] surprise

# Chapter 025

- [ ] get a surprise
- [ ] snake
- [ ] scared
- [ ] move
- [ ] shout to…
- [ ] start
- [ ] jump
- [ ] up and down
- [ ] wake
- [ ] into
- [ ] forest
- [ ] ear

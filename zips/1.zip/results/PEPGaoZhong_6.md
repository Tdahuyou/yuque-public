
# Chapter 001

- [ ] realistic
- [ ] abstract
- [ ] sculpture
- [ ] sculptor
- [ ] gallery
- [ ] faith
- [ ] faithfully
- [ ] consequently
- [ ] aim
- [ ] conventional
- [ ] typical
- [ ] evident
- [ ] Giotto di Bondone
- [ ] renaissance
- [ ] the Renaissance
- [ ] adopt
- [ ] humanistic
- [ ] possess
- [ ] possession
- [ ] superb

# Chapter 002

- [ ] perspective
- [ ] technique
- [ ] Masaccio
- [ ] coincidence
- [ ] by coincidence
- [ ] masterpiece
- [ ] impressionism
- [ ] impressionist
- [ ] post-impressionist
- [ ] a great deal
- [ ] shadow
- [ ] ridiculous
- [ ] controversial
- [ ] attempt
- [ ] on the other hand
- [ ] predict
- [ ] landscape
- [ ] specific
- [ ] figure
- [ ] clay

# Chapter 003

- [ ] critic
- [ ] bronze
- [ ] marble
- [ ] Mona Lisa
- [ ] Leonardo da Vinci
- [ ] carve
- [ ] delicate
- [ ] Michelangelo
- [ ] canvas
- [ ] Picasso
- [ ] café
- [ ] allergic
- [ ] effectively
- [ ] exhibition
- [ ] aggressive
- [ ] scholar
- [ ] flesh
- [ ] in the flesh
- [ ] Matisse
- [ ] geometry

# Chapter 004

- [ ] bunch
- [ ] Manhattan
- [ ] avenue
- [ ] preference
- [ ] Guggenheim  Museum
- [ ] display
- [ ] appeal
- [ ] appeal to
- [ ] fragile
- [ ] circular
- [ ] metropolitan
- [ ] reputation
- [ ] civilization
- [ ] Egypt
- [ ] Egyptian
- [ ] visual
- [ ] fragrant
- [ ] Monet
- [ ] Whitney
- [ ] Madison

# Chapter 005

- [ ] contemporary
- [ ] permanent
- [ ] district
- [ ] committee
- [ ] signature
- [ ] poetry
- [ ] tick
- [ ] rhyme
- [ ] convey
- [ ] emotion
- [ ] nursery
- [ ] nursery rhyme
- [ ] concrete
- [ ] repetition
- [ ] contradictory
- [ ] hush
- [ ] mockingbird
- [ ] diamond
- [ ] brass
- [ ] billy-goat

# Chapter 006

- [ ] flexible
- [ ] pattern
- [ ] squire
- [ ] cottage
- [ ] coffin
- [ ] sparrow
- [ ] kitten
- [ ] take it easy
- [ ] run out of
- [ ] cinquain
- [ ] be made up of
- [ ] tease
- [ ] salty
- [ ] droop
- [ ] dread
- [ ] endless
- [ ] haiku
- [ ] syllable
- [ ] minimum
- [ ] translation

# Chapter 007

- [ ] branch
- [ ] melt
- [ ] brimful
- [ ] in particular
- [ ] eventually
- [ ] await
- [ ] transform
- [ ] revolve
- [ ] utter
- [ ] sorrow
- [ ] bare
- [ ] librarian
- [ ] forever
- [ ] stem
- [ ] cement
- [ ] section
- [ ] appropriate
- [ ] exchange
- [ ] diploma
- [ ] sponsor

# Chapter 008

- [ ] blank
- [ ] compass
- [ ] bride
- [ ] bridegroom
- [ ] championship
- [ ] rhythmic
- [ ] darkness
- [ ] warmth
- [ ] try out
- [ ] scholarship
- [ ] pianist
- [ ] violinist
- [ ] let out
- [ ] load
- [ ] cigarette
- [ ] alcohol
- [ ] alcoholic
- [ ] abuse
- [ ] fitness
- [ ] sexual

# Chapter 009

- [ ] stress
- [ ] stressful
- [ ] obesity
- [ ] adolescent
- [ ] adolescence
- [ ] ban
- [ ] due
- [ ] due to
- [ ] tough
- [ ] addicted
- [ ] addicted to
- [ ] nicotine
- [ ] accustom
- [ ] accustomed
- [ ] accustomed to
- [ ] withdrawal
- [ ] bad-tempered
- [ ] automatic
- [ ] automatically
- [ ] mental

# Chapter 010

- [ ] mentally
- [ ] quit
- [ ] effect
- [ ] lung
- [ ] pregnant
- [ ] abnormal
- [ ] breathless
- [ ] unfit
- [ ] strengthen
- [ ] resolve
- [ ] decide on
- [ ] packet
- [ ] feel like
- [ ] feel like doing
- [ ] relaxation
- [ ] desperate
- [ ] chemist
- [ ] gum
- [ ] chewing gum
- [ ] disappointed

# Chapter 011

- [ ] weaken
- [ ] ashamed
- [ ] comprehension
- [ ] in spite of
- [ ] take risks
- [ ] take a risk
- [ ] get into
- [ ] etc
- [ ] appendix
- [ ] illegal
- [ ] pill
- [ ] robbery
- [ ] slippery
- [ ] HIV
- [ ] AIDS
- [ ] at risk
- [ ] SARS
- [ ] immune
- [ ] survival
- [ ] sex

# Chapter 012

- [ ] fluid
- [ ] inject
- [ ] injection
- [ ] needle
- [ ] spill
- [ ] male
- [ ] female
- [ ] condom
- [ ] homosexual
- [ ] prejudice
- [ ] judgement
- [ ] disco
- [ ] abortion
- [ ] cigar
- [ ] embarrassed
- [ ] awkward
- [ ] consume
- [ ] renewable
- [ ] greenhouse
- [ ] Fahrenheit

# Chapter 013

- [ ] come about
- [ ] Sophie
- [ ] Armstrong
- [ ] graph
- [ ] random
- [ ] phenomenon
- [ ] subscribe
- [ ] subscribe to
- [ ] fossil
- [ ] fuel
- [ ] byproduct
- [ ] Janice
- [ ] Foster
- [ ] methane
- [ ] Celsius
- [ ] quantity
- [ ] quantities of
- [ ] tend
- [ ] go up
- [ ] Charles Keeling

# Chapter 014

- [ ] measurement
- [ ] per
- [ ] data
- [ ] result in
- [ ] trend
- [ ] catastrophe
- [ ] flood
- [ ] drought
- [ ] famine
- [ ] George Hambley
- [ ] oppose
- [ ] opposed
- [ ] be opposed to
- [ ] mild
- [ ] environmental
- [ ] environmentalist
- [ ] consequence
- [ ] state
- [ ] range
- [ ] even if

# Chapter 015

- [ ] keep on
- [ ] glance
- [ ] steady
- [ ] steadily
- [ ] tendency
- [ ] widespread
- [ ] on the whole
- [ ] economical
- [ ] hectare
- [ ] average
- [ ] existence
- [ ] outer
- [ ] on behalf of
- [ ] individual
- [ ] advocate
- [ ] commitment
- [ ] put up with
- [ ] pollution
- [ ] growth
- [ ] electrical

# Chapter 016

- [ ] appliance
- [ ] so long as
- [ ] casual
- [ ] and so on
- [ ] motor
- [ ] can
- [ ] circumstance
- [ ] microwave
- [ ] refresh
- [ ] educator
- [ ] contribution
- [ ] imperative
- [ ] heading
- [ ] slogan
- [ ] presentation
- [ ] nuclear
- [ ] disagreement
- [ ] diagram
- [ ] volcano
- [ ] volcanic

# Chapter 017

- [ ] volcanology
- [ ] volcanologist
- [ ] erupt
- [ ] eruption
- [ ] ash
- [ ] crater
- [ ] lava
- [ ] hurricane
- [ ] questionnaire
- [ ] alongside
- [ ] equipment
- [ ] appoint
- [ ] observatory
- [ ] database
- [ ] Mount  Kilauea
- [ ] evaluate
- [ ] burn to the ground
- [ ] wave
- [ ] molten
- [ ] fountain

# Chapter 018

- [ ] absolute
- [ ] absolutely
- [ ] spaceman
- [ ] suit
- [ ] helmet
- [ ] boot
- [ ] make one’s way
- [ ] potential
- [ ] actual
- [ ] geology
- [ ] Mount Etna
- [ ] Sicily
- [ ] sample
- [ ] candidate
- [ ] Mount Vesuvius
- [ ] threat
- [ ] bungalow
- [ ] Pompeii
- [ ] tornado
- [ ] typhoon

# Chapter 019

- [ ] thunderstorm
- [ ] precious
- [ ] novelist
- [ ] fog
- [ ] document
- [ ] rainbow
- [ ] uncomfortable
- [ ] balcony
- [ ] unconscious
- [ ] shoot
- [ ] shot
- [ ] tremble
- [ ] sweat
- [ ] anxious
- [ ] anxiety
- [ ] panic
- [ ] tsunami
- [ ] glance through
- [ ] Manchu
- [ ] vary from…to…

# Chapter 020

- [ ] diverse
- [ ] diversity
- [ ] crane
- [ ] leopard
- [ ] spectacular
- [ ] bathe
- [ ] arouse
- [ ] appreciation
- [ ] peak
- [ ] persuasion
- [ ] guarantee

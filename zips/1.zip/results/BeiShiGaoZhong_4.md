
# Chapter 001

- [ ] motivate
- [ ] technique
- [ ] native
- [ ] fluently
- [ ] achievement
- [ ] put off
- [ ] percentage
- [ ] exist
- [ ] billion
- [ ] at present
- [ ] variety
- [ ] alien
- [ ] bow
- [ ] passer-by
- [ ] applause
- [ ] Latin
- [ ] Roman
- [ ] defeat
- [ ] earn
- [ ] wallet

# Chapter 002

- [ ] out of work
- [ ] obsess
- [ ] determine
- [ ] enjoyable
- [ ] second-hand
- [ ] concern
- [ ] hardworking
- [ ] dormitory
- [ ] pleased
- [ ] give away
- [ ] aware
- [ ] drop out
- [ ] businessman
- [ ] stove
- [ ] drunk
- [ ] journalist
- [ ] greedy
- [ ] popcorn
- [ ] cigarette
- [ ] resolution

# Chapter 003

- [ ] rude
- [ ] armchair
- [ ] carpet
- [ ] vase
- [ ] bargain
- [ ] cash
- [ ] product
- [ ] fax
- [ ] scarf
- [ ] necklace
- [ ] enthusiastic
- [ ] ashamed
- [ ] firm
- [ ] aggressive
- [ ] groceries
- [ ] clothing
- [ ] annoy
- [ ] salesgirl
- [ ] salesman
- [ ] blouse

# Chapter 004

- [ ] boot
- [ ] leather
- [ ] vest
- [ ] comment
- [ ] amusement
- [ ] cookie
- [ ] appeal
- [ ] approximately
- [ ] soil
- [ ] contain
- [ ] balance
- [ ] remove
- [ ] erosion
- [ ] importance
- [ ] crop
- [ ] economy
- [ ] puzzle
- [ ] valley
- [ ] homeland
- [ ] motherland

# Chapter 005

- [ ] behave
- [ ] advance
- [ ] software
- [ ] gadget
- [ ] practical
- [ ] laptop
- [ ] mobile phone
- [ ] headphone
- [ ] wire
- [ ] bath
- [ ] signal
- [ ] freedom
- [ ] photography
- [ ] credit card
- [ ] automatic
- [ ] focus
- [ ] flash
- [ ] noisy
- [ ] customer
- [ ] cleaner

# Chapter 006

- [ ] refrigerator
- [ ] translation
- [ ] electric
- [ ] kettle
- [ ] contact
- [ ] incredibly
- [ ] truly
- [ ] textbook
- [ ] disk
- [ ] replace
- [ ] media
- [ ] chat
- [ ] quiz
- [ ] opera
- [ ] current
- [ ] affair
- [ ] photographer
- [ ] paparazzi
- [ ] bomb
- [ ] agenda

# Chapter 007

- [ ] nation
- [ ] political
- [ ] widespread
- [ ] poverty
- [ ] electricity
- [ ] AIDS
- [ ] sex
- [ ] administration
- [ ] reform
- [ ] demand
- [ ] debt
- [ ] belief
- [ ] painful
- [ ] stand for
- [ ] host
- [ ] announce
- [ ] committee
- [ ] distinction
- [ ] application
- [ ] pub

# Chapter 008

- [ ] delighted
- [ ] publish
- [ ] incident
- [ ] evidence
- [ ] explanation
- [ ] explode
- [ ] analyse
- [ ] arise
- [ ] blame
- [ ] willing
- [ ] self
- [ ] employ
- [ ] legal
- [ ] attempt
- [ ] defend
- [ ] argument
- [ ] process
- [ ] profit
- [ ] favour
- [ ] analysis

# Chapter 009

- [ ] encouragement
- [ ] onto
- [ ] attitude
- [ ] dislike
- [ ] pretend
- [ ] hire
- [ ] bush
- [ ] respect
- [ ] disagreement
- [ ] channel
- [ ] advertise
- [ ] classic
- [ ] sew
- [ ] beer
- [ ] corporation
- [ ] brand
- [ ] suitable
- [ ] consist of
- [ ] advertiser
- [ ] budget

# Chapter 010

- [ ] visually
- [ ] boom
- [ ] visual
- [ ] stand out
- [ ] concept
- [ ] approach
- [ ] humour
- [ ] contemporary
- [ ] contribution
- [ ] citizen
- [ ] niece
- [ ] nephew
- [ ] consideration
- [ ] as long as
- [ ] conclude
- [ ] innocent
- [ ] astronomer
- [ ] sightseeing
- [ ] trolleybus
- [ ] greengrocer

# Chapter 011

- [ ] southwest
- [ ] fog
- [ ] tyre
- [ ] muddy
- [ ] ankle
- [ ] spokesman
- [ ] scene
- [ ] ambulance
- [ ] strawberry
- [ ] load
- [ ] bravery
- [ ] fiction
- [ ] ex-husband
- [ ] district
- [ ] editor
- [ ] ahead
- [ ] harmful
- [ ] faithfully
- [ ] unemployment
- [ ] interrupt

# Chapter 012

- [ ] tobacco
- [ ] false
- [ ] environmental
- [ ] protection
- [ ] kangaroo
- [ ] steak
- [ ] roast
- [ ] soccer
- [ ] tip
- [ ] owe
- [ ] apology
- [ ] absorb
- [ ] brief
- [ ] expectation
- [ ] get used to
- [ ] bacon
- [ ] slice
- [ ] toast
- [ ] waiter
- [ ] waitress

# Chapter 013

- [ ] exchange
- [ ] cheque
- [ ] wander
- [ ] mushroom
- [ ] tasty
- [ ] foggy
- [ ] laughter
- [ ] majority
- [ ] anyhow
- [ ] reasonable
- [ ] mosquito
- [ ] northeast
- [ ] physician
- [ ] book
- [ ] manners
- [ ] modest
- [ ] indicate
- [ ] eastern
- [ ] curiously
- [ ] movement

# Chapter 014

- [ ] lemon
- [ ] informal
- [ ] flashlight
- [ ] cave
- [ ] cosy
- [ ] novel
- [ ] circus
- [ ] lift
- [ ] schoolmate
- [ ] headmaster
- [ ] jeep
- [ ] blanket
- [ ] sheet
- [ ] request
- [ ] parcel
- [ ] handkerchief
- [ ] canteen
- [ ] mailbox
- [ ] twin
- [ ] courtyard

# Chapter 015

- [ ] familiar
- [ ] arrival
- [ ] aspect
- [ ] splendid
- [ ] cocoa
- [ ] outgoing
- [ ] cautious
- [ ] desert
- [ ] stare
- [ ] whisper
- [ ] appetite
- [ ] yummy
- [ ] spoken
- [ ] see...off
- [ ] fur
- [ ] conduct
- [ ] band
- [ ] burglar
- [ ] bark
- [ ] injure

# Chapter 016

- [ ] educator
- [ ] erupt
- [ ] dinosaur
- [ ] detective
- [ ] earthquake
- [ ] acre
- [ ] belong
- [ ] attach
- [ ] birthplace
- [ ] chef
- [ ] fusion
- [ ] vast
- [ ] export
- [ ] fond
- [ ] outdoors
- [ ] literature
- [ ] contrary
- [ ] broad
- [ ] bear
- [ ] minority

# Chapter 017

- [ ] well-off
- [ ] unfair
- [ ] forgive
- [ ] preview
- [ ] dusk
- [ ] multi-cultural
- [ ] spot
- [ ] garlic
- [ ] apron
- [ ] ashtray
- [ ] cassette
- [ ] comb
- [ ] scissors
- [ ] dustbin
- [ ] addition
- [ ] contrast


# Chapter 001

- [ ] UK
- [ ] Canada
- [ ] USA
- [ ] China
- [ ] she
- [ ] student
- [ ] pupil
- [ ] he
- [ ] teacher
- [ ] boy
- [ ] and
- [ ] girl
- [ ] new
- [ ] friend
- [ ] today
- [ ] father
- [ ] dad
- [ ] man
- [ ] woman
- [ ] mother

# Chapter 002

- [ ] sister
- [ ] brother
- [ ] grandmother
- [ ] grandma
- [ ] grandfather
- [ ] grandpa
- [ ] family
- [ ] thin
- [ ] fat
- [ ] tall
- [ ] short
- [ ] long
- [ ] small
- [ ] big
- [ ] giraffe
- [ ] so
- [ ] children
- [ ] child
- [ ] tail
- [ ] on

# Chapter 003

- [ ] in
- [ ] under
- [ ] chair
- [ ] desk
- [ ] cap
- [ ] ball
- [ ] car
- [ ] boat
- [ ] map
- [ ] toy
- [ ] box
- [ ] pear
- [ ] apple
- [ ] orange
- [ ] banana
- [ ] watermelon
- [ ] strawberry
- [ ] grape
- [ ] buy
- [ ] fruit

# Chapter 004

- [ ] eleven
- [ ] twelve
- [ ] thirteen
- [ ] fourteen
- [ ] fifteen
- [ ] sixteen
- [ ] seventeen
- [ ] eighteen
- [ ] nineteen
- [ ] twenty
- [ ] kite
- [ ] beautiful


# Chapter 001

- [ ] mother tongue
- [ ] input
- [ ] output
- [ ] fluency
- [ ] accuracy
- [ ] punctuation
- [ ] royal
- [ ] nationwide
- [ ] thankful
- [ ] constitution
- [ ] liberty
- [ ] jungle
- [ ] cafeteria
- [ ] fold
- [ ] global
- [ ] decade
- [ ] trend
- [ ] absence
- [ ] theory
- [ ] acquisition

# Chapter 002

- [ ] attain
- [ ] surround
- [ ] curriculum
- [ ] adequate
- [ ] medium
- [ ] ensure
- [ ] accelerate
- [ ] target
- [ ] enlarge
- [ ] guarantee
- [ ] adjust
- [ ] inform
- [ ] dedication
- [ ] dedicated
- [ ] manual
- [ ] theft
- [ ] announcement
- [ ] mate
- [ ] cream
- [ ] razor

# Chapter 003

- [ ] catch on
- [ ] for ages
- [ ] brochure
- [ ] cab
- [ ] relative
- [ ] pat
- [ ] congratulate
- [ ] explicit
- [ ] eyebrow
- [ ] on purpose
- [ ] upwards
- [ ] upper
- [ ] unconscious
- [ ] rigid
- [ ] tight
- [ ] resemble
- [ ] transparent
- [ ] unrest
- [ ] merely
- [ ] purchase

# Chapter 004

- [ ] on the other hand
- [ ] negotiate
- [ ] outline
- [ ] ambiguous
- [ ] offence
- [ ] approval
- [ ] bent
- [ ] applicant
- [ ] certificate
- [ ] registration
- [ ] competence
- [ ] diploma
- [ ] marketing
- [ ] overview
- [ ] provided that
- [ ] register
- [ ] candidate
- [ ] cheers
- [ ] diagram
- [ ] caption

# Chapter 005

- [ ] booth
- [ ] barbershop
- [ ] globe
- [ ] barber
- [ ] fasten
- [ ] stewardess
- [ ] steward
- [ ] regulation
- [ ] bingo
- [ ] haircut
- [ ] amateur
- [ ] sincerely
- [ ] embarrass
- [ ] punctual
- [ ] directory
- [ ] personnel
- [ ] bet
- [ ] academy
- [ ] algebra
- [ ] geometry

# Chapter 006

- [ ] bacteria
- [ ] software
- [ ] mass
- [ ] radiation
- [ ] radium
- [ ] radioactive
- [ ] shuttle
- [ ] crew
- [ ] assist
- [ ] emotional
- [ ] technical
- [ ] journal
- [ ] issue
- [ ] recreation
- [ ] futurology
- [ ] latter
- [ ] futurologist
- [ ] seminar
- [ ] enterprise
- [ ] click

# Chapter 007

- [ ] handy
- [ ] shortly
- [ ] download
- [ ] update
- [ ] stainless
- [ ] stain
- [ ] garment
- [ ] worn
- [ ] starvation
- [ ] welfare
- [ ] discrimination
- [ ] conflict
- [ ] equality
- [ ] cell
- [ ] assess
- [ ] database
- [ ] electronic
- [ ] dawn
- [ ] digital
- [ ] source

# Chapter 008

- [ ] specialist
- [ ] participant
- [ ] present
- [ ] category
- [ ] autonomous
- [ ] programmer
- [ ] in advance
- [ ] creator
- [ ] premiere
- [ ] caveman
- [ ] give away
- [ ] take over
- [ ] official
- [ ] invest
- [ ] colleague
- [ ] hibernation
- [ ] rescue
- [ ] exit
- [ ] disconnect
- [ ] original

# Chapter 009

- [ ] operational
- [ ] instructor
- [ ] dilemma
- [ ] microscope
- [ ] procedure
- [ ] organ
- [ ] donate
- [ ] correspond
- [ ] meanwhile
- [ ] split
- [ ] premier
- [ ] outspoken
- [ ] telescope
- [ ] galaxy
- [ ] mist
- [ ] mould
- [ ] penicillin
- [ ] outcome
- [ ] cure
- [ ] navy

# Chapter 010

- [ ] wrestle
- [ ] circuit
- [ ] microwave
- [ ] patent
- [ ] jet
- [ ] exploration
- [ ] dot
- [ ] ancestor
- [ ] outwards
- [ ] boundary
- [ ] fade
- [ ] barrier
- [ ] phenomenon
- [ ] primitive
- [ ] orbit
- [ ] permanent
- [ ] headline
- [ ] initial
- [ ] spin
- [ ] overhead

# Chapter 011

- [ ] permit
- [ ] sneeze
- [ ] sniff
- [ ] porridge
- [ ] ripe
- [ ] melon
- [ ] ripen
- [ ] walnut
- [ ] press
- [ ] socket
- [ ] shaver
- [ ] Mars
- [ ] Venus
- [ ] poisonous
- [ ] carbon dioxide
- [ ] poison
- [ ] canal
- [ ] declare
- [ ] souvenir
- [ ] settler

# Chapter 012

- [ ] kidney
- [ ] liver
- [ ] interval
- [ ] pump
- [ ] digest
- [ ] mineral
- [ ] swap
- [ ] hearing
- [ ] pulse
- [ ] track and field
- [ ] enhance
- [ ] performance-enhancing
- [ ] supreme
- [ ] doping
- [ ] abuse
- [ ] tolerate
- [ ] fundamental
- [ ] doubtful
- [ ] seek
- [ ] annual

# Chapter 013

- [ ] lame
- [ ] in vain
- [ ] compulsory
- [ ] at random
- [ ] gene-therapy
- [ ] threat
- [ ] controversial
- [ ] oppose
- [ ] dash
- [ ] marathon
- [ ] contradict
- [ ] violate
- [ ] at all costs
- [ ] impulse
- [ ] complicated
- [ ] miniature
- [ ] soundtrack
- [ ] interpret
- [ ] identify
- [ ] emotion

# Chapter 014

- [ ] privileged
- [ ] cater
- [ ] entry
- [ ] ample
- [ ] herb
- [ ] scan
- [ ] treat
- [ ] storage
- [ ] postpone
- [ ] straight away
- [ ] epidemic
- [ ] cancer
- [ ] wipe out
- [ ] urban
- [ ] rebuild
- [ ] empire
- [ ] trial
- [ ] prohibit
- [ ] unite
- [ ] pause

# Chapter 015

- [ ] acute
- [ ] statistics
- [ ] symptom
- [ ] routine
- [ ] press.
- [ ] parallel
- [ ] tissue
- [ ] adaptation
- [ ] foresee
- [ ] mourn
- [ ] carrier
- [ ] prescription
- [ ] tablet
- [ ] underline
- [ ] thorough
- [ ] systematic
- [ ] teamwork
- [ ] faith
- [ ] stop sth.in its tracks
- [ ] pill

# Chapter 016

- [ ] coma
- [ ] weekly
- [ ] temporary
- [ ] numb
- [ ] sacred
- [ ] rob
- [ ] terminal
- [ ] helmet
- [ ] decline
- [ ] minimum
- [ ] institution
- [ ] unconditionally
- [ ] tentatively
- [ ] equip
- [ ] firm
- [ ] fortune
- [ ] reverse
- [ ] rate
- [ ] enquiry
- [ ] deadline

# Chapter 017

- [ ] submit
- [ ] appendix
- [ ] extension
- [ ] tractor
- [ ] jealous
- [ ] spade
- [ ] aluminum
- [ ] tin
- [ ] concern
- [ ] vote
- [ ] sceptical
- [ ] belly
- [ ] absurd
- [ ] circumstance

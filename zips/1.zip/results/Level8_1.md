
# Chapter 001

- [ ] internship
- [ ] trial
- [ ] untimely
- [ ] omelet
- [ ] moth
- [ ] champagne
- [ ] dive
- [ ] raft
- [ ] slit
- [ ] draw
- [ ] cataract
- [ ] foam
- [ ] omnibus
- [ ] scamper
- [ ] brisk
- [ ] toil
- [ ] scrub
- [ ] shear
- [ ] ravage
- [ ] crate

# Chapter 002

- [ ] fruiterer
- [ ] extract
- [ ] canvas
- [ ] garnish
- [ ] glistening
- [ ] spiced
- [ ] baked
- [ ] brass
- [ ] liquor
- [ ] orchestra
- [ ] gaudy
- [ ] permeate
- [ ] perish
- [ ] penetrate
- [ ] perpetrate
- [ ] innuendo
- [ ] prodigality
- [ ] swell
- [ ] hush
- [ ] obligingly

# Chapter 003

- [ ] erroneous
- [ ] understudy
- [ ] chauffeur
- [ ] peculiar
- [ ] flannel
- [ ] earnest
- [ ] agonizingly
- [ ] vicinity
- [ ] dizzy
- [ ] dreadful
- [ ] whereabouts
- [ ] vehemently
- [ ] purposeless
- [ ] coin
- [ ] legitimate
- [ ] consensual
- [ ] hallucination
- [ ] graphic
- [ ] prescient
- [ ] myriad

# Chapter 004

- [ ] tremendous
- [ ] breach
- [ ] prominent
- [ ] surveillance
- [ ] contractor
- [ ] domain
- [ ] sabotage
- [ ] affiliate
- [ ] controversial
- [ ] contradictory
- [ ] complementary
- [ ] congruent
- [ ] espionage
- [ ] anticipate
- [ ] malicious
- [ ] geeky
- [ ] resilient
- [ ] vengeance
- [ ] bastion
- [ ] mediocre

# Chapter 005

- [ ] mediocrity
- [ ] bloated
- [ ] fourfold
- [ ] pervasive
- [ ] liberate
- [ ] tenure
- [ ] knowingly
- [ ] prestige
- [ ] decisive
- [ ] euphemism
- [ ] analogy
- [ ] metaphor
- [ ] personification
- [ ] literally
- [ ] douse
- [ ] monetary
- [ ] pertinent
- [ ] drought
- [ ] gallon
- [ ] warranted

# Chapter 006

- [ ] inference
- [ ] adversarial
- [ ] implication
- [ ] intimate
- [ ] residue
- [ ] tactics
- [ ] dialectical
- [ ] namely
- [ ] paradigm
- [ ] polarize
- [ ] proponent
- [ ] synch
- [ ] platitude
- [ ] pretext
- [ ] hurdle
- [ ] chastise
- [ ] speculative
- [ ] tidbit
- [ ] rarity
- [ ] numb

# Chapter 007

- [ ] marijuana
- [ ] diarrhea
- [ ] sanitation
- [ ] frenetic
- [ ] indulgence
- [ ] extravagant
- [ ] plausible
- [ ] ritual
- [ ] corollary
- [ ] instinct
- [ ] revelation
- [ ] indignant
- [ ] docile
- [ ] disobedient
- [ ] fickleness
- [ ] gratitude
- [ ] betray
- [ ] begrudging
- [ ] conspire
- [ ] steadfastness

# Chapter 008

- [ ] tenacity
- [ ] stubbornly
- [ ] totter
- [ ] senile
- [ ] buckle
- [ ] wheeze
- [ ] gasp
- [ ] stern
- [ ] clutch
- [ ] willful
- [ ] strangle
- [ ] leopard
- [ ] crouch
- [ ] duck
- [ ] reckless
- [ ] imperceptibly
- [ ] loop
- [ ] languid
- [ ] hum
- [ ] chorus

# Chapter 009

- [ ] squat
- [ ] majestically
- [ ] shudder
- [ ] tremble
- [ ] spout
- [ ] radiator
- [ ] crawl
- [ ] stroll
- [ ] flush
- [ ] ubiquitous
- [ ] corridor
- [ ] habitat
- [ ] buzzword
- [ ] multiple
- [ ] spatial
- [ ] megacity
- [ ] temperate
- [ ] arid
- [ ] compromise
- [ ] topography

# Chapter 010

- [ ] homogenize
- [ ] aesthetic
- [ ] portable
- [ ] envision
- [ ] incorporate
- [ ] heritage
- [ ] psycholinguistic
- [ ] tacit
- [ ] explicit
- [ ] aggression
- [ ] fossil
- [ ] skull
- [ ] outraged
- [ ] bizarre
- [ ] consensus
- [ ] obedience
- [ ] nurture
- [ ] allocate
- [ ] deteriorating
- [ ] predisposition

# Chapter 011

- [ ] coercion
- [ ] inadvertently
- [ ] advert
- [ ] propensity
- [ ] gratification
- [ ] arrogant
- [ ] irritable
- [ ] pinched
- [ ] proximity
- [ ] pedantic
- [ ] conducive
- [ ] monotony
- [ ] facetiously
- [ ] freckled
- [ ] flatter
- [ ] frill
- [ ] bunk
- [ ] metallic
- [ ] clamor
- [ ] profess

# Chapter 012

- [ ] jolt
- [ ] gregarious
- [ ] velocity
- [ ] generic
- [ ] cerebral
- [ ] omnipresent
- [ ] pathology
- [ ] stigmatize
- [ ] bland
- [ ] extrovert
- [ ] introvert
- [ ] contemplation
- [ ] heed
- [ ] cognition
- [ ] suppression
- [ ] inhibit
- [ ] obstruct
- [ ] tussle
- [ ] hone
- [ ] ample

# Chapter 013

- [ ] handicap
- [ ] ascending
- [ ] denote
- [ ] whilst
- [ ] homophones
- [ ] arbitrarily
- [ ] convict
- [ ] malnutrition
- [ ] famine
- [ ] adolescence
- [ ] tavern
- [ ] discursive
- [ ] initiative
- [ ] whistleblower
- [ ] footage
- [ ] scrupulous
- [ ] vociferous
- [ ] stridently
- [ ] strikingly
- [ ] pamphlet

# Chapter 014

- [ ] roomy
- [ ] profound
- [ ] filter
- [ ] conduit
- [ ] anonymous
- [ ] baron
- [ ] reserved
- [ ] ambiguous
- [ ] skeptical
- [ ] chic
- [ ] decadence
- [ ] hype
- [ ] blockbuster
- [ ] pornography
- [ ] swing
- [ ] condescension
- [ ] condescend
- [ ] impulse
- [ ] bountiful
- [ ] hangar

# Chapter 015

- [ ] scoop
- [ ] mandate
- [ ] gross
- [ ] innately
- [ ] amenity
- [ ] surly
- [ ] aura
- [ ] ardent
- [ ] flaunt
- [ ] allure
- [ ] lure
- [ ] preemptive
- [ ] snobby
- [ ] pantomime
- [ ] demeanor
- [ ] wince
- [ ] haggle
- [ ] incentive
- [ ] serene
- [ ] bluff

# Chapter 016

- [ ] outright
- [ ] luster
- [ ] wanton
- [ ] solicitousness
- [ ] tinge
- [ ] decry
- [ ] stud
- [ ] trauma
- [ ] frugality
- [ ] arable
- [ ] onomatopoeia
- [ ] interrogative
- [ ] denominator
- [ ] impotent
- [ ] rivalry
- [ ] abuse
- [ ] oblivious
- [ ] scarcity
- [ ] infiltrate
- [ ] cascade

# Chapter 017

- [ ] trump
- [ ] crunch
- [ ] outrageous
- [ ] invidiously
- [ ] extracurricular
- [ ] fraternity
- [ ] veteran
- [ ] affection
- [ ] boggle
- [ ] alumni
- [ ] alumna
- [ ] cruise
- [ ] affinity
- [ ] hostile
- [ ] rhetorical
- [ ] prelude
- [ ] stocky
- [ ] stoop
- [ ] squirt
- [ ] session

# Chapter 018

- [ ] pave
- [ ] legacy
- [ ] totalitarian
- [ ] refute
- [ ] unveil
- [ ] subdue
- [ ] episode
- [ ] compassionate
- [ ] sage
- [ ] emancipator
- [ ] magnitude
- [ ] rectify
- [ ] disparage
- [ ] implicitly
- [ ] gulp
- [ ] ledge
- [ ] thoroughfare
- [ ] subdued
- [ ] institutionalized
- [ ] cynical

# Chapter 019

- [ ] anonymity
- [ ] hub
- [ ] drone
- [ ] drab
- [ ] stark
- [ ] inevitable
- [ ] outstrip
- [ ] indulge
- [ ] lackluster
- [ ] notation
- [ ] simultaneous
- [ ] aviation
- [ ] prophetic
- [ ] perch
- [ ] entrenched
- [ ] entrench
- [ ] decode
- [ ] convergence
- [ ] blur
- [ ] autonomy

# Chapter 020

- [ ] smudge
- [ ] understatement
- [ ] hue
- [ ] precipice
- [ ] attire
- [ ] stiff
- [ ] scrutiny
- [ ] countenance
- [ ] placid
- [ ] contemplate
- [ ] gleam
- [ ] sturdy
- [ ] chamber
- [ ] fresco
- [ ] elation
- [ ] bully
- [ ] snobbery
- [ ] oppress
- [ ] evince
- [ ] glee

# Chapter 021

- [ ] sardonic
- [ ] equanimity
- [ ] benevolence
- [ ] patronage
- [ ] entwine
- [ ] deference
- [ ] ballad
- [ ] epic
- [ ] elegy
- [ ] pragmatics
- [ ] articulation
- [ ] articulate
- [ ] topographical
- [ ] contour
- [ ] ridge
- [ ] mirage
- [ ] terrace
- [ ] trek
- [ ] polychronic
- [ ] cocoon

# Chapter 022

- [ ] chandelier
- [ ] circumscribe
- [ ] luxuriate
- [ ] parlor
- [ ] congregate
- [ ] communal
- [ ] hierarchy
- [ ] huddle
- [ ] muddle
- [ ] aristocracy
- [ ] surge
- [ ] amiability
- [ ] furtive
- [ ] beam
- [ ] semantics
- [ ] evacuate
- [ ] torrential
- [ ] rickshaw
- [ ] demeaning
- [ ] infrastructure

# Chapter 023

- [ ] imminent
- [ ] hawker
- [ ] clout
- [ ] clot
- [ ] clog
- [ ] sardar
- [ ] rehabilitate
- [ ] crucial
- [ ] democratic
- [ ] disembark
- [ ] hapless
- [ ] bemuse
- [ ] amnesty
- [ ] bereft
- [ ] covet
- [ ] savvy
- [ ] renowned
- [ ] consign
- [ ] teasing
- [ ] profusion

# Chapter 024

- [ ] bewilder
- [ ] cauldron
- [ ] farthing
- [ ] vulgar
- [ ] gigantic
- [ ] grime
- [ ] confectionery
- [ ] bust
- [ ] disdain
- [ ] tremolo
- [ ] sleek
- [ ] murmur
- [ ] gullible
- [ ] pristine
- [ ] encumber
- [ ] attune
- [ ] ostensible
- [ ] allotment
- [ ] allegory
- [ ] sonnet

# Chapter 025

- [ ] rhyme
- [ ] morphology
- [ ] backformation
- [ ] blend
- [ ] meadow
- [ ] hedge
- [ ] tranquil
- [ ] repose
- [ ] huskiness
- [ ] proprietor
- [ ] fabric
- [ ] province
- [ ] elite
- [ ] unaffiliated
- [ ] sucker
- [ ] shatter
- [ ] temperamental
- [ ] loot
- [ ] vermilion
- [ ] servitude

# Chapter 026

- [ ] verve
- [ ] exotic
- [ ] manicure
- [ ] boulevard
- [ ] acquaint
- [ ] fascinate
- [ ] labyrinth
- [ ] bazaar
- [ ] pungent
- [ ] boutique
- [ ] gourmet
- [ ] harem
- [ ] gear
- [ ] recruit
- [ ] genial
- [ ] conspiracy
- [ ] elevate
- [ ] indiscriminate
- [ ] discriminate
- [ ] applause

# Chapter 027

- [ ] implausible
- [ ] tentative
- [ ] amorousness
- [ ] abrasive
- [ ] erotic
- [ ] daunt
- [ ] dauntless
- [ ] arduous
- [ ] amphitheater
- [ ] bereave
- [ ] jut
- [ ] stupendous
- [ ] sheer
- [ ] demure
- [ ] demur
- [ ] colossal
- [ ] shuffle
- [ ] grimy
- [ ] rivulet
- [ ] tumble

# Chapter 028

- [ ] stumble
- [ ] abbot
- [ ] trudge
- [ ] panoramic
- [ ] haze
- [ ] piety
- [ ] idiolect
- [ ] vaccination
- [ ] manicured
- [ ] pique
- [ ] bulky
- [ ] eligible
- [ ] void
- [ ] crest
- [ ] diminutive
- [ ] emissary
- [ ] paradox
- [ ] grueling
- [ ] grumpy
- [ ] grumble

# Chapter 029

- [ ] grudge
- [ ] grouse
- [ ] grouch
- [ ] cram
- [ ] fretful
- [ ] fret
- [ ] egalitarian
- [ ] curriculum
- [ ] prestigious
- [ ] melodramatic
- [ ] bias
- [ ] burgeon
- [ ] dwindle
- [ ] affluence
- [ ] rustic
- [ ] chronicle
- [ ] authentic
- [ ] stereotypical
- [ ] scrummage
- [ ] scramble

# Chapter 030

- [ ] rampart
- [ ] defy
- [ ] defiance
- [ ] grin
- [ ] epitomize
- [ ] metropolis
- [ ] raucous
- [ ] roar
- [ ] reminiscent
- [ ] reminisce
- [ ] repression
- [ ] pimp
- [ ] rage
- [ ] sobriety
- [ ] sober
- [ ] brink
- [ ] cando
- [ ] lucrative
- [ ] callous
- [ ] calloused

# Chapter 031

- [ ] callosity
- [ ] snap
- [ ] mortgage
- [ ] ultimate
- [ ] ultimatum
- [ ] resurgence
- [ ] centrifugal
- [ ] devolution
- [ ] enact
- [ ] figurehead
- [ ] waterfront
- [ ] esteem
- [ ] indigenous
- [ ] compatriot
- [ ] jersey
- [ ] feudal
- [ ] hilarious
- [ ] amble
- [ ] swig
- [ ] satchel

# Chapter 032

- [ ] grenade
- [ ] anthrax
- [ ] wield
- [ ] abstention
- [ ] municipal
- [ ] furious
- [ ] thwart
- [ ] spangle
- [ ] suffragette
- [ ] medieval
- [ ] embody
- [ ] chivalry
- [ ] compliment
- [ ] reign
- [ ] prowess
- [ ] sinew
- [ ] dexterous
- [ ] malice
- [ ] impetuous
- [ ] treacherous

# Chapter 033

- [ ] munificent
- [ ] circumspect
- [ ] ineptitude
- [ ] tenable
- [ ] unearth
- [ ] paramount
- [ ] bolt
- [ ] fealty
- [ ] flay
- [ ] pompous
- [ ] demise
- [ ] impoverish
- [ ] audacious
- [ ] cumulative
- [ ] prudent
- [ ] quirk
- [ ] cosmos
- [ ] margin
- [ ] zealous
- [ ] discretion

# Chapter 034

- [ ] circumvent
- [ ] dynamo
- [ ] charcoal
- [ ] agile
- [ ] ruckus
- [ ] exemplify
- [ ] venerable
- [ ] stilt
- [ ] impersonator
- [ ] teeter
- [ ] console
- [ ] bondage
- [ ] brawl
- [ ] exuberant
- [ ] attic
- [ ] buoyant
- [ ] burgeoning
- [ ] fugitive
- [ ] overwhelmingly
- [ ] vaporize

# Chapter 035

- [ ] flirtatious
- [ ] stance
- [ ] reversal
- [ ] portfolio

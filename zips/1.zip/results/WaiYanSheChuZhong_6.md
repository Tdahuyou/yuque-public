
# Chapter 001

- [ ] flight
- [ ] because of
- [ ] direct
- [ ] pilot
- [ ] succeed
- [ ] as long as
- [ ] school-leaver
- [ ] exactly
- [ ] take care
- [ ] sir
- [ ] officer
- [ ] stupid
- [ ] take off
- [ ] jacket
- [ ] ours
- [ ] tie
- [ ] row
- [ ] pool
- [ ] pass
- [ ] secondary

# Chapter 002

- [ ] secondary school
- [ ] absent
- [ ] bell
- [ ] wealthy
- [ ] fear
- [ ] used to
- [ ] wealth
- [ ] double
- [ ] seldom
- [ ] spare
- [ ] spare time
- [ ] speak up
- [ ] deaf
- [ ] tiny
- [ ] electric
- [ ] light
- [ ] candle
- [ ] postman
- [ ] cold
- [ ] heat

# Chapter 003

- [ ] full-time
- [ ] role
- [ ] education
- [ ] transport
- [ ] set off
- [ ] sock
- [ ] whenever
- [ ] proper
- [ ] edge
- [ ] yourself
- [ ] go off
- [ ] starve
- [ ] go
- [ ] in one go
- [ ] rock
- [ ] rock climbing
- [ ] stone
- [ ] fairly
- [ ] smooth
- [ ] straight

# Chapter 004

- [ ] tent
- [ ] fall
- [ ] fall asleep
- [ ] hang
- [ ] sudden
- [ ] gun
- [ ] soft
- [ ] still
- [ ] wood
- [ ] blood
- [ ] catch up
- [ ] agreement
- [ ] blind
- [ ] ouch
- [ ] call off
- [ ] thanks to
- [ ] health care
- [ ] expect
- [ ] require
- [ ] physical

# Chapter 005

- [ ] effort
- [ ] once in a while
- [ ] harm
- [ ] invitation
- [ ] calendar
- [ ] balloon
- [ ] paint
- [ ] Heat
- [ ] heat up
- [ ] knife
- [ ] fork
- [ ] spoon
- [ ] cheeseburger
- [ ] Italian
- [ ] Westerner
- [ ] West
- [ ] serve
- [ ] similar
- [ ] wing
- [ ] lady

# Chapter 006

- [ ] gentleman
- [ ] help yourself
- [ ] cross
- [ ] achieve
- [ ] including
- [ ] speaker
- [ ] boss
- [ ] secretary
- [ ] quarter
- [ ] industry
- [ ] zero
- [ ] Indian
- [ ] type
- [ ] handbag
- [ ] beat
- [ ] pardon
- [ ] intend
- [ ] fetch
- [ ] pancake
- [ ] rose

# Chapter 007

- [ ] laugh at
- [ ] kindness
- [ ] give up
- [ ] try one's best
- [ ] disappointed
- [ ] bedside
- [ ] note
- [ ] whom

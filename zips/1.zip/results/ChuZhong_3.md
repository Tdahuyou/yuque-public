
# Chapter 001

- [ ] cancel
- [ ] prepare
- [ ] half
- [ ] fifty
- [ ] England
- [ ] hall
- [ ] your
- [ ] pollution
- [ ] pretend
- [ ] without
- [ ] these
- [ ] tea
- [ ] postman
- [ ] pick
- [ ] rabbit
- [ ] ten
- [ ] prison
- [ ] sister
- [ ] energy
- [ ] mystery

# Chapter 002

- [ ] solid
- [ ] require
- [ ] yourselves
- [ ] lion
- [ ] size
- [ ] left
- [ ] eleven
- [ ] wine
- [ ] object
- [ ] newspaper
- [ ] flight
- [ ] eraser
- [ ] hang
- [ ] role
- [ ] achieve
- [ ] anybody
- [ ] yellow
- [ ] I
- [ ] turn
- [ ] example

# Chapter 003

- [ ] result
- [ ] same
- [ ] after
- [ ] quiet
- [ ] connect
- [ ] hand
- [ ] a
- [ ] salt
- [ ] address
- [ ] nineteen
- [ ] blood
- [ ] straight
- [ ] the
- [ ] ninety
- [ ] sale
- [ ] photograph
- [ ] police
- [ ] blue
- [ ] throw
- [ ] thank

# Chapter 004

- [ ] fifth
- [ ] information
- [ ] yours
- [ ] discuss
- [ ] standard
- [ ] correct
- [ ] nobody
- [ ] empty
- [ ] wish
- [ ] tie
- [ ] wise
- [ ] serious
- [ ] laugh
- [ ] conversation
- [ ] area
- [ ] pay
- [ ] check
- [ ] list
- [ ] European
- [ ] strange

# Chapter 005

- [ ] sand
- [ ] toast
- [ ] frustrate
- [ ] success
- [ ] authority
- [ ] creature
- [ ] child
- [ ] outgoing
- [ ] young
- [ ] rope
- [ ] instrument
- [ ] medium
- [ ] pear
- [ ] society
- [ ] root
- [ ] treasure
- [ ] hard
- [ ] airline
- [ ] lend
- [ ] November

# Chapter 006

- [ ] ticket
- [ ] umbrella
- [ ] perform
- [ ] name
- [ ] concentrate
- [ ] cheer
- [ ] room
- [ ] better
- [ ] with
- [ ] service
- [ ] coffee
- [ ] there
- [ ] lady
- [ ] well
- [ ] suitable
- [ ] magazine
- [ ] pocket
- [ ] pioneer
- [ ] experiment
- [ ] pen

# Chapter 007

- [ ] hate
- [ ] block
- [ ] write
- [ ] pet
- [ ] period
- [ ] bulb
- [ ] understand
- [ ] birth
- [ ] dismiss
- [ ] picnic
- [ ] heaven
- [ ] alright
- [ ] loving
- [ ] ever
- [ ] unhappy
- [ ] million
- [ ] even
- [ ] crazy
- [ ] volleyball
- [ ] coach

# Chapter 008

- [ ] southeast
- [ ] champion
- [ ] hundred
- [ ] pink
- [ ] wait
- [ ] woman
- [ ] queen
- [ ] save
- [ ] matter
- [ ] ton
- [ ] conjunction
- [ ] top
- [ ] too
- [ ] have
- [ ] documentary
- [ ] toy
- [ ] product
- [ ] famous
- [ ] question
- [ ] peel

# Chapter 009

- [ ] spirit
- [ ] cheap
- [ ] produce
- [ ] picture
- [ ] cheat
- [ ] regard
- [ ] rose
- [ ] thousand
- [ ] tonight
- [ ] capital
- [ ] con
- [ ] almost
- [ ] cow
- [ ] manner
- [ ] upon
- [ ] lab
- [ ] pie
- [ ] wake
- [ ] charity
- [ ] whether

# Chapter 010

- [ ] raise
- [ ] west
- [ ] spoon
- [ ] quite
- [ ] lap
- [ ] tower
- [ ] traffic
- [ ] law
- [ ] everyone
- [ ] lay
- [ ] plenty
- [ ] less
- [ ] tutor
- [ ] girlfriend
- [ ] condition
- [ ] thirsty
- [ ] improve
- [ ] snow
- [ ] try
- [ ] lake

# Chapter 011

- [ ] chicken
- [ ] bush
- [ ] university
- [ ] fruit
- [ ] cause
- [ ] wound
- [ ] teacher
- [ ] twentieth
- [ ] design
- [ ] extra
- [ ] busy
- [ ] land
- [ ] department
- [ ] floor
- [ ] exhibition
- [ ] burn
- [ ] modern
- [ ] lamp
- [ ] cry
- [ ] doctor

# Chapter 012

- [ ] English
- [ ] obey
- [ ] lamb
- [ ] fantastic
- [ ] unfamiliar
- [ ] spoken
- [ ] tidy
- [ ] wall
- [ ] sport
- [ ] walk
- [ ] marry
- [ ] concert
- [ ] pity
- [ ] discussion
- [ ] supply
- [ ] unimportant
- [ ] leg
- [ ] beautiful
- [ ] recycle
- [ ] let

# Chapter 013

- [ ] state
- [ ] press
- [ ] welcome
- [ ] meeting
- [ ] want
- [ ] Africa
- [ ] opposite
- [ ] pack
- [ ] each
- [ ] bamboo
- [ ] Mr.
- [ ] difference
- [ ] offend
- [ ] circle
- [ ] thirty
- [ ] cup
- [ ] polite
- [ ] cut
- [ ] probably
- [ ] entertainment

# Chapter 014

- [ ] battery
- [ ] prize
- [ ] two
- [ ] chase
- [ ] accident
- [ ] anyway
- [ ] pop
- [ ] found
- [ ] excuse
- [ ] shout
- [ ] kitchen
- [ ] escape
- [ ] funny
- [ ] situation
- [ ] latest
- [ ] think
- [ ] receive
- [ ] team
- [ ] tragedy
- [ ] watch

# Chapter 015

- [ ] speech
- [ ] clap
- [ ] purple
- [ ] nice
- [ ] Jew
- [ ] thing
- [ ] fashion
- [ ] medical
- [ ] friendship
- [ ] till
- [ ] fridge
- [ ] lie
- [ ] anymore
- [ ] smell
- [ ] unable
- [ ] late
- [ ] ham
- [ ] school
- [ ] continue
- [ ] avenue

# Chapter 016

- [ ] hat
- [ ] shoot
- [ ] realize
- [ ] chest
- [ ] eastern
- [ ] chess
- [ ] marathon
- [ ] last
- [ ] wash
- [ ] doubt
- [ ] weight
- [ ] jacket
- [ ] uncomfortable
- [ ] develop
- [ ] pro
- [ ] warn
- [ ] warm
- [ ] district
- [ ] chalk
- [ ] page

# Chapter 017

- [ ] swim
- [ ] full
- [ ] memory
- [ ] away
- [ ] scientist
- [ ] impossible
- [ ] effort
- [ ] video
- [ ] house
- [ ] wave
- [ ] anything
- [ ] yesterday
- [ ] schoolwork
- [ ] furry
- [ ] early
- [ ] pain
- [ ] disease
- [ ] yes
- [ ] center
- [ ] start

# Chapter 018

- [ ] most
- [ ] yet
- [ ] teen
- [ ] engineer
- [ ] supper
- [ ] pair
- [ ] lifestyle
- [ ] manage
- [ ] short
- [ ] time
- [ ] cabbage
- [ ] national
- [ ] happy
- [ ] program
- [ ] myself
- [ ] three
- [ ] put
- [ ] climb
- [ ] hen
- [ ] her

# Chapter 019

- [ ] season
- [ ] specifically
- [ ] enter
- [ ] lonely
- [ ] hey
- [ ] gallery
- [ ] lesson
- [ ] destroy
- [ ] moon
- [ ] creative
- [ ] provide
- [ ] light
- [ ] passenger
- [ ] tiny
- [ ] primary
- [ ] artist
- [ ] lazy
- [ ] bright
- [ ] alien
- [ ] smart

# Chapter 020

- [ ] lot
- [ ] tourist
- [ ] low
- [ ] theme
- [ ] wealth
- [ ] wallet
- [ ] doll
- [ ] chair
- [ ] centre
- [ ] tennis
- [ ] chat
- [ ] fetch
- [ ] choice
- [ ] travel
- [ ] small
- [ ] door
- [ ] quick
- [ ] fiction
- [ ] before
- [ ] dad

# Chapter 021

- [ ] sixteenth
- [ ] tell
- [ ] stomach
- [ ] husband
- [ ] appointment
- [ ] experience
- [ ] him
- [ ] listen
- [ ] hit
- [ ] his
- [ ] major
- [ ] beat
- [ ] worldwide
- [ ] bear
- [ ] eighty
- [ ] consider
- [ ] day
- [ ] housework
- [ ] banana
- [ ] island

# Chapter 022

- [ ] tree
- [ ] particular
- [ ] water
- [ ] August
- [ ] square
- [ ] careless
- [ ] twice
- [ ] soap
- [ ] morning
- [ ] part
- [ ] their
- [ ] percent
- [ ] thirteen
- [ ] point
- [ ] bike
- [ ] general
- [ ] east
- [ ] sixteen
- [ ] hospital
- [ ] park

# Chapter 023

- [ ] eighth
- [ ] clear
- [ ] clean
- [ ] meal
- [ ] sock
- [ ] someone
- [ ] third
- [ ] build
- [ ] mean
- [ ] meat
- [ ] chew
- [ ] hurry
- [ ] schoolbag
- [ ] chopsticks
- [ ] path
- [ ] trip
- [ ] casually
- [ ] record
- [ ] railway
- [ ] strict

# Chapter 024

- [ ] modest
- [ ] you
- [ ] jump
- [ ] happen
- [ ] sofa
- [ ] pass
- [ ] past
- [ ] festival
- [ ] mile
- [ ] shock
- [ ] milk
- [ ] opportunity
- [ ] bill
- [ ] pancake
- [ ] active
- [ ] court
- [ ] easy
- [ ] whose
- [ ] population
- [ ] route

# Chapter 025

- [ ] Monday
- [ ] adult
- [ ] relative
- [ ] attitude
- [ ] treatment
- [ ] mirror
- [ ] compare
- [ ] bottle
- [ ] hot
- [ ] how
- [ ] October
- [ ] hotel
- [ ] term
- [ ] spare
- [ ] mine
- [ ] mind
- [ ] chip
- [ ] business
- [ ] tail
- [ ] staff

# Chapter 026

- [ ] possible
- [ ] right
- [ ] march
- [ ] meet
- [ ] answer
- [ ] stage
- [ ] borrow
- [ ] junk
- [ ] waiter
- [ ] under
- [ ] purse
- [ ] spotlight
- [ ] represent
- [ ] quarter
- [ ] die
- [ ] dig
- [ ] sometimes
- [ ] promise
- [ ] down
- [ ] hold

# Chapter 027

- [ ] tale
- [ ] later
- [ ] passport
- [ ] lookout
- [ ] bird
- [ ] club
- [ ] talk
- [ ] tall
- [ ] reply
- [ ] train
- [ ] possibly
- [ ] test
- [ ] planet
- [ ] count
- [ ] brown
- [ ] take
- [ ] misleading
- [ ] final
- [ ] some
- [ ] blank

# Chapter 028

- [ ] rather
- [ ] importance
- [ ] back
- [ ] miss
- [ ] pound
- [ ] company
- [ ] just
- [ ] human
- [ ] notice
- [ ] owner
- [ ] hometown
- [ ] relax
- [ ] custom
- [ ] permission
- [ ] home
- [ ] hole
- [ ] print
- [ ] material
- [ ] although
- [ ] beach

# Chapter 029

- [ ] baby
- [ ] iron
- [ ] adverb
- [ ] president
- [ ] explain
- [ ] hum
- [ ] basket
- [ ] lunch
- [ ] hope
- [ ] thirteenth
- [ ] attempt
- [ ] thick
- [ ] soon
- [ ] December
- [ ] tape
- [ ] balance
- [ ] lock
- [ ] fear
- [ ] song
- [ ] cookie

# Chapter 030

- [ ] belt
- [ ] chop
- [ ] cream
- [ ] sense
- [ ] bell
- [ ] heavy
- [ ] Canada
- [ ] afford
- [ ] field
- [ ] underground
- [ ] baseball
- [ ] dog
- [ ] upset
- [ ] thief
- [ ] embarrassed
- [ ] unpleasant
- [ ] skin
- [ ] stamp
- [ ] summer
- [ ] eight

# Chapter 031

- [ ] mention
- [ ] mad
- [ ] barbecue
- [ ] next
- [ ] stream
- [ ] member
- [ ] nurse
- [ ] man
- [ ] stand
- [ ] map
- [ ] together
- [ ] illness
- [ ] twenty
- [ ] cigarette
- [ ] may
- [ ] forward
- [ ] could
- [ ] health
- [ ] positive
- [ ] menu

# Chapter 032

- [ ] machine
- [ ] able
- [ ] evening
- [ ] mend
- [ ] return
- [ ] instance
- [ ] opera
- [ ] mail
- [ ] use
- [ ] feel
- [ ] thrill
- [ ] main
- [ ] serve
- [ ] cough
- [ ] smile
- [ ] radio
- [ ] solution
- [ ] fine
- [ ] find
- [ ] host

# Chapter 033

- [ ] international
- [ ] terrible
- [ ] combine
- [ ] waste
- [ ] turtle
- [ ] comedy
- [ ] pleasant
- [ ] equipment
- [ ] difficult
- [ ] dry
- [ ] film
- [ ] sort
- [ ] pressure
- [ ] fill
- [ ] heart
- [ ] dentist
- [ ] trash
- [ ] feed
- [ ] forget
- [ ] task

# Chapter 034

- [ ] convenient
- [ ] background
- [ ] true
- [ ] position
- [ ] neck
- [ ] since
- [ ] handsome
- [ ] soup
- [ ] stair
- [ ] belong
- [ ] dangerous
- [ ] best
- [ ] mess
- [ ] sour
- [ ] native
- [ ] breath
- [ ] ball
- [ ] hour
- [ ] repeat
- [ ] nervous

# Chapter 035

- [ ] make
- [ ] microwave
- [ ] structure
- [ ] master
- [ ] outdoor
- [ ] orange
- [ ] online
- [ ] writer
- [ ] fence
- [ ] depend
- [ ] about
- [ ] weekday
- [ ] danger
- [ ] theatre
- [ ] cover
- [ ] firm
- [ ] bank
- [ ] character
- [ ] meaning
- [ ] above

# Chapter 036

- [ ] fire
- [ ] Brazilian
- [ ] stick
- [ ] band
- [ ] height
- [ ] mall
- [ ] invent
- [ ] taxi
- [ ] wonderful
- [ ] tiger
- [ ] something
- [ ] quality
- [ ] labor
- [ ] rude
- [ ] animal
- [ ] except
- [ ] shower
- [ ] fact
- [ ] examine
- [ ] association

# Chapter 037

- [ ] industry
- [ ] believe
- [ ] cute
- [ ] long
- [ ] remember
- [ ] into
- [ ] unless
- [ ] temperature
- [ ] free
- [ ] mix
- [ ] dirty
- [ ] natural
- [ ] middle
- [ ] bother
- [ ] though
- [ ] star
- [ ] wolf
- [ ] many
- [ ] people
- [ ] transportation

# Chapter 038

- [ ] everyday
- [ ] stay
- [ ] diary
- [ ] appear
- [ ] face
- [ ] fish
- [ ] afraid
- [ ] progress
- [ ] invite
- [ ] Australia
- [ ] operation
- [ ] open
- [ ] agent
- [ ] treat
- [ ] movie
- [ ] rapid
- [ ] seven
- [ ] project
- [ ] ice
- [ ] inside

# Chapter 039

- [ ] whenever
- [ ] wood
- [ ] five
- [ ] surprise
- [ ] suitcase
- [ ] beard
- [ ] celebrate
- [ ] please
- [ ] look
- [ ] hunger
- [ ] laboratory
- [ ] allow
- [ ] knock
- [ ] father
- [ ] rule
- [ ] proper
- [ ] vegetable
- [ ] speed
- [ ] Russia
- [ ] apple

# Chapter 040

- [ ] poem
- [ ] common
- [ ] interest
- [ ] China
- [ ] themselves
- [ ] wonder
- [ ] music
- [ ] every
- [ ] twin
- [ ] again
- [ ] step
- [ ] comment
- [ ] mark
- [ ] whole
- [ ] fair
- [ ] during
- [ ] relation
- [ ] money
- [ ] elevator
- [ ] safety

# Chapter 041

- [ ] lost
- [ ] price
- [ ] calculator
- [ ] still
- [ ] biology
- [ ] work
- [ ] lose
- [ ] agree
- [ ] fail
- [ ] itself
- [ ] toward
- [ ] among
- [ ] anyone
- [ ] pride
- [ ] math
- [ ] monkey
- [ ] breakfast
- [ ] word
- [ ] favorite
- [ ] love

# Chapter 042

- [ ] church
- [ ] enjoy
- [ ] secret
- [ ] ourselves
- [ ] foreign
- [ ] uniform
- [ ] across
- [ ] fall
- [ ] ear
- [ ] indoors
- [ ] eat
- [ ] finger
- [ ] loud
- [ ] include
- [ ] homework
- [ ] juice
- [ ] opinion
- [ ] comma
- [ ] soldier
- [ ] culture

# Chapter 043

- [ ] first
- [ ] voice
- [ ] prefer
- [ ] perfect
- [ ] space
- [ ] never
- [ ] basketball
- [ ] frog
- [ ] theater
- [ ] mother
- [ ] from
- [ ] soft
- [ ] moment
- [ ] discover
- [ ] spell
- [ ] much
- [ ] bottom
- [ ] Japan
- [ ] ill
- [ ] mouse

# Chapter 044

- [ ] excite
- [ ] pond
- [ ] repair
- [ ] death
- [ ] steal
- [ ] advice
- [ ] scientific
- [ ] winter
- [ ] elder
- [ ] terrorist
- [ ] attendant
- [ ] public
- [ ] paper
- [ ] my
- [ ] spend
- [ ] zoo
- [ ] February
- [ ] value
- [ ] x-ray
- [ ] advantage

# Chapter 045

- [ ] assistant
- [ ] ink
- [ ] instead
- [ ] rush
- [ ] expensive
- [ ] trade
- [ ] round
- [ ] dessert
- [ ] carrot
- [ ] bicycle
- [ ] egg
- [ ] year
- [ ] kangaroo
- [ ] awful
- [ ] yeah
- [ ] resolution
- [ ] building
- [ ] score
- [ ] poor
- [ ] farm

# Chapter 046

- [ ] absent
- [ ] because
- [ ] July
- [ ] educate
- [ ] rat
- [ ] excellent
- [ ] pool
- [ ] lighting
- [ ] airport
- [ ] exam
- [ ] stop
- [ ] science
- [ ] poster
- [ ] hobby
- [ ] June
- [ ] southern
- [ ] forest
- [ ] throat
- [ ] least
- [ ] immediately

# Chapter 047

- [ ] pork
- [ ] symphony
- [ ] dollar
- [ ] sleep
- [ ] hungry
- [ ] French
- [ ] vocabulary
- [ ] refuse
- [ ] retire
- [ ] aggressive
- [ ] close
- [ ] chemistry
- [ ] sweep
- [ ] unfriendly
- [ ] fourteenth
- [ ] learn
- [ ] photo
- [ ] swing
- [ ] handbag
- [ ] fast

# Chapter 048

- [ ] move
- [ ] sweet
- [ ] thirtieth
- [ ] couple
- [ ] communicate
- [ ] rural
- [ ] red
- [ ] spring
- [ ] act
- [ ] post
- [ ] duck
- [ ] leave
- [ ] finish
- [ ] add
- [ ] computer
- [ ] cruel
- [ ] its
- [ ] ninth
- [ ] often
- [ ] insist

# Chapter 049

- [ ] seventeenth
- [ ] article
- [ ] shelf
- [ ] ache
- [ ] shell
- [ ] therefore
- [ ] exchange
- [ ] hardly
- [ ] bored
- [ ] useful
- [ ] trust
- [ ] blackboard
- [ ] private
- [ ] choose
- [ ] ride
- [ ] jeans
- [ ] prevent
- [ ] behave
- [ ] sorry
- [ ] medal

# Chapter 050

- [ ] end
- [ ] forty
- [ ] mistake
- [ ] pour
- [ ] rich
- [ ] message
- [ ] rice
- [ ] praise
- [ ] special
- [ ] environment
- [ ] truth
- [ ] Asia
- [ ] airplane
- [ ] pronounce
- [ ] family
- [ ] age
- [ ] gift
- [ ] college
- [ ] popcorn
- [ ] ago

# Chapter 051

- [ ] number
- [ ] punish
- [ ] brave
- [ ] must
- [ ] similar
- [ ] shape
- [ ] seventy
- [ ] nothing
- [ ] seventh
- [ ] spot
- [ ] silver
- [ ] aid
- [ ] other
- [ ] singer
- [ ] aim
- [ ] city
- [ ] against
- [ ] confident
- [ ] uncle
- [ ] air

# Chapter 052

- [ ] holiday
- [ ] courage
- [ ] local
- [ ] encourage
- [ ] potato
- [ ] speak
- [ ] share
- [ ] restroom
- [ ] polar
- [ ] shark
- [ ] chairman
- [ ] boat
- [ ] future
- [ ] more
- [ ] shake
- [ ] cent
- [ ] honor
- [ ] screen
- [ ] body
- [ ] cage

# Chapter 053

- [ ] unhealthy
- [ ] insect
- [ ] net
- [ ] always
- [ ] all
- [ ] border
- [ ] read
- [ ] below
- [ ] already
- [ ] shall
- [ ] touch
- [ ] clock
- [ ] real
- [ ] tool
- [ ] April
- [ ] unit
- [ ] nearby
- [ ] Sunday
- [ ] model
- [ ] collect

# Chapter 054

- [ ] shame
- [ ] around
- [ ] pronoun
- [ ] and
- [ ] today
- [ ] talented
- [ ] predict
- [ ] saying
- [ ] row
- [ ] France
- [ ] OK
- [ ] raincoat
- [ ] abroad
- [ ] fifteen
- [ ] ant
- [ ] pencil
- [ ] specific
- [ ] any
- [ ] minute
- [ ] super

# Chapter 055

- [ ] chore
- [ ] semester
- [ ] until
- [ ] strategy
- [ ] dull
- [ ] reason
- [ ] thought
- [ ] ring
- [ ] legend
- [ ] taste
- [ ] ship
- [ ] anywhere
- [ ] professional
- [ ] cheese
- [ ] nineteenth
- [ ] cake
- [ ] neighbor
- [ ] gentle
- [ ] shoulder
- [ ] dance

# Chapter 056

- [ ] boil
- [ ] remain
- [ ] eye
- [ ] himself
- [ ] toilet
- [ ] envelope
- [ ] dictionary
- [ ] slow
- [ ] turkey
- [ ] letter
- [ ] tasty
- [ ] maybe
- [ ] another
- [ ] enemy
- [ ] worth
- [ ] new
- [ ] helicopter
- [ ] are
- [ ] advertisement
- [ ] disabled

# Chapter 057

- [ ] watermelon
- [ ] arm
- [ ] popular
- [ ] art
- [ ] mom
- [ ] black
- [ ] tour
- [ ] call
- [ ] calm
- [ ] such
- [ ] kick
- [ ] ask
- [ ] describe
- [ ] through
- [ ] jazz
- [ ] run
- [ ] either
- [ ] view
- [ ] ours
- [ ] white

# Chapter 058

- [ ] furniture
- [ ] huge
- [ ] yourself
- [ ] donate
- [ ] helpful
- [ ] those
- [ ] worry
- [ ] imagine
- [ ] town
- [ ] might
- [ ] telephone
- [ ] girl
- [ ] delicious
- [ ] worse
- [ ] whatever
- [ ] camp
- [ ] volunteer
- [ ] museum
- [ ] everywhere
- [ ] worst

# Chapter 059

- [ ] clothing
- [ ] aloud
- [ ] shop
- [ ] Christmas
- [ ] string
- [ ] September
- [ ] distance
- [ ] color
- [ ] truck
- [ ] book
- [ ] show
- [ ] nor
- [ ] Mars
- [ ] not
- [ ] arrive
- [ ] street
- [ ] now
- [ ] statement
- [ ] Tuesday
- [ ] shoe

# Chapter 060

- [ ] race
- [ ] near
- [ ] introduce
- [ ] war
- [ ] way
- [ ] what
- [ ] duty
- [ ] risk
- [ ] window
- [ ] rise
- [ ] penny
- [ ] play
- [ ] yard
- [ ] decide
- [ ] rent
- [ ] when
- [ ] fan
- [ ] anxious
- [ ] slice
- [ ] far

# Chapter 061

- [ ] fat
- [ ] catch
- [ ] fax
- [ ] plan
- [ ] case
- [ ] give
- [ ] double
- [ ] eighteen
- [ ] phone
- [ ] comfortable
- [ ] slide
- [ ] style
- [ ] jungle
- [ ] suit
- [ ] card
- [ ] Yin
- [ ] chocolate
- [ ] care
- [ ] study
- [ ] boss

# Chapter 062

- [ ] direct
- [ ] exercise
- [ ] fever
- [ ] supermarket
- [ ] madam
- [ ] kilo
- [ ] seldom
- [ ] physics
- [ ] protect
- [ ] stress
- [ ] display
- [ ] wet
- [ ] born
- [ ] kill
- [ ] wrong
- [ ] porridge
- [ ] shirt
- [ ] criticize
- [ ] certain
- [ ] board

# Chapter 063

- [ ] shut
- [ ] luck
- [ ] simple
- [ ] autograph
- [ ] eleventh
- [ ] influence
- [ ] cloud
- [ ] whale
- [ ] talent
- [ ] few
- [ ] rain
- [ ] violin
- [ ] king
- [ ] kind
- [ ] both
- [ ] market
- [ ] important
- [ ] keen
- [ ] nine
- [ ] phrase

# Chapter 064

- [ ] outside
- [ ] daily
- [ ] keep
- [ ] yoghurt
- [ ] elementary
- [ ] topic
- [ ] skate
- [ ] job
- [ ] sugar
- [ ] daughter
- [ ] who
- [ ] game
- [ ] why
- [ ] forbid
- [ ] captain
- [ ] bowl
- [ ] alone
- [ ] along
- [ ] joy
- [ ] dialogue

# Chapter 065

- [ ] America
- [ ] sad
- [ ] diet
- [ ] win
- [ ] sheep
- [ ] rest
- [ ] soccer
- [ ] butter
- [ ] amount
- [ ] original
- [ ] album
- [ ] electric
- [ ] also
- [ ] say
- [ ] sandwich
- [ ] enough
- [ ] increase
- [ ] shine
- [ ] spread
- [ ] afternoon

# Chapter 066

- [ ] attention
- [ ] shiny
- [ ] visit
- [ ] headache
- [ ] front
- [ ] oneself
- [ ] plane
- [ ] parent
- [ ] stupid
- [ ] bad
- [ ] bring
- [ ] bag
- [ ] sauce
- [ ] awake
- [ ] kiss
- [ ] hamburger
- [ ] offer
- [ ] fit
- [ ] robot
- [ ] fix

# Chapter 067

- [ ] need
- [ ] honest
- [ ] rank
- [ ] cinema
- [ ] rubbish
- [ ] surf
- [ ] sure
- [ ] angry
- [ ] am
- [ ] an
- [ ] fold
- [ ] as
- [ ] plastic
- [ ] mysterious
- [ ] plant
- [ ] peace
- [ ] drive
- [ ] Atlantic
- [ ] brother
- [ ] hurt

# Chapter 068

- [ ] strong
- [ ] deal
- [ ] prove
- [ ] be
- [ ] homeland
- [ ] maths
- [ ] deaf
- [ ] dead
- [ ] mouth
- [ ] adj.
- [ ] tomato
- [ ] sea
- [ ] sixth
- [ ] search
- [ ] see
- [ ] servant
- [ ] fool
- [ ] sudden
- [ ] popularity
- [ ] mountain

# Chapter 069

- [ ] by
- [ ] whom
- [ ] wheat
- [ ] dear
- [ ] tooth
- [ ] foot
- [ ] sixty
- [ ] set
- [ ] outstanding
- [ ] escalator
- [ ] medicine
- [ ] flu
- [ ] food
- [ ] fly
- [ ] partner
- [ ] Thursday
- [ ] kilometer
- [ ] river
- [ ] spider
- [ ] kite

# Chapter 070

- [ ] interview
- [ ] bed
- [ ] bee
- [ ] beauty
- [ ] scarf
- [ ] language
- [ ] do
- [ ] humorous
- [ ] Friday
- [ ] scary
- [ ] which
- [ ] disadvantage
- [ ] complain
- [ ] fourteen
- [ ] she
- [ ] knife
- [ ] piece
- [ ] western
- [ ] carry
- [ ] refrigerator

# Chapter 071

- [ ] elephant
- [ ] party
- [ ] little
- [ ] however
- [ ] deep
- [ ] shy
- [ ] for
- [ ] fox
- [ ] perhaps
- [ ] aunt
- [ ] skill
- [ ] oak
- [ ] trouble
- [ ] divide
- [ ] sir
- [ ] class
- [ ] sit
- [ ] over
- [ ] six
- [ ] football

# Chapter 072

- [ ] dinner
- [ ] fork
- [ ] form
- [ ] farmer
- [ ] neither
- [ ] avoid
- [ ] gate
- [ ] fresh
- [ ] he
- [ ] very
- [ ] big
- [ ] practice
- [ ] crowd
- [ ] sick
- [ ] bit
- [ ] corner
- [ ] else
- [ ] four
- [ ] easily
- [ ] beside

# Chapter 073

- [ ] join
- [ ] if
- [ ] costume
- [ ] bathroom
- [ ] sky
- [ ] sentence
- [ ] hallway
- [ ] large
- [ ] surface
- [ ] in
- [ ] tomorrow
- [ ] verb
- [ ] metal
- [ ] is
- [ ] it
- [ ] fry
- [ ] drink
- [ ] announce
- [ ] somebody
- [ ] India

# Chapter 074

- [ ] traditional
- [ ] operate
- [ ] hello
- [ ] begin
- [ ] parrot
- [ ] become
- [ ] alive
- [ ] weekend
- [ ] noodle
- [ ] plate
- [ ] world
- [ ] library
- [ ] ability
- [ ] everything
- [ ] camera
- [ ] table
- [ ] bread
- [ ] side
- [ ] break
- [ ] restaurant

# Chapter 075

- [ ] change
- [ ] draw
- [ ] cupboard
- [ ] off
- [ ] joke
- [ ] knee
- [ ] hide
- [ ] century
- [ ] instruction
- [ ] discovery
- [ ] candle
- [ ] report
- [ ] complete
- [ ] fun
- [ ] theirs
- [ ] sign
- [ ] several
- [ ] cotton
- [ ] office
- [ ] while

# Chapter 076

- [ ] northern
- [ ] second
- [ ] that
- [ ] high
- [ ] edge
- [ ] son
- [ ] skirt
- [ ] than
- [ ] me
- [ ] level
- [ ] author
- [ ] Europe
- [ ] meter
- [ ] infinitive
- [ ] establish
- [ ] coat
- [ ] license
- [ ] dish
- [ ] dream
- [ ] Wednesday

# Chapter 077

- [ ] essay
- [ ] prediction
- [ ] coal
- [ ] survey
- [ ] tense
- [ ] birthday
- [ ] heat
- [ ] behind
- [ ] tenth
- [ ] candy
- [ ] student
- [ ] careful
- [ ] recipe
- [ ] seal
- [ ] box
- [ ] bow
- [ ] boy
- [ ] head
- [ ] month
- [ ] total

# Chapter 078

- [ ] oil
- [ ] upstairs
- [ ] of
- [ ] fight
- [ ] hear
- [ ] on
- [ ] zebra
- [ ] pretty
- [ ] or
- [ ] chance
- [ ] social
- [ ] wheel
- [ ] homeless
- [ ] cross
- [ ] control
- [ ] cousin
- [ ] clerk
- [ ] earth
- [ ] Paris
- [ ] elbow

# Chapter 079

- [ ] salad
- [ ] rocket
- [ ] somewhere
- [ ] scene
- [ ] injure
- [ ] Saturday
- [ ] freeze
- [ ] province
- [ ] clever
- [ ] friend
- [ ] bookcase
- [ ] January
- [ ] recent
- [ ] they
- [ ] noise
- [ ] pleasure
- [ ] old
- [ ] them
- [ ] then
- [ ] ancient

# Chapter 080

- [ ] accept
- [ ] zigzag
- [ ] seat
- [ ] horse
- [ ] twelve
- [ ] London
- [ ] underwater
- [ ] singular
- [ ] autumn
- [ ] bridge
- [ ] conference
- [ ] activity
- [ ] dormitory
- [ ] recite
- [ ] seek
- [ ] sun
- [ ] eighteenth
- [ ] seem
- [ ] secretary
- [ ] heel

# Chapter 081

- [ ] disturb
- [ ] so
- [ ] pierce
- [ ] key
- [ ] teenager
- [ ] calendar
- [ ] silk
- [ ] dumpling
- [ ] silent
- [ ] storm
- [ ] one
- [ ] garage
- [ ] slipper
- [ ] store
- [ ] flower
- [ ] single
- [ ] hill
- [ ] pull
- [ ] subway
- [ ] to

# Chapter 082

- [ ] fourth
- [ ] story
- [ ] but
- [ ] country
- [ ] symbol
- [ ] bus
- [ ] separate
- [ ] dislike
- [ ] buy
- [ ] express
- [ ] ruler
- [ ] zero
- [ ] amazing
- [ ] postcard
- [ ] up
- [ ] fifteenth
- [ ] unusual
- [ ] us
- [ ] usual
- [ ] sink

# Chapter 083

- [ ] degree
- [ ] this
- [ ] necessary
- [ ] thin
- [ ] ocean
- [ ] especially
- [ ] once
- [ ] solve
- [ ] desk
- [ ] know
- [ ] sing
- [ ] Internet
- [ ] support
- [ ] coin
- [ ] drop
- [ ] idea
- [ ] kid
- [ ] Yang
- [ ] cold
- [ ] life

# Chapter 084

- [ ] we
- [ ] cola
- [ ] honey
- [ ] normal
- [ ] wide
- [ ] teach
- [ ] argue
- [ ] stone
- [ ] succeed
- [ ] specially
- [ ] accessory
- [ ] gentleman
- [ ] shampoo
- [ ] yogurt
- [ ] reach
- [ ] competition
- [ ] none
- [ ] type
- [ ] beyond
- [ ] pupil

# Chapter 085

- [ ] problem
- [ ] road
- [ ] review
- [ ] sight
- [ ] weather
- [ ] asleep
- [ ] between
- [ ] method
- [ ] wife
- [ ] come
- [ ] push
- [ ] nature
- [ ] seventeen
- [ ] lift
- [ ] force
- [ ] scared
- [ ] flag
- [ ] south
- [ ] musician
- [ ] night

# Chapter 086

- [ ] north
- [ ] wear
- [ ] our
- [ ] weak
- [ ] out
- [ ] overseas
- [ ] rock
- [ ] impress
- [ ] noon
- [ ] feature
- [ ] flat
- [ ] get
- [ ] dark
- [ ] course
- [ ] copy
- [ ] place
- [ ] regular
- [ ] dare
- [ ] cook
- [ ] sell

# Chapter 087

- [ ] cool
- [ ] tired
- [ ] suggest
- [ ] leaf
- [ ] brain
- [ ] lead
- [ ] help
- [ ] expect
- [ ] emotion
- [ ] etiquette
- [ ] Chinese
- [ ] queue
- [ ] date
- [ ] magic
- [ ] impolite
- [ ] dress
- [ ] panda
- [ ] reveal
- [ ] passage
- [ ] onion

# Chapter 088

- [ ] sound
- [ ] own
- [ ] drum
- [ ] sausage
- [ ] dozen
- [ ] translate
- [ ] drug
- [ ] negative
- [ ] realistic
- [ ] twelfth
- [ ] monster
- [ ] plain
- [ ] should
- [ ] only
- [ ] create
- [ ] tag
- [ ] blow
- [ ] sunny
- [ ] notebook
- [ ] proud

# Chapter 089

- [ ] like
- [ ] ugly
- [ ] earthquake
- [ ] towards
- [ ] person
- [ ] safe
- [ ] send
- [ ] here
- [ ] note
- [ ] everybody
- [ ] week
- [ ] sail
- [ ] purpose
- [ ] regret
- [ ] line
- [ ] snake
- [ ] flee
- [ ] hero
- [ ] hers
- [ ] can

# Chapter 090

- [ ] award
- [ ] cap
- [ ] organize
- [ ] car
- [ ] ready
- [ ] marriage
- [ ] cat
- [ ] station
- [ ] disappointing
- [ ] village
- [ ] player
- [ ] nose
- [ ] balloon
- [ ] cost
- [ ] satisfy
- [ ] will
- [ ] match
- [ ] smoke
- [ ] follow
- [ ] really

# Chapter 091

- [ ] clothes
- [ ] challenge
- [ ] wild

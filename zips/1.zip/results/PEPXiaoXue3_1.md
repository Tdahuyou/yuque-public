
# Chapter 001

- [ ] ruler
- [ ] pencil
- [ ] eraser
- [ ] crayon
- [ ] bag
- [ ] pen
- [ ] pencil box
- [ ] book
- [ ] no
- [ ] your
- [ ] red
- [ ] green
- [ ] yellow
- [ ] blue
- [ ] black
- [ ] brown
- [ ] white
- [ ] orange
- [ ] OK
- [ ] mum

# Chapter 002

- [ ] face
- [ ] ear
- [ ] eye
- [ ] nose
- [ ] mouth
- [ ] arm
- [ ] hand
- [ ] head
- [ ] body
- [ ] leg
- [ ] foot
- [ ] school
- [ ] duck
- [ ] pig
- [ ] cat
- [ ] bear
- [ ] dog
- [ ] elephant
- [ ] monkey
- [ ] bird

# Chapter 003

- [ ] tiger
- [ ] panda
- [ ] zoo
- [ ] funny
- [ ] bread
- [ ] juice
- [ ] egg
- [ ] milk
- [ ] water
- [ ] cake
- [ ] fish
- [ ] rice
- [ ] one
- [ ] two
- [ ] three
- [ ] four
- [ ] five
- [ ] six
- [ ] seven
- [ ] eight

# Chapter 004

- [ ] nine
- [ ] ten
- [ ] brother
- [ ] plate


# Chapter 001

- [ ] greenhouse effect
- [ ] endanger
- [ ] trap
- [ ] ecology
- [ ] botanical
- [ ] a number of
- [ ] consultant
- [ ] brewery
- [ ] reserve
- [ ] principle
- [ ] boycott
- [ ] corrupt
- [ ] conservation
- [ ] consensus
- [ ] beyond
- [ ] claim
- [ ] look ahead
- [ ] relevant
- [ ] refer to
- [ ] in turn

# Chapter 002

- [ ] lead to
- [ ] ray
- [ ] bounce
- [ ] pin
- [ ] agriculture
- [ ] coincidence
- [ ] condemn
- [ ] drought
- [ ] federal
- [ ] reservation
- [ ] sacrifice
- [ ] take action
- [ ] advocate
- [ ] recycle
- [ ] substitute
- [ ] threaten
- [ ] ahead of
- [ ] pancake
- [ ] hurricane
- [ ] species

# Chapter 003

- [ ] leopard
- [ ] crested ibis
- [ ] alligator
- [ ] extinct
- [ ] habitat
- [ ] tortoise
- [ ] apart from
- [ ] mainland
- [ ] hook
- [ ] answer for
- [ ] seize
- [ ] call for an end to sth.
- [ ] or else
- [ ] wrap up
- [ ] behalf
- [ ] for good
- [ ] carry off
- [ ] Tibetan antelope
- [ ] Tibet
- [ ] fashionable

# Chapter 004

- [ ] enforce
- [ ] all in all
- [ ] orangutan
- [ ] landslide
- [ ] tsunami
- [ ] typhoon
- [ ] grand
- [ ] scale
- [ ] changeable
- [ ] thunderstorm
- [ ] rainfall
- [ ] irrigation
- [ ] arm
- [ ] result in
- [ ] rough
- [ ] quake
- [ ] offshore
- [ ] catastrophe
- [ ] separation
- [ ] means

# Chapter 005

- [ ] earn one's living
- [ ] construct
- [ ] clay
- [ ] brick
- [ ] slip
- [ ] slide
- [ ] mountainous
- [ ] howl
- [ ] flee
- [ ] potential
- [ ] dust
- [ ] roll
- [ ] plug
- [ ] quilt
- [ ] cushion
- [ ] industrialisation
- [ ] negative
- [ ] adopt
- [ ] soundproof
- [ ] rail

# Chapter 006

- [ ] warehouse
- [ ] considerate
- [ ] all the best
- [ ] decibel
- [ ] sum up
- [ ] as a matter of fact
- [ ] finance
- [ ] allocate
- [ ] politics
- [ ] fragile
- [ ] pest
- [ ] break away from
- [ ] sharpener
- [ ] sharpen
- [ ] valid
- [ ] evolution
- [ ] trunk
- [ ] tusk
- [ ] carve
- [ ] calculate

# Chapter 007

- [ ] cube
- [ ] cubic
- [ ] betray
- [ ] friction
- [ ] hand over
- [ ] recipe
- [ ] Muslim
- [ ] Catholic
- [ ] holy
- [ ] memorial
- [ ] justice
- [ ] widow
- [ ] minister
- [ ] compromise
- [ ] immigration
- [ ] civilian
- [ ] prejudice
- [ ] racial
- [ ] community
- [ ] drummer

# Chapter 008

- [ ] bid goodbye
- [ ] furnished
- [ ] bachelor
- [ ] expose
- [ ] alcoholic
- [ ] adolescent
- [ ] council
- [ ] departure
- [ ] lounge
- [ ] suite
- [ ] classify
- [ ] maid
- [ ] laundry
- [ ] tailor
- [ ] fortnight
- [ ] in a flash
- [ ] adolescence
- [ ] antique
- [ ] statesman
- [ ] bedding

# Chapter 009

- [ ] bungalow
- [ ] smog
- [ ] stand up for
- [ ] rugby
- [ ] talk sth. over with sb.
- [ ] put forward
- [ ] bakery
- [ ] sneaker
- [ ] from then on
- [ ] give in
- [ ] send for
- [ ] subscribe
- [ ] call in
- [ ] appoint
- [ ] union
- [ ] have a gift for
- [ ] sculpture
- [ ] pyramid
- [ ] commercial
- [ ] nutrition

# Chapter 010

- [ ] tip
- [ ] possession
- [ ] compass
- [ ] allowance
- [ ] criticise
- [ ] contradict
- [ ] sarcastic
- [ ] hold out
- [ ] by and by
- [ ] call on
- [ ] look down on
- [ ] keep one’s word
- [ ] come about
- [ ] slavery
- [ ] oilfield
- [ ] security
- [ ] ending
- [ ] in surprise
- [ ] weep
- [ ] shoot

# Chapter 011

- [ ] unconscious
- [ ] pile
- [ ] frontier
- [ ] trench
- [ ] representative
- [ ] greet
- [ ] remark
- [ ] distribute
- [ ] consume
- [ ] in peace
- [ ] bond
- [ ] shot
- [ ] ward
- [ ] scar
- [ ] surgeon
- [ ] bandage
- [ ] salute
- [ ] take sb.in one's arms
- [ ] sob
- [ ] swear

# Chapter 012

- [ ] acquaintance
- [ ] westwards
- [ ] handful
- [ ] tank
- [ ] firework
- [ ] greed
- [ ] import
- [ ] sponsor
- [ ] strengthen
- [ ] the more...the more...
- [ ] despite
- [ ] stable
- [ ] intend
- [ ] draft
- [ ] unfit
- [ ] spray
- [ ] dam
- [ ] tram
- [ ] thermos
- [ ] expense

# Chapter 013

- [ ] join up
- [ ] daisy
- [ ] Kaiser
- [ ] tramp
- [ ] rope off
- [ ] cabinet
- [ ] underpants
- [ ] arbitrary
- [ ] theoretical
- [ ] communism
- [ ] socialism
- [ ] communist
- [ ] socialist
- [ ] liberation
- [ ] possess
- [ ] bring sth. on sb.
- [ ] look into
- [ ] confidential
- [ ] sort out
- [ ] opening

# Chapter 014

- [ ] homelessness
- [ ] inequality
- [ ] abortion
- [ ] household
- [ ] graph
- [ ] life expectancy
- [ ] voluntary
- [ ] abundant
- [ ] consumer
- [ ] deposit
- [ ] currency
- [ ] signature
- [ ] taxpayer
- [ ] govern
- [ ] accumulate
- [ ] ownership
- [ ] burden
- [ ] rag
- [ ] vacant
- [ ] resistance

# Chapter 015

- [ ] come into being
- [ ] adjustment
- [ ] diverse
- [ ] grill
- [ ] vice
- [ ] mutton
- [ ] wind sb. up
- [ ] brunch
- [ ] buffet
- [ ] bare
- [ ] pension
- [ ] resign
- [ ] pregnant
- [ ] fingernail
- [ ] hydrogen
- [ ] format
- [ ] choke
- [ ] delete
- [ ] shrink
- [ ] Utopia

# Chapter 016

- [ ] leisure
- [ ] virtue
- [ ] framework
- [ ] show off
- [ ] feast
- [ ] surplus
- [ ] elect
- [ ] merciful
- [ ] sow
- [ ] roundabout
- [ ] collision
- [ ] knock into sb.
- [ ] weed
- [ ] fountain
- [ ] paddle
- [ ] wag
- [ ] packet
- [ ] grocer
- [ ] rot
- [ ] league

# Chapter 017

- [ ] ministry
- [ ] poster
- [ ] skip
- [ ] edition
- [ ] alley
- [ ] rectangular
- [ ] mop
- [ ] fragrant
- [ ] cast
- [ ] turning point
- [ ] undertake
- [ ] preservation
- [ ] squeeze
- [ ] arch
- [ ] thirst
- [ ] container
- [ ] relay
- [ ] spoonful
- [ ] robbery
- [ ] break into

# Chapter 018

- [ ] rape
- [ ] shoplifting
- [ ] penalty
- [ ] fine
- [ ] sentence
- [ ] revenge
- [ ] on principle
- [ ] abolish
- [ ] sentence sb.to death
- [ ] moreover
- [ ] furthermore
- [ ] consequently
- [ ] anchor
- [ ] seaweed
- [ ] swing
- [ ] seagull
- [ ] spiritual
- [ ] Buddhism
- [ ] prayer
- [ ] merchant

# Chapter 019

- [ ] wax
- [ ] pan
- [ ] semicircle
- [ ] suck

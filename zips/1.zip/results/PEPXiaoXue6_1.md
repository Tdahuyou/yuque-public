
# Chapter 001

- [ ] science
- [ ] museum
- [ ] post office
- [ ] bookstore
- [ ] cinema
- [ ] hospital
- [ ] crossing
- [ ] turn
- [ ] left
- [ ] on foot
- [ ] by
- [ ] bus
- [ ] plane
- [ ] taxi
- [ ] ship
- [ ] subway
- [ ] train
- [ ] slow
- [ ] down
- [ ] slow down

# Chapter 002

- [ ] stop
- [ ] Mrs
- [ ] early
- [ ] helmet
- [ ] must
- [ ] wear
- [ ] attention
- [ ] pay attention to
- [ ] traffic
- [ ] traffic lights
- [ ] Munich
- [ ] Germany
- [ ] Alaska
- [ ] sled
- [ ] fast
- [ ] ferry
- [ ] Papa Westray
- [ ] Scotland
- [ ] visit
- [ ] film

# Chapter 003

- [ ] see a film
- [ ] trip
- [ ] take a trip
- [ ] supermarket
- [ ] evening
- [ ] tonight
- [ ] tomorrow
- [ ] next week
- [ ] dictionary
- [ ] comic
- [ ] comic book
- [ ] word
- [ ] word book
- [ ] post card
- [ ] lesson
- [ ] space
- [ ] travel
- [ ] half
- [ ] price
- [ ] Mid-Autumn Festival

# Chapter 004

- [ ] together
- [ ] get together
- [ ] mooncake
- [ ] poem
- [ ] moon
- [ ] studies
- [ ] puzzle
- [ ] hiking
- [ ] pen pal
- [ ] hobby
- [ ] jasmine
- [ ] idea
- [ ] Canberra
- [ ] amazing
- [ ] shall
- [ ] goal
- [ ] join
- [ ] club
- [ ] share
- [ ] factory

# Chapter 005

- [ ] worker
- [ ] postman
- [ ] businessman
- [ ] police officer
- [ ] fisherman
- [ ] scientist
- [ ] pilot
- [ ] coach
- [ ] country
- [ ] head teacher
- [ ] sea
- [ ] stay
- [ ] university
- [ ] gym
- [ ] if
- [ ] reporter
- [ ] use
- [ ] type
- [ ] quickly
- [ ] secretary

# Chapter 006

- [ ] angry
- [ ] afraid
- [ ] sad
- [ ] worried
- [ ] happy
- [ ] see a doctor
- [ ] wear.
- [ ] more
- [ ] deep
- [ ] breath
- [ ] take a deep breath
- [ ] count
- [ ] count to ten
- [ ] chase
- [ ] mice
- [ ] bad
- [ ] hurt
- [ ] ill
- [ ] wrong
- [ ] should

# Chapter 007

- [ ] feel
- [ ] well
- [ ] sit
- [ ] grass
- [ ] ant
- [ ] worry
- [ ] stuck
- [ ] mud
- [ ] pull
- [ ] everyone

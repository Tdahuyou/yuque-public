
# Chapter 001

- [ ] first floor
- [ ] second floor
- [ ] teacher's office
- [ ] library
- [ ] playground
- [ ] computer room
- [ ] art room
- [ ] music room
- [ ] next to
- [ ] homework
- [ ] class
- [ ] forty
- [ ] way
- [ ] breakfast
- [ ] English class
- [ ] lunch
- [ ] music class
- [ ] PE class
- [ ] dinner
- [ ] get up

# Chapter 002

- [ ] go to school
- [ ] go home
- [ ] go to bed
- [ ] over
- [ ] now
- [ ] o'clock
- [ ] kid
- [ ] thirty
- [ ] hurry up
- [ ] come on
- [ ] just a minute
- [ ] cold
- [ ] cool
- [ ] warm
- [ ] hot
- [ ] sunny
- [ ] windy
- [ ] cloudy
- [ ] snowy
- [ ] rainy

# Chapter 003

- [ ] outside
- [ ] be careful
- [ ] weather
- [ ] New York
- [ ] how about...
- [ ] degree
- [ ] world
- [ ] London
- [ ] Moscow
- [ ] Singapore
- [ ] Sydney
- [ ] fly
- [ ] love
- [ ] tomato
- [ ] potato
- [ ] green beans
- [ ] carrot
- [ ] horse
- [ ] cow
- [ ] sheep

# Chapter 004

- [ ] hen
- [ ] these
- [ ] yum
- [ ] animal
- [ ] those
- [ ] garden
- [ ] farm
- [ ] goat
- [ ] eat
- [ ] clothes
- [ ] pants
- [ ] hat
- [ ] dress
- [ ] skirt
- [ ] coat
- [ ] sweater
- [ ] sock
- [ ] shorts
- [ ] jacket
- [ ] shirt

# Chapter 005

- [ ] yours
- [ ] whose
- [ ] mine
- [ ] pack
- [ ] wait
- [ ] glove
- [ ] scarf
- [ ] umbrella
- [ ] sunglasses
- [ ] pretty
- [ ] expensive
- [ ] cheap
- [ ] nice
- [ ] try on
- [ ] size
- [ ] of course
- [ ] too
- [ ] just
- [ ] how much
- [ ] eighty

# Chapter 006

- [ ] dollar
- [ ] sale
- [ ] more
- [ ] us

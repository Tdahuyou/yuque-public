
# Chapter 001

- [ ] sensible
- [ ] sign
- [ ] as
- [ ] explicit
- [ ] wreck
- [ ] ravage
- [ ] wreathe
- [ ] impede
- [ ] thesis
- [ ] precedent
- [ ] lofty
- [ ] fridge
- [ ] immune
- [ ] scratch
- [ ] circulate
- [ ] nitrogen
- [ ] alone
- [ ] sieve
- [ ] spiral
- [ ] mercenary

# Chapter 002

- [ ] mechanism
- [ ] integrate
- [ ] earnest
- [ ] adolescence
- [ ] grave
- [ ] intrigue
- [ ] claim
- [ ] opt
- [ ] stipulate
- [ ] eradicate
- [ ] delirium
- [ ] pole
- [ ] herd
- [ ] stitch
- [ ] slag
- [ ] consolidate
- [ ] civic
- [ ] clash
- [ ] distract
- [ ] strap

# Chapter 003

- [ ] format
- [ ] company
- [ ] trench
- [ ] vain
- [ ] exempt
- [ ] mask
- [ ] dwell
- [ ] misgiving
- [ ] vex
- [ ] fare
- [ ] external
- [ ] sue
- [ ] haphazard
- [ ] allot
- [ ] psychiatry
- [ ] out
- [ ] posture
- [ ] recycle
- [ ] expose
- [ ] perception

# Chapter 004

- [ ] paranoia
- [ ] alongside
- [ ] canteen
- [ ] supreme
- [ ] reasonable
- [ ] naught
- [ ] unfold
- [ ] cushion
- [ ] mimic
- [ ] vicinity
- [ ] toss
- [ ] refine
- [ ] shred
- [ ] disperse
- [ ] edition
- [ ] fetter
- [ ] renaissance
- [ ] proceeding
- [ ] abridge
- [ ] dome

# Chapter 005

- [ ] reckon
- [ ] rarely
- [ ] rural
- [ ] imitation
- [ ] steward
- [ ] abound
- [ ] colonial
- [ ] immense
- [ ] placard
- [ ] client
- [ ] flavour
- [ ] exchange
- [ ] pamphlet
- [ ] module
- [ ] gentle
- [ ] annoy
- [ ] luminous
- [ ] exclaim
- [ ] pertinent
- [ ] certify

# Chapter 006

- [ ] revenue
- [ ] insurance
- [ ] authority
- [ ] endorse
- [ ] wrap
- [ ] lenient
- [ ] pompous
- [ ] decorate
- [ ] infinite
- [ ] perplex
- [ ] snatch
- [ ] sweep
- [ ] odor
- [ ] rip
- [ ] livestock
- [ ] unlikely
- [ ] signature
- [ ] grieve
- [ ] dizzy
- [ ] ancestor

# Chapter 007

- [ ] vanish
- [ ] gallery
- [ ] manual
- [ ] whereas
- [ ] glare
- [ ] fret
- [ ] admission
- [ ] criminal
- [ ] drastic
- [ ] lucid
- [ ] simultaneous
- [ ] static
- [ ] redundant
- [ ] be
- [ ] elite
- [ ] economic
- [ ] destine
- [ ] janitor
- [ ] thermometer
- [ ] advertise

# Chapter 008

- [ ] commence
- [ ] project
- [ ] retail
- [ ] rear
- [ ] vital
- [ ] mission
- [ ] paralyse
- [ ] massive
- [ ] glacier
- [ ] oxide
- [ ] occur
- [ ] carry
- [ ] loan
- [ ] overlook
- [ ] periscope
- [ ] typical
- [ ] priority
- [ ] weave
- [ ] overt
- [ ] flank

# Chapter 009

- [ ] overcome
- [ ] alter
- [ ] interval
- [ ] sheer
- [ ] slight
- [ ] simulate
- [ ] convenience
- [ ] electronic
- [ ] verbal
- [ ] mildew
- [ ] disposition
- [ ] marvel
- [ ] freight
- [ ] tease
- [ ] intermittent
- [ ] tame
- [ ] sluggish
- [ ] fulfil
- [ ] compass
- [ ] paternity

# Chapter 010

- [ ] ferocious
- [ ] intense
- [ ] humidity
- [ ] elaborate
- [ ] underlying
- [ ] endow
- [ ] anticipate
- [ ] offshore
- [ ] detriment
- [ ] nourishment
- [ ] lick
- [ ] marsh
- [ ] perspire
- [ ] gauge
- [ ] explode
- [ ] fringe
- [ ] fascinating
- [ ] uneasy
- [ ] expedition
- [ ] organism

# Chapter 011

- [ ] swallow
- [ ] spare
- [ ] means
- [ ] proportion
- [ ] microfilm
- [ ] obscene
- [ ] meek
- [ ] herb
- [ ] mansion
- [ ] minute
- [ ] outcry
- [ ] preface
- [ ] sediment
- [ ] resign
- [ ] torch
- [ ] deteriorate
- [ ] degenerate
- [ ] characterize
- [ ] parade
- [ ] let

# Chapter 012

- [ ] swing
- [ ] incongruous
- [ ] inventory
- [ ] choir
- [ ] hatch
- [ ] demonstrate
- [ ] conversion
- [ ] dearth
- [ ] profane
- [ ] cluster
- [ ] revolt
- [ ] secular
- [ ] agenda
- [ ] loop
- [ ] conscientious
- [ ] revenge
- [ ] friction
- [ ] diversion
- [ ] check
- [ ] proceed

# Chapter 013

- [ ] chase
- [ ] plea
- [ ] mobilize
- [ ] yearn
- [ ] personnel
- [ ] vice
- [ ] paddle
- [ ] clutch
- [ ] pedestrian
- [ ] graphic
- [ ] mercantile
- [ ] console
- [ ] tremendous
- [ ] decrease
- [ ] performance
- [ ] attempt
- [ ] naked
- [ ] female
- [ ] raid
- [ ] miserable

# Chapter 014

- [ ] innocent
- [ ] stack
- [ ] humble
- [ ] shamble
- [ ] ribbon
- [ ] tyrannical
- [ ] aerial
- [ ] astronomy
- [ ] segment
- [ ] downtown
- [ ] defraud
- [ ] improvise
- [ ] oppress
- [ ] flabby
- [ ] essay
- [ ] racket
- [ ] flaw
- [ ] nominate
- [ ] syllabus
- [ ] stiff

# Chapter 015

- [ ] toxic
- [ ] rampant
- [ ] propulsion
- [ ] telling
- [ ] throughout
- [ ] highlight
- [ ] devise
- [ ] wield
- [ ] enormous
- [ ] fade
- [ ] exhilarate
- [ ] slum
- [ ] peer
- [ ] slogan
- [ ] transaction
- [ ] incorporate
- [ ] discard
- [ ] grope
- [ ] triple
- [ ] variety

# Chapter 016

- [ ] detrimental
- [ ] hitherto
- [ ] indispensable
- [ ] porcelain
- [ ] mania
- [ ] neurosis
- [ ] dot
- [ ] utterly
- [ ] evaporate
- [ ] quest
- [ ] coarse
- [ ] resume
- [ ] integrity
- [ ] contention
- [ ] universal
- [ ] opponent
- [ ] solar
- [ ] consist
- [ ] reptile
- [ ] headstrong

# Chapter 017

- [ ] complicated
- [ ] deprive
- [ ] helicopter
- [ ] grief
- [ ] commission
- [ ] rehabilitate
- [ ] sheet
- [ ] port
- [ ] outline
- [ ] eject
- [ ] opportunity
- [ ] savage
- [ ] approximate
- [ ] gesture
- [ ] cape
- [ ] commute
- [ ] hazardous
- [ ] curve
- [ ] catalogue
- [ ] abrasion

# Chapter 018

- [ ] agitation
- [ ] accountable
- [ ] custom
- [ ] sporadic
- [ ] towel
- [ ] knob
- [ ] invariably
- [ ] plumb
- [ ] triumph
- [ ] forum
- [ ] decompose
- [ ] confident
- [ ] liberal
- [ ] sway
- [ ] perplexity
- [ ] prospective
- [ ] straightforward
- [ ] marble
- [ ] registrar
- [ ] prototype

# Chapter 019

- [ ] oust
- [ ] trespass
- [ ] enzyme
- [ ] smuggle
- [ ] petition
- [ ] tract
- [ ] falter
- [ ] marine
- [ ] fraction
- [ ] multitude
- [ ] plunder
- [ ] activate
- [ ] treatise
- [ ] contemplate
- [ ] fibre
- [ ] reel
- [ ] misfortune
- [ ] delicious
- [ ] certainty
- [ ] expedient

# Chapter 020

- [ ] throat
- [ ] disdain
- [ ] inferior
- [ ] magnanimous
- [ ] abortion
- [ ] commentary
- [ ] plankton
- [ ] succession
- [ ] compile
- [ ] dimension
- [ ] traction
- [ ] reverent
- [ ] stubborn
- [ ] cemetery
- [ ] classic
- [ ] melancholy
- [ ] ultimately
- [ ] laborious
- [ ] notion
- [ ] ensemble

# Chapter 021

- [ ] adapt
- [ ] maltreat
- [ ] fidelity
- [ ] nap
- [ ] foam
- [ ] sculpture
- [ ] charm
- [ ] accuse
- [ ] ratio
- [ ] cement
- [ ] cure
- [ ] upbringing
- [ ] agreement
- [ ] unify
- [ ] maintenance
- [ ] mischief
- [ ] centenary
- [ ] twilight
- [ ] accommodation
- [ ] intimate

# Chapter 022

- [ ] inject
- [ ] heir
- [ ] postgraduate
- [ ] engrave
- [ ] festival
- [ ] mishap
- [ ] characteristic
- [ ] on
- [ ] numerate
- [ ] ridge
- [ ] threshold
- [ ] profit
- [ ] premise
- [ ] seam
- [ ] paraphrase
- [ ] underestimate
- [ ] automobile
- [ ] square
- [ ] manuscript
- [ ] gravity

# Chapter 023

- [ ] condition
- [ ] specialize
- [ ] undermine
- [ ] motif
- [ ] fatuous
- [ ] underwrite
- [ ] dairy
- [ ] conquest
- [ ] drown
- [ ] pseudonym
- [ ] coordinate
- [ ] designate
- [ ] athlete
- [ ] underline
- [ ] loath
- [ ] meddle
- [ ] myth
- [ ] coil
- [ ] enthusiasm
- [ ] guild

# Chapter 024

- [ ] excerpt
- [ ] jolt
- [ ] nobility
- [ ] novelty
- [ ] garment
- [ ] obedient
- [ ] drill
- [ ] dodge
- [ ] gymnasium
- [ ] part
- [ ] deflate
- [ ] clasp
- [ ] drench
- [ ] ecology
- [ ] guardian
- [ ] pit
- [ ] conflict
- [ ] sympathetic
- [ ] objective
- [ ] electrical

# Chapter 025

- [ ] turbulent
- [ ] invade
- [ ] permanent
- [ ] fundamental
- [ ] receipt
- [ ] profuse
- [ ] extort
- [ ] spacious
- [ ] velocity
- [ ] checkup
- [ ] landscape
- [ ] convene
- [ ] cork
- [ ] increment
- [ ] host
- [ ] suspense
- [ ] infringe
- [ ] discern
- [ ] shimmer
- [ ] medal

# Chapter 026

- [ ] negation
- [ ] venture
- [ ] fantastic
- [ ] line
- [ ] suspend
- [ ] faint
- [ ] due
- [ ] reticent
- [ ] deduce
- [ ] renovation
- [ ] recite
- [ ] dubious
- [ ] invalid
- [ ] exuberant
- [ ] autonomy
- [ ] damp
- [ ] aspire
- [ ] transmission
- [ ] toast
- [ ] circus

# Chapter 027

- [ ] qualification
- [ ] lounge
- [ ] dip
- [ ] tenacious
- [ ] rub
- [ ] chasm
- [ ] mind
- [ ] justify
- [ ] transfer
- [ ] physique
- [ ] technician
- [ ] protein
- [ ] ambiguous
- [ ] fascinate
- [ ] gradual
- [ ] recruit
- [ ] convey
- [ ] obligation
- [ ] testimony
- [ ] fragment

# Chapter 028

- [ ] moderate
- [ ] endeavor
- [ ] sort
- [ ] conceal
- [ ] mandate
- [ ] crumple
- [ ] arch
- [ ] supervise
- [ ] territory
- [ ] swift
- [ ] robust
- [ ] unravel
- [ ] responsive
- [ ] weld
- [ ] accumulate
- [ ] oval
- [ ] gratitude
- [ ] circumference
- [ ] congestion
- [ ] sociology

# Chapter 029

- [ ] pinnacle
- [ ] prevalent
- [ ] hereditary
- [ ] speciality
- [ ] stock
- [ ] propose
- [ ] epoch
- [ ] mirage
- [ ] supplementary
- [ ] chart
- [ ] unemployment
- [ ] fallacy
- [ ] incline
- [ ] prohibit
- [ ] zoology
- [ ] elicit
- [ ] numerical
- [ ] solvent
- [ ] correspondence
- [ ] epidemic

# Chapter 030

- [ ] disrupt
- [ ] humiliate
- [ ] medium
- [ ] ripple
- [ ] curse
- [ ] scandal
- [ ] counsel
- [ ] stagger
- [ ] capsule
- [ ] imperative
- [ ] recipe
- [ ] drift
- [ ] hum
- [ ] generic
- [ ] referendum
- [ ] fluid
- [ ] authentic
- [ ] swamp
- [ ] shrug
- [ ] flush

# Chapter 031

- [ ] repatriate
- [ ] parachute
- [ ] dam
- [ ] warden
- [ ] pursuit
- [ ] catch
- [ ] plot
- [ ] reverse
- [ ] purity
- [ ] statistics
- [ ] tenable
- [ ] tangible
- [ ] dismiss
- [ ] invoice
- [ ] nutrition
- [ ] gaunt
- [ ] defendant
- [ ] fluctuate
- [ ] enhance
- [ ] terrific

# Chapter 032

- [ ] display
- [ ] symphony
- [ ] tonic
- [ ] tissue
- [ ] tuition
- [ ] journal
- [ ] kernel
- [ ] thumb
- [ ] prospectus
- [ ] diagnose
- [ ] extra
- [ ] dwindle
- [ ] patch
- [ ] sketch
- [ ] mean
- [ ] trace
- [ ] defence
- [ ] expulsion
- [ ] potential
- [ ] passport

# Chapter 033

- [ ] craft
- [ ] gleam
- [ ] overflow
- [ ] solemn
- [ ] vegetation
- [ ] pliable
- [ ] apprehension
- [ ] rave
- [ ] locomotive
- [ ] entrepreneur
- [ ] doubtful
- [ ] morbid
- [ ] violent
- [ ] exemplify
- [ ] cease
- [ ] rotate
- [ ] solution
- [ ] identify
- [ ] paramount
- [ ] combine

# Chapter 034

- [ ] avalanche
- [ ] apparatus
- [ ] ditch
- [ ] range
- [ ] colossal
- [ ] slim
- [ ] pavement
- [ ] random
- [ ] disturb
- [ ] terrify
- [ ] keep
- [ ] physician
- [ ] precious
- [ ] insane
- [ ] code
- [ ] entitle
- [ ] alternative
- [ ] criterion
- [ ] ward
- [ ] assess

# Chapter 035

- [ ] flesh
- [ ] stuntman
- [ ] via
- [ ] framework
- [ ] pose
- [ ] competitive
- [ ] confine
- [ ] natal
- [ ] flame
- [ ] surmount
- [ ] comparable
- [ ] transparent
- [ ] lens
- [ ] crush
- [ ] condemn
- [ ] precedence
- [ ] organ
- [ ] staple
- [ ] differentiate
- [ ] engage

# Chapter 036

- [ ] truant
- [ ] embassy
- [ ] alienate
- [ ] obligatory
- [ ] predominant
- [ ] indifferent
- [ ] delete
- [ ] cart
- [ ] translucent
- [ ] posterity
- [ ] curriculum
- [ ] forgive
- [ ] component
- [ ] granular
- [ ] scrutiny
- [ ] wary
- [ ] relevant
- [ ] spiritual
- [ ] hectic
- [ ] phenomenal

# Chapter 037

- [ ] guarantee
- [ ] lame
- [ ] nuance
- [ ] destination
- [ ] irrespective
- [ ] drudgery
- [ ] saline
- [ ] descent
- [ ] cognitive
- [ ] submerge
- [ ] concoct
- [ ] anxiety
- [ ] ungainly
- [ ] impetus
- [ ] asylum
- [ ] conjunction
- [ ] one
- [ ] visualize
- [ ] ephemeral
- [ ] pants

# Chapter 038

- [ ] thermostat
- [ ] stimulate
- [ ] manufacture
- [ ] defiance
- [ ] moreover
- [ ] veto
- [ ] combat
- [ ] symptom
- [ ] casual
- [ ] concerted
- [ ] subsidiary
- [ ] insolent
- [ ] permit
- [ ] dreary
- [ ] merit
- [ ] torrent
- [ ] flatter
- [ ] layoff
- [ ] evaluate
- [ ] vent

# Chapter 039

- [ ] compact
- [ ] productivity
- [ ] unconditional
- [ ] lurk
- [ ] stress
- [ ] zest
- [ ] rival
- [ ] fragrance
- [ ] comply
- [ ] trustworthy
- [ ] stain
- [ ] patent
- [ ] harassment
- [ ] dwarf
- [ ] appraisal
- [ ] painstaking
- [ ] frail
- [ ] competence
- [ ] airing
- [ ] deny

# Chapter 040

- [ ] residence
- [ ] achieve
- [ ] intellect
- [ ] commonplace
- [ ] drowse
- [ ] aquatic
- [ ] cheer
- [ ] charity
- [ ] lock
- [ ] posthumous
- [ ] puncture
- [ ] aupair
- [ ] corporate
- [ ] proclaim
- [ ] fame
- [ ] trifle
- [ ] pervade
- [ ] scar
- [ ] unconscious
- [ ] investigate

# Chapter 041

- [ ] oasis
- [ ] hard
- [ ] orthodox
- [ ] salvage
- [ ] confusion
- [ ] exceptional
- [ ] drought
- [ ] null
- [ ] fetch
- [ ] harness
- [ ] trivial
- [ ] ease
- [ ] furnish
- [ ] paraphernalia
- [ ] extent
- [ ] instrumental
- [ ] exorbitant
- [ ] combustible
- [ ] address
- [ ] junk

# Chapter 042

- [ ] reputation
- [ ] obstruct
- [ ] enclosure
- [ ] telecommunication
- [ ] custodian
- [ ] meditate
- [ ] oblige
- [ ] versus
- [ ] timidity
- [ ] volatile
- [ ] indignant
- [ ] seal
- [ ] sovereign
- [ ] cute
- [ ] navigation
- [ ] shock
- [ ] account
- [ ] main
- [ ] repertoire
- [ ] void

# Chapter 043

- [ ] regarding
- [ ] contract
- [ ] resolve
- [ ] virtuous
- [ ] incredible
- [ ] compensate
- [ ] hysterical
- [ ] hug
- [ ] inhabit
- [ ] tweezers
- [ ] oversee
- [ ] lateral
- [ ] scroll
- [ ] outset
- [ ] locker
- [ ] imperial
- [ ] upkeep
- [ ] voluntary
- [ ] relentless
- [ ] glide

# Chapter 044

- [ ] splendid
- [ ] freak
- [ ] dynamic
- [ ] cardinal
- [ ] lace
- [ ] derelict
- [ ] viable
- [ ] fusion
- [ ] recede
- [ ] prophecy
- [ ] ego
- [ ] muscular
- [ ] exterior
- [ ] accommodate
- [ ] violate
- [ ] jealous
- [ ] initiate
- [ ] concrete
- [ ] unrest
- [ ] apply

# Chapter 045

- [ ] havoc
- [ ] poster
- [ ] entangle
- [ ] purge
- [ ] sponsor
- [ ] title
- [ ] steamer
- [ ] scorn
- [ ] inertia
- [ ] audition
- [ ] meadow
- [ ] pamper
- [ ] memorandum
- [ ] reluctant
- [ ] ragged
- [ ] tentacle
- [ ] territorial
- [ ] album
- [ ] restore
- [ ] creep

# Chapter 046

- [ ] make
- [ ] attach
- [ ] galaxy
- [ ] encounter
- [ ] suitcase
- [ ] stall
- [ ] staff
- [ ] curtail
- [ ] wail
- [ ] thereby
- [ ] mediocre
- [ ] valley
- [ ] tolerance
- [ ] renowned
- [ ] conspiracy
- [ ] protocol
- [ ] picnic
- [ ] dazzle
- [ ] malnutrition
- [ ] plight

# Chapter 047

- [ ] afflict
- [ ] detergent
- [ ] engross
- [ ] score
- [ ] awkward
- [ ] preserve
- [ ] fruition
- [ ] cane
- [ ] inhibit
- [ ] pilot
- [ ] logic
- [ ] singular
- [ ] hell
- [ ] practical
- [ ] shuttle
- [ ] offset
- [ ] destiny
- [ ] disorder
- [ ] denial
- [ ] spin

# Chapter 048

- [ ] onset
- [ ] native
- [ ] overwrought
- [ ] roast
- [ ] survey
- [ ] profile
- [ ] offspring
- [ ] practicable
- [ ] discharge
- [ ] chorus
- [ ] statute
- [ ] latitude
- [ ] rot
- [ ] phase
- [ ] ruffle
- [ ] diverse
- [ ] wicked
- [ ] omit
- [ ] diploma
- [ ] crack

# Chapter 049

- [ ] remittance
- [ ] vibrate
- [ ] controversy
- [ ] microbe
- [ ] frustrate
- [ ] omen
- [ ] fraught
- [ ] disclose
- [ ] superb
- [ ] talented
- [ ] hydrogen
- [ ] stagnant
- [ ] obstacle
- [ ] pour
- [ ] respiration
- [ ] aware
- [ ] sectional
- [ ] crisis
- [ ] procure
- [ ] trigger

# Chapter 050

- [ ] discrete
- [ ] stabilize
- [ ] nursery
- [ ] apt
- [ ] whip
- [ ] protest
- [ ] thigh
- [ ] trickle
- [ ] reward
- [ ] outlaw
- [ ] chisel
- [ ] ideal
- [ ] rivet
- [ ] equitable
- [ ] thesaurus
- [ ] penetrate
- [ ] dilate
- [ ] participate
- [ ] provision
- [ ] emphasize

# Chapter 051

- [ ] plank
- [ ] rig
- [ ] pedal
- [ ] inert
- [ ] tactic
- [ ] plague
- [ ] deserve
- [ ] communication
- [ ] clinic
- [ ] nickel
- [ ] orderly
- [ ] faith
- [ ] upset
- [ ] sabotage
- [ ] slice
- [ ] fantasy
- [ ] expire
- [ ] manacle
- [ ] discipline
- [ ] foul

# Chapter 052

- [ ] sacred
- [ ] suspect
- [ ] face
- [ ] narrative
- [ ] oblong
- [ ] sacrifice
- [ ] pacify
- [ ] cocaine
- [ ] interpret
- [ ] conducive
- [ ] tremble
- [ ] rack
- [ ] carton
- [ ] perish
- [ ] scatter
- [ ] tension
- [ ] exclude
- [ ] flake
- [ ] linger
- [ ] plug

# Chapter 053

- [ ] truce
- [ ] issue
- [ ] schedule
- [ ] yard
- [ ] navigable
- [ ] vehement
- [ ] eliminate
- [ ] prejudice
- [ ] dual
- [ ] essential
- [ ] promote
- [ ] appreciate
- [ ] motto
- [ ] toddle
- [ ] feud
- [ ] census
- [ ] archaic
- [ ] dissolve
- [ ] carrier
- [ ] cue

# Chapter 054

- [ ] impromptu
- [ ] amaze
- [ ] weary
- [ ] assurance
- [ ] automation
- [ ] undertake
- [ ] pessimism
- [ ] proxy
- [ ] heal
- [ ] stale
- [ ] destructive
- [ ] pounce
- [ ] deliver
- [ ] defy
- [ ] delegate
- [ ] evade
- [ ] hilarious
- [ ] septic
- [ ] pave
- [ ] roar

# Chapter 055

- [ ] literature
- [ ] historic
- [ ] tune
- [ ] aggressive
- [ ] identification
- [ ] fuss
- [ ] geometry
- [ ] transit
- [ ] potent
- [ ] transition
- [ ] commotion
- [ ] tropic
- [ ] assert
- [ ] malleable
- [ ] resolution
- [ ] fleet
- [ ] summary
- [ ] irony
- [ ] perspective
- [ ] polar

# Chapter 056

- [ ] attendant
- [ ] handicap
- [ ] eligible
- [ ] crooked
- [ ] diplomatic
- [ ] plough
- [ ] riot
- [ ] absorb
- [ ] parody
- [ ] gear
- [ ] errand
- [ ] microcosm
- [ ] inapt
- [ ] decent
- [ ] coeducation
- [ ] utility
- [ ] sterling
- [ ] ominous
- [ ] erect
- [ ] immigrant

# Chapter 057

- [ ] periphery
- [ ] execute
- [ ] arbitrary
- [ ] good
- [ ] interact
- [ ] spectacular
- [ ] layman
- [ ] rust
- [ ] elderly
- [ ] prolong
- [ ] whereby
- [ ] jog
- [ ] persist
- [ ] settle
- [ ] hawk
- [ ] heritage
- [ ] pad
- [ ] ongoing
- [ ] souvenir
- [ ] pastime

# Chapter 058

- [ ] foster
- [ ] exaggerate
- [ ] gracious
- [ ] familiar
- [ ] physiological
- [ ] warehouse
- [ ] solitary
- [ ] complication
- [ ] redeem
- [ ] turnover
- [ ] sanction
- [ ] motivate
- [ ] thorn
- [ ] involve
- [ ] architect
- [ ] particle
- [ ] accord
- [ ] pay
- [ ] pharmaceutical
- [ ] insult

# Chapter 059

- [ ] tug
- [ ] constituent
- [ ] piecemeal
- [ ] decimal
- [ ] starch
- [ ] invincible
- [ ] anchor
- [ ] avail
- [ ] isolate
- [ ] limp
- [ ] represent
- [ ] dissipate
- [ ] intersection
- [ ] complement
- [ ] vacuum
- [ ] personal
- [ ] sulphur
- [ ] stride
- [ ] linen
- [ ] grip

# Chapter 060

- [ ] sake
- [ ] piety
- [ ] concern
- [ ] intuition
- [ ] troupe
- [ ] panel
- [ ] ascent
- [ ] anthem
- [ ] traverse
- [ ] qualify
- [ ] manifold
- [ ] oriental
- [ ] fracture
- [ ] snap
- [ ] capture
- [ ] kidney
- [ ] disaster
- [ ] customary
- [ ] tentative
- [ ] figure

# Chapter 061

- [ ] undergo
- [ ] sprawl
- [ ] trek
- [ ] equation
- [ ] mould
- [ ] depict
- [ ] grease
- [ ] insolvent
- [ ] misery
- [ ] zeal
- [ ] erupt
- [ ] compliance
- [ ] apparent
- [ ] ore
- [ ] temper
- [ ] atlas
- [ ] fuse
- [ ] antecedent
- [ ] inflict
- [ ] glossary

# Chapter 062

- [ ] declare
- [ ] generate
- [ ] regeneration
- [ ] jagged
- [ ] impressive
- [ ] parallel
- [ ] patio
- [ ] overdue
- [ ] amount
- [ ] cast
- [ ] lodging
- [ ] dingy
- [ ] temperament
- [ ] shabby
- [ ] foremost
- [ ] merge
- [ ] attorney
- [ ] militant
- [ ] wrinkle
- [ ] maintain

# Chapter 063

- [ ] editorial
- [ ] kin
- [ ] contend
- [ ] partition
- [ ] outbreak
- [ ] authoritative
- [ ] slippery
- [ ] goal
- [ ] outstrip
- [ ] preceding
- [ ] transform
- [ ] skim
- [ ] insure
- [ ] debris
- [ ] hemisphere
- [ ] dominant
- [ ] antonym
- [ ] emerge
- [ ] squeeze
- [ ] nicety

# Chapter 064

- [ ] role
- [ ] remind
- [ ] torture
- [ ] condense
- [ ] exclusively
- [ ] integral
- [ ] token
- [ ] shift
- [ ] taxation
- [ ] tow
- [ ] reliable
- [ ] deft
- [ ] potion
- [ ] disarray
- [ ] overall
- [ ] resource
- [ ] species
- [ ] platform
- [ ] elastic
- [ ] tenancy

# Chapter 065

- [ ] minimal
- [ ] inevitable
- [ ] contradict
- [ ] subsidy
- [ ] flare
- [ ] digest
- [ ] din
- [ ] shoal
- [ ] hasty
- [ ] insulate
- [ ] colony
- [ ] repent
- [ ] illusion
- [ ] enrolment
- [ ] chaos
- [ ] pine
- [ ] transfuse
- [ ] comic
- [ ] infectious
- [ ] liable

# Chapter 066

- [ ] composite
- [ ] moustache
- [ ] acquaint
- [ ] adjoin
- [ ] sphere
- [ ] anecdote
- [ ] compartment
- [ ] durable
- [ ] growl
- [ ] submit
- [ ] arrogant
- [ ] persecute
- [ ] slot
- [ ] access
- [ ] terrestrial
- [ ] crater
- [ ] charge
- [ ] nurture
- [ ] splash
- [ ] modest

# Chapter 067

- [ ] inspiration
- [ ] doubtless
- [ ] version
- [ ] slack
- [ ] correlate
- [ ] subside
- [ ] donation
- [ ] feel
- [ ] piracy
- [ ] oscillate
- [ ] norm
- [ ] trample
- [ ] compliment
- [ ] genuine
- [ ] fancy
- [ ] augment
- [ ] smart
- [ ] gaudy
- [ ] generalize
- [ ] carpenter

# Chapter 068

- [ ] sincere
- [ ] glimmer
- [ ] muster
- [ ] gene
- [ ] devastating
- [ ] decree
- [ ] reservoir
- [ ] jeopardize
- [ ] sterilize
- [ ] deadlock
- [ ] chant
- [ ] rupture
- [ ] ritual
- [ ] gaol
- [ ] leaflet
- [ ] subsequent
- [ ] aviation
- [ ] fraud
- [ ] initial
- [ ] erase

# Chapter 069

- [ ] readily
- [ ] limb
- [ ] mint
- [ ] pitch
- [ ] counter
- [ ] dedicate
- [ ] vindicate
- [ ] current
- [ ] flaunt
- [ ] parliament
- [ ] specification
- [ ] anniversary
- [ ] homestay
- [ ] scan
- [ ] grace
- [ ] cite
- [ ] tranquility
- [ ] severe
- [ ] excess
- [ ] considerate

# Chapter 070

- [ ] distort
- [ ] corpse
- [ ] entity
- [ ] wander
- [ ] acute
- [ ] delectable
- [ ] context
- [ ] dominate
- [ ] flyover
- [ ] quaint
- [ ] dispose
- [ ] regulate
- [ ] antibiotic
- [ ] influence
- [ ] vein
- [ ] obsession
- [ ] capital
- [ ] swerve
- [ ] remnant
- [ ] tilt

# Chapter 071

- [ ] pass
- [ ] opaque
- [ ] prestige
- [ ] precipice
- [ ] outskirts
- [ ] refusal
- [ ] patrol
- [ ] ambassador
- [ ] shower
- [ ] dilapidated
- [ ] description
- [ ] ignorance
- [ ] corps
- [ ] amphibian
- [ ] patriotism
- [ ] periodical
- [ ] energetic
- [ ] promising
- [ ] rim
- [ ] put

# Chapter 072

- [ ] artery
- [ ] resort
- [ ] petal
- [ ] deficiency
- [ ] locality
- [ ] handsome
- [ ] myriad
- [ ] percussion
- [ ] routine
- [ ] strip
- [ ] amidst
- [ ] minister
- [ ] funeral
- [ ] corrode
- [ ] incidence
- [ ] scheme
- [ ] rail
- [ ] ponderous
- [ ] degrade
- [ ] confirm

# Chapter 073

- [ ] scalpel
- [ ] complexion
- [ ] outcast
- [ ] prior
- [ ] pimple
- [ ] theft
- [ ] compose
- [ ] infect
- [ ] symmetry
- [ ] significant
- [ ] currency
- [ ] prelude
- [ ] typhoon
- [ ] discriminate
- [ ] drawback
- [ ] vacant
- [ ] track
- [ ] culture
- [ ] excavate
- [ ] fit

# Chapter 074

- [ ] motion
- [ ] expel
- [ ] allowance
- [ ] coward
- [ ] germ
- [ ] flash
- [ ] subtract
- [ ] glitter
- [ ] predictable
- [ ] undue
- [ ] dart
- [ ] coincide
- [ ] consecutive
- [ ] in
- [ ] gamble
- [ ] committee
- [ ] dumb
- [ ] hygiene
- [ ] smother
- [ ] wilderness

# Chapter 075

- [ ] signal
- [ ] furnace
- [ ] confess
- [ ] minority
- [ ] nostalgia
- [ ] cautious
- [ ] pillow
- [ ] adjacent
- [ ] transcript
- [ ] crevice
- [ ] slander
- [ ] subdue
- [ ] magnify
- [ ] neutralize
- [ ] stripe
- [ ] suite
- [ ] nothing
- [ ] siege
- [ ] consequence
- [ ] manure

# Chapter 076

- [ ] mobile
- [ ] solidarity
- [ ] glue
- [ ] misguided
- [ ] vigorous
- [ ] cricket
- [ ] novice
- [ ] likelihood
- [ ] premium
- [ ] genial
- [ ] ludicrous
- [ ] prestigious
- [ ] oblique
- [ ] overhear
- [ ] anticipation
- [ ] chaste
- [ ] explore
- [ ] pungent
- [ ] indulge
- [ ] simplify

# Chapter 077

- [ ] vicious
- [ ] counterbalance
- [ ] kit
- [ ] shrub
- [ ] sceptical
- [ ] comprise
- [ ] pathetic
- [ ] mall
- [ ] manipulate
- [ ] rational
- [ ] vulnerable
- [ ] heave
- [ ] come
- [ ] justification
- [ ] arc
- [ ] wrestle
- [ ] treaty
- [ ] mammal
- [ ] advocate
- [ ] fickle

# Chapter 078

- [ ] salute
- [ ] clear
- [ ] otherwise
- [ ] arduous
- [ ] punctual
- [ ] directory
- [ ] vanquish
- [ ] oblivious
- [ ] apprentice
- [ ] excursion
- [ ] downpour
- [ ] mandatory
- [ ] loom
- [ ] variant
- [ ] council
- [ ] meager
- [ ] chord
- [ ] tolerable
- [ ] fabric
- [ ] setting

# Chapter 079

- [ ] inference
- [ ] summon
- [ ] observe
- [ ] exotic
- [ ] superior
- [ ] single
- [ ] spectacle
- [ ] equilibrium
- [ ] soluble
- [ ] gale
- [ ] crust
- [ ] junction
- [ ] heap
- [ ] mourn
- [ ] hound
- [ ] mutation
- [ ] mantle
- [ ] superfluous
- [ ] set
- [ ] insert

# Chapter 080

- [ ] portray
- [ ] studio
- [ ] ashamed
- [ ] arise
- [ ] repel
- [ ] flux
- [ ] raw
- [ ] elapse
- [ ] diffuse
- [ ] delicate
- [ ] vow
- [ ] gist
- [ ] specific
- [ ] candidate
- [ ] magistrate
- [ ] accessory
- [ ] submarine
- [ ] thermal
- [ ] indelible
- [ ] protract

# Chapter 081

- [ ] quit
- [ ] ramble
- [ ] lash
- [ ] pottery
- [ ] prosecute
- [ ] aggravate
- [ ] mediate
- [ ] conscience
- [ ] scenery
- [ ] chronic
- [ ] sustain
- [ ] stuff
- [ ] site
- [ ] veteran
- [ ] accompany
- [ ] pace
- [ ] annual
- [ ] cosmic
- [ ] majestic
- [ ] give

# Chapter 082

- [ ] outspoken
- [ ] storage
- [ ] unique
- [ ] screw
- [ ] pore
- [ ] slap
- [ ] stick
- [ ] keen
- [ ] status
- [ ] lubricate
- [ ] overwhelm
- [ ] pains
- [ ] variable
- [ ] handbook
- [ ] rigid
- [ ] embrace
- [ ] ivory
- [ ] radical
- [ ] identity
- [ ] prevail

# Chapter 083

- [ ] ferry
- [ ] pinpoint
- [ ] refreshment
- [ ] essence
- [ ] hail
- [ ] litter
- [ ] shiver
- [ ] portion
- [ ] courtesy
- [ ] feast
- [ ] propriety
- [ ] surplus
- [ ] odyssey
- [ ] portfolio
- [ ] superficial
- [ ] session
- [ ] obliging
- [ ] shutter
- [ ] petty
- [ ] cripple

# Chapter 084

- [ ] probation
- [ ] pendulum
- [ ] exile
- [ ] convince
- [ ] righteous
- [ ] champagne
- [ ] appetite
- [ ] sophisticated
- [ ] poke
- [ ] elevator
- [ ] touchy
- [ ] recommendation
- [ ] tap
- [ ] shed
- [ ] outweigh
- [ ] reinforce
- [ ] loaf
- [ ] feat
- [ ] cumulative
- [ ] nylon

# Chapter 085

- [ ] madden
- [ ] technique
- [ ] guideline
- [ ] hang
- [ ] emotion
- [ ] tuck
- [ ] magnitude
- [ ] cereal
- [ ] jungle
- [ ] misappropriate
- [ ] erosion
- [ ] hijack
- [ ] meteoric
- [ ] clearance
- [ ] scrape
- [ ] sicken
- [ ] statue
- [ ] occupy
- [ ] nil
- [ ] culminate

# Chapter 086

- [ ] file
- [ ] ghastly
- [ ] ugly
- [ ] chip
- [ ] occurrence
- [ ] propel
- [ ] once
- [ ] approach
- [ ] overture
- [ ] wholesale
- [ ] stationery
- [ ] liquor
- [ ] legend
- [ ] contaminate
- [ ] loll
- [ ] inspire
- [ ] constant
- [ ] perimeter
- [ ] neurotic
- [ ] assemble

# Chapter 087

- [ ] origin
- [ ] hurl
- [ ] coed
- [ ] upright
- [ ] volcano
- [ ] momentous
- [ ] amid
- [ ] fierce
- [ ] grill
- [ ] primary
- [ ] flexible
- [ ] affiliate
- [ ] famine
- [ ] say
- [ ] undoubtedly
- [ ] naval
- [ ] uneven
- [ ] perishable
- [ ] grudge
- [ ] fabulous

# Chapter 088

- [ ] granary
- [ ] psychology
- [ ] slaughter
- [ ] ingredient
- [ ] refugee
- [ ] signify
- [ ] convert
- [ ] extract
- [ ] invisible
- [ ] contrive
- [ ] descend
- [ ] perturb
- [ ] instantaneous
- [ ] terrace
- [ ] permissible
- [ ] allegiance
- [ ] plaster
- [ ] practically
- [ ] infirmary
- [ ] distil

# Chapter 089

- [ ] unanimous
- [ ] scissors
- [ ] accelerate
- [ ] disable
- [ ] lapse
- [ ] antique
- [ ] crease
- [ ] evolution
- [ ] sow
- [ ] prodigious
- [ ] embark
- [ ] questionnaire
- [ ] voucher
- [ ] puzzle
- [ ] foil
- [ ] grant
- [ ] request
- [ ] subtle
- [ ] sewer
- [ ] consumption

# Chapter 090

- [ ] hence
- [ ] texture
- [ ] vary
- [ ] fleeting
- [ ] hostage
- [ ] pledge
- [ ] pry
- [ ] synthesis
- [ ] distress
- [ ] intimidate
- [ ] oppose
- [ ] orientate
- [ ] ornament
- [ ] teem
- [ ] precipitate
- [ ] ordeal
- [ ] placid
- [ ] conversely
- [ ] worthwhile
- [ ] realm

# Chapter 091

- [ ] vocational
- [ ] inaugurate
- [ ] loyal
- [ ] crystal
- [ ] embarrass
- [ ] howl
- [ ] release
- [ ] sanity
- [ ] visible
- [ ] transistor
- [ ] pasture
- [ ] sprint
- [ ] cradle
- [ ] amateur
- [ ] determination
- [ ] discreet
- [ ] perverse
- [ ] perpendicular
- [ ] scoop
- [ ] refund

# Chapter 092

- [ ] productive
- [ ] yawn
- [ ] kidnap
- [ ] emit
- [ ] accountant
- [ ] glamour
- [ ] environment
- [ ] stand
- [ ] likewise
- [ ] traitor
- [ ] grind
- [ ] mock
- [ ] vacation
- [ ] marrow
- [ ] steadfast
- [ ] assumption
- [ ] optimum
- [ ] discrepancy
- [ ] presence
- [ ] terrain

# Chapter 093

- [ ] dine
- [ ] perfume
- [ ] echo
- [ ] cutting
- [ ] momentum
- [ ] nowhere
- [ ] shepherd
- [ ] superintend
- [ ] mythology
- [ ] delinquency
- [ ] relief
- [ ] dole
- [ ] suspension
- [ ] laudable
- [ ] snack
- [ ] demolish
- [ ] whistle
- [ ] monster
- [ ] doctrine
- [ ] trait

# Chapter 094

- [ ] rouse
- [ ] compatible
- [ ] deck
- [ ] gratuity
- [ ] historian
- [ ] desert
- [ ] civilian
- [ ] making
- [ ] rough
- [ ] desirable
- [ ] profound
- [ ] transport
- [ ] provisional
- [ ] fragile
- [ ] subscribe
- [ ] queer
- [ ] decipher
- [ ] imaginative
- [ ] inclusive
- [ ] mushroom

# Chapter 095

- [ ] horrible
- [ ] sparkle
- [ ] temperate
- [ ] prerogative
- [ ] subtitle
- [ ] torment
- [ ] seemingly
- [ ] tile
- [ ] isle
- [ ] enquiry
- [ ] scout
- [ ] ransom
- [ ] venerate
- [ ] outright
- [ ] pageant
- [ ] graph
- [ ] liner
- [ ] notary
- [ ] melody
- [ ] similar

# Chapter 096

- [ ] contemporary
- [ ] reckless
- [ ] goad
- [ ] leak
- [ ] politic
- [ ] register
- [ ] lure
- [ ] eventually
- [ ] negotiable
- [ ] resonant
- [ ] attribute
- [ ] convict
- [ ] assure
- [ ] sightseeing
- [ ] latent
- [ ] varied
- [ ] override
- [ ] raft
- [ ] perceive
- [ ] symposium

# Chapter 097

- [ ] appropriate
- [ ] interior
- [ ] scum
- [ ] engagement
- [ ] trap
- [ ] transcend
- [ ] circumstance
- [ ] authorize
- [ ] flask
- [ ] spontaneous
- [ ] penalty
- [ ] fortify
- [ ] monsoon
- [ ] retrospect
- [ ] spit
- [ ] negligence
- [ ] pension
- [ ] enlighten
- [ ] audience
- [ ] symbolize

# Chapter 098

- [ ] hobby
- [ ] petroleum
- [ ] classical
- [ ] thrill
- [ ] stadium
- [ ] tyre
- [ ] review
- [ ] spoil
- [ ] cucumber
- [ ] assign
- [ ] twist
- [ ] privacy
- [ ] probe
- [ ] ambition
- [ ] shanty
- [ ] devastate
- [ ] acknowledge
- [ ] trail
- [ ] infant
- [ ] appointment

# Chapter 099

- [ ] auction
- [ ] constrict
- [ ] commercial
- [ ] equivocal
- [ ] anonymous
- [ ] duplicate
- [ ] farewell
- [ ] consumer
- [ ] welfare
- [ ] tributary
- [ ] measure
- [ ] wording
- [ ] spray
- [ ] fabricate
- [ ] eke
- [ ] might
- [ ] uprising
- [ ] nominee
- [ ] evict
- [ ] march

# Chapter 100

- [ ] extravagant
- [ ] recital
- [ ] gush
- [ ] cut
- [ ] skip
- [ ] recession
- [ ] spur
- [ ] attain
- [ ] privilege
- [ ] abrupt
- [ ] withhold
- [ ] resemblance
- [ ] lethal
- [ ] exhort
- [ ] detective
- [ ] synthetic
- [ ] collaboration
- [ ] henceforth
- [ ] dull
- [ ] choke

# Chapter 101

- [ ] legal
- [ ] furious
- [ ] pivot
- [ ] timber
- [ ] orbit
- [ ] pharmacy
- [ ] subject
- [ ] fry
- [ ] diligent
- [ ] quantitative
- [ ] monetary
- [ ] deviate
- [ ] clip
- [ ] maniac
- [ ] optical
- [ ] classify
- [ ] metaphor
- [ ] slender
- [ ] desolate
- [ ] wit

# Chapter 102

- [ ] hand
- [ ] odd
- [ ] dispatch
- [ ] tangle
- [ ] associate
- [ ] slip
- [ ] retreat
- [ ] revelation
- [ ] defeat
- [ ] slab
- [ ] lobby
- [ ] administration
- [ ] efficient
- [ ] throbbing
- [ ] lawn
- [ ] superstition
- [ ] exceedingly
- [ ] pillar
- [ ] spokesman
- [ ] avert

# Chapter 103

- [ ] cash
- [ ] grin
- [ ] stroke
- [ ] applicant
- [ ] pull
- [ ] secondary
- [ ] indicative
- [ ] wither
- [ ] commuter
- [ ] distribute
- [ ] excrement
- [ ] intelligible
- [ ] contempt
- [ ] palm
- [ ] trauma
- [ ] shelter
- [ ] disregard
- [ ] perennial
- [ ] ownership
- [ ] antagonism

# Chapter 104

- [ ] provided
- [ ] evoke
- [ ] clarity
- [ ] revolve
- [ ] ambiguity
- [ ] charter
- [ ] grid
- [ ] notation
- [ ] slit
- [ ] hardware
- [ ] mercy
- [ ] diameter
- [ ] empirical
- [ ] standard
- [ ] gown
- [ ] filter
- [ ] fester
- [ ] doom
- [ ] dub
- [ ] matrimony

# Chapter 105

- [ ] sanitary
- [ ] enrich
- [ ] frontier
- [ ] equity
- [ ] generous
- [ ] juvenile
- [ ] fend
- [ ] longitude
- [ ] sting
- [ ] escalate
- [ ] poverty
- [ ] cassette
- [ ] date
- [ ] hedge
- [ ] hospitality
- [ ] declaration
- [ ] detest
- [ ] incite
- [ ] innovation
- [ ] liability

# Chapter 106

- [ ] strenuous
- [ ] principal
- [ ] exhaust
- [ ] drain
- [ ] export
- [ ] log
- [ ] superstructure
- [ ] taboo
- [ ] spatial
- [ ] objection
- [ ] tornado
- [ ] pin
- [ ] style
- [ ] ultimatum
- [ ] presentation
- [ ] neglect
- [ ] carrot
- [ ] linear
- [ ] sweater
- [ ] precarious

# Chapter 107

- [ ] amends
- [ ] approval
- [ ] faculty
- [ ] avoid
- [ ] chat
- [ ] surpass
- [ ] appliance
- [ ] despise
- [ ] plunge
- [ ] disguise
- [ ] deflect
- [ ] optional
- [ ] elementary
- [ ] mar
- [ ] compute
- [ ] dramatic
- [ ] maim
- [ ] partial
- [ ] launch
- [ ] hearing

# Chapter 108

- [ ] mighty
- [ ] striking
- [ ] counterpart
- [ ] unilateral
- [ ] ruinous
- [ ] jumble
- [ ] instalment
- [ ] refreshing
- [ ] notch
- [ ] correspondent
- [ ] peril
- [ ] agency
- [ ] elated
- [ ] critical
- [ ] picturesque
- [ ] tacit
- [ ] controversial
- [ ] mucous
- [ ] perpetual
- [ ] porous

# Chapter 109

- [ ] whirl
- [ ] swell
- [ ] gross
- [ ] defile
- [ ] virtually
- [ ] equivalent
- [ ] forte
- [ ] tamper
- [ ] prone
- [ ] estimate
- [ ] uniform
- [ ] pupil
- [ ] ambulance
- [ ] shallow
- [ ] fume
- [ ] disc
- [ ] emergency
- [ ] geology
- [ ] stem
- [ ] prey

# Chapter 110

- [ ] frost
- [ ] gravel
- [ ] dividend
- [ ] pump
- [ ] strain
- [ ] nibble
- [ ] ally
- [ ] facilitate
- [ ] twig
- [ ] gape
- [ ] ample
- [ ] contingency
- [ ] validity
- [ ] monotonous
- [ ] peel
- [ ] lay
- [ ] leap
- [ ] necessitate
- [ ] conviction
- [ ] dread

# Chapter 111

- [ ] script
- [ ] devote
- [ ] supersonic
- [ ] scale
- [ ] alien
- [ ] axis
- [ ] fluent
- [ ] design
- [ ] mundane
- [ ] withdraw
- [ ] synchronize
- [ ] individual
- [ ] afford
- [ ] light
- [ ] perceptible
- [ ] luxury
- [ ] derive
- [ ] executive
- [ ] soar
- [ ] abundance

# Chapter 112

- [ ] susceptible
- [ ] automatic
- [ ] corrupt
- [ ] multilateral
- [ ] formulate
- [ ] facet
- [ ] supersede
- [ ] hostile
- [ ] solo
- [ ] ruthless
- [ ] click
- [ ] contest
- [ ] agreeable
- [ ] tube
- [ ] flourish
- [ ] detect
- [ ] tarnish
- [ ] counterfeit
- [ ] chew
- [ ] devour

# Chapter 113

- [ ] offend
- [ ] item
- [ ] confidence
- [ ] cosy
- [ ] suck
- [ ] employment
- [ ] amend
- [ ] update
- [ ] vengeance
- [ ] factor
- [ ] abort
- [ ] scapegoat
- [ ] imposing
- [ ] toll
- [ ] irritate
- [ ] assassination
- [ ] subjective
- [ ] surgery
- [ ] yoke
- [ ] multiply

# Chapter 114

- [ ] overthrow
- [ ] soak
- [ ] poise
- [ ] interim
- [ ] prompt
- [ ] applaud
- [ ] adequate
- [ ] amplify
- [ ] cling
- [ ] jail
- [ ] paradox
- [ ] flock
- [ ] divert
- [ ] filth
- [ ] enquire
- [ ] haste
- [ ] attractive
- [ ] plantation
- [ ] reclaim
- [ ] muddle

# Chapter 115

- [ ] metallic
- [ ] obvious
- [ ] sentiment
- [ ] harass
- [ ] constrain
- [ ] wretched
- [ ] resent
- [ ] offence
- [ ] go
- [ ] precise
- [ ] overlap
- [ ] episode
- [ ] malice
- [ ] palatable
- [ ] carve
- [ ] mentality
- [ ] proposition
- [ ] steep
- [ ] hitchhike
- [ ] tumour

# Chapter 116

- [ ] alliance
- [ ] chic
- [ ] denomination
- [ ] frown
- [ ] coerce
- [ ] cumbersome
- [ ] credit
- [ ] rhythm
- [ ] crash
- [ ] toneless
- [ ] vomit
- [ ] electrician
- [ ] articulate
- [ ] porch
- [ ] fortnight
- [ ] arouse
- [ ] champion
- [ ] hazard
- [ ] clause
- [ ] enthusiastic

# Chapter 117

- [ ] original
- [ ] output
- [ ] plausible
- [ ] nausea
- [ ] discount
- [ ] thunder
- [ ] outcome
- [ ] dial
- [ ] confidential
- [ ] hinge
- [ ] adore
- [ ] finite
- [ ] masculine
- [ ] mutter
- [ ] competition
- [ ] recipient
- [ ] embargo
- [ ] digital
- [ ] scholarship
- [ ] impose

# Chapter 118

- [ ] complex
- [ ] consent
- [ ] hubbub
- [ ] shaft
- [ ] caption
- [ ] harbour
- [ ] tumble
- [ ] sink
- [ ] patron
- [ ] flu
- [ ] column
- [ ] overrun
- [ ] etiquette
- [ ] deduct
- [ ] dense
- [ ] tinge
- [ ] congruent
- [ ] crouch
- [ ] conserve
- [ ] fahrenheit

# Chapter 119

- [ ] corporation
- [ ] quench
- [ ] alarm
- [ ] nasty
- [ ] shovel
- [ ] suspicious
- [ ] trunk
- [ ] ovation
- [ ] saddle
- [ ] tragedy
- [ ] meteorology
- [ ] saturate
- [ ] elbow
- [ ] formidable
- [ ] structural
- [ ] kindle
- [ ] decline
- [ ] enroll
- [ ] slope
- [ ] distend

# Chapter 120

- [ ] exert
- [ ] appreciable
- [ ] aggregate
- [ ] thirst
- [ ] hurricane
- [ ] miracle
- [ ] nightmare
- [ ] opposite
- [ ] dedicated
- [ ] tender
- [ ] pervert
- [ ] idiot
- [ ] forge
- [ ] conscious
- [ ] concise
- [ ] cartoon
- [ ] overtake
- [ ] layout
- [ ] outdated
- [ ] sigh

# Chapter 121

- [ ] consequent
- [ ] chop
- [ ] exposition
- [ ] outlet
- [ ] wardrobe
- [ ] molecule
- [ ] tablet
- [ ] observatory
- [ ] distinct
- [ ] telex
- [ ] monarchy
- [ ] negative
- [ ] graze
- [ ] starve
- [ ] tide
- [ ] parasite
- [ ] layer
- [ ] strengthen
- [ ] vogue
- [ ] nevertheless

# Chapter 122

- [ ] chiche
- [ ] levy
- [ ] encyclopedia
- [ ] drainage
- [ ] tunnel
- [ ] excel
- [ ] circuit
- [ ] thrust
- [ ] modify
- [ ] utmost
- [ ] endurance
- [ ] mount
- [ ] consensus
- [ ] enforce
- [ ] tag
- [ ] concede
- [ ] grit
- [ ] elevate
- [ ] horizon
- [ ] crawl

# Chapter 123

- [ ] mingle
- [ ] substantial
- [ ] marginal
- [ ] foresee
- [ ] soil
- [ ] awful
- [ ] regime
- [ ] divine
- [ ] assume
- [ ] Easter
- [ ] shatter
- [ ] inquire
- [ ] annuity
- [ ] cynical
- [ ] affix
- [ ] compress
- [ ] verge
- [ ] crumb
- [ ] sustenance
- [ ] diminish

# Chapter 124

- [ ] itinerary
- [ ] array
- [ ] planetarium
- [ ] gland
- [ ] exquisite
- [ ] deputy
- [ ] ridiculous
- [ ] reconcile
- [ ] funnel
- [ ] shell
- [ ] succinct
- [ ] eminent
- [ ] jam
- [ ] terminate
- [ ] temporary
- [ ] rage
- [ ] span
- [ ] dialect
- [ ] proficiency
- [ ] pilgrim

# Chapter 125

- [ ] shrink
- [ ] radius
- [ ] oar
- [ ] web
- [ ] diplomat
- [ ] database
- [ ] standing
- [ ] cellar
- [ ] cooperate
- [ ] dictate
- [ ] partisan
- [ ] weed
- [ ] chief
- [ ] lap
- [ ] surrender
- [ ] misconceive
- [ ] fervent
- [ ] aisle
- [ ] configuration
- [ ] reap

# Chapter 126

- [ ] missile
- [ ] oncoming
- [ ] mature
- [ ] occasion
- [ ] pretentious
- [ ] mischance
- [ ] conquer
- [ ] nourish
- [ ] tourism
- [ ] valuation
- [ ] compromise
- [ ] shield
- [ ] greedy
- [ ] diet
- [ ] pigment
- [ ] ascend
- [ ] sour
- [ ] fury
- [ ] guy
- [ ] nullify

# Chapter 127

- [ ] presumption
- [ ] stumble
- [ ] nucleus
- [ ] thrive
- [ ] languid
- [ ] homogeneous
- [ ] scant
- [ ] versatile
- [ ] conspicuous
- [ ] tighten
- [ ] haul
- [ ] rejoice
- [ ] comet
- [ ] phonetic
- [ ] ambitious
- [ ] abnormal
- [ ] maneuver
- [ ] primitive
- [ ] valve
- [ ] vanity

# Chapter 128

- [ ] reception
- [ ] cordial
- [ ] noxious
- [ ] reimburse
- [ ] exacerbate
- [ ] object
- [ ] palpitate
- [ ] tick
- [ ] certificate
- [ ] exploit
- [ ] vigilant
- [ ] grand
- [ ] congress
- [ ] academic
- [ ] correspond
- [ ] passive
- [ ] discord
- [ ] defer
- [ ] gloomy
- [ ] fanatic

# Chapter 129

- [ ] trick
- [ ] abandon
- [ ] therapy
- [ ] forfeit
- [ ] execution
- [ ] majority
- [ ] fertile
- [ ] treatment
- [ ] coin
- [ ] vertical
- [ ] erroneous
- [ ] alloy
- [ ] feasible
- [ ] collide
- [ ] triangle
- [ ] innumerable
- [ ] holocaust
- [ ] dawn
- [ ] adverse
- [ ] prescription

# Chapter 130

- [ ] notorious
- [ ] obnoxious
- [ ] desperate
- [ ] reign
- [ ] lane
- [ ] cruise
- [ ] fastidious
- [ ] expertise
- [ ] restless
- [ ] undo
- [ ] courier
- [ ] grab
- [ ] frantic
- [ ] yacht
- [ ] doze
- [ ] relapse
- [ ] contact
- [ ] astound
- [ ] ostensible
- [ ] equal

# Chapter 131

- [ ] terminal
- [ ] fall
- [ ] alleviate
- [ ] sociable
- [ ] wholesome
- [ ] cube
- [ ] provoke
- [ ] acquire
- [ ] resemble
- [ ] coherent
- [ ] margin
- [ ] depart
- [ ] mode
- [ ] preliminary
- [ ] intrinsic
- [ ] enclose
- [ ] entail
- [ ] heart
- [ ] positive
- [ ] collapse

# Chapter 132

- [ ] statesman
- [ ] jeer
- [ ] sack
- [ ] narcotic
- [ ] ponder
- [ ] argue
- [ ] sound
- [ ] irrigation
- [ ] despair
- [ ] dentist
- [ ] focus
- [ ] inundate
- [ ] cherish
- [ ] pointless
- [ ] rhetoric
- [ ] humanity
- [ ] disgust
- [ ] wager
- [ ] promise
- [ ] aspiration

# Chapter 133

- [ ] fee
- [ ] fault
- [ ] envy
- [ ] yield
- [ ] erratic
- [ ] intent
- [ ] steak
- [ ] clan
- [ ] anthropology
- [ ] credible
- [ ] spotlight
- [ ] lag
- [ ] piston
- [ ] comment
- [ ] metabolism
- [ ] inclination
- [ ] mackintosh
- [ ] appendix
- [ ] cathedral
- [ ] assorted

# Chapter 134

- [ ] possession
- [ ] width
- [ ] variation
- [ ] commemorate
- [ ] mosaic
- [ ] misdeed
- [ ] mitigate
- [ ] mesh
- [ ] float
- [ ] illuminate
- [ ] quarry
- [ ] compound
- [ ] confuse
- [ ] dean
- [ ] gossip
- [ ] succumb
- [ ] obsess
- [ ] distraction
- [ ] miscarriage
- [ ] dormant

# Chapter 135

- [ ] economy
- [ ] aesthetic
- [ ] facility
- [ ] armour
- [ ] hamper
- [ ] commitment
- [ ] professional
- [ ] attack
- [ ] exasperate
- [ ] trial
- [ ] mess
- [ ] tear
- [ ] dose
- [ ] dreadful
- [ ] maternal
- [ ] feeble
- [ ] depression
- [ ] sparse
- [ ] polish
- [ ] trim

# Chapter 136

- [ ] massacre
- [ ] waver
- [ ] decrepit
- [ ] mortgage
- [ ] hypothesis
- [ ] all
- [ ] finance
- [ ] take
- [ ] legislate
- [ ] permeate
- [ ] cavity
- [ ] definite
- [ ] skeleton
- [ ] quarterly
- [ ] textile
- [ ] conception
- [ ] jury
- [ ] murmur
- [ ] virus
- [ ] gasp

# Chapter 137

- [ ] fatal
- [ ] altitude
- [ ] outdo
- [ ] opinion
- [ ] decay
- [ ] audit
- [ ] forthcoming
- [ ] anthology
- [ ] yarn
- [ ] plaintive
- [ ] misrepresent
- [ ] warranty
- [ ] rigorous
- [ ] auxiliary
- [ ] terse
- [ ] orchard
- [ ] dissertation
- [ ] vivid
- [ ] grumble
- [ ] phenomenon

# Chapter 138

- [ ] rally
- [ ] ceramic
- [ ] tongue
- [ ] initiative
- [ ] formula
- [ ] incipient
- [ ] coincidence
- [ ] envisage
- [ ] precaution
- [ ] challenge
- [ ] annihilate
- [ ] addict
- [ ] conservative
- [ ] edge
- [ ] rumour
- [ ] misuse
- [ ] propaganda
- [ ] inherit
- [ ] secretion
- [ ] attendance

# Chapter 139

- [ ] illiterate
- [ ] turmoil
- [ ] denote
- [ ] adhere
- [ ] pinch
- [ ] pulp
- [ ] pierce
- [ ] contribution
- [ ] analogy
- [ ] policy
- [ ] elegant
- [ ] witness
- [ ] vulgar
- [ ] option
- [ ] economics
- [ ] periodically
- [ ] roam
- [ ] stoop
- [ ] extinguish
- [ ] disturbance

# Chapter 140

- [ ] censor
- [ ] lever
- [ ] gang
- [ ] detach
- [ ] stimulus
- [ ] knot
- [ ] tumult
- [ ] ardent
- [ ] ideology
- [ ] everlasting
- [ ] insight
- [ ] artificial
- [ ] uphold
- [ ] constitution
- [ ] canvas
- [ ] prominent
- [ ] flirt
- [ ] duly
- [ ] maize
- [ ] insipid

# Chapter 141

- [ ] favour
- [ ] malignant
- [ ] systematic
- [ ] caustic
- [ ] inherent
- [ ] wage
- [ ] amuse
- [ ] negligible
- [ ] air
- [ ] incur
- [ ] molest
- [ ] monstrous
- [ ] edible
- [ ] offer
- [ ] alternate
- [ ] tramp
- [ ] sprout
- [ ] tempo
- [ ] tough
- [ ] maritime

# Chapter 142

- [ ] spark
- [ ] establish
- [ ] dim
- [ ] lodge
- [ ] rendezvous
- [ ] martyr
- [ ] confront
- [ ] neat
- [ ] rectangle
- [ ] transgress
- [ ] verdict
- [ ] evacuate
- [ ] remorse
- [ ] caution
- [ ] subordinate
- [ ] chin
- [ ] live
- [ ] global
- [ ] revive
- [ ] pesticide

# Chapter 143

- [ ] create
- [ ] gloss
- [ ] entreat
- [ ] detain
- [ ] tidy
- [ ] eloquent
- [ ] attend
- [ ] postage
- [ ] postpone
- [ ] crisp
- [ ] instrument
- [ ] most
- [ ] situated
- [ ] notify
- [ ] phobia
- [ ] municipal
- [ ] eye
- [ ] curl
- [ ] vehicle
- [ ] minus

# Chapter 144

- [ ] scold
- [ ] section
- [ ] reciprocal
- [ ] category
- [ ] captive
- [ ] panic
- [ ] intact
- [ ] entry
- [ ] inspiring
- [ ] tedious
- [ ] cannon
- [ ] stereo
- [ ] feedback
- [ ] lament
- [ ] paradise
- [ ] fountain
- [ ] acquisition
- [ ] revise
- [ ] closet
- [ ] prolific

# Chapter 145

- [ ] audible
- [ ] advent
- [ ] get
- [ ] recline
- [ ] pier
- [ ] menace
- [ ] outrageous
- [ ] fossil
- [ ] ethnic
- [ ] marital
- [ ] wrought
- [ ] supposedly
- [ ] clockwise
- [ ] sector
- [ ] chunk
- [ ] transplant
- [ ] radiate
- [ ] millennium
- [ ] speculate
- [ ] inept

# Chapter 146

- [ ] lamb
- [ ] specimen
- [ ] hop
- [ ] differ
- [ ] volunteer
- [ ] aquarium
- [ ] supposition
- [ ] costume
- [ ] fixture
- [ ] strive
- [ ] seclude
- [ ] heighten
- [ ] predecessor
- [ ] aboriginal
- [ ] chronological
- [ ] assault
- [ ] sober
- [ ] implement
- [ ] quiver
- [ ] ostentation

# Chapter 147

- [ ] compulsory
- [ ] hike
- [ ] tackle
- [ ] legislation
- [ ] estate
- [ ] interrogate
- [ ] plummet
- [ ] roll
- [ ] assimilate
- [ ] harsh
- [ ] recall
- [ ] electronics
- [ ] abbreviation
- [ ] flee
- [ ] numb
- [ ] crude
- [ ] metropolitan
- [ ] notable
- [ ] treble
- [ ] propagate

# Chapter 148

- [ ] converge
- [ ] compel
- [ ] pointed
- [ ] swarm
- [ ] shrewd
- [ ] abolish
- [ ] imitate
- [ ] waggon
- [ ] definitive
- [ ] imminent
- [ ] dispute
- [ ] horticulture
- [ ] semblance
- [ ] impair
- [ ] dismay
- [ ] dash
- [ ] outlying
- [ ] catching
- [ ] deter
- [ ] influx

# Chapter 149

- [ ] deplore
- [ ] pathos
- [ ] namely
- [ ] relinguish
- [ ] sole
- [ ] thaw
- [ ] fling
- [ ] sufficient
- [ ] morality
- [ ] shave
- [ ] liaison
- [ ] flip
- [ ] shear
- [ ] hover
- [ ] wax
- [ ] gaily
- [ ] slide
- [ ] lump
- [ ] inspection
- [ ] arena

# Chapter 150

- [ ] economical
- [ ] magnetic
- [ ] fluff
- [ ] cashier
- [ ] maiden
- [ ] startle
- [ ] chill
- [ ] reserve
- [ ] substitute
- [ ] auditorium
- [ ] esteem
- [ ] creation
- [ ] manifest
- [ ] confer
- [ ] underneath
- [ ] hoist
- [ ] capacity
- [ ] fuel
- [ ] incidentally
- [ ] giggle

# Chapter 151

- [ ] escort
- [ ] lottery
- [ ] retain
- [ ] undercharge
- [ ] synonym
- [ ] turf
- [ ] owe
- [ ] deplete
- [ ] fort
- [ ] delude
- [ ] ingenious
- [ ] compare
- [ ] inland
- [ ] suppress
- [ ] terror
- [ ] procedure
- [ ] pretext
- [ ] flap
- [ ] obsolete
- [ ] deliberate

# Chapter 152

- [ ] oath
- [ ] depletion
- [ ] forecast
- [ ] sore
- [ ] metric
- [ ] plead
- [ ] wrench
- [ ] surgeon
- [ ] compensation
- [ ] reference
- [ ] huddle
- [ ] dock
- [ ] eccentric
- [ ] indefinite
- [ ] coverage
- [ ] stationary
- [ ] maximum
- [ ] edit
- [ ] somehow
- [ ] obstinate

# Chapter 153

- [ ] string
- [ ] day
- [ ] numerous
- [ ] resignation
- [ ] laden
- [ ] instinct
- [ ] end
- [ ] extinct
- [ ] theme
- [ ] prologue
- [ ] diagram
- [ ] fitting
- [ ] install
- [ ] dilute
- [ ] storey
- [ ] odds
- [ ] swirl
- [ ] reassure
- [ ] casualty
- [ ] match

# Chapter 154

- [ ] decade
- [ ] exceed
- [ ] tutor
- [ ] proximity
- [ ] cosmopolitan
- [ ] Christian
- [ ] catalyst
- [ ] consign
- [ ] lease
- [ ] wane
- [ ] quota
- [ ] depress
- [ ] clarify
- [ ] extreme
- [ ] radar
- [ ] pertain
- [ ] given
- [ ] seismic
- [ ] summit
- [ ] nautical

# Chapter 155

- [ ] licence
- [ ] target
- [ ] analytical
- [ ] jerk
- [ ] rescue
- [ ] couch
- [ ] strategic
- [ ] impulse
- [ ] ultraviolet
- [ ] melodious
- [ ] crucial
- [ ] commodity
- [ ] conceive
- [ ] monopoly
- [ ] weird
- [ ] stereotype
- [ ] smooth
- [ ] clumsy
- [ ] portable
- [ ] voltage

# Chapter 156

- [ ] nuisance
- [ ] intensify
- [ ] retrieve
- [ ] fist
- [ ] twinkle
- [ ] orchestra
- [ ] conform
- [ ] fallible
- [ ] fatigue
- [ ] practitioner
- [ ] Catholic
- [ ] comedy
- [ ] originate
- [ ] allocate
- [ ] junior
- [ ] cupboard
- [ ] moped
- [ ] plus
- [ ] optimism
- [ ] embody

# Chapter 157

- [ ] wedge
- [ ] ceremony
- [ ] suicide
- [ ] swear
- [ ] considerable
- [ ] judicial
- [ ] catastrophe
- [ ] hose
- [ ] minimum
- [ ] domestic
- [ ] deficit
- [ ] leave
- [ ] abuse
- [ ] feature
- [ ] escalator
- [ ] domain
- [ ] expand
- [ ] corresponding
- [ ] deem
- [ ] passion

# Chapter 158

- [ ] flour
- [ ] collision
- [ ] ascribe
- [ ] infest
- [ ] intervene
- [ ] rectify
- [ ] temptation
- [ ] smash
- [ ] explosive
- [ ] coach
- [ ] induce
- [ ] curb
- [ ] untold
- [ ] predisposition
- [ ] climax
- [ ] remedy
- [ ] archives
- [ ] magnificent
- [ ] toil
- [ ] mortal

# Chapter 159

- [ ] flutter
- [ ] obscure
- [ ] deposit
- [ ] dignity
- [ ] lucrative
- [ ] hint
- [ ] resilience
- [ ] sequence
- [ ] aptitude
- [ ] scrap
- [ ] asset
- [ ] throng
- [ ] postmortem
- [ ] time
- [ ] elsewhere
- [ ] monologue
- [ ] property
- [ ] displace
- [ ] identical
- [ ] gorgeous

# Chapter 160

- [ ] withstand
- [ ] deluge
- [ ] immerse
- [ ] glorious
- [ ] sponge
- [ ] glimpse
- [ ] consult
- [ ] humdrum
- [ ] crown
- [ ] trend
- [ ] stretch
- [ ] pollinate
- [ ] article
- [ ] haven
- [ ] adopt
- [ ] protrude
- [ ] chapel
- [ ] fake
- [ ] moist
- [ ] regardless

# Chapter 161

- [ ] slate
- [ ] glow
- [ ] federation
- [ ] cunning
- [ ] gust
- [ ] chore
- [ ] absurd
- [ ] surge
- [ ] survival
- [ ] ignite
- [ ] gigantic
- [ ] prospect
- [ ] term
- [ ] refrain
- [ ] equator
- [ ] slam
- [ ] render
- [ ] whatever
- [ ] steer
- [ ] affection

# Chapter 162

- [ ] hold
- [ ] lull
- [ ] invaluable
- [ ] plagiarize
- [ ] acid
- [ ] mutual
- [ ] publicity
- [ ] grate
- [ ] administer
- [ ] restrain
- [ ] martial
- [ ] veil
- [ ] inflation
- [ ] previous
- [ ] eclipse
- [ ] scarcely
- [ ] platitude
- [ ] incentive
- [ ] mire
- [ ] dispel

# Chapter 163

- [ ] eternal
- [ ] stake
- [ ] harmony
- [ ] whilst
- [ ] literally
- [ ] ascertain
- [ ] paralysis
- [ ] timely
- [ ] worship
- [ ] idiom
- [ ] safeguard
- [ ] trumpet
- [ ] spill
- [ ] eddy
- [ ] spectator
- [ ] spectrum
- [ ] ammunition
- [ ] condolence
- [ ] indigenous
- [ ] constitute

# Chapter 164

- [ ] spouse
- [ ] plateau
- [ ] implicit
- [ ] vegetarian
- [ ] genetic
- [ ] legitimate
- [ ] wisdom
- [ ] retort
- [ ] adjust
- [ ] motel
- [ ] tendency
- [ ] lunar
- [ ] extend
- [ ] journalist
- [ ] apologetic
- [ ] contradiction
- [ ] meticulous
- [ ] anyhow
- [ ] draft
- [ ] forerunner

# Chapter 165

- [ ] repetition
- [ ] emigrate
- [ ] stuffing
- [ ] novel
- [ ] observance
- [ ] intellectual
- [ ] laundry
- [ ] indemnity
- [ ] concentrate
- [ ] impart
- [ ] qualitative
- [ ] exclusive
- [ ] somewhat
- [ ] appeal
- [ ] even
- [ ] intricate
- [ ] outfit
- [ ] continuity
- [ ] expenditure
- [ ] sauce

# Chapter 166

- [ ] impact
- [ ] personality
- [ ] inhabitant
- [ ] hardy
- [ ] vessel
- [ ] convention
- [ ] coupon
- [ ] grim
- [ ] groa
- [ ] invest
- [ ] crumble
- [ ] overhaul
- [ ] commend
- [ ] peculiar
- [ ] commonwealth
- [ ] deceive
- [ ] lax
- [ ] default
- [ ] monitor
- [ ] intermediate

# Chapter 167

- [ ] nominal
- [ ] deadly
- [ ] exterminate
- [ ] contrast
- [ ] presumably
- [ ] conservatory
- [ ] embed
- [ ] available
- [ ] arctic
- [ ] onlooker
- [ ] hinder
- [ ] relay
- [ ] medieval
- [ ] commit
- [ ] halt
- [ ] conservation
- [ ] illustrate
- [ ] function
- [ ] scent
- [ ] entertainment

# Chapter 168

- [ ] pregnant
- [ ] invert
- [ ] sturdy
- [ ] spring
- [ ] scorch
- [ ] panorama
- [ ] content
- [ ] tar
- [ ] migrate
- [ ] magnate
- [ ] deaf
- [ ] contribute
- [ ] remarkable
- [ ] affect
- [ ] fellowship
- [ ] pester
- [ ] frugal
- [ ] clamp
- [ ] masterpiece
- [ ] cultivate

# Chapter 169

- [ ] split
- [ ] concession
- [ ] idle
- [ ] pragmatic
- [ ] dilemma
- [ ] lavish
- [ ] series
- [ ] strait
- [ ] sarcasm
- [ ] sensitive
- [ ] rely
- [ ] enterprise
- [ ] garbage
- [ ] postscript
- [ ] segregate
- [ ] cylinder
- [ ] surcharge
- [ ] ensue
- [ ] pant
- [ ] stern

# Chapter 170

- [ ] steady
- [ ] abstract
- [ ] clue
- [ ] thorough
- [ ] alphabetical
- [ ] democracy
- [ ] seep
- [ ] distinction
- [ ] indicator
- [ ] persevere
- [ ] literacy
- [ ] affirm
- [ ] denounce
- [ ] defect
- [ ] knit
- [ ] marvelous
- [ ] haunt
- [ ] preach
- [ ] tariff
- [ ] prime

# Chapter 171

- [ ] mist
- [ ] agony
- [ ] pick
- [ ] tournament
- [ ] genius
- [ ] flicker
- [ ] hierarchy
- [ ] distinguish
- [ ] chamber
- [ ] credentials
- [ ] invigilate
- [ ] recover
- [ ] artillery
- [ ] ventilate
- [ ] reproach
- [ ] dump
- [ ] volume
- [ ] coalition
- [ ] opening
- [ ] hit

# Chapter 172

- [ ] substantiate
- [ ] allege
- [ ] prescribe
- [ ] expend
- [ ] thoughtful
- [ ] poultry
- [ ] cater


# Chapter 001

- [ ] abandonment
- [ ] abnormally
- [ ] absolutely
- [ ] abstract
- [ ] abuse
- [ ] accelerate
- [ ] accomplish
- [ ] accountant
- [ ] accrue
- [ ] accurate
- [ ] accuse
- [ ] accustom
- [ ] achieve
- [ ] acquaintance
- [ ] activate
- [ ] acutely
- [ ] addict
- [ ] address
- [ ] administration
- [ ] adopt

# Chapter 002

- [ ] adventure
- [ ] adventurer
- [ ] adverse
- [ ] adversely
- [ ] affection
- [ ] agenda
- [ ] aggravate
- [ ] agonize
- [ ] aid
- [ ] alert
- [ ] alien
- [ ] allergic
- [ ] alternative
- [ ] analytical
- [ ] ancient
- [ ] ankle
- [ ] anonymous
- [ ] anticipate
- [ ] anxiety
- [ ] apartment

# Chapter 003

- [ ] apathy
- [ ] apologize
- [ ] applicable
- [ ] applicant
- [ ] appoint
- [ ] appreciative
- [ ] approach
- [ ] appropriate
- [ ] approve
- [ ] approximately
- [ ] arm
- [ ] arouse
- [ ] arrogant
- [ ] artificial
- [ ] aspect
- [ ] assassinate
- [ ] assemble
- [ ] assessment
- [ ] association
- [ ] athletic

# Chapter 004

- [ ] atmosphere
- [ ] attendant
- [ ] authorities
- [ ] authority
- [ ] authorization
- [ ] automatic
- [ ] auxiliary
- [ ] available
- [ ] awareness
- [ ] awesome
- [ ] backup
- [ ] bacteria
- [ ] ballet
- [ ] barely
- [ ] barrier
- [ ] battery
- [ ] battle
- [ ] bias
- [ ] biography
- [ ] bitter

# Chapter 005

- [ ] bizarre
- [ ] blame
- [ ] blouse
- [ ] blueprint
- [ ] board
- [ ] boom
- [ ] boost
- [ ] botanical
- [ ] bother
- [ ] branch
- [ ] breakthrough
- [ ] breed
- [ ] breezy
- [ ] bribe
- [ ] bridge
- [ ] bruise
- [ ] brutal
- [ ] buck
- [ ] burden
- [ ] bureaucracy

# Chapter 006

- [ ] burial
- [ ] calculation
- [ ] calorie
- [ ] campaign
- [ ] cancel
- [ ] capable
- [ ] capacity
- [ ] capital
- [ ] capture
- [ ] cast
- [ ] casualty
- [ ] category
- [ ] cautious
- [ ] chain
- [ ] chaos
- [ ] character
- [ ] check
- [ ] chronicle
- [ ] circulation
- [ ] circumstance

# Chapter 007

- [ ] citation
- [ ] claim
- [ ] clarify
- [ ] classify
- [ ] clause
- [ ] clue
- [ ] coastal
- [ ] code
- [ ] collaborative
- [ ] collapse
- [ ] collective
- [ ] collide
- [ ] commerce
- [ ] commitment
- [ ] commodity
- [ ] compartment
- [ ] compel
- [ ] compelling
- [ ] compensate
- [ ] competence

# Chapter 008

- [ ] complaint
- [ ] complicated
- [ ] comprehensive
- [ ] concession
- [ ] conclusive
- [ ] concrete
- [ ] conduct
- [ ] confine
- [ ] conflict
- [ ] conformity
- [ ] confrontational
- [ ] consensus
- [ ] conservation
- [ ] conservative
- [ ] considerable
- [ ] console
- [ ] constant
- [ ] construction
- [ ] consultancy
- [ ] consumption

# Chapter 009

- [ ] contamination
- [ ] content
- [ ] contention
- [ ] contrary
- [ ] contribute
- [ ] contribution
- [ ] controversy
- [ ] conventional
- [ ] convert
- [ ] convict
- [ ] convince
- [ ] coordination
- [ ] corruption
- [ ] counsel
- [ ] counselor
- [ ] countermeasure
- [ ] cover
- [ ] coverage
- [ ] criminal
- [ ] criteria

# Chapter 010

- [ ] critical
- [ ] criticism
- [ ] crucial
- [ ] curb
- [ ] currency
- [ ] dare
- [ ] debris
- [ ] decent
- [ ] decisive
- [ ] decline
- [ ] deem
- [ ] defect
- [ ] defensive
- [ ] deficient
- [ ] deficit
- [ ] defy
- [ ] deliberate
- [ ] delicate
- [ ] deliver
- [ ] democracy

# Chapter 011

- [ ] denationalize
- [ ] deny
- [ ] deprive
- [ ] derail
- [ ] derive
- [ ] descendant
- [ ] descriptive
- [ ] deserve
- [ ] desperate
- [ ] destination
- [ ] destructive
- [ ] detached
- [ ] detect
- [ ] detective
- [ ] diligence
- [ ] dim
- [ ] diminish
- [ ] disadvantage
- [ ] disappear
- [ ] disarm

# Chapter 012

- [ ] discipline
- [ ] disconnect
- [ ] discourage
- [ ] disengagement
- [ ] dishonest
- [ ] dismiss
- [ ] dispatch
- [ ] disproportionately
- [ ] disservice
- [ ] distinctive
- [ ] distort
- [ ] distribution
- [ ] diverse
- [ ] diversion
- [ ] diversity
- [ ] divert
- [ ] dividend
- [ ] documentary
- [ ] dolphin
- [ ] domestic

# Chapter 013

- [ ] dominate
- [ ] donor
- [ ] dorm
- [ ] dramatically
- [ ] drastically
- [ ] drift
- [ ] dropout
- [ ] drought
- [ ] drown
- [ ] dweller
- [ ] dysfunction
- [ ] eccentric
- [ ] ecological
- [ ] edit
- [ ] election
- [ ] eliminate
- [ ] elite
- [ ] eloquent
- [ ] emerge
- [ ] emphasize

# Chapter 014

- [ ] encounter
- [ ] encourage
- [ ] endless
- [ ] enforce
- [ ] engage
- [ ] enormous
- [ ] enrich
- [ ] enrollment
- [ ] enthusiastic
- [ ] entrepreneurship
- [ ] epidemic
- [ ] eradicate
- [ ] erect
- [ ] erroneous
- [ ] erupt
- [ ] essential
- [ ] esteem
- [ ] ethnic
- [ ] evolution
- [ ] exaggerate

# Chapter 015

- [ ] exceed
- [ ] exceptional
- [ ] excess
- [ ] excessive
- [ ] executive
- [ ] exert
- [ ] exotic
- [ ] expansion
- [ ] expectation
- [ ] expedition
- [ ] expenditure
- [ ] expertise
- [ ] extend
- [ ] extent
- [ ] extinction
- [ ] extreme
- [ ] eyewitness
- [ ] facility
- [ ] faculty
- [ ] fade

# Chapter 016

- [ ] fatal
- [ ] fatigue
- [ ] favor
- [ ] fearlessly
- [ ] fierce
- [ ] figure
- [ ] fiscal
- [ ] flat
- [ ] flavor
- [ ] flaw
- [ ] flee
- [ ] flexible
- [ ] float
- [ ] footnote
- [ ] forecast
- [ ] format
- [ ] formidable
- [ ] foster
- [ ] foundation
- [ ] frankly

# Chapter 017

- [ ] frantic
- [ ] fresh
- [ ] frighten
- [ ] frontier
- [ ] frustrate
- [ ] fulfill
- [ ] furious
- [ ] fuss
- [ ] gallery
- [ ] gap
- [ ] garage
- [ ] gender
- [ ] generate
- [ ] generous
- [ ] genetic
- [ ] genius
- [ ] genuine
- [ ] geology
- [ ] gesture
- [ ] glamorous

# Chapter 018

- [ ] glory
- [ ] govern
- [ ] grand
- [ ] grasp
- [ ] gratitude
- [ ] grocery
- [ ] guarantee
- [ ] guard
- [ ] guesstimate
- [ ] habitual
- [ ] handgun
- [ ] handle
- [ ] hardship
- [ ] harsh
- [ ] hatch
- [ ] hazard
- [ ] hesitate
- [ ] hinder
- [ ] hospitality
- [ ] host

# Chapter 019

- [ ] hostile
- [ ] household
- [ ] humanistic
- [ ] humorous
- [ ] hypothesis
- [ ] identify
- [ ] ideologically
- [ ] ideology
- [ ] ignore
- [ ] imbalance
- [ ] immense
- [ ] immensely
- [ ] immigrant
- [ ] imminent
- [ ] impact
- [ ] impose
- [ ] imprison
- [ ] inadequate
- [ ] incentive
- [ ] incidence

# Chapter 020

- [ ] incompetence
- [ ] index
- [ ] indicate
- [ ] indicative
- [ ] indifferent
- [ ] indiscriminately
- [ ] indispensable
- [ ] indulge
- [ ] industrious
- [ ] ineffective
- [ ] inevitable
- [ ] inexhaustible
- [ ] infant
- [ ] infect
- [ ] inflation
- [ ] influential
- [ ] inhale
- [ ] inherit
- [ ] initiative
- [ ] injustice

# Chapter 021

- [ ] innovation
- [ ] inspire
- [ ] instant
- [ ] instinctively
- [ ] institution
- [ ] insufficient
- [ ] integrity
- [ ] intelligent
- [ ] intensely
- [ ] interact
- [ ] interaction
- [ ] interference
- [ ] interpretation
- [ ] interracial
- [ ] intervene
- [ ] intervention
- [ ] intriguing
- [ ] invasion
- [ ] irony
- [ ] irrelevant

# Chapter 022

- [ ] irritate
- [ ] isolation
- [ ] judicial
- [ ] jury
- [ ] justifiable
- [ ] justified
- [ ] keen
- [ ] kidnap
- [ ] lack
- [ ] lag
- [ ] launch
- [ ] lawn
- [ ] layman
- [ ] layout
- [ ] legend
- [ ] legislation
- [ ] legislator
- [ ] lest
- [ ] lobby
- [ ] luxurious

# Chapter 023

- [ ] magnify
- [ ] maintenance
- [ ] majority
- [ ] mall
- [ ] manifest
- [ ] manufacture
- [ ] marine
- [ ] markedly
- [ ] mask
- [ ] material
- [ ] materialize
- [ ] matter
- [ ] maturity
- [ ] measure
- [ ] mechanism
- [ ] melt
- [ ] memo
- [ ] memorable
- [ ] mention
- [ ] merit

# Chapter 024

- [ ] migrate
- [ ] milestone
- [ ] minimal
- [ ] mining
- [ ] minor
- [ ] minority
- [ ] miracle
- [ ] misfortune
- [ ] misinterpret
- [ ] mobility
- [ ] modernize
- [ ] moist
- [ ] monopoly
- [ ] mortality
- [ ] motel
- [ ] motivation
- [ ] mount
- [ ] mourn
- [ ] municipal
- [ ] narrow

# Chapter 025

- [ ] necessity
- [ ] needy
- [ ] neglect
- [ ] negotiation
- [ ] neighborhood
- [ ] neutrality
- [ ] nightmare
- [ ] nominate
- [ ] notion
- [ ] numerous
- [ ] nutritious
- [ ] obesity
- [ ] objective
- [ ] oblige
- [ ] obstacle
- [ ] occur
- [ ] offense
- [ ] oppose
- [ ] opposition
- [ ] optimistic

# Chapter 026

- [ ] organic
- [ ] orient
- [ ] outcome
- [ ] outdated
- [ ] outlive
- [ ] outnumber
- [ ] outsource
- [ ] outweigh
- [ ] overcharge
- [ ] overexcited
- [ ] overwhelm
- [ ] owe
- [ ] owl
- [ ] panic
- [ ] paradise
- [ ] paralyze
- [ ] pasture
- [ ] pattern
- [ ] pause
- [ ] pave

# Chapter 027

- [ ] payroll
- [ ] peculiar
- [ ] penalty
- [ ] pension
- [ ] perish
- [ ] perspective
- [ ] pessimist
- [ ] phenomenon
- [ ] philosopher
- [ ] plot
- [ ] poetry
- [ ] polar
- [ ] poll
- [ ] ponder
- [ ] portion
- [ ] pose
- [ ] position
- [ ] possession
- [ ] potential
- [ ] potentially

# Chapter 028

- [ ] practical
- [ ] precedent
- [ ] precision
- [ ] predict
- [ ] predominantly
- [ ] preference
- [ ] preindustrial
- [ ] prejudice
- [ ] premium
- [ ] prescribe
- [ ] present
- [ ] presentation
- [ ] presidency
- [ ] prestige
- [ ] previous
- [ ] priceless
- [ ] primitive
- [ ] principle
- [ ] prior
- [ ] private

# Chapter 029

- [ ] procedure
- [ ] productivity
- [ ] profitable
- [ ] profound
- [ ] prolonged
- [ ] promote
- [ ] promotion
- [ ] prompt
- [ ] property
- [ ] propose
- [ ] prospect
- [ ] prosperity
- [ ] publicity
- [ ] publicize
- [ ] purchase
- [ ] pursue
- [ ] puzzling
- [ ] quantifiable
- [ ] qualification
- [ ] qualify

# Chapter 030

- [ ] quantity
- [ ] quicken
- [ ] quota
- [ ] quote
- [ ] rally
- [ ] randomly
- [ ] rank
- [ ] rape
- [ ] rare
- [ ] rate
- [ ] realm
- [ ] reap
- [ ] recall
- [ ] receipt
- [ ] reception
- [ ] recipe
- [ ] reckless
- [ ] reckon
- [ ] reconcile
- [ ] recruit

# Chapter 031

- [ ] recurrence
- [ ] reflect
- [ ] reflective
- [ ] refreshing
- [ ] regain
- [ ] registration
- [ ] regulation
- [ ] reimbursement
- [ ] reinforce
- [ ] release
- [ ] relevant
- [ ] reliable
- [ ] relieve
- [ ] relieved
- [ ] reluctance
- [ ] remarkable
- [ ] remove
- [ ] replacement
- [ ] representative
- [ ] reproduction

# Chapter 032

- [ ] reservation
- [ ] resident
- [ ] resign
- [ ] resist
- [ ] resolute
- [ ] resort
- [ ] respective
- [ ] responsibility
- [ ] responsive
- [ ] restrict
- [ ] resume
- [ ] retailer
- [ ] reunion
- [ ] reveal
- [ ] revenue
- [ ] reverse
- [ ] revive
- [ ] revolutionize
- [ ] rewarding
- [ ] ridiculous

# Chapter 033

- [ ] rigorous
- [ ] ritual
- [ ] robbery
- [ ] romantic
- [ ] ruin
- [ ] rustle
- [ ] sample
- [ ] scandal
- [ ] scarcity
- [ ] scare
- [ ] scent
- [ ] schedule
- [ ] sculpture
- [ ] sector
- [ ] sensible
- [ ] server
- [ ] session
- [ ] severity
- [ ] sexism
- [ ] shade

# Chapter 034

- [ ] shady
- [ ] shareholder
- [ ] shed
- [ ] sheer
- [ ] shepherd
- [ ] shift
- [ ] shot
- [ ] shrewd
- [ ] shrink
- [ ] shrug
- [ ] shuttle
- [ ] signal
- [ ] significant
- [ ] signify
- [ ] simultaneous
- [ ] skeptical
- [ ] skip
- [ ] skyrocket
- [ ] skyscraper
- [ ] slack

# Chapter 035

- [ ] slash
- [ ] slight
- [ ] slim
- [ ] smuggle
- [ ] solid
- [ ] solution
- [ ] soothe
- [ ] sophisticated
- [ ] spacious
- [ ] specialist
- [ ] species
- [ ] specific
- [ ] specification
- [ ] spectacle
- [ ] sponsor
- [ ] spot
- [ ] spread
- [ ] squalor
- [ ] standardize
- [ ] startle

# Chapter 036

- [ ] steady
- [ ] stereotype
- [ ] stimulate
- [ ] stockbroker
- [ ] stove
- [ ] straightforward
- [ ] strain
- [ ] strategy
- [ ] stray
- [ ] stress
- [ ] strike
- [ ] strip
- [ ] stuff
- [ ] submerge
- [ ] submit
- [ ] subsidy
- [ ] substance
- [ ] subtle
- [ ] suburban
- [ ] supervisor

# Chapter 037

- [ ] surgical
- [ ] suspect
- [ ] suspicious
- [ ] sway
- [ ] switch
- [ ] sympathetic
- [ ] symptom
- [ ] tackle
- [ ] tangled
- [ ] tank
- [ ] temptation
- [ ] testify
- [ ] testimony
- [ ] texture
- [ ] therapy
- [ ] threat
- [ ] threaten
- [ ] threshold
- [ ] tough
- [ ] trace

# Chapter 038

- [ ] track
- [ ] tragedy
- [ ] trap
- [ ] trend
- [ ] trigger
- [ ] tropical
- [ ] tuition
- [ ] turbulence
- [ ] turtle
- [ ] tutor
- [ ] twist
- [ ] typical
- [ ] uncertain
- [ ] undecided
- [ ] underestimate
- [ ] underfunded
- [ ] underlying
- [ ] undertake
- [ ] undertaking
- [ ] undocumented

# Chapter 039

- [ ] unethical
- [ ] uneven
- [ ] unexpected
- [ ] unified
- [ ] unprecedented
- [ ] unrealistic
- [ ] unstable
- [ ] untiring
- [ ] untrustworthy
- [ ] urban
- [ ] urbanization
- [ ] urge
- [ ] urgent
- [ ] utilization
- [ ] validity
- [ ] variation
- [ ] vary
- [ ] vegetarian
- [ ] vehicle
- [ ] vessel

# Chapter 040

- [ ] victim
- [ ] view
- [ ] viewpoint
- [ ] violation
- [ ] violent
- [ ] virtual
- [ ] virtually
- [ ] virus
- [ ] vitamin
- [ ] vulnerable
- [ ] welfare
- [ ] widespread
- [ ] wildfire
- [ ] wildlife
- [ ] wishful
- [ ] wonder
- [ ] workload
- [ ] yield
- [ ] deposit
- [ ] receptionist

# Chapter 041

- [ ] particle
- [ ] furnish
- [ ] elaborately
- [ ] infectious
- [ ] diagnose
- [ ] cripple
- [ ] aggressive
- [ ] aptly
- [ ] assimilate
- [ ] consistent
- [ ] suspend
- [ ] ingenuity
- [ ] reserved
- [ ] unbiased
- [ ] disposal
- [ ] inferior
- [ ] stabilize
- [ ] fertility
- [ ] bleak
- [ ] soar

# Chapter 042

- [ ] optimism
- [ ] ambition
- [ ] pragmatic
- [ ] compromise
- [ ] perpetual
- [ ] dispensable
- [ ] assault
- [ ] transcend
- [ ] inherent
- [ ] baffle
- [ ] stain
- [ ] peer
- [ ] isolate
- [ ] abolition
- [ ] slavery
- [ ] script
- [ ] manuscript
- [ ] trait
- [ ] deviate
- [ ] overwhelming

# Chapter 043

- [ ] successively
- [ ] visualize
- [ ] underrepresented
- [ ] tap
- [ ] extinguish
- [ ] toxic
- [ ] postdoctoral
- [ ] recommend
- [ ] consultation
- [ ] determine
- [ ] confidential
- [ ] curriculum
- [ ] cafeteria
- [ ] trim
- [ ] expel
- [ ] refine
- [ ] suicide
- [ ] manual
- [ ] alphabetical
- [ ] bloom

# Chapter 044

- [ ] fertilizer
- [ ] plough
- [ ] affiliate
- [ ] hazardous
- [ ] instantaneous
- [ ] intrinsic
- [ ] paradox
- [ ] grateful
- [ ] modify
- [ ] consent
- [ ] intuitive
- [ ] scaffolding
- [ ] outperform
- [ ] discern
- [ ] lawsuit
- [ ] ruling
- [ ] designate
- [ ] endorsement
- [ ] tasteless
- [ ] brilliant

# Chapter 045

- [ ] fabric
- [ ] vocational
- [ ] carpentry
- [ ] ventilate
- [ ] embody
- [ ] tedious
- [ ] deduction
- [ ] fluctuate
- [ ] simultaneously
- [ ] craft
- [ ] facilitate
- [ ] deteriorate
- [ ] hasten
- [ ] specialize
- [ ] liberation
- [ ] pursuit
- [ ] bemoan
- [ ] evolve
- [ ] fluently
- [ ] composition

# Chapter 046

- [ ] literal
- [ ] honorary
- [ ] hurl
- [ ] confer
- [ ] notoriously
- [ ] validation
- [ ] jeopardize
- [ ] allegedly
- [ ] vigorous
- [ ] fake
- [ ] contestant
- [ ] column
- [ ] hasty
- [ ] linger
- [ ] inheritance
- [ ] worldly
- [ ] dimension
- [ ] eligible
- [ ] permanent
- [ ] memorize

# Chapter 047

- [ ] evaluation
- [ ] literacy
- [ ] enviable
- [ ] bipartisan
- [ ] amend
- [ ] interpret
- [ ] access
- [ ] champion
- [ ] navigate
- [ ] intertwine
- [ ] collaborate
- [ ] evaluate
- [ ] domain
- [ ] accumulate
- [ ] persistent
- [ ] boast
- [ ] assume
- [ ] forthcoming
- [ ] mysteriously
- [ ] spoil

# Chapter 048

- [ ] complement
- [ ] immersive
- [ ] cognitive
- [ ] rhetorical
- [ ] impair
- [ ] competent
- [ ] undermine
- [ ] incompatibility
- [ ] superficial
- [ ] endanger
- [ ] practice
- [ ] decode
- [ ] immigration
- [ ] inescapable
- [ ] utterly
- [ ] inanimate
- [ ] irreversible
- [ ] incalculable
- [ ] bump
- [ ] demonstration

# Chapter 049

- [ ] desert
- [ ] jail
- [ ] cozy
- [ ] lounge
- [ ] worship
- [ ] seasick
- [ ] interfere
- [ ] tension
- [ ] transition
- [ ] accidentally
- [ ] exertion
- [ ] impart
- [ ] provoke
- [ ] assumption
- [ ] formula
- [ ] overlap
- [ ] thrive
- [ ] chronic
- [ ] adversity
- [ ] endure

# Chapter 050

- [ ] assert
- [ ] chew
- [ ] tradeoff
- [ ] commentator
- [ ] vice
- [ ] attribute
- [ ] vivid
- [ ] upgrade
- [ ] prospective
- [ ] regime
- [ ] appeal
- [ ] weave
- [ ] sew
- [ ] nap
- [ ] row
- [ ] helicopter
- [ ] conquer
- [ ] memorandum
- [ ] clarity
- [ ] carpenter

# Chapter 051

- [ ] drummer
- [ ] discrimination
- [ ] uninformed
- [ ] entitle
- [ ] imitate
- [ ] subordinate
- [ ] suppress
- [ ] throne
- [ ] athletics
- [ ] coach
- [ ] biodiversity
- [ ] accommodate
- [ ] ultimate
- [ ] invasive
- [ ] underscore
- [ ] ongoing
- [ ] greedy
- [ ] lessen
- [ ] incur
- [ ] integral

# Chapter 052

- [ ] merge
- [ ] unintentionally
- [ ] grave
- [ ] intimate
- [ ] alleviate
- [ ] conspicuous
- [ ] territory
- [ ] displace
- [ ] regardless
- [ ] duplication
- [ ] overturn
- [ ] identical
- [ ] miniature
- [ ] tempting
- [ ] segregation
- [ ] variance
- [ ] inaction
- [ ] conserve
- [ ] renewable
- [ ] embrace

# Chapter 053

- [ ] counterpart
- [ ] rival
- [ ] intense
- [ ] aspirational
- [ ] transform
- [ ] grip
- [ ] unfold
- [ ] ideological
- [ ] filter
- [ ] pronoun
- [ ] philosophy
- [ ] illuminate
- [ ] odds
- [ ] confess
- [ ] manipulate
- [ ] rhythm
- [ ] hijack
- [ ] sweep
- [ ] withdraw
- [ ] flame

# Chapter 054

- [ ] spark
- [ ] feasibility
- [ ] fascinate
- [ ] crew
- [ ] cumulative
- [ ] awkward
- [ ] obscurity
- [ ] badge
- [ ] distinction
- [ ] formulate
- [ ] monetary
- [ ] portray
- [ ] hostility
- [ ] robust
- [ ] appropriation
- [ ] deforestation
- [ ] puzzle
- [ ] migration
- [ ] constrain
- [ ] sneak

# Chapter 055

- [ ] margin
- [ ] division
- [ ] privilege
- [ ] imperial
- [ ] justice
- [ ] opponent
- [ ] crush
- [ ] harness
- [ ] monopolize
- [ ] tremendous
- [ ] vital
- [ ] imperative
- [ ] initial
- [ ] distract
- [ ] convincing
- [ ] consult
- [ ] agony
- [ ] refrain
- [ ] thrilling
- [ ] prematurely

# Chapter 056

- [ ] conscientious
- [ ] entail
- [ ] forge
- [ ] overstate
- [ ] accountable
- [ ] pessimistic
- [ ] subsequently
- [ ] hack
- [ ] liability
- [ ] conversion
- [ ] needle
- [ ] deterioration
- [ ] fault
- [ ] relay
- [ ] shrank
- [ ] transmit
- [ ] incidentally
- [ ] notably
- [ ] worldwide
- [ ] rigor

# Chapter 057

- [ ] readjust
- [ ] prolong
- [ ] redefine
- [ ] controversial
- [ ] degeneration
- [ ] malicious
- [ ] widen
- [ ] density
- [ ] metropolitan
- [ ] prominent
- [ ] prevalence
- [ ] compact
- [ ] correlation
- [ ] simulate
- [ ] momentum
- [ ] fixture
- [ ] proposition
- [ ] dynamics
- [ ] descent
- [ ] affiliation

# Chapter 058

- [ ] perception
- [ ] permeate
- [ ] recruiter
- [ ] dilute
- [ ] prioritize
- [ ] privileged
- [ ] landmark
- [ ] extracurricular
- [ ] deprivation
- [ ] cater
- [ ] pierce
- [ ] surpass
- [ ] target
- [ ] ready
- [ ] alternatively
- [ ] chronically
- [ ] frame
- [ ] mournful
- [ ] cultivate
- [ ] cornerstone

# Chapter 059

- [ ] legalize
- [ ] rigid
- [ ] certify
- [ ] orbit
- [ ] astronomical
- [ ] Automatically
- [ ] existence
- [ ] intolerant
- [ ] occupation
- [ ] slightly
- [ ] exploit
- [ ] regarding
- [ ] ecosystem
- [ ] noted
- [ ] incorporate
- [ ] interactive
- [ ] novel
- [ ] mismanagement
- [ ] irrational
- [ ] groundless

# Chapter 060

- [ ] restructure
- [ ] stimulus
- [ ] feasible
- [ ] adaptation
- [ ] institute
- [ ] biochemistry
- [ ] entrepreneur
- [ ] arise
- [ ] ascend
- [ ] combination
- [ ] definite
- [ ] preserve
- [ ] program
- [ ] proximately
- [ ] lobbyist
- [ ] redundant
- [ ] insurer
- [ ] overestimate
- [ ] cropland
- [ ] irrigation

# Chapter 061

- [ ] contaminate
- [ ] untreated
- [ ] sanitation
- [ ] echo
- [ ] duplicate
- [ ] elevate
- [ ] illustrate
- [ ] inquire
- [ ] prevail
- [ ] strap
- [ ] turbulent
- [ ] rebellion
- [ ] lofty
- [ ] render
- [ ] recyclable
- [ ] trick
- [ ] certification
- [ ] prevailing
- [ ] misled
- [ ] elimination

# Chapter 062

- [ ] unqualified
- [ ] subconscious
- [ ] incompetent
- [ ] discriminate
- [ ] elegant
- [ ] gown
- [ ] bride
- [ ] costume
